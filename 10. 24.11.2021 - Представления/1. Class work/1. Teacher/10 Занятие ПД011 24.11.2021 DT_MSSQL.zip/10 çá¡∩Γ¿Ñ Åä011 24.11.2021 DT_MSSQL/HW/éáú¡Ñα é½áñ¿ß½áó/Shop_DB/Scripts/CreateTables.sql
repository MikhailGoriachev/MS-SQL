﻿
-- Удаление всех таблиц
drop table if exists Sales;
drop table if exists Purchases;
drop table if exists Sellers;
drop table if exists Goods;
drop table if exists Units;

--drop table if exists 
--drop table if exists 

-- Таблица едениц измерения 
create table dbo.Units (
	Id          int not null primary key identity (1, 1), 
	Short nvarchar(8) not null,
	Long nvarchar(25) not null,
);
go	

-- Таблица общего списка товаров 
create table dbo.Goods (
	Id        int not null primary key identity (1, 1), 
	Good_name nvarchar(60)  not null,
);
go	

-- Таблица закупки товара
create table dbo.Purchases (
	Id             int not null primary key identity (1, 1), 
	IdGood         int   not null,
	IdUnit         int  not null,
	Purchase_price int  not null, 
	Amount         int  not null,
	DatePurchase   Date not null,

	-- Ограничения 
	constraint CK_Purchase_Amount check(Amount > 0),
	constraint FK_Purchases_Goods    foreign key (IdGood) references dbo.Goods (Id) ,
	constraint FK_Purchases_Units    foreign key (IdUnit) references dbo.Units (Id)
);
go	

-- Таблица продавцов магазина
create table dbo.Sellers (
	Id          int not null primary key identity (1, 1), 
	Surname     nvarchar(60) not null, -- Фамилия продавца
	Name_s      nvarchar(50) not null, -- Имя продавца
	Patronymic  nvarchar(60) not null, -- Отчество продавца
	Interest    float        not null, -- Процент от продажи

	--Ограничния 
	constraint CK_Selleres_Interest check (Interest > 0)
);
go

-- Итоговая таблица продаж 
create table dbo.Sales (
	Id          int not null primary key identity (1, 1), 
	DateSale   date not null, -- Дата совершения продажи
	IdSeller    int not null, -- Продавец
	IdPurchase  int not null, -- Закупленный товар 
	IdUnit      int not null, -- Еденица измерения 
	Amount      int not null, -- Кол-во проданного товара
	Price       int not null, -- Выходная стоимость товара 
	
-- Ограничения 
constraint CK_Sales_Amount check(Amount >= 0),
constraint CK_Sales_Price  check(Price >= 0),


-- Связи с другими таблицами
	constraint FK_Sales_Seller   foreign key (IdSeller)   references dbo.Sellers   (Id) ,
	constraint FK_Sales_Purchases foreign key (IdPurchase) references dbo.Purchases  (Id),
	constraint FK_Sales_Unit     foreign key (IdUnit)     references dbo.Units     (Id)
);
go


/*create table dbo. (
	Id          int not null primary key identity (1, 1), 
	Field not null,
);
go	

-- Связи с другими таблицами
	constraint FK_ _ foreign key (Id) references dbo. (Id) ,
	constraint FK_ _    foreign key (Id)    references dbo.  (Id)
*/