﻿/*
Размер ознаграждения равен = Цена продажи единицы товара * Кол-во проданных единиц товара * Процент комиссионных продавца.
Прибыль от продажи партии товара = (Цена продажи единицы товара - Цена закупки единицы товара) * Кол-во проданных единиц товара
*/


-- Выборка из таблицы закупок 
Select 
  Goods.Good_name   
 ,Units.Short as units
 ,Purchases.Purchase_price as price
 ,Purchases.Amount 
 ,Purchases.DatePurchase as Bought
 from 
	Purchases join Goods on Purchases.IdGood = Goods.Id
			   join Units on Purchases.IdUnit = Units.Id

go

-- Выборка всех продавцов
select 
 Sellers.Surname + N' ' + SUBSTRING(Sellers.Name_s,1,1) + N'.' + SUBSTRING(Sellers.Patronymic,1,1) + N'.' as Seller
 ,Sellers.Interest*100 as interest 
from 
	Sellers

go

-- Выборка из таблицы продаж 
select 
 Goods.Good_name
,Purchases.Purchase_price as priceBought
,Purchases.DatePurchase as GoodBought
,U.Short as Units_sold
,Sellers.Surname + N'.' + SUBSTRING(Sellers.Name_s,1,1) + N'.' + SUBSTRING(Sellers.Patronymic,1,1) as Seller -- Сформировали ФИО продавца 
,Sales.Price as priceSold
,Sales.Amount as SoldAmount

from 
	Sales join (Purchases join Goods on Purchases.IdGood = Goods.Id 
						  join Units on Purchases.IdUnit = Units.Id) on Sales.IdPurchase = Purchases.Id
		  join Sellers on Sales.IdSeller = Sellers.Id
		  join Units as U on Sales.IdUnit = U.Id
order by 
	Sales.Amount

go
-- 001  Выбрать из таблицы ТОВАРЫ информацию о товарах, 
--      единицей измерения которых является «шт» (штуки) 
--      и цена закупки составляет меньше 200 руб.

Select 
	Goods.Good_name
	,Units.Short
	,Purchases.Purchase_price
from 
	Purchases join Goods on Purchases.IdGood = Goods.Id
			  join Units on Purchases.IdUnit = Units.Id
where 
	Purchases.Purchase_price < 20000 and Units.Short like N'шт%'

go

-- 002  Выбирает из таблицы ТОВАРЫ информацию о товарах, 
--      цена закупки которых больше 500 руб. за единицу товара

Select 
	Goods.Good_name
	,Purchases.Purchase_price/Purchases.Amount as Amount
	,Units.Short
from 
	Purchases join Goods on Purchases.IdGood = Goods.Id
			  join Units on Purchases.IdUnit = Units.Id
where 
	(Purchases.Purchase_price/Purchases.Amount) > 5000
go

-- 003  Выбирает из таблицы ТОВАРЫ информацию о товарах с заданным наименованием 
--      (например, «чехол защитный»), 
--      для которых цена закупки меньше 1800 руб.
declare @Name nvarchar(40) = N'Ремень%ГРМ%'
Select 
	Goods.Good_name
	,Purchases.Purchase_price
	,Units.Short
from 
	Purchases join Goods on Purchases.IdGood = Goods.Id
			  join Units on Purchases.IdUnit = Units.Id
where 
	Goods.Good_name Like @Name
go

-- 004  Выбирает из таблицы ПРОДАВЦЫ информацию о продавцах 
--      с заданным значением процента комиссионных. 
declare @Interest float = 0.09
select 
 Sellers.Surname + N' ' + SUBSTRING(Sellers.Name_s,1,1) + N'.' + SUBSTRING(Sellers.Patronymic,1,1) + N'.' as Seller
 ,Sellers.Interest*100 as interest 
from 
	Sellers
where 
	Sellers.Interest = @Interest
go

-- 005  Выбирает из таблиц ТОВАРЫ, ПРОДАВЦЫ и ПРОДАЖИ информацию обо всех зафиксированных фактах продажи товаров
--      (Наименование товара, Цена закупки, Цена продажи, дата продажи), 
--      для которых Цена продажи оказалась в некоторых заданных границах. 
declare @Lo int = 30000, @Hi int = 100000
Select 
    Goods.Good_name
   ,Purchases.Purchase_price as priceBought 
   ,Sales.Price as priceSold
   ,Purchases.DatePurchase as GoodBought
   ,Sales.DateSale
   ,Units.Short as Units_sold
from	
	Sales join (Purchases join Goods on Purchases.IdGood = Goods.Id
	                      join Units as U on Purchases.IdUnit = U.Id) on Sales.IdPurchase = Purchases.Id
		  join Units  on Purchases.IdUnit = Units.Id
where 
	Sales.Price between @Lo and @Hi 
go
	

-- 006   Вычисляет прибыль от продажи за каждый проданный товар. 
--       Включает поля Дата продажи, Наименование товара, 
--       Цена закупки, Цена продажи, Количество проданных единиц, Прибыль. 
--       Сортировка по полю Наименование товара
Select 
    Goods.Good_name
   ,Purchases.Purchase_price as priceBought 
   ,Sales.Price as priceSold
   ,Purchases.DatePurchase as GoodBought
   ,Sales.Amount as Amount
   ,U.Short as Units_sold
   ,(Sales.Price - Purchase_price)*Sales.Amount as Income
from	
	Sales join (Purchases join Goods on Purchases.IdGood = Goods.Id) on Sales.IdPurchase = Purchases.Id
		  join Units as U on Purchases.IdUnit = U.Id

go



-- 007 - запрос на левое соеденение:
--       Выбирает всех продавцов (выводить Код продавца, фамилию и инициалы продавца),
--       количество и суммы их продаж за заданный период, 
--       упорядочивать по фамилиям и инициалам 
declare @from date = '2021-09-02', @to date = '2021-10-29';
Select 
	 Sellers.Id
	,Sellers.Surname + N' ' + SUBSTRING(Sellers.Name_s,1,1) + N'.' + SUBSTRING(Sellers.Patronymic,1,1) + N'.' as Seller
	,COUNT(Sales.IdSeller) as Amount 
	,ISNULL(SUM(Sales.Price*Sales.Amount),0) as Summ
from 
	Sellers left join (select Sales.Price,Sales.DateSale, Sales.IdSeller, Sales.Amount from Sales where Sales.DateSale between @from and @to) as Sales on Sales.IdSeller = Sellers.Id 
group by 
	Sellers.Id,Sellers.Name_s,Sellers.Surname,Sellers.Patronymic
order by 
	Amount Desc
go

-- 008 - запрос на левое соеденение:
--       Выбирает все товары, количество и сумму продаж по этим товарам. 
--       Упорядочивать по убыванию суммы продаж
Select 
	Good.Good_name
	,ISNULL(SUM(Sales.Amount),0) as Sold_units       -- Подсчёт количества проданных едениц
	,ISNULL(SUM(Sales.Price*Sales.Amount),0) as Summ -- Общая сумма продаж
from 
	Goods as Good left join (Sales join (Purchases join Goods on Purchases.IdGood = Goods.Id) on Sales.IdPurchase = Purchases.Id) on Purchases.IdGood = Good.Id
group by
Good.Good_name
order by Sold_units desc

-- 009  Выполняет группировку по полю Наименование товара. 
--      Для каждого наименования вычисляет среднюю цену закупки товара, количество закупок

Select 
    Goods.Good_name
   ,AVG(Purchases.Purchase_price) as AveragePruchasePrice
   ,COUNT(Goods.Id) as Amount
from	
	Purchases join Goods on Purchases.IdGood = Goods.Id
group by 
	Goods.Good_name

order by 
	Amount Desc
go

-- 010  Выполняет группировку по полю Код продавца из таблицы ПРОДАЖИ. 
--      Для каждого продавца вычисляет среднее значение по полю Цена продажи единицы товара, количество продаж

Select 
    Sellers.Id
   ,Sellers.Surname + N' ' + SUBSTRING(Sellers.Name_s,1,1) + N'.' + SUBSTRING(Sellers.Patronymic,1,1) + N'.' as Seller
   ,AVG(Sales.Price) as AvgPrice
   ,ISNULL(SUM(Sales.Amount),0) as SumOdSales
from	
	Sales join Purchases  on Sales.IdPurchase = Purchases.Id
		  join Sellers on Sales.IdSeller = Sellers.Id
group by 
	Sellers.Id,Sellers.Name_s,Sellers.Surname,Sellers.Patronymic 
order by 
	AvgPrice desc
go

-- 011 - UNION
--      Тремя запросами к таблице ТОВАРЫ с объединением определить минимальную цену закупки единицы товара, 
--      среднюю цену закупки единицы товара, максимальную цену закупки единицы товара. 
--      Выводить текстовые названия значений 
select 
	N'Минимальная цена закупки' as KindOfPrice
	,MIN(Purchases.Purchase_price) as Price
from 
	Purchases join Goods on Purchases.IdGood = Goods.Id
	          join Units on Purchases.IdUnit = Units.Id
union 

Select 
	 N'Средняя цена закупки'
	,AVG(Purchases.Purchase_price)
from 
	Purchases

union 

Select 
	N'Максимальная цена закупки'
	,MAX(Purchases.Purchase_price)
from 
	Purchases
order by 
	Price asc


-- 012 - UNION
--      Двумя запросами с объединением к таблицам ТОВАРЫ, ПРОДАВЦЫ, ПРОДАЖИ выводить наименование товара и его количество, 
--      фамилии и инициалы продавцов и количество продаж

Select 
	 Goods.Good_name                 as GoodName 
	,N'Нет данных о продавцах' as Seller
	,N'Кол-во закупленного товара'   as Title
	,Purchases.Amount                as Amount
from 
	Purchases join Goods on Purchases.IdGood = Goods.Id

union all 

Select 
	 Goods.Good_name                 
	,Sellers.Surname + N' ' + SUBSTRING(Sellers.Name_s,1,1) + N'.' + SUBSTRING(Sellers.Patronymic,1,1) + N'.' 
	,N'Кол-во проданного товара'   
	,Purchases.Amount  
from 
	Sales join (Purchases join Goods on Purchases.IdGood = Goods.Id) on Sales.IdPurchase = Purchases.Id
		  join Sellers on Sales.IdSeller = Sellers.Id

-- 013  Создает таблицу ТОВАРЫ_ШТ, содержащую информацию о товарах, 
--      единицей измерения которых является «шт» (штуки)
drop table if exists Goods_pieces


Select 
Goods.Good_name

into Goods_pieces

from 
	Purchases join Goods on Purchases.IdGood = Goods.Id	
			  join Units on Purchases.IdUnit = Units.Id
where 
	Units.Short like N'шт%'
go

-- Демонстрация работы запроса 
Select 
	Goods_pieces.Good_name as Good_piece
	,(Select 
	  Units.Short 
	  from 
	  Purchases join Goods on Purchases.IdGood = Goods.Id 
	  		    join Units on Purchases.IdUnit = Units.Id
	  where 
	  	Goods.Good_name Like Goods_pieces.Good_name
	  group by 
		Units.Short

	  ) as Short
from 
	Goods_pieces
go

-- Выборка всех товаров в закупках
Select 
	Goods.Good_name
	,Units.Short
from 
	Purchases join Goods on Purchases.IdGood = Goods.Id
			  join Units on Purchases.IdUnit = Units.Id


-- 014  Создает копию таблицы ТОВАРЫ с именем КОПИЯ_ТОВАРЫ
drop table if exists Goods_COPY

Select 
Goods.Good_name

into Goods_COPY

from 
	Goods

-- Демонстрация результата 
Select 
Goods_COPY.Good_name

from 
	Goods_COPY
-- 015  Удаляет из таблицы КОПИЯ_ТОВАРЫ записи, 
--      в которых значение в поле Цена закупки единицы товара больше 500 руб.
--Демонстрация до удаления 
Select 
Goods_COPY.Good_name
,ISNULL((Select AVG(Purchases.Purchase_price)  -- Используем агрегатную функцию, поскольку в таблице закупок може быть более 1-й следственно
											   -- для подзапроса нужо получать скалярную переменную
		 from Purchases join Goods on Purchases.IdGood = Goods.Id 
		 group by Goods.Good_name 
		 having Goods.Good_name Like Goods_COPY.Good_name),0) as Purchase_price -- За счёт подзапроса создаём нечто похожее на левое соеденение
from 
	Goods_COPY
order by 
	Purchase_price desc
-- Удаление 
delete from
 Goods_COPY
 where 
 (Select AVG(Purchases.Purchase_price)  
		 from Purchases join Goods on Purchases.IdGood = Goods.Id 
		 group by Goods.Good_name 
		 having Goods.Good_name Like Goods_COPY.Good_name) > 50000

--Демонстрация после удаления 
Select 
Goods_COPY.Good_name
,ISNULL((Select AVG(Purchases.Purchase_price)  
		 from Purchases join Goods on Purchases.IdGood = Goods.Id 
		 group by Goods.Good_name 
		 having Goods.Good_name Like Goods_COPY.Good_name),0) as Purchase_price 
from 
	Goods_COPY
order by 
	Purchase_price desc

go
-- 016  Устанавливает значение в поле Процент комиссионных таблицы ПРОДАВЦЫ равным 10 % 
--      для тех продавцов, процент комиссионных которых составляет 8 %
	update 
     	Sellers
     set
     	Interest = 0.08
     where
     	Id = any (Select Sellers.Id from Sellers where Sellers.Interest = 0.1)
     go
   

--Вывод до изменения 
select 
 Sellers.Surname + N' ' + SUBSTRING(Sellers.Name_s,1,1) + N'.' + SUBSTRING(Sellers.Patronymic,1,1) + N'.' as Seller
 ,Sellers.Interest*100 as interest 
from 
	Sellers
order by
	Sellers.Interest desc

-- Изменения относительного вознаграждения
declare @Basic float = 0.08, @Update float = 0.1;
update 
	Sellers
set
	Interest = @Update
where
	Id = any (Select Sellers.Id from Sellers where Sellers.Interest = @Basic)

go

-- Вывод после изменения 
select 
 Sellers.Surname + N' ' + SUBSTRING(Sellers.Name_s,1,1) + N'.' + SUBSTRING(Sellers.Patronymic,1,1) + N'.' as Seller
 ,Sellers.Interest*100 as interest 
from 
	Sellers
order by
	Sellers.Interest desc
go

