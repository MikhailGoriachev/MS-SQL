﻿ -- ==================>  Создание таблиц  <==================

  -- удаление существующих таблиц, работает в MS SQL Server 2016+
drop table if exists Sales;
drop table if exists Purchases;
drop table if exists Sellers;
drop table if exists Units;
drop table if exists Goods; 
go

 

-- Создание таблицы "Товары" (Goods)
create table dbo.Goods(
	Id     int           not null primary key identity (1,1),
	[Name] nvarchar(50)  not null  -- наименование товара
);
go


-- Создание таблицы "Единица измерения товара" (Units)
create table dbo.Units(
	Id     int          not null  primary key identity(1,1),
	Short  nvarchar(8)  not null, -- сокращенное название единици измерения
	Long   nvarchar(30) not null  -- полное название единици измерения
);
go


-- Создание таблицы "Продавцы" (Sellers)
create table dbo.Sellers(
	Id         int          not null  primary key identity(1,1),
	Surname    nvarchar(60) not null, -- фамилия
	[Name]     nvarchar(50) not null, -- имя
	Patronymic nvarchar(60) not null, -- отчество
	Interest   float        not null, -- процент комисионных от продажи

	-- Ограничения процента комисионных
	constraint CK_Sellers_Interest check (Interest > 0)

);


-- Создание таблицы "Закупки" (Purchases)
create table dbo.Purchases(
	Id             int  not null  primary key identity(1,1),
	IdGood         int  not null,  -- Внешний ключ. Связь с таблицей товаров (Goods)
	IdUnit         int  not null,  -- Внешний ключ. Связь с таблицей единиц измерения (Units)
	PricePurchase  int  not null,  -- цена закупки единицы товара 
	Amount         int  not null,  -- количество единиц закупаемого товара
	DatePurchase   Date not null,  -- дата закупки товара
	
	-- Проверки полей таблицы
	constraint CK_Purchases_PricePurchase check (PricePurchase > 0),
	constraint CK_Purchases_Amount        check (Amount > 0),
	constraint CK_Purchases_DatePurchase  check (DatePurchase  >= '2019-01-01'),

	-- внешний ключ - связь М:1 к таблице Goods(товары)
	constraint FK_Purchases_Goods foreign key (IdGood) references dbo.Goods(Id),
	-- внешний ключ - связь М:1 к таблице Units(Единица измерения товара)
	constraint FK_Purchases_Units foreign key (IdUnit) references dbo.Units(Id)
);
go


-- Создание таблицы "Продажи" (Sales)
create table dbo.Sales(
	Id         int  not null  primary key identity(1,1),
	IdSeller   int  not null,   -- Внешний ключ. Связь с таблицей продавцов (Sellers)
	IdPurchase int  not null,   -- Внешний ключ. Связь с таблицей единиц измерения (Purchases)
	IdUnit     int  not null,	-- Внешний ключ. Связь с таблицей единиц измерения (Units)
	DateSell   Date not null,   -- дата продажи товара
	Amount     int  not null,   -- количество проданных единиц товара
	Price      int  not null,   -- цена продажи единицы товара

		-- Проверки полей таблицы
    constraint CK_Sales_DateSell check (DateSell >= '2019-01-01'),
    constraint CK_Sales_Amount   check (Amount > 0),
	constraint CK_Sales_Price    check (Price > 0),
	
	-- внешний ключ - связь М:1 к таблице Sellers(продавцы)
	constraint FK_Sales_Sellers foreign key (IdSeller) references dbo.Sellers(Id),
	-- внешний ключ - связь М:1 к таблице Purchases(закупки)
	constraint FK_Sales_Purchases foreign key (IdPurchase) references dbo.Purchases(Id),
	-- внешний ключ - связь М:1 к таблице Units(единица измерения товара)
	constraint FK_Sales_Units foreign key (IdUnit) references dbo.Units(Id)
);
go





