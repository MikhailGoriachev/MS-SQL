﻿-- Удаление таблиц созданных в ходе выполнения запросов 
drop table if exists Purchases_Piece;
drop table if exists Purchases_Copy;

--			-> Запрос №1 [ Запрос с параметром ] <-
-- Выбирает из таблицы ТОВАРЫ информацию о товарах, 
-- единицей измерения которых является «шт» (штуки) 
-- и цена закупки составляет меньше 200 руб.
declare @shUnit nvarchar(10) = N'шт.', @price int = 200;
select
	Purchases.Id
	,Goods.[Name]
	,Units.Short
	,Purchases.PricePurchase
	,Purchases.Amount
	,Purchases.DatePurchase
from
	Purchases join Goods on Purchases.IdGood = Goods.Id
			  join Units on Purchases.IdUnit = Units.Id
where
	Units.Short = @shUnit and Purchases.PricePurchase < @price;
go


--			-> Запрос №2 [ Запрос с параметром ] <-
-- Выбирает из таблицы ТОВАРЫ информацию о товарах, 
-- цена закупки которых больше 500 руб. за единицу товара
declare @price int = 500;
select
	Purchases.Id
	,Goods.[Name]
	,Units.Short
	,Purchases.PricePurchase
	,Purchases.Amount
	,Purchases.DatePurchase
from
	Purchases join Goods on Purchases.IdGood = Goods.Id
			  join Units on Purchases.IdUnit = Units.Id
where
	 Purchases.PricePurchase > @price;
go


--			-> Запрос №3 [ Запрос с параметром ] <-
-- Выбирает из таблицы ТОВАРЫ информацию о товарах 
-- с заданным наименованием (например, «чехол защитный»), 
-- для которых цена закупки меньше 1800 руб.
declare @price int = 1800, @name nvarchar(50) = N'Порошок стиральный автомат BiMax 100 пятен';
select
	Purchases.Id
	,Goods.[Name]
	,Units.Short
	,Purchases.PricePurchase
	,Purchases.Amount
	,Purchases.DatePurchase
from
	Purchases join Goods on Purchases.IdGood = Goods.Id
			  join Units on Purchases.IdUnit = Units.Id
where
	 Purchases.PricePurchase < @price and Goods.[Name] = @name;
go
 

--			-> Запрос №4 [ Запрос с параметром ] <-
-- Выбирает из таблицы ПРОДАВЦЫ информацию 
-- о продавцах с заданным значением процента комиссионных. 
declare @interest float = 5.5;
select
	 Sellers.Id
	,Sellers.Surname
	,Sellers.[Name] 
	,Sellers.Patronymic
	,Sellers.Interest
from
	Sellers
where
	Interest = @interest;
go


--			-> Запрос №5 [ Запрос с параметром ] <-
-- Выбирает из таблиц ТОВАРЫ, ПРОДАВЦЫ и ПРОДАЖИ 
-- информацию обо всех зафиксированных фактах продажи товаров 
-- (Наименование товара, Цена закупки, Цена продажи, дата продажи),
-- для которых Цена продажи оказалась в некоторых заданных границах. 
declare @loPrice int = 100, @hiPrice int = 250;
select
	Sales.Id
	,Goods.[Name]
	,Purchases.PricePurchase
	,Sales.Price
	,Sales.DateSell
from
	Sales join (Purchases join Goods on Purchases.IdGood = Goods.Id) 
				on Sales.IdPurchase = Purchases.Id
where
	Sales.Price between @loPrice and @hiPrice;
go


--			-> Запрос №6 [ Запрос с вычисляемыми полями ] <-
-- Вычисляет прибыль от продажи за каждый проданный товар. 
-- Включает поля Дата продажи, Наименование товара, Цена закупки,
-- Цена продажи, Количество проданных единиц, Прибыль.
-- Сортировка по полю Наименование товара
select
	Sales.Id
	,Goods.[Name]
	,Purchases.PricePurchase
	,Sales.Price
	,Sales.Amount  as SalesAmount
	,Sales.DateSell
	,(Sales.Price - Purchases.PricePurchase) * Sales.Amount  as profitSales 
from
	Sales join (Purchases join Goods on Purchases.IdGood = Goods.Id) 
				on Sales.IdPurchase = Purchases.Id;
go


--			-> Запрос №7 [ Запрос на левое соединение ] <-
-- Выбирает всех продавцов (выводить Код продавца(id), фамилию и инициалы продавца),
-- количество и суммы их продаж за заданный период, упорядочивать по фамилиям и инициалам 
declare @loDate Date = '2021-09-11', @hiDate Date = '2021-11-12';
select
	 Sellers.Id 
	,Sellers.Surname + N' ' + Substring(Sellers.[Name], 1, 1) + N'. ' + Substring(Sellers.Patronymic, 1, 1) + N'.' as Sellers
	,COUNT(TemporarySales.Price) as CountSellerSales
	,IsNull(SUM(TemporarySales.Price), 0) as SumSellerSales
from
	Sellers left join 
		-- готовим данные по условию, через подзапрос
			(select Sales.IdSeller, Sales.Price
				from (Sales join Sellers on Sales.IdSeller = Sellers.Id)) TemporarySales
		 on Sellers.Id = TemporarySales.IdSeller
group by
	Sellers.Id, 
	Sellers.Surname + N' ' + Substring(Sellers.[Name], 1, 1) + N'. ' + Substring(Sellers.Patronymic, 1, 1) + N'.' 
order by
	Sellers.Surname + N' ' + Substring(Sellers.[Name], 1, 1) + N'. ' + Substring(Sellers.Patronymic, 1, 1) + N'.';
go


--			-> Запрос №8 [ Запрос на левое соединение ] <-
-- Выбирает все товары, количество и сумму продаж по этим товарам. 
-- Упорядочивать по убыванию суммы продаж
select
	Goods.[Name]
	,COUNT(TemporarySales.Price)  as AmountSales
	,IsNull(SUM(TemporarySales.Price), 0)  as SumSales
from 
	Goods left join 
			(select Purchases.IdGood, Sales.Price from 
									(Sales join (Purchases join Goods on Purchases.IdGood = Goods.Id)
						on Sales.IdPurchase = Purchases.Id)) TemporarySales
					on Goods.Id = TemporarySales.IdGood  
group by 
	Goods.[Name]
order by
	SUM(TemporarySales.Price) desc;
go


--			-> Запрос №9 [ Итоговый запрос ] <-
-- Выполняет группировку по полю Наименование товара. 
-- Для каждого наименования вычисляет среднюю цену закупки товара, количество закупок
select 
	Goods.[Name]
	,COUNT(Purchases.IdGood)	    as Amount
	,AVG  (Purchases.PricePurchase) as AvgPricePurchase
from
	Purchases join Goods on Purchases.IdGood = Goods.Id
group by
	Goods.[Name];
go


--			-> Запрос №10 [ Итоговый запрос ] <-
-- Выполняет группировку по полю Код продавца из таблицы ПРОДАЖИ.
-- Для каждого продавца вычисляет среднее значение по полю 
-- Цена продажи единицы товара, количество продаж
select
-- "Код продавца из таблицы ПРОДАЖИ"
--   Sales.Id -> возможно имелось ввиду это, но тогда группировка безрезультатна 
	 Sellers.Id  
	,Sellers.Surname + N' ' + Substring(Sellers.[Name], 1, 1) + N'. ' + Substring(Sellers.Patronymic, 1, 1) + N'.' as Sellers
	,AVG(Sales.Price)  as AvgPriceSales
	,AVG(Sales.Amount) as AvgAmountSales
from
	Sales join Sellers on Sales.IdSeller = Sellers.Id
group by
	Sellers.Id, 
	Sellers.Surname + N' ' + Substring(Sellers.[Name], 1, 1) + N'. ' + Substring(Sellers.Patronymic, 1, 1) + N'.';
go



--			-> Запрос №11 [ Итоговый запрос с объединением ] <-
-- Тремя запросами к таблице ТОВАРЫ с объединением 
-- определить минимальную цену закупки единицы товара, 
-- среднюю цену закупки единицы товара, максимальную цену закупки единицы товара. 
-- Выводить текстовые названия значений 
select
	N'Минимальная цена закупки единицы товара:' as Title
	, MIN(PricePurchase) as MinPricePurchase
from
	Purchases

union all

select
	N'Средняя цена закупки единицы товара:' as Title
	, AVG(PricePurchase) as AvgPricePurchase
from
	Purchases

union all

select
	N'Максимальная цена закупки единицы товара:' as Title
	, MAX(PricePurchase) as MaxPricePurchase
from
	Purchases;
go



--			-> Запрос №12 [ Итоговый запрос с объединением ] <-
-- Двумя запросами с объединением к таблицам 
-- ТОВАРЫ, ПРОДАВЦЫ, ПРОДАЖИ выводить 
-- наименование товара и его количество,
-- фамилии и инициалы продавцов и количество продаж
select
	Goods.[Name]
	,Purchases.Amount
from
	Purchases join Goods on Purchases.IdGood = Goods.Id

union 

select
	Sellers.Surname + N' ' + SUBSTRING(Sellers.[Name],1,1) + N'. ' + SUBSTRING(Sellers.Patronymic,1,1) as Sellers
	,Sales.Amount
from
	Sales join Sellers on Sales.IdSeller = Sellers.Id;
go


--			-> Запрос №13 [ Запрос на создание базовой таблицы ] <-
-- Создает таблицу ТОВАРЫ_ШТ, содержащую информацию о товарах, 
-- единицей измерения которых является «шт» (штуки)
 
drop table if exists Purchases_Piece;

select
	*
	into Purchases_Piece
from
	Purchases 
where	
	Purchases.IdUnit in (select id from Units where Units.Short = N'шт.');
go


--			-> Запрос №14 [ Запрос на создание базовой таблицы ] <-
-- Создает копию таблицы ТОВАРЫ с именем КОПИЯ_ТОВАРЫ
  
drop table if exists Purchases_Copy;
 
select
	*
    into Purchases_Copy
from
	Purchases;
go


--			-> Запрос №15 [ Запрос на создание базовой таблицы ] <-
-- Удаляет из таблицы КОПИЯ_ТОВАРЫ записи,
-- в которых значение в поле Цена закупки единицы товара больше 500 руб.

--				Таблица до удаления
select
	Purchases_Copy.Id
	,Goods.[Name]
	,Units.Short
	,Purchases_Copy.PricePurchase
	,Purchases_Copy.Amount
	,Purchases_Copy.DatePurchase
from
	Purchases_Copy join Goods on Purchases_Copy.IdGood = Goods.Id
			       join Units on Purchases_Copy.IdUnit = Units.Id;
go

--		    	   Само удаление
declare @highPrice int = 500;
delete from 
	Purchases_Copy
where
	PricePurchase > @highPrice;
go

--				Таблица после удаления
select
	Purchases_Copy.Id
	,Goods.[Name]
	,Units.Short
	,Purchases_Copy.PricePurchase
	,Purchases_Copy.Amount
	,Purchases_Copy.DatePurchase
from
	Purchases_Copy join Goods on Purchases_Copy.IdGood = Goods.Id
				   join Units on Purchases_Copy.IdUnit = Units.Id;
go


--			-> Запрос №16 [ Запрос на создание базовой таблицы ] <-
-- Устанавливает значение в поле Процент комиссионных 
-- таблицы ПРОДАВЦЫ равным 10 % для тех продавцов, 
-- процент комиссионных которых составляет 8 %

--				Таблица до изменения
select
	Sellers.Surname + N' ' + SUBSTRING(Sellers.[Name],1,1) + N'. ' + SUBSTRING(Sellers.Patronymic,1,1) as Sellers
	,Sellers.Interest
from 
	Sellers;
go

--				Сам процесс изменения
declare @newInterest float = 10, @definitionInterest float = 8;
update
	Sellers
set
	Interest = @newInterest
where
	Interest = @definitionInterest;
go

--				Таблица после изменения
select
	Sellers.Surname + N' ' + SUBSTRING(Sellers.[Name],1,1) + N'. ' + SUBSTRING(Sellers.Patronymic,1,1) as Sellers
	,Sellers.Interest
from 
	Sellers;
go
