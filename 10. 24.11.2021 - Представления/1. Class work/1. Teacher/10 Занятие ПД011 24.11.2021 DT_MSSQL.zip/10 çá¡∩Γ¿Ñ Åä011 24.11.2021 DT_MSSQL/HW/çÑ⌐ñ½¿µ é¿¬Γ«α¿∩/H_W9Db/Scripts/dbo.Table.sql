﻿/*
База данных «Оптовый магазин. Учет продаж»

  База данных должна включать как минимум таблицы ТОВАРЫ,
  ПРОДАВЦЫ, ПРОДАЖИ, содержащие следующую информацию:
*  Наименование товара
*  Единица измерения товара
*  Цена закупки единицы товара
*  Дата продажи товара
*  Цена продажи единицы товара
*  Количество проданных единиц товара
*  Фамилия продавца, оформившего продажу
*  Имя продавца, оформившего продажу
*  Отчество продавца, оформившего продажу
*  Процент комиссионных продавца, оформившего продажу
*/

-- создание таблиц базы данных

-- при повторном запуске скрипта удаляем старые варианты таблиц, не разбирая пустые они или нет
-- таблицы удаляем в порядке, обратном порядку создания
drop table if exists Sales;
drop table if exists Purchases;
drop table if exists Sellers;
drop table if exists Units;
drop table if exists Goods;


-- таблица - наименование товара
CREATE TABLE [dbo].[Goods]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Name] NVARCHAR(50) NOT NULL
);
go


-- таблица - единица измерения товара
CREATE TABLE [dbo].[Units]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Short] NVARCHAR(10) NOT NULL, 
);
go


-- таблица - продавцы
CREATE TABLE [dbo].[Sellers]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Surname] NVARCHAR(50) NOT NULL, 
    [NameSeller] NVARCHAR(40) NOT NULL, 
    [Patronymic] NVARCHAR(60) NOT NULL, 
    [Interest] INT NOT NULL, 
    CONSTRAINT [CK_Sellers_Interest] CHECK (Interest between 1 and 20)
);
go


-- таблица - закупки товара
CREATE TABLE [dbo].[Purchases]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [IdGood] INT NOT NULL, 
    [IdUnit] INT NOT NULL, 
    [Amount] INT NOT NULL, 
    [PricePurchase] INT NOT NULL, 
    [DatePurchase] DATE NOT NULL, 
    CONSTRAINT [CK_Purchases_Amount] CHECK ([Amount] > 0), 
    CONSTRAINT [CK_Purchases_PricePurchase] CHECK ([PricePurchase] >= 0), 
    CONSTRAINT [FK_Purchases_Goods] FOREIGN KEY ([IdGood]) REFERENCES [Goods]([Id]), 
    CONSTRAINT [FK_Purchases_Units] FOREIGN KEY ([IdUnit]) REFERENCES [Units]([Id])
);
go


-- таблица - продажи товара
CREATE TABLE [dbo].[Sales]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [DateSale] DATE NOT NULL, 
    [IdSell] INT NOT NULL, 
    [IdPurchase] INT NOT NULL, 
    [AmountSale] INT NOT NULL, 
    [PriceSale] INT NOT NULL, 
    [IdUnit] INT NOT NULL, 
    CONSTRAINT [CK_Sales_AmountSale] CHECK ([AmountSale] >= 0), 
    CONSTRAINT [CK_Sales_PriceSale] CHECK ([PriceSale] >= 0), 
    CONSTRAINT [FK_Sales_Sellers] FOREIGN KEY ([IdSell]) REFERENCES [Sellers]([Id]), 
    CONSTRAINT [FK_Sales_Purchases] FOREIGN KEY ([IdPurchase]) REFERENCES [Purchases]([Id]), 
    CONSTRAINT [FK_Sales_Units] FOREIGN KEY ([IdUnit]) REFERENCES [Units]([Id])
);
go