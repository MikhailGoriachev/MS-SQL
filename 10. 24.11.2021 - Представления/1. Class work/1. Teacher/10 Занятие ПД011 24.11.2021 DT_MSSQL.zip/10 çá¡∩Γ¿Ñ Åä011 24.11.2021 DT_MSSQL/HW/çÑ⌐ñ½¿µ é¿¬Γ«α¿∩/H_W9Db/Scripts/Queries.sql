﻿-- База данных «Оптовый магазин. Учет продаж»

-- 1. Запрос с параметрами
-- Выбирает из таблицы ТОВАРЫ информацию о товарах,
-- единицей измерения которых является «шт» (штуки)
-- и цена закупки составляет меньше 100 руб.
declare @unit nvarchar(10) = N'шт.', @price int = 100;
select
   Goods.[Name]
   , Purchases.Amount
   , Units.Short
   , Purchases.PricePurchase
   , Purchases.DatePurchase
from
   Purchases join Goods on Purchases.IdGood = Goods.Id
             join Units on Purchases.IdUnit = Units.Id
where
   Units.Short = @unit and Purchases.PricePurchase < @price;
go


-- 2. Запрос с параметрами
-- Выбирает из таблицы ТОВАРЫ информацию о товарах,
-- цена закупки которых больше 140 руб. за единицу товара
declare @price int = 140;
select
   Goods.[Name]
   , Purchases.Amount
   , Units.Short
   , Purchases.PricePurchase
   , Purchases.DatePurchase
from
   Purchases join Goods on Purchases.IdGood = Goods.Id
             join Units on Purchases.IdUnit = Units.Id
where
   Purchases.PricePurchase > @price;
go


-- 3. Запрос с параметрами
-- Выбирает из таблицы ТОВАРЫ информацию о товарах с
-- заданным наименованием (например, «чехол защитный»),
-- для которых цена закупки меньше 200 руб
declare @name nvarchar(80) = N'Кофе NESCAFE %', @price int = 200;
select
   Goods.[Name]
   , Purchases.Amount
   , Units.Short
   , Purchases.PricePurchase
   , Purchases.DatePurchase
from
   Purchases join Goods on Purchases.IdGood = Goods.Id
             join Units on Purchases.IdUnit = Units.Id
where
   Goods.[Name] like @name and Purchases.PricePurchase < @price;
go


-- 4. Запрос с параметрами
-- Выбирает из таблицы ПРОДАВЦЫ информацию о продавцах с
-- заданным значением процента комиссионных.
declare @percent int = 4;
select
   *
from
   Sellers
where
   Sellers.Interest = @percent;
go


-- 5. Запрос с параметрами
-- Выбирает из таблиц ТОВАРЫ, ПРОДАВЦЫ и ПРОДАЖИ информацию
-- обо всех зафиксированных фактах продажи товаров
-- (Наименование товара, Цена закупки,
-- Цена продажи, дата продажи),
-- для которых Цена продажи оказалась в некоторых заданных границах.
declare @loPrice int = 150, @hiPrice int = 300;
select
   Goods.[Name]
   , Purchases.PricePurchase
   , Sales.PriceSale
   , Sales.DateSale
from
   Sales join(Purchases join Goods on Purchases.IdGood = Goods.Id)
          on Sales.IdPurchase = Purchases.Id
where
   Sales.PriceSale between @loPrice and @hiPrice
order by
   Goods.[Name];
go


-- 6. Запрос с вычисляемыми полями
-- Вычисляет прибыль от продажи за каждый проданный товар.
-- Включает поля Дата продажи, Наименование товара,
-- Цена закупки, Цена продажи, Количество проданных единиц, Прибыль.
-- Сортировка по полю Наименование товара
select
   Sales.DateSale
   , Goods.[Name]
   , Purchases.PricePurchase
   , Sales.PriceSale
   , Sales.AmountSale
   -- Прибыль от продажи партии товара вычисляется как
   -- (Цена продажи единицы товара - Цена закупки единицы товара) * Кол-во проданных единиц товара.
   , (Sales.AmountSale - Sales.PriceSale) * -Sales.AmountSale as Profit
from
      Sales join(Purchases join Goods on Purchases.IdGood = Goods.Id)
          on Sales.IdPurchase = Purchases.Id
order by
   Goods.[Name];
go


-- 7. Запрос на левое соединение
-- Выбирает всех продавцов 
-- (выводить Код продавца, фамилию и инициалы продавца),
-- количество и суммы их продаж за заданный период,
-- упорядочивать по фамилиям и инициалам
declare @loDate date = '11-01-2021', @hiDate date = '11-15-2021';
select
   Sellers.Id
   , Sellers.Surname + N' ' + Substring(Sellers.NameSeller, 1, 1) + N'.' + 
          Substring(Sellers.Patronymic, 1, 1) + N'.' as Seller
   , COUNT(Sales.IdSell) as Amount
   , IsNull(SUM(Sales.PriceSale * AmountSale),0) as SumSale
from
   Sellers left join Sales on Sellers.Id = Sales.IdSell
where
   Sales.DateSale between @loDate and @hiDate
group by
   Sellers.Id, Sellers.Surname, Sellers.NameSeller, Sellers.Patronymic
order by
   Seller;
go

   
-- 8. Запрос на левое соединение
-- Выбирает все товары, количество и сумму продаж по этим товарам.
-- Упорядочивать по убыванию суммы продаж
select
   Goods.[Name]
   , COUNT(Sales.AmountSale) as Amount
   , IsNull(SUM(Sales.PriceSale * AmountSale),0) as SumSale
from
    (Purchases join Goods on Purchases.IdGood = Goods.Id)
               left join 
         Sales on  Sales.IdPurchase = Purchases.Id 
group by
  Goods.[Name]
order by
   SumSale DESC;
go


-- 9. Итоговый запрос
-- Выполняет группировку по полю Наименование товара.
-- Для каждого наименования вычисляет среднюю цену закупки товара, количество закупок
select
   Goods.[Name]
   , COUNT(Purchases.Amount) as AmountPurchase
   , AVG(Purchases.PricePurchase) as AvgPricePurchase
from
   Purchases join Goods on Purchases.IdGood = Goods.Id
group by
  Goods.[Name]
order by
   AvgPricePurchase;
go


-- 10. Итоговый запрос
-- Выполняет группировку по полю Код продавца из таблицы ПРОДАЖИ.
-- Для каждого продавца вычисляет среднее значение по
-- полю Цена продажи единицы товара, количество продаж
select
  Sellers.Id
  , Sellers.Surname + N' ' + Substring(Sellers.NameSeller, 1, 1) + N'.' + 
                    Substring(Sellers.Patronymic, 1, 1) + N'.' as Seller
  , COUNT(Sales.AmountSale) as Amount
  , IsNull(AVG(Sales.PriceSale),0)  as AvgPriceSale
from
  Sellers left join Sales on Sellers.Id = Sales.IdSell
group by
  Sellers.Id, Sellers.Surname, Sellers.NameSeller, Sellers.Patronymic;
go


-- 11. Итоговый запрос с объединением
-- Тремя запросами к таблице ТОВАРЫ с объединением
-- определить минимальную цену закупки единицы товара,
-- среднюю цену закупки единицы товара,
-- максимальную цену закупки единицы товара.
-- Выводить текстовые названия значений
select
   N'Mинимальнaя цена закупки' as Title
   , MIN(Purchases.PricePurchase) as PricePurchase
from
  Purchases
   
union all

select
   N'Средняя цена закупки' as Title
   , AVG(Purchases.PricePurchase)
from
  Purchases

union all

select
   N'Максимальная цена закупки' as Title
   , MAX(Purchases.PricePurchase)
from
  Purchases
;
go


-- 12. Итоговый запрос с объединением
-- Двумя запросами с объединением к таблицам ТОВАРЫ,
-- ПРОДАВЦЫ, ПРОДАЖИ выводить наименование товара и его количество,
-- фамилии и инициалы продавцов и количество продаж
select
   Goods.[Name] as [Name]
   , N'Наименование товара' as [Name]
   , COUNT(Sales.AmountSale) as Amount
from
   Sales join(Purchases join Goods on Purchases.IdGood = Goods.Id)
          on Sales.IdPurchase = Purchases.Id
group by
  Goods.[Name]

union all

select
   Sellers.Surname + N' ' + Substring(Sellers.NameSeller, 1, 1) + N'.' + 
                    Substring(Sellers.Patronymic, 1, 1) + N'.' as Seller
  , N'ФИО продавцов' as [Name]
  , COUNT(Sales.AmountSale) as Amount
from
      Sales join Sellers on Sales.IdSell = Sellers.Id
group by
  Sellers.Surname, Sellers.NameSeller, Sellers.Patronymic;  
go 


-- 13. Запрос на создание базовой таблицы
-- Создает таблицу ТОВАРЫ_ШТ, содержащую информацию о товарах,
-- единицей измерения которых является «шт» (штуки)
select
   Goods.[Name]
   , Units.Short
into
   Goods_Pc
from
      Purchases join Goods on Purchases.IdGood = Goods.Id
                join Units on Purchases.IdUnit = Units.Id
where
   Units.Short = N'шт.';
go


-- 14. Запрос на создание базовой таблицы
-- Создает копию таблицы ТОВАРЫ с именем КОПИЯ_ТОВАРЫ
select
   Goods.[Name]
   , Units.Short
   , Purchases.Amount
   , Purchases.PricePurchase
into
   Copy_Goods
from
      Purchases join Goods on Purchases.IdGood = Goods.Id
                join Units on Purchases.IdUnit = Units.Id;
go


-- показать выбранные в таблицу Copy_Goods данные 
select * from Copy_Goods;
go

-- 15. Запрос на удаление
-- Удаляет из таблицы КОПИЯ_ТОВАРЫ записи,
-- в которых значение в поле Цена закупки единицы товара больше 130 руб.
delete from
   Copy_Goods
where
   Copy_Goods.PricePurchase > 130;
go


-- 16. Запрос на обновление
-- Устанавливает значение в поле Процент комиссионных
-- таблицы ПРОДАВЦЫ равным 10 % для тех продавцов,
-- процент комиссионных которых составляет 8 %
update
   Sellers
set
   Interest = 10
where
   Interest = 8;
go