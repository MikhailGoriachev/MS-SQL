﻿--1	Запрос с параметрами	
--Выбирает из таблицы ТОВАРЫ информацию о товарах, единицей измерения которых 
--является «шт» (штуки) и цена закупки составляет меньше 200 руб.
select
	Good
	,Units.Short
	,Cost
	,Amount
	,DateOfPurchase
from
	Purchases join Goods on Purchases.idGood = Goods.id
				join Units on Purchases.idUnit = Units.Id
where Purchases.Id in (select Purchases.Id from Purchases where idUnit = 
								(select Units.Id from Units where Short = N'шт')
						and Cost < 200);
--2	Запрос с параметрами	
--Выбирает из таблицы ТОВАРЫ информацию о товарах, цена закупки которых 
--больше 500 руб. за единицу товара
select
	Good
	,Units.Short
	,Cost
	,Amount
	,DateOfPurchase
from
	Purchases join Goods on Purchases.idGood = Goods.id
				join Units on Purchases.idUnit = Units.Id
where Purchases.Id in (select Purchases.Id from Purchases where Cost > 500);
--3	Запрос с параметрами	
--Выбирает из таблицы ТОВАРЫ информацию о товарах с заданным наименованием 
--(например, «чехол защитный»), для которых цена закупки меньше 1800 руб.
select
	Good
	,Units.Short
	,Cost
	,Amount
	,DateOfPurchase
from
	Purchases join Goods on Purchases.idGood = Goods.id
				join Units on Purchases.idUnit = Units.Id
where Purchases.Id in (select Purchases.Id from Purchases where idGood = 
								(select Goods.Id from Goods where Good = N'Бананы')
						and Cost < 1800);
--4	Запрос с параметрами	
--Выбирает из таблицы ПРОДАВЦЫ информацию о продавцах с заданным значением 
--процента комиссионных. 
select
	Surname
	,[Name]
	,Patronymic
	,Commission
from Sellers
where Commission in (select Commission from Sellers where Commission = 4)
--5	Запрос с параметрами	
--Выбирает из таблиц ТОВАРЫ, ПРОДАВЦЫ и ПРОДАЖИ информацию обо всех зафиксированных
--фактах продажи товаров (Наименование товара, Цена закупки, Цена продажи, дата продажи),
--для которых Цена продажи оказалась в некоторых заданных границах. 
select
	Good
	,Purchases.Cost
	,Sells.Price
	,Sells.DateOfSale
from Sells
		join (Purchases join Goods on Purchases.idGood = Goods.Id)
		on Sells.idPurchase = Purchases.Id
where
	Sells.Price in (select Price from Sells where Price between 100 and 500)

--6	Запрос с вычисляемыми полями	
--Вычисляет прибыль от продажи за каждый проданный товар. Включает поля 
--Дата продажи, Наименование товара, Цена закупки, Цена продажи, Количество 
--проданных единиц, Прибыль. Сортировка по полю Наименование товара
select
	Sells.DateOfSale
	,Good
	,Purchases.Cost
	,Sells.Price
	,Sells.Amount
	,(Sells.Price - Purchases.Cost) * Sells.Amount as Прибыль
	
from Sells
		join (Purchases join Goods on Purchases.idGood = Goods.Id)
		on Sells.idPurchase = Purchases.Id
order by Good
--7	Запрос на левое соединение	
--Выбирает всех продавцов (выводить Код продавца, фамилию и инициалы продавца),
--количество и суммы их продаж за заданный период, упорядочивать по фамилиям и инициалам 
select
	Sellers.Surname
	,SUM(Sells.Amount) as [Количетсво продаж]
	,SUM(Sells.Price)  as [Сумма продаж]
from Sellers left join Sells on Sellers.Id = Sells.idSeller
--where Sells.DateOfSale between '2021-11-01' and '2021-11-23'
group by Sellers.Surname
order by Sellers.Surname
	
--8	Запрос на левое соединение	
--Выбирает все товары, количество и сумму продаж по этим товарам. Упорядочивать 
--по убыванию суммы продаж
select
	Good
	,SUM(Sells.Amount)		as [Количетсво продаж]
	,SUM(Purchases.Cost)    as [Сумма продаж]
from Goods 
		left join (Purchases join Sells on Purchases.Id = Sells.idPurchase)
			on Goods.Id = Purchases.idGood
group by Good
--9	Итоговый запрос	
--Выполняет группировку по полю Наименование товара. Для каждого наименования 
--вычисляет среднюю цену закупки товара, количество закупок
select 
	Good
	,AVG(Purchases.Cost) as [Средняя цена закупки]
	,Sum(Purchases.Amount) as [Количество закупок]
from
	Purchases join Goods on Purchases.idGood = Goods.id
group by Good
--10	Итоговый запрос	
--Выполняет группировку по полю 
--Код продавца из таблицы ПРОДАЖИ. Для каждого 
--продавца вычисляет среднее значение по полю 
--Цена продажи единицы товара, количество продаж
select
	Sells.idSeller
	,AVG(Sells.Price) as [Cредняя цена продажи единицы товара]
	,Sum(Sells.Amount) as [Количество продаж]
from Sells
group by Sells.idSeller

--11	Итоговый запрос с объединением	
--Тремя запросами к таблице ТОВАРЫ с объединением определить минимальную 
--цену закупки единицы товара, среднюю цену закупки единицы товара, 
--максимальную цену закупки единицы товара. Выводить текстовые названия значений 
select
	N'Минимальная цена закупки единицы товара' as Title
	,MIN(Purchases.Cost)					   as Value
from Purchases
union
select
	N'Средняя цена закупки единицы товара'
	,AVG(Purchases.Cost)
from Purchases
union
select
	N'Максимальная цена закупки единицы товара'
	,MAX(Purchases.Cost)
from Purchases
--12	Итоговый запрос с объединением	
--Двумя запросами с объединением к таблицам ТОВАРЫ, ПРОДАВЦЫ, ПРОДАЖИ 
--выводить наименование товара и его количество, фамилии и инициалы 
--продавцов и количество продаж
select
	N'Товар' as [Type]
	,Good    as [Value]
	, Purchases.Amount
from Purchases 
				join Goods on Purchases.idGood = Goods.Id

union

select
	N'Продавец'
	,Sellers.Surname + ' ' + SUBSTRING(Sellers.[Name],1,1) + N'.' +  + Substring(Sellers.Patronymic,1,1)
	,Sells.Amount
from Sells
		join Sellers on Sells.idSeller = Sellers.Id
order by [Type] desc
--13	Запрос на создание базовой таблицы	
--Создает таблицу ТОВАРЫ_ШТ, содержащую информацию о товарах, единицей 
--измерения которых является «шт» (штуки)
drop table if exists Goods_Short; 
select
    *
    into Goods_Short
from
    Purchases
where idUnit = (select Units.Id from Units where Short = N'шт')
--14	Запрос на создание базовой таблицы	
--Создает копию таблицы ТОВАРЫ с именем КОПИЯ_ТОВАРЫ
drop table if exists Goods_Copy; 
select
    *
    into Goods_Copy
from
    Goods
--15	Запрос на удаление	
--Удаляет из таблицы КОПИЯ_ТОВАРЫ записи, в которых значение в поле 
--Цена закупки единицы товара больше 500 руб.

--16	Запрос на обновление
--Устанавливает значение в поле Процент комиссионных таблицы ПРОДАВЦЫ 
--равным 10 % для тех продавцов, процент комиссионных которых составляет 8 %
update Sellers
set Sellers.Commission = 10
where Sellers.Commission in (select Commission from Sellers where Commission = 8)
