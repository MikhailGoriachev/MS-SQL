﻿drop table if exists Sells
drop table if exists Purchases
drop table if exists Sellers
drop table if exists Goods
drop table if exists Units

--создание таблицы Единица измерения товара
CREATE TABLE [dbo].Units
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    Short NVARCHAR(10) NOT NULL,
    Long NVARCHAR(40) NOT NULL
)

go

--создание таблицы Товаров
CREATE TABLE [dbo].Goods
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    Good NVARCHAR(40) NOT NULL
)

go

--создание таблицы продавцов
CREATE TABLE [dbo].[Sellers]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Surname] NCHAR(40) NOT NULL, 
    [Name] NCHAR(40) NOT NULL, 
    [Patronymic] NCHAR(40) NOT NULL, 
    [Commission] INT NOT NULL, 
    CONSTRAINT [CK_Sellers_Commission] CHECK (Commission > 0), 
    
)

go


--создание таблицы Закупок
CREATE TABLE [dbo].[Purchases]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [idGood] INT NOT NULL, 
    [idUnit] INT NOT NULL, 
    [Cost]   INT NOT NULL,
    [Amount] INT NOT NULL,
    [DateOfPurchase] DATE NOT NULL,

    CONSTRAINT [CK_Purchases_idGood] CHECK ([idGood] > 0), 
    CONSTRAINT [CK_Purchases_idUnit] CHECK ([idUnit] > 0), 
    CONSTRAINT [CK_Purchases_Cost] CHECK ([Cost] > 1), 
    CONSTRAINT [CK_Purchases_Amount] CHECK ([Amount] > 1),

    CONSTRAINT [FK_Purchases_Good] FOREIGN KEY ([idGood]) REFERENCES Goods(id), 
    CONSTRAINT [FK_Purchases_Unit] FOREIGN KEY ([idUnit]) REFERENCES Units(id) 
)

go

--создание таблицы Продаж
CREATE TABLE [dbo].[Sells]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [DateOfSale] DATE NOT NULL, 
    [idSeller] INT NOT NULL, 
    [idPurchase] INT NOT NULL, 
    [idUnit] INT NOT NULL,
    [Amount] INT NOT NULL,
    [Price] INT NOT NULL,
    
    CONSTRAINT [CK_Sells_idSeller] CHECK ([idSeller] > 0), 
    CONSTRAINT [CK_Sells_idPurchase] CHECK ([idPurchase] > 0), 
    CONSTRAINT [CK_Sells_idUnit] CHECK ([idUnit] > 0), 
    CONSTRAINT [CK_Sells_Amount] CHECK ([Amount] > 0), 
    CONSTRAINT [CK_Sells_Price] CHECK ([Price] > 0), 



    CONSTRAINT [FK_Sells_Purchase] FOREIGN KEY ([idPurchase]) REFERENCES Purchases(id), 
    CONSTRAINT [FK_Sells_Seller] FOREIGN KEY ([idSeller]) REFERENCES Sellers(id),
    CONSTRAINT [FK_Sells_Unit] FOREIGN KEY ([idUnit]) REFERENCES Units(id) 
)

go