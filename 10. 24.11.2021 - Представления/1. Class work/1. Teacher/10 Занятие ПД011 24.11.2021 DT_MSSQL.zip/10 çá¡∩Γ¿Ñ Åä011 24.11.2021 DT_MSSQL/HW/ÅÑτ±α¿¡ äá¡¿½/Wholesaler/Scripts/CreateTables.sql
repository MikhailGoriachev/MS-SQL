﻿--База данных «Оптовый магазин. Учет продаж»

--Описание предметной области
--Оптовый магазин закупает товар по Цене закупки единицы товара и продает 
--товар по Цене продажи единицы товара. Разница между ценой продажи и ценой 
--закупки составляет прибыль магазина от реализации единицы товара.
--Каждый продавец получает комиссионное вознаграждение за проданный товар. 
--Размер этого вознаграждения равен: Цена продажи единицы товара * Кол-во проданных единиц товара * Процент комиссионных продавца.
--Прибыль от продажи партии товара вычисляется как 
--(Цена продажи единицы товара - Цена закупки единицы товара) * Кол-во проданных единиц товара.

drop table if exists Sales;
drop table if exists Purchases;
drop table if exists Sellers;
drop table if exists Goods;
drop table if exists Units;

--Таблица единиц измерения товаров 
create table dbo.Units 
(
   Id    int          not null primary key identity(1,1), 
   long  nvarchar(20) not null, 
   short nvarchar(20) not null, 
);
go

--Таблица наименования товаров
create table dbo.Goods 
(
    Id     int          not null primary key identity(1,1),
    [Name] nvarchar(60) not null, 
);
go

--Таблица данных о продавцах
create table dbo.Sellers 
(
     Id         int          not null primary key identity(1,1), 
     [Name]     nvarchar(60) not null, 
     Patronymic nvarchar(60) not null, 
     Surname    nvarchar(60) not null,
	 Interest   float        not null,
);
go

--Таблица данных о закупках 
create table dbo.Purchases 
(
     Id           int not null primary key identity(1,1), 
     IdGoods      int not null, 
     IdUnits      int not null, 
     Cost         int not null, 
     Amount       int not null, 
     DatePurchase date not null,  

     constraint FK_Purchases_Goods foreign key (IdGoods) references dbo.Goods(Id), 
     constraint FK_Purchases_Units foreign key (IdUnits) references dbo.Units(Id),

     constraint CK_Purchases_Cost check (Cost > 0),
	 constraint CK_Purchases_Amount check (Amount > 0),
);
go

--Таблица данных о продажах 
create table dbo.Sales 
(
       Id         int  not null primary key identity (1,1), 
       SaleDate   date not null, 
       IdSeller   int  not null,
       IdPurchase int  not null, 
       [Amount]   int  not null,
       [Price]    int  not null, 
       [IdUnit]   int  not null, 

       constraint FK_Sales_Sellers   foreign key (IdSeller)   references Sellers(id),
       constraint FK_Sales_Purchases foreign key (IdPurchase) references Purchases(id),

);
go
