﻿---- Запросы по заданию


--1. Выбирает из таблицы ТОВАРЫ информацию о товарах, единицей измерения которых является «шт» (штуки) 
--и цена закупки составляет меньше 200 руб.
declare @price int = 200, @unit nvarchar(20) = N'шт.';

select
  Goods.[Name]
  , Purchases.Amount
  , Purchases.DatePurchase
  ,Units.short

from
   Goods join (Purchases join Units on Purchases.IdUnits = Units.Id) on Goods.Id = Purchases.IdGoods
         
where Cost < @price and short = @unit 
    
--2. Выбирает из таблицы ТОВАРЫ информацию о товарах, цена закупки которых больше 500 руб. за единицу товара

declare @price int = 500; 

select 
 Goods.[Name]
 , Purchases.Amount
 , Purchases.DatePurchase

 from 
      Goods join (Purchases join Units on Purchases.IdUnits = Units.Id) on Goods.Id = Purchases.IdGoods

 where Cost > @price;
 go



