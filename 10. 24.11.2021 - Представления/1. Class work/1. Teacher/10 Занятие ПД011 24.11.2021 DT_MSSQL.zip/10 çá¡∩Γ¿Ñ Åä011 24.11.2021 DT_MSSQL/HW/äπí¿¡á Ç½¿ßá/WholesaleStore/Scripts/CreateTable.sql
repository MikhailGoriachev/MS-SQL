﻿-- Создание таблиц базы данных «Оптовый магазин. Учет продаж»

drop table if exists Sales;
drop table if exists Sellers;
drop table if exists Purchases;
drop table if exists Goods;
drop table if exists Units;
go

-- таблица единиц измерения товара
create table dbo.Units(
	  [Id]         int           not null primary key identity (1, 1),
	  Long         nvarchar(20)  not null,  -- полное название
	  Short        nvarchar(5)   not null   -- краткое название
);
go


-- таблица наименований товаров
create table dbo.Goods(
	  [Id]         int           not null primary key identity (1, 1),
	  [Name]       nvarchar(80)  not null, -- Наименование товара
);
go


-- таблица закупок
create table dbo.Purchases(
	  [Id]         int           not null primary key identity (1, 1),
	  IdGood       int           not null,
	  IdUnit       int           not null,
	  Purchase     int           not null,
	  Amount       int           not null,
	  DatePurchase date          not null,

	  constraint CK_Purcheses_Purchase check (Purchase > 0),
	  constraint CK_Purcheses_Amount check (Amount > 0),
	  -- constraint FK_Cars_Brands foreign key (IdBrand) references dbo.Brands(Id),
	  constraint FK_Purchases_Goods foreign key (IdGood) references dbo.Goods(Id),
	  constraint FK_Purchases_Units foreign key (IdUnit) references dbo.Units(Id)
);
go


-- таблица продавцов
create table dbo.Sellers(
	  [Id]        int           not null primary key identity (1, 1),
	  Surname     nvarchar(60) not null,    -- Фамилия 
	  [Name]      nvarchar(50) not null,    -- Имя 
	  Patronymic  nvarchar(60) not null,    -- Отчество 
	  Interest    float        not null,    -- процент комиссионных

	  constraint CK_Sellers_Interest check (Interest > 0)
);
go


-- таблица продаж
create table dbo.Sales(
	  [Id]        int           not null primary key identity (1, 1),
	  DateSale    date          not null, -- дата продажи товара
	  IdSeller    int           not null, -- данные продавца
	  IdPurchase  int           not null, -- данные товара
	  IdUnit      int           not null, -- единица измерения товара
	  Amount      int           not null, -- кол-во проданных единиц товара
	  Price       int           not null, -- цена продажи единицы товара

	  constraint CK_Sales_Price check (Price > 0),
	  constraint CK_Sales_Amount check (Amount > 0),

	  constraint FK_Sales_Sellers foreign key (IdSeller) references dbo.Sellers(Id),
	  constraint FK_Sales_Purchases foreign key (IdPurchase) references dbo.Purchases(Id),
	  constraint FK_Sales_Units foreign key (IdUnit) references dbo.Units(Id)
);
go