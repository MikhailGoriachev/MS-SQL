﻿-- запросы

-- 1	Запрос с параметрами	
-- Выбирает из таблицы ТОВАРЫ информацию о товарах, единицей измерения которых является «шт» (штуки) 
-- и цена закупки составляет меньше 200 руб.
declare @Unit nvarchar(60) = N'Штука',
        @Price int = 200;
select
    Purchases.Id
    , Goods.[Name]
    , Purchases.Amount
    , Units.Long as Unit
    , Purchases.PurchasePrice
    , Purchases.DatePurchase  
from
    Purchases   join Goods   on Purchases.IdGoods = Goods.Id
                join Units   on Purchases.IdUnit  = Units.Id                   
where
    Units.Long = @Unit and Purchases.PurchasePrice < @Price
go

-- 2	Запрос с параметрами	
-- Выбирает из таблицы ТОВАРЫ информацию о товарах,
-- цена закупки которых больше 500 руб. за единицу товара
declare @Price int = 500;
select
    Purchases.Id
    , Goods.[Name]
    , Purchases.Amount
    , Units.Long as Unit
    , Purchases.PurchasePrice
    , Purchases.DatePurchase  
from
    Purchases   join Goods   on Purchases.IdGoods = Goods.Id
                join Units   on Purchases.IdUnit  = Units.Id                   
where
    Purchases.PurchasePrice > @Price
go

-- 3	Запрос с параметрами	
-- Выбирает из таблицы ТОВАРЫ информацию о товарах с заданным наименованием 
-- (например, «чехол защитный»), для которых цена закупки меньше 1800 руб.
declare @Name nvarchar(60) = N'Молоко',
        @Price int = 1800;
select
    Purchases.Id
    , Goods.[Name]
    , Purchases.Amount
    , Units.Long as Unit
    , Purchases.PurchasePrice
    , Purchases.DatePurchase  
from
    Purchases   join Goods   on Purchases.IdGoods = Goods.Id
                join Units   on Purchases.IdUnit  = Units.Id                   
where
    Goods.[Name] = @Name and Purchases.PurchasePrice < @Price
go

-- 4	Запрос с параметрами	
-- Выбирает из таблицы ПРОДАВЦЫ информацию о продавцах 
-- с заданным значением процента комиссионных. 
declare @Interest int = 8;       
select
    Sellers.Id
    , Sellers.[Name]
    , Sellers.Patronymic
    , Sellers.Surname
    , Sellers.Interest   
from
    Sellers                   
where
    Sellers.Interest = @Interest
go

-- 5	Запрос с параметрами	
-- Выбирает из таблиц ТОВАРЫ, ПРОДАВЦЫ и ПРОДАЖИ информацию обо всех 
-- зафиксированных фактах продажи товаров (Наименование товара, Цена закупки, Цена продажи, дата продажи), 
-- для которых Цена продажи оказалась в некоторых заданных границах. 
declare @lo int = 70,       
        @hi int = 140;       
select
    Sales.Id
    , Goods.[Name]
    , Purchases.PurchasePrice
    , Sales.Price
    , Sales.DateSell   
from
    Sales join Sellers on Sales.IdSeller = Sellers.Id
          join (Purchases join Goods   on Purchases.IdGoods = Goods.Id  )          
                       on Sales.IdPurchase = Purchases.Id
where
    Sales.Price between @lo and @hi
go

-- 6	Запрос с вычисляемыми полями	
-- Вычисляет прибыль от продажи за каждый проданный товар. 
-- Включает поля Дата продажи, Наименование товара, Цена закупки, Цена продажи, Количество проданных единиц, Прибыль. 
-- Сортировка по полю Наименование товара
select
    Sales.Id
    , Sales.DateSell   
    , Goods.[Name]
    , Units.Short
    , Purchases.PurchasePrice
    , Sales.Price
    , Sales.Amount
    , (Sales.Price * Sales.Amount) - (Purchases.PurchasePrice * Sales.Amount) as Profit   
from
    Sales join Sellers on Sales.IdSeller = Sellers.Id
          join (Purchases join Goods   on Purchases.IdGoods = Goods.Id
                          join Units   on Purchases.IdUnit  = Units.Id )          
                       on Sales.IdPurchase = Purchases.Id
order by
    Goods.[Name]
go

-- 7	Запрос на левое соединение	
-- Выбирает всех продавцов (выводить Код продавца, фамилию и инициалы продавца), 
-- количество и суммы их продаж за заданный период, 
-- упорядочивать по фамилиям и инициалам 
select
    Sellers.Id
    , Sellers.Surname + N' ' + Substring(Sellers.[Name], 1, 1) + N'.' + 
          Substring(Sellers.Patronymic, 1, 1) + N'.' as Seller
    , COUNT(Sales.Id) as Amount
    , SUM (Sales.Price) as SumSales
from
    Sellers left join (Sales join (Purchases    join Goods   on Purchases.IdGoods = Goods.Id
                                                join Units   on Purchases.IdUnit  = Units.Id )          
                             on Sales.IdPurchase = Purchases.Id )
            on Sales.IdSeller = Sellers.Id
group by
    Sellers.Id, Sellers.Surname, Sellers.[Name], Sellers.Patronymic
order by
    Sellers.Surname + N' ' + Substring(Sellers.[Name], 1, 1) + N'.' + 
          Substring(Sellers.Patronymic, 1, 1) + N'.'
go

-- 8	Запрос на левое соединение	
-- Выбирает все товары, количество и сумму продаж по этим товарам. 
-- Упорядочивать по убыванию суммы продаж
select
    Purchases.Id
    , Goods.[Name]
    , Units.Long 
    , COUNT(Sales.Id) as Amount
    , SUM (Sales.Price) as SumSales
from
    Purchases left join (Sales join Sellers on Sales.IdSeller = Sellers.Id)
                    on Sales.IdPurchase = Purchases.Id
                   join Goods on Purchases.IdGoods= Goods.Id
                   join Units on Purchases.IdUnit = Units.Id

group by
    Purchases.Id, Goods.[Name], Units.Long, Sales.Price
order by
    SUM (Sales.Price) desc
go


-- 9	Итоговый запрос	
-- Выполняет группировку по полю Наименование товара. 
-- Для каждого наименования вычисляет среднюю цену закупки товара, количество закупок
select
    Goods.[Name]
    , Units.Long
    , AVG(Purchases.PurchasePrice) as AvgPurchasePrice   
    , COUNT(Purchases.Id) as Amount   
    
from
   
     Sales join Sellers on Sales.IdSeller = Sellers.Id
          join (Purchases join Goods   on Purchases.IdGoods = Goods.Id
                          join Units   on Purchases.IdUnit  = Units.Id )          
                       on Sales.IdPurchase = Purchases.Id
group by
    Goods.[Name], Units.Long
go


-- 10	Итоговый запрос	
-- Выполняет группировку по полю Код продавца из таблицы ПРОДАЖИ. 
-- Для каждого продавца вычисляет среднее значение по полю Цена продажи единицы товара, количество продаж
select
    Sellers.Id
    , Sellers.Surname + N' ' + Substring(Sellers.[Name], 1, 1) + N'.' + Substring(Sellers.Patronymic, 1, 1) + N'.' as Seller
    , AVG(Sales.Price) as AvgPrice   
    , COUNT(Sales.Id) as Amount   
    
from
   
     Sales join Sellers on Sales.IdSeller = Sellers.Id
          join (Purchases join Goods   on Purchases.IdGoods = Goods.Id
                          join Units   on Purchases.IdUnit  = Units.Id )          
                       on Sales.IdPurchase = Purchases.Id
group by
    Sellers.Id, Sellers.Surname, Sellers.[Name], Sellers.Patronymic
go

-- 11	Итоговый запрос с объединением	
-- Тремя запросами к таблице ТОВАРЫ с объединением определить минимальную цену закупки единицы товара, 
-- среднюю цену закупки единицы товара, максимальную цену закупки единицы товара. 
-- Выводить текстовые названия значений 

select
    N'Минимальная цена закупки' as Title
    , Min(Purchases.PurchasePrice) as Price
from
    Purchases

union all

select 
    N'Средняя цена закупки'
    , Avg(Purchases.PurchasePrice)
from
    Purchases
    
union all

select
    N'максимальная цена закупки'
    , Max(Purchases.PurchasePrice)
from
    Purchases
go


-- 12	Итоговый запрос с объединением	
-- Двумя запросами с объединением к таблицам ТОВАРЫ, ПРОДАВЦЫ, ПРОДАЖИ 
-- выводить наименование товара и его количество, 
-- фамилии и инициалы продавцов и количество продаж
select
    Goods.[Name] as [Name]
    , Count(Purchases.Id) as Amount
from
    Purchases join Goods   on Purchases.IdGoods = Goods.Id       
group by
    Goods.[Name]                     

union all

select 
    Sellers.Surname + N' ' + Substring(Sellers.[Name], 1, 1) + N'.' + Substring(Sellers.Patronymic, 1, 1) + N'.' 
    , Count(Sales.Id)
from
    Sales join Sellers on Sales.IdSeller = Sellers.Id
group by
    Sellers.Surname, Sellers.[Name], Sellers.Patronymic    
go

-- 13	Запрос на создание базовой таблицы	
-- Создает таблицу ТОВАРЫ_ШТ, содержащую информацию о товарах, 
-- единицей измерения которых является «шт» (штуки)
declare @UnitShort nvarchar(20) = N'шт';
select
    Purchases.Id
    ,IdGoods
    , IdUnit
    , PurchasePrice
    , Amount
    , DatePurchase
    into PurchasesThing
from
    Purchases join Units on Purchases.IdUnit  = Units.Id
where
    Units.Short = @UnitShort

-- удалить таблицу PurchasesThing
-- drop table if exists PurchasesThing;


-- 14	Запрос на создание базовой таблицы	
-- Создает копию таблицы ТОВАРЫ с именем КОПИЯ_ТОВАРЫ
select
    *
    into Copy_Purchases
from
    Purchases;

-- удалить таблицу Copy_Purchases
-- drop table if exists Copy_Purchases;


-- 15	Запрос на удаление	
-- Удаляет из таблицы КОПИЯ_ТОВАРЫ записи, в которых значение в поле 
-- Цена закупки единицы товара больше 500 руб.
declare @Price int = 500; 
delete from 
    Copy_Purchases 
where
    Copy_Purchases.PurchasePrice > @Price;
go


-- 16	Запрос на обновление	
-- Устанавливает значение в поле Процент комиссионных таблицы ПРОДАВЦЫ 
-- равным 10 % для тех продавцов, 
-- процент комиссионных которых составляет 8 %
declare @NewInterest int = 10,      
        @OldInterest int = 8;
update
    Sellers
set
    Sellers.Interest = @NewInterest    
from
     Sellers 
where
    Sellers.Interest = @OldInterest;