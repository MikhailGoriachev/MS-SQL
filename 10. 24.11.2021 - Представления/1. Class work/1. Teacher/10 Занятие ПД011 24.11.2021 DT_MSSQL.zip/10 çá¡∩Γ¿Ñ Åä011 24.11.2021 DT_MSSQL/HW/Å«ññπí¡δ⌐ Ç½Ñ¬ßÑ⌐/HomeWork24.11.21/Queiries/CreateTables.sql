﻿-- создание базовых таблиц

-- удалить все таблицы
drop table if exists Sales;
drop table if exists Purchases;
drop table if exists Sellers;
drop table if exists Goods;
drop table if exists Units;


-- Таблица наименования продуктов
CREATE TABLE [dbo].[Goods]
(
	[Id] INT NOT NULL PRIMARY KEY identity (1,1), 
    [Name] NVARCHAR(50) NOT NULL,
)

-- Таблица едениц измерения
CREATE TABLE [dbo].[Units]
(
	[Id] INT NOT NULL PRIMARY KEY identity (1,1), 
    [Short] NVARCHAR(10) NOT NULL, 
    [Long] NVARCHAR(20) NOT NULL,
)


-- Табоица закупок
CREATE TABLE [dbo].[Purchases]
(
	[Id] INT NOT NULL PRIMARY KEY identity (1,1), 
    [IdGoods] INT NOT NULL, 
    [IdUnit] INT NOT NULL, 
    [PurchasePrice] FLOAT NOT NULL, 
    [Amount] INT NOT NULL, 
    [DatePurchase] DATE NOT NULL, 
    CONSTRAINT [CK_Purchases_Price] CHECK (PurchasePrice > 0), 
    CONSTRAINT [CK_Purchases_Amount] CHECK (Amount > 0), 
    CONSTRAINT [FK_Purchases_Goods] FOREIGN KEY ([IdGoods]) REFERENCES [Goods]([Id]), 
    CONSTRAINT [FK_Purchases_Unit] FOREIGN KEY ([IdUnit]) REFERENCES [Units]([Id]),

)

-- Таблица продавцов
CREATE TABLE [dbo].[Sellers]
(
	[Id] INT NOT NULL PRIMARY KEY identity (1,1), 
    [Name] NVARCHAR(60) NOT NULL, 
    [Patronymic] NVARCHAR(60) NOT NULL, 
    [Surname] NVARCHAR(60) NOT NULL, 
    [Interest] INT NOT NULL,

)

-- Таблица продаж
CREATE TABLE [dbo].[Sales]
(
	[Id] INT NOT NULL PRIMARY KEY Identity (1,1), 
    [DateSell] DATE NOT NULL, 
    [IdSeller] INT NOT NULL, 
    [IdPurchase] INT NOT NULL, 
    [IdUnit] INT NOT NULL, 
    [Amount] FLOAT NOT NULL, 
    [Price] FLOAT NOT NULL, 
    CONSTRAINT [CK_Sales_Amount] CHECK (Amount > 0), 
    CONSTRAINT [CK_Sales_Price] CHECK (Price > 0), 
    CONSTRAINT [FK_Sales_Sellers] FOREIGN KEY ([IdSeller]) REFERENCES [Sellers]([Id]), 
    CONSTRAINT [FK_Sales_Purchase] FOREIGN KEY ([IdPurchase]) REFERENCES [Purchases]([Id]), 
    CONSTRAINT [FK_Sales_Units] FOREIGN KEY ([IdUnit]) REFERENCES [Units]([Id]),

)