﻿-- 1
-- Выбирает из таблицы ВРАЧИ информацию о врачах, имеющих конкретную специальность (например, хирург)
select * from Doctors
where Category = N'хирург'
go


-- 2
-- Выбирает из таблицы ПАЦИЕНТЫ информацию о пациентах, родившихся до 01.01.1980 (дату можно выбрать другую)
declare @date date = convert(date, '01.01.1980', 104); 

select * from Patients
where BirthDate < @date
go


-- 3
-- Выбирает из таблицы ВРАЧИ информацию о врачах, имеющих специальность «хирург», 
-- стоимость приема которых меньше 1200 рублей
select * from Doctors
where Cost < 1200
go


-- 4
-- Выбирает из таблицы ПАЦИЕНТЫ информацию о пациентах с заданной датой рождения. 
-- Дата рождения задается переменной при выполнении запроса
declare @date date = convert(date, '30.10.2003', 104); 

select * from Patients
where BirthDate = @date
go


-- 5
-- Выбирает из таблицы ПАЦИЕНТЫ информацию о пациентах, проживающих на улице, 
-- заданной переменной при выполнении запроса
declare @street nvarchar(max) = N'6749 Augue St.'; 

select * from Patients
where Address = @street
go


-- 6
-- Выбирает из таблицы ВРАЧИ информацию о врачах, процент отчисления которых
-- принадлежит диапазону, заданному переменными при выполнении запроса
declare @min float = 2,
		@max float = 5; 

select * from Doctors
where InterestDeduction between @min and @max
go


-- 7
-- В таблице ПАЦИЕНТЫ выполняет группировку по полю Дата рождения. 
-- Для каждой даты группы вычисляет количество пациентов 
select convert(nvarchar, BirthDate, 104) as BirthDate, Count(BirthDate) as Count
from Patients
group by BirthDate
go


-- 8
-- В таблице ВРАЧИ выполняет группировку по полю Специальность. 
-- Для каждой специальности вычисляет количество докторов в группе, максимальный, минимальный и средний 
-- Процент отчисления 
select 
	Category, 
	Count(Category) as Count, 
	Max(InterestDeduction) as MaxInterest,
	Min(InterestDeduction) as MinInterest,
	format(Avg(InterestDeduction), 'F') as AverageInterest
from Doctors
group by Category
go


-- 9
-- Создает таблицу ВРАЧИ_ТЕРАПЕВТЫ, содержащую информацию о врачах-терапевтах, используйте select … into
drop table if exists Doctors_Therapeutic;

select * into Doctors_Therapeutic from Doctors
where Category = N'терапевт'
go


-- 10
-- Создает копию таблицы ПАЦИЕНТЫ с именем КОПИЯ_ПАЦИЕНТЫ, используйте select … into
drop table if exists Copy_Patients;

select * into Copy_Patients from Patients
go


-- 11
-- Удаляет из таблицы ВРАЧИ_ТЕРАПЕВТЫ записи, в которых значение в поле Стоимость приема больше 200
delete from Doctors_Therapeutic
where Cost > 200
go


-- 12
-- Удаляет из таблицы ПАЦИЕНТЫ записи о пациентах, проживающих на улицах «Садовая» или «Содовая» или «Судовая» 
delete from Copy_Patients
where Address in (N'Садовая', N'Содовая', N'Судовая')
go


-- 13
-- Увеличивает значение в поле Стоимость приема таблицы ВРАЧИ на 10 процентов для врачей, 
-- имеющих специальность «хирург» и Процент отчисления у которых меньше 5% 
update Doctors
set Cost += Cost * 10 / 100
where Category = N'хирург' and InterestDeduction < 5
go


-- 14
-- Для записей таблицы ПАЦИЕНТЫ, у которых дата рождения между 01.01.1935 и 31.12.1959 
-- к фамилии добавить строку «риск» (операция конкатенации строк: +, как в C#)
declare @min date = convert(date, '01.01.1935', 104),
        @max date = convert(date, '31.12.1970', 104);

update Patients
set Surname += N' риск'
where BirthDate between @min and @max and Surname not like N'% риск'
go