﻿--1.Выбирает из таблицы ВРАЧИ информацию о врачах, имеющих 
--конкретную специальность (например, хирург)
select * 
from Doctors
where Speciality = N'хирург';

--2.Выбирает из таблицы ПАЦИЕНТЫ информацию о пациентах, родившихся до 01.01.1980 
--(дату можно выбрать другую)
select *
from Patients
where DateOfBorn < '1980-01-01';

--3.Выбирает из таблицы ВРАЧИ информацию о врачах, имеющих специальность «хирург», 
--стоимость приема которых меньше 1200 рублей
select * 
from Doctors
where Speciality = N'хирург' and CostOfAdmission < 1200;

--4.Выбирает из таблицы ПАЦИЕНТЫ информацию о пациентах с заданной 
--датой рождения. Дата рождения задается переменной при выполнении запроса
select *
from Patients
where DateOfBorn = '1978-05-04';

--5.Выбирает из таблицы ПАЦИЕНТЫ информацию о пациентах, проживающих на улице, 
--заданной переменной при выполнении запроса
select *
from Patients
where PtAddress like N'%Пушкина%';

--6.Выбирает из таблицы ВРАЧИ информацию о врачах, процент отчисления 
--которых принадлежит диапазону, заданному переменными при выполнении запроса
select * 
from Doctors
where PercDeduction between 60 and 80;
--7.В таблице ПАЦИЕНТЫ выполняет группировку по полю Дата рождения. 
--Для каждой даты группы вычисляет количество пациентов 
select
	DateOfBorn
	,COUNT(DateOfBorn) as [Amount]
from Patients
group by DateOfBorn

--8.В таблице ВРАЧИ выполняет группировку по полю Специальность. 
--Для каждой специальности вычисляет количество докторов в группе, максимальный, 
--минимальный и средний Процент отчисления 
select 
	Speciality
	,COUNT(Speciality) as Amount
	,MAX(PercDeduction) as MaxPercent
	,MIN(PercDeduction) as MinPercent
	,AVG(PercDeduction) as MiddlePercent
from Doctors
group by Speciality;
--9.Создает таблицу ВРАЧИ_ТЕРАПЕВТЫ, содержащую информацию о 
--врачах-терапевтах, используйте select … into
select *
into [DrsTherapists] 
from Doctors
where Speciality = N'терапевт';

drop table DrsTherapists;
--10.Создает копию таблицы ПАЦИЕНТЫ с именем КОПИЯ_ПАЦИЕНТЫ, используйте select … into
select *
into [Copy_Patients]
from Patients;
--11.Удаляет из таблицы ВРАЧИ_ТЕРАПЕВТЫ записи, в которых значение в
--поле Стоимость приема больше 200
delete from DrsTherapists
where CostOfAdmission > 200;
--12.Удаляет из таблицы ПАЦИЕНТЫ записи о пациентах, проживающих 
--на улицах «Садовая» или «Содовая» или «Судовая» 
delete from Patients
where PtAddress in (N'Садовая%', N'Содовая%', N'Судовая%');
--13.Увеличивает значение в поле Стоимость приема таблицы ВРАЧИ на 10 процентов 
--для врачей, имеющих специальность «хирург» и Процент отчисления у которых меньше 5% 
update Doctors
set CostOfAdmission += CostOfAdmission * 10 / 100
where Speciality = N'хирург' and PercDeduction < 5;
--14.Для записей таблицы ПАЦИЕНТЫ, у которых дата рождения между 
--01.01.1935 и 31.12.1959 к фамилии добавить строку «риск» (операция конкатенации строк: +, как в C#)
update Patients
set Surname += N'риск'
where DateOfBorn between '1935-01-01' and '1959-12-31';
