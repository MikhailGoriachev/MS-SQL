﻿create table [dbo].[Patients]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY(1, 1), 
    [PtName] NVARCHAR(60) NOT NULL, 
    [PtSurname] NVARCHAR(60) NOT NULL, 
    [PtPatronymic] NVARCHAR(60) NOT NULL, 
    [DateOfBorn] DATE NOT NULL, 
    [PtAddress] NVARCHAR(60) NOT NULL, 
    CONSTRAINT [CK_Patients_DateOfBorn] CHECK (DateOfBorn > '1900-01-01'), 
)

go

insert into Patients
    (PtName,PtSurname,PtPatronymic,DateOfBorn,PtAddress)
values
    (N'Игнат',N'Ляшенко',N'Даниилович','1980-01-02', N'Ленина 23, 8'),
    (N'Альберт',N'Чуб',N'Петрович','1980-11-23', N'Ильича 5'),
    (N'Антон',N'Коток',N'Иванович','1981-04-03', N'Железнодорожная 1, 9'),
    (N'Спартак',N'Самойленко',N'Денисович','1975-06-06', N'Садовая 9'),
    (N'Максим',N'Межерич',N'Васильевич','1970-11-11', N'Московская 55'),
    (N'Александр',N'Чижов',N'Петрович','1978-05-04', N'Питерская 2, 2'),
    (N'Василий',N'Бобруйко',N'Богданович','1990-03-10', N'Морская 23'),
    (N'Эдуард',N'Галкин',N'Васильевич','1990-05-09', N'Стальная 9'),
    (N'Георгий',N'Пащенко',N'Алексеевич','2000-03-12', N'Зеленая 23'),
    (N'Игорь',N'Чудин',N'Игнатович','1990-11-23', N'Пушкина 23, 3');

go