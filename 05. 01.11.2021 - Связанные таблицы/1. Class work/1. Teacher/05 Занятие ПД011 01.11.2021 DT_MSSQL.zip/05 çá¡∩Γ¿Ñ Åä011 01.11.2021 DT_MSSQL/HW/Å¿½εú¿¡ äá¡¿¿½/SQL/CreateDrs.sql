﻿create table [dbo].[Doctors]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY(1, 1), 
    [DrName] NVARCHAR(60) NOT NULL, 
    [DrSurname] NVARCHAR(60) NOT NULL, 
    [DrPatronymic] NVARCHAR(60) NOT NULL, 
    [Speciality] NVARCHAR(60) NOT NULL, 
    [CostOfAdmission] INT NOT NULL, 
    [PercDeduction] INT NOT NULL, 
    CONSTRAINT [CK_Doctors_CostOfAdmis] CHECK (CostOfAdmission > 0), 
    CONSTRAINT [CK_Doctors_PercDeduction] CHECK (PercDeduction > 0)
)

go

insert into Doctors
    (DrName,DrSurname,DrPatronymic,Speciality,CostOfAdmission,PercDeduction)
values
    (N'Василий',N'Судиловский',N'Евгеньевич', N'хирург', 1000, 75),
    (N'Иван',N'Андреев',N'Петрович', N'терапевт', 500, 50),
    (N'Петр',N'Вотинцев',N'Иванович', N'кардиолог', 450, 75),
    (N'Игорь',N'Марушкевич',N'Данилович', N'офтальмолог ', 550, 77),
    (N'Никита',N'Алексеев',N'Васильевич', N'терапевт', 400, 66),
    (N'Николай',N'Булыгин',N'Денисович', N'кардиолог', 350, 65),
    (N'Владислав',N'Летков',N'Богданович', N'хирург', 550, 55),
    (N'Вячеслав',N'Ешуков',N'Алексеевич', N'кардиолог', 400, 80),
    (N'Владимир',N'Детков',N'Николаевич', N'хирург', 750, 45),
    (N'Алексей',N'Тарасов',N'Игнатович', N'офтальмолог', 800, 80);

go