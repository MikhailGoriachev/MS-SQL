﻿--1	Запрос на выборку	
--Выбирает из таблицы ВРАЧИ информацию о врачах,
--имеющих конкретную специальность (например, хирург)
SELECT 
	Id,
	FirstName,
	Surname,
	Speciality,
	Price,
	Deductions	
FROM Doctors
WHERE Doctors.Speciality = N'Хирург';

--2	Запрос на выборку	
--Выбирает из таблицы ПАЦИЕНТЫ информацию о пациентах,
--родившихся до 01.01.1980 (дату можно выбрать другую)
SELECT
	Id,
	FirstName,
	Surname,
	Patronymic,
	BirthDate,
	LivingAddress
FROM Patients
WHERE BirthDate < '19800325'
ORDER BY BirthDate;

--3	Запрос на выборку
--Выбирает из таблицы ВРАЧИ информацию о врачах,
--имеющих специальность «хирург», 
--стоимость приема которых меньше 1200 рублей
SELECT 
	Id,
	FirstName,
	Surname,
	Speciality,
	Price,
	Deductions		
FROM Doctors
WHERE Speciality = N'Хирург' and Price < 1200;

--4	Запрос с параметром
--Выбирает из таблицы ПАЦИЕНТЫ информацию о пациентах с заданной датой рождения.
--Дата рождения задается переменной при выполнении запроса
 DECLARE @bdate Date = '19571222';
 --set @bdate = '19571222';
 SELECT
	Id,
	FirstName,
	Surname,
	Patronymic,
	BirthDate,
	LivingAddress
FROM Patients
WHERE BirthDate = @bdate;


--5	Запрос с параметром
--Выбирает из таблицы ПАЦИЕНТЫ информацию о пациентах,
--проживающих на улице, заданной переменной при выполнении запроса
DECLARE @street NVARCHAR(40) = N'%[Тт]орфяная%'

SELECT
	Id,
	FirstName,
	Surname,
	Patronymic,
	BirthDate,
	LivingAddress
FROM Patients
WHERE LivingAddress like @street;


--6	Запрос с параметром	
--Выбирает из таблицы ВРАЧИ информацию о врачах,
--процент отчисления которых принадлежит диапазону,
--заданному переменными при выполнении запроса
DECLARE @from REAL = 20, @to REAL = 40

SELECT 
	Id,
	FirstName,
	Surname,
	Speciality,
	Price,
	Deductions
FROM Doctors
WHERE Deductions between @from and @to
ORDER BY Deductions;
		
--7	Итоговый запрос
--В таблице ПАЦИЕНТЫ выполняет группировку по полю Дата рождения. 
--Для каждой даты группы вычисляет количество пациентов 
SELECT
	BirthDate,
	COUNT(*) as Amount
FROM Patients
GROUP BY BirthDate
ORDER BY BirthDate;

--8	Итоговый запрос
--В таблице ВРАЧИ выполняет группировку по полю Специальность. 
--Для каждой специальности вычисляет количество докторов в группе, 
--максимальный, минимальный и средний Процент отчисления 
SELECT
	Speciality,
	COUNT(*) as Amount,
	MIN(Deductions) as MinDeduction,
	MAX(Deductions) as MaxDeduction,
	AVG(Deductions) as AvgDeduction
FROM Doctors
GROUP BY Speciality
ORDER BY Amount;
		
--9	Запрос на создание базовой таблицы
--Создает таблицу ВРАЧИ_ТЕРАПЕВТЫ, содержащую информацию о врачах-терапевтах,
--используйте select … 
SELECT 
	*
INTO Doctors_Theraphists
FROM Doctors
WHERE Speciality = N'Терапевт';

--10	Запрос на создание базовой таблицы
--Создает копию таблицы ПАЦИЕНТЫ с именем КОПИЯ_ПАЦИЕНТЫ
--используйте select … into
SELECT 
	*
INTO Copy_Patients
FROM Patients;

--11	Запрос на удаление
--Удаляет из таблицы ВРАЧИ_ТЕРАПЕВТЫ записи, 
--в которых значение в поле Стоимость приема больше 200
DELETE FROM Doctors_Theraphists
WHERE Price > 200;
	

--12	Запрос на удаление
--Удаляет из таблицы ПАЦИЕНТЫ записи о пациентах,
--проживающих на улицах «Садовая» или «Содовая» или «Судовая» 
DELETE FROM Patients
WHERE LivingAddress like N'%[ .]С[аоу]довая[ ,]%';
		
--13	Запрос на обновление
--Увеличивает значение в поле Стоимость приема таблицы ВРАЧИ на 10 процентов для врачей, 
--имеющих специальность «хирург» и Процент отчисления у которых меньше 5% 
UPDATE Doctors
SET Price += Price * 0.1
WHERE Speciality = N'Хирург' and Deductions < 5;

--14	Запрос на обновление
--Для записей таблицы ПАЦИЕНТЫ, у которых дата рождения между 01.01.1935 и 31.12.1959 
--к фамилии добавить строку «риск» (операция конкатенации строк: +, как в C#)
UPDATE Patients
SET Surname += N' «риск»'
WHERE BirthDate between '19350101' and '19591231';
