﻿
DROP TABLE IF EXISTS dbo.Doctors;

CREATE TABLE [dbo].[Doctors]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY(1, 1), 
    [SurName] NVARCHAR(30) NOT NULL, 
    [Firstname] NVARCHAR(30) NOT NULL, 
    [Patronymic] NVARCHAR(30) NOT NULL, 
    [Speciality] NVARCHAR(60) NOT NULL, 
    [Price] INT NOT NULL, 
    [Deductions] REAL NOT NULL, 
    CONSTRAINT [CK_Doctors_Price] CHECK (Price > 0), 
    CONSTRAINT [CK_Doctors_Deductions] CHECK (Deductions > 0)
)

INSERT INTO Doctors
	(SurName, Firstname, Patronymic, Speciality, Price, Deductions)
VALUES
	(N'Никитина', N'Стефания', N'Мироновна', N'Терапевт', 200, 25),
	(N'Самсонова', N'Софья', N'Ярославовна', N'Хирург',500, 45),
	(N'Харитонова', N'Евдокия', N'Артёмовна', N'Неонатолог', 300, 20),
	(N'Павловский', N'Иван', N'Русланович', N'Нейрохирург', 900, 50),
	(N'Александрова', N'Арина', N'Платоновна', N'Венеролог', 400, 30),
	(N'Сазонов', N'Дамир', N'Ярославович', N'Гастроэнтеролог', 350, 25),
	(N'Яковлев', N'Кирилл', N'Иванович', N'Дерматолог', 300, 33),
	(N'Медведев', N'Роман', N'Романович', N'Педиатр', 400, 28),
	(N'Антонов', N'Олег', N'Романович', N'Хирург', 700, 58),
	(N'Газманов', N'Юрий', N'Олегович', N'Хирург', 1500, 48),
	(N'Селиванов', N'Лев', N'Евгеньевич', N'Кардиолог', 330, 38),
	(N'Федотова', N'Полина', N'Демидовна', N'Ортопед', 200, 20),
	(N'Кисигач', N'Яна', N'Юрьевна', N'Терапевт', 100, 20),
	(N'Бергман', N'Вадим', N'Дмитриевич', N'Хирург', 600, 3),
	(N'Фролова', N'Алина', N'Андреевна', N'Терапевт', 400, 10)

