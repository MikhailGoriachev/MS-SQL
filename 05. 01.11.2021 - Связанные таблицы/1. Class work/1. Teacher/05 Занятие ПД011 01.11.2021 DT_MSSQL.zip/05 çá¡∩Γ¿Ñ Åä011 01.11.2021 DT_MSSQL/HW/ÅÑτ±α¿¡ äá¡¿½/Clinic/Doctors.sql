﻿-- drop table Doctors;

CREATE TABLE [dbo].Doctors
(
	Id INT NOT NULL PRIMARY KEY IDENTITY, 
    Surname NCHAR(50) NOT NULL, 
    [Name] NCHAR(40) NOT NULL, 
    Patronymic NCHAR(50) NOT NULL, 
    Speciality NCHAR(10) NOT NULL, 
    AdmissionPrice INT NOT NULL, 
    AddToPayroll INT NOT NULL
)

insert into Doctors
     (Surname,Name, Patronymic, Speciality, AdmissionPrice, AddToPayroll)
values 
(N'Мадулин', N'Степан', N'Тимофеевич', N'Венеролог', 120, 25),
(N'Левкович', N'Никита', N'Захарович', N'Нарколог', 150, 23),
(N'Серебров', N'Савва',  N'Феодосивич',N'Нейрохируг', 160, 35),
(N'Прокашев', N'Кирилл', N'Александрович', N'Гематолг', 170, 25),
(N'Прохоров', N'Александр', N'Фомич',N'Терапевт', 190, 34),
(N'Рамазана', N'Алла', N'Павловна', N'Педиатр', 200, 45),
(N'Рыбаков', N'Тарас', N'Кузьмич', N'Психиатр', 210, 56 ),
(N'Касьянова', N'Оксана', N'Павловна', N'Ортопед',230, 12 ),
(N'Закрятин', N'Антон', N'Юлианович', N'Ревматолог', 167, 39 ),
(N'Рощина', N'Лидия', N'Александровна', N'Акушер', 150, 35);