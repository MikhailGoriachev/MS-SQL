﻿CREATE TABLE [dbo].[Doctors]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY(1, 1), 
    [Surname] NVARCHAR(60) NOT NULL, 
    [Name] NVARCHAR(60) NOT NULL, 
    [Patronymic] NVARCHAR(60) NOT NULL, 
    [Branch] NVARCHAR(50) NOT NULL, 
    [Cost] INT NOT NULL, 
    [Percent] FLOAT NOT NULL, 
    CONSTRAINT [Doctors_CostCheck] CHECK ([Cost] > 0), 
    CONSTRAINT [Doctors_PercentCheck] CHECK ([Percent] > 0)
)
go

insert into Doctors
    ([Surname], [Name], [Patronymic], [Branch], [Cost], [Percent])
values
    (N'Евсеев', N'Александр', N'Дмитриевич', N'Стоматолог', 1200, 5.1),
    (N'Сазонова', N'Мария', N'Марковна', N'Стоматолог', 2500, 3.5),
    (N'Майоров', N'Михаил', N'Савельевич', N'Акушер', 1600, 5.7),
    (N'Смирнов', N'Иван', N'Ильич', N'Акушер', 1900, 5.55),
    (N'Наумова', N'Анна', N'Николаевна', N'Терапевт', 100, 2.1),
    (N'Иванов', N'Григорий', N'Ильич', N'Терапевт', 220, 5.3),
    (N'Горбачева', N'Ксения', N'Степановна', N'Хирург', 1100, 2.7),
    (N'Голубев', N'Руслан', N'Тимофеевич', N'Хирург', 2100, 6.5),
    (N'Наумова', N'Алёна', N'Яновна', N'Реабилитолог', 1399, 5.6),
    (N'Кочеткова', N'Мария', N'Павловна', N'Реабилитолог', 1129, 5.7)
go