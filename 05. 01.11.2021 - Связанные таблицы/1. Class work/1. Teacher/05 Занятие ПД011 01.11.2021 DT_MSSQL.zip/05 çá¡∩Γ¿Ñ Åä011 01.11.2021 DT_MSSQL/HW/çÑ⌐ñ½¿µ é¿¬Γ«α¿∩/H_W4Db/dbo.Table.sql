﻿CREATE TABLE [dbo].[Doctors]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [SurnameDoc] NVARCHAR(50) NOT NULL, 
    [NameDoc] NVARCHAR(40) NOT NULL, 
    [PatronymicDoc] NVARCHAR(60) NOT NULL, 
    [SpecialtyDoc] NVARCHAR(50) NOT NULL, 
    [CostOfSeeing] INT NOT NULL, 
    [PercentOfContribution] INT NOT NULL,
	CONSTRAINT [CK_Publications_CostOfSeeing] CHECK (CostOfSeeing > 0),
	CONSTRAINT [CK_Publications_PercentOfContribution] CHECK (PercentOfContribution > 0)
)
