﻿--              Создание и заполнение таблицы Докторов
CREATE TABLE [dbo].[Doctors]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY(1, 1), 
    [Surname] NVARCHAR(65) NOT NULL,         -- Фамилия  врача
    [Name] NVARCHAR(60) NOT NULL,            -- Имя      врача
    [Patronymic] NVARCHAR(70) NOT NULL,      -- Отчество врача
    [Specialization] NVARCHAR(60) NOT NULL,  -- Специализация врача (хирург, терапевт, кардиолог, офтальмолог)
    [Price] FLOAT  NOT NULL,                 -- Стоимость приема
    [PercentageDeduction] FLOAT NOT NULL,  -- Процент отчисления от стоимости приема на зарплату врача
                                           
    CONSTRAINT [CK_Doctors_Price] CHECK (Price > 0), 
    CONSTRAINT [CK_Doctors_PercentageDeduction] CHECK (PercentageDeduction > 0)
)
go  -- без этого таблица не создается.

insert into Doctors
    (Surname, [Name], Patronymic, Specialization, Price, PercentageDeduction)
values
    (N'Рудаков' , N'Андрей' , N'Андреевич' , N'Хирург'     , 1500, 3),
    (N'Новиков' , N'Макар'  , N'Никитич'   , N'Терапевт'   , 150 , 4 ),
    (N'Никулин' , N'Михаил' , N'Германович', N'Кардиолог'  , 340 , 7 ),
    (N'Платонов', N'Алексей', N'Артемьевич', N'Офтальмолог', 2100, 6 ),
    (N'Кудряшов', N'Иван'   , N'Иванович'  , N'Терапевт'   , 1200, 3 ),
    (N'Миронова', N'Милана' , N'Данииловна', N'Офтальмолог', 1800, 12),
    (N'Устинов' , N'Кирилл' , N'Филиппович', N'Хирург'     , 890 , 2 ),
    (N'Соколов' , N'Ярослав', N'Русланович', N'Кардиолог'  , 490 , 11),
    (N'Гришин'  , N'Игорь'  , N'Андреевич' , N'Терапевт'   , 900 , 6 ),
    (N'Медведев', N'Давид'  , N'Максимович', N'Хирург'     , 1024, 13)
go

 