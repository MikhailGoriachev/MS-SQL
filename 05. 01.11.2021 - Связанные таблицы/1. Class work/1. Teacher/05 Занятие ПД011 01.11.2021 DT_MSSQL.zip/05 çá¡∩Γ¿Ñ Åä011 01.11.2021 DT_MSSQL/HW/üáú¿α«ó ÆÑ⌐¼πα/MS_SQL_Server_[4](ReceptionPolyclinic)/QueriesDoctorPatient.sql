﻿
--	 Для начала проверки запросов запустите скрипт в файле 
-- "CreateTableAndInsertDoctors.sql" и "CreateTableAndInsertPatients.sql"

--				Запрос №1 (таблица врачей)
-- Выбирает из таблицы ВРАЧИ информацию о врачах, 
-- имеющих конкретную специальность (например, хирург)
select
	*
from
	Doctors
where
	Specialization = N'Хирург'
;

--				Запрос №2 (таблица пациентов)
-- Выбирает из таблицы ПАЦИЕНТЫ информацию о пациентах, 
-- родившихся до 01.01.1980 (дату можно выбрать другую)
select
	*
from
	Patients
where
	[Date] < '01.01.2015'
;

--				Запрос №3 (таблица врачей)
-- Выбирает из таблицы ВРАЧИ информацию о врачах, 
-- имеющих специальность «хирург», стоимость приема 
-- которых меньше 1200 рублей
select
	*
from
	Doctors
where
	Specialization = N'Хирург' and Price < 1200
;

--				Запрос №4 (таблица пациетов)
-- Выбирает из таблицы ПАЦИЕНТЫ информацию о пациентах с заданной датой рождения. 
-- Дата рождения задается переменной при выполнении запроса
declare @personDate Date;
set @personDate = '2010.07.24';
select
	*
from
	Patients
where
	[Date] = @personDate
;

--				Запрос №5 (таблица пациетов)
-- Выбирает из таблицы ПАЦИЕНТЫ информацию о пациентах, 
-- проживающих на улице, заданной переменной при выполнении запроса
declare @personAddress nvarchar(35);
set @personAddress = N'ул.Ладыгина, д.96, кв.34, ком.303';
select
	*
from
	Patients
where
	[Address] = @personAddress
;

--				Запрос №6 (таблица врачей)
-- Выбирает из таблицы ВРАЧИ информацию о врачах, 
-- процент отчисления которых принадлежит диапазону, 
-- заданному переменными при выполнении запроса
declare @lowPercentageDeduction  float;
declare @highPercentageDeduction float;
set @lowPercentageDeduction  = 5;
set @highPercentageDeduction = 10;
select
	*
from
	Doctors
where
	PercentageDeduction between @lowPercentageDeduction and @highPercentageDeduction
;

--				Запрос №7 (таблица пациентов)
-- В таблице ПАЦИЕНТЫ выполняет группировку по полю Дата рождения. 
-- Для каждой даты группы вычисляет количество пациентов 
select
	[Date]
	,COUNT(*) as CouPatients
from
	Patients
group by
	[Date]
;

--				Запрос №8 (таблица врачей)
-- В таблице ВРАЧИ выполняет группировку по полю Специальность. 
-- Для каждой специальности вычисляет количество докторов в группе, 
-- максимальный, минимальный и средний Процент отчисления 
select
	Specialization
	,COUNT(*) as CouDoctors
	,MIN(PercentageDeduction) as MinPercentageDeduction
	,AVG(PercentageDeduction) as AvgPercentageDeduction
	,MAX(PercentageDeduction) as MaxPercentageDeduction
from
	Doctors
group by
	Specialization
;

--				Запрос №9 (таблица врачей)
-- Создает таблицу ВРАЧИ_ТЕРАПЕВТЫ, содержащую информацию о врачах-терапевтах, 
-- используйте select … into
select
	*
	into ВРАЧИ_ТЕРАПЕВТЫ
from 
	Doctors
where
	Specialization = N'Терапевт'
;

--				Запрос №10 (таблица пациентов)
-- Создает копию таблицы ПАЦИЕНТЫ с именем КОПИЯ_ПАЦИЕНТЫ, 
-- используйте select … into
select
	*
	into КОПИЯ_ПАЦИЕНТЫ
from 
	Patients
;

--				Запрос №11 (таблица врачей)
-- Удаляет из таблицы ВРАЧИ_ТЕРАПЕВТЫ записи, 
-- в которых значение в поле Стоимость приема больше 200
delete from	
	ВРАЧИ_ТЕРАПЕВТЫ
where	
	Price > 200
;

--				Запрос №12 (таблица пациентов)
-- Удаляет из таблицы ПАЦИЕНТЫ записи о пациентах, 
-- проживающих на улицах «Садовая» или «Содовая» или «Судовая» 
delete from	
	Patients
where
	[Address] like N'%[Сс][аоу]довая%'
;

--				Запрос №13 (таблица врачей)
-- Увеличивает значение в поле Стоимость приема таблицы ВРАЧИ на 10 процентов
-- для врачей, имеющих специальность «хирург» и Процент отчисления у которых меньше 5% 
update
	Doctors
set
	Price *= 1.1
where
	Specialization = N'Хирург' and PercentageDeduction < 5
;

--				Запрос №14 (таблица пациентов)
-- Для записей таблицы ПАЦИЕНТЫ, у которых дата рождения между 01.01.1935 и 31.12.1959 
-- к фамилии добавить строку «риск» (операция конкатенации строк: +, как в C#)
declare @minDate Date;
declare @maxDate Date;
set @minDate = '1935.01.01';
set @maxDate = '1959.12.31';
update
	Patients
set
	Surname += N'риск' -- без пробела, по заданию
where
	[Date] between @minDate and @maxDate
;