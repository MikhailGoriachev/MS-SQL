﻿select
	*
from 
	Doctors
where
	Speciality like N'Косметолог';

select
	*
from
	Patient
where
	DOB < '01.01.1995';

select
	*
from
	Doctors
where
	Price < 200; --поставил 200, т.к. у меня в таблице значений как требуется-нет.

declare @DateOfBirth Date;
set @DateOfBirth = '1993.10.17';
select
	*
from
	Patient
where
	DOB like @DateOfBirth;

declare @Home nvarchar(80);
set @Home = N'ул. Будапештсткая, 78';
select
	*
from
	Patient
where
	Address like @Home;

declare @LowPercent float;
declare @HighPercent float;
set	@LowPercent = 2;
set	@HighPercent = 7;
select
	*
from
	Doctors
where
	POD between @LowPercent and @HighPercent;

select
	DOB,
	COUNT(*) as DateOfBirth
from 
	Patient
group by
	DOB;

select
	Speciality,
	MIN(POD) as MinPod,
	MAX(POD) as MaxPod,
	AVG(POD) as AvgPod
from
	Doctors
group by
	Speciality;

select
	*
	into Therapists
from
	Doctors
where
	Speciality like N'Терапевт';

select
	*
	into PatientCopy
from
	Patient;

delete from 
	Therapists
where
	Price > 100; --у меня цены ниже, не стал переделывать

delete from	
	Patient
where
	[Address] like N'%С[аоу]довая%';

update
	Doctors
set 
	Price *=1.1
where
	Speciality = N'Хирург' and POD < 5;

update
	Patient
set 
	Surname +=N'риск'
where
	DOB between '1935.01.01' and '1959.12.31';

	

