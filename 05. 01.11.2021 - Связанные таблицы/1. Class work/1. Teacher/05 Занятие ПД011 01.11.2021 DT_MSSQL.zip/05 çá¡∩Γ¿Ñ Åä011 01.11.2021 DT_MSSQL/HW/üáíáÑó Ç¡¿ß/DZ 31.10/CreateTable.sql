﻿CREATE TABLE [dbo].[Doctors]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY(1, 1), 
    [SurName] NVARCHAR(80) NOT NULL, 
    [FirstName] NVARCHAR(80) NOT NULL, 
    [Patronymic] NVARCHAR(80) NOT NULL,
    [Speciality] NVARCHAR(80) NOT NULL,
    [Price] INT NOT NULL,
    [POD] float NOT NULL
)
go
insert into Doctors
    (SurName, FirstName, Patronymic, Speciality,Price, POD)
values--без введения айди вручную таблица данных не заполнялась
    (N'Абрамов', N'Иван', N'Сергеевич', N'Дерматолог', 200, 5),
    (N'Маслова', N'Анастасия', N'Максимова', N'Хирург', 250, 2),
    (N'Гадетский', N'Андрей', N'Константинов', N'Терапевт', 100, 10),
    (N'Демина', N'Анна', N'Михайловича', N'Терапевт', 150, 15),
    (N'Комаров', N'Максим', N'Александрович', N'Хирург', 300, 3),
    (N'Багиров', N'Никита', N'Игоревич', N'Диетолог', 400, 5),
    (N'Никитин', N'Дмитрий', N'Филипович', N'Кардиолог', 250, 6),
    (N'Косака', N'Елизавета', N'Германовича', N'Косметолог', 120, 7),
    (N'Петрунин', N'Павел', N'Денисович', N'Хирург', 200, 9),
    (N'Прохоров', N'Денис', N'Максимович', N'Уролог', 220, 8);
go


