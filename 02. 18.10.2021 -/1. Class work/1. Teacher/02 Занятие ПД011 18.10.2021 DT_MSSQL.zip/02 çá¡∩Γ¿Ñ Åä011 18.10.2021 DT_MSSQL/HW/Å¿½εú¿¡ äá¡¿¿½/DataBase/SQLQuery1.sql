﻿--1
select * from Clients
--2
select
	*
from
	Clients
where 
	Discont between 0.3 and 0.5
--3
select
	Id
	,Surname
	,Name
	,Patronymic
	,Discont
from
	Clients
where
	Discont < 0.3
--4
select
	*
from
	Clients
where
	Discont > 0.6
--5
select
	Surname
	,Name
	,Patronymic
	,YearofBirth
from
	Clients
where
	YearofBirth < 2000
--6
select
	*
from
	Clients
where
	YearofBirth between 1960 and 1996
--7
select
	Id
	,Surname
	,Name
	,Patronymic
	,YearofBirth
from
	Clients
where
	YearofBirth > 1996