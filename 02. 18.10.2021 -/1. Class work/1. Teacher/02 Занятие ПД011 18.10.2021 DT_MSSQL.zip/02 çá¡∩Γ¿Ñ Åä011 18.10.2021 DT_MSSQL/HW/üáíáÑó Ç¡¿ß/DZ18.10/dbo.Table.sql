﻿CREATE TABLE [dbo].[Clients] (
    [Id]                 INT NOT NULL IDENTITY ,
    [Surname]            NVARCHAR (50) NOT NULL,
    [Name]               NVARCHAR (40) NOT NULL,
    [Patronymic]         NVARCHAR (60) NOT NULL,
    [DOB]          INT           NOT NULL,
    [Discount] FLOAT (53)     NOT NULL DEFAULT 0,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);