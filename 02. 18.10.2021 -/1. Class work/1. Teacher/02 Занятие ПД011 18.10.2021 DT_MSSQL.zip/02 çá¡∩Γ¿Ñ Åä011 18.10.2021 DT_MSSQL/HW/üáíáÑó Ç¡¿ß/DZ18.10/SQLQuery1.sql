﻿select
* 
from 
	Clients;

select
*
from
	Clients
where
	Discount between 0.3 and 0.5;

select
	Id
	, Surname
	, Name
	, Patronymic
	, Discount 
from 
	Clients
where
	Discount < 0.3;

select
	*
from
	Clients
where
	Discount > 0.6;

select
	Surname
	, Name
	, Patronymic
	, DOB
from
	Clients
where
	DOB > 2000;

select
	*
from 
	Clients
where
	DOB between 1960 and 1996;

select 
	Id
	, Surname
	, Name
	, Patronymic
	, DOB
from
	Clients
where
	DOB < 1996;