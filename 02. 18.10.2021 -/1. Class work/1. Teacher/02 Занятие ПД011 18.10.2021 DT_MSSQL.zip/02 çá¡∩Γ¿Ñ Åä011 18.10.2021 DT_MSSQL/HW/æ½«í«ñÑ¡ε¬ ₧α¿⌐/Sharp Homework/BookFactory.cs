﻿using System.Linq;
using System.Text;
using Main.Utilities;


namespace Sharp_Homework
{
	/// Фабрика для создания книг и всех её частей
	public sealed class BookFactory
	{
		public string CreateAuthor()
		{
			string[] authors =
			{
				"Седельникова В. Е.", "Лебедева З. Ф.", "Конак Е. И.", "Китаев Н. В.",
				"Моренова О. Я.", "Томсин А. Г.", "Зеленин В. Ю.", "Дульцев Л. И."
			};

			return authors[General.Rand.Next(authors.Length)];
		}


		public Book CreateBook() =>
			new()
			{
				Code        = CreateCode(),
				Count       = CreateCount(),
				Author    = CreateAuthor(),
				Title       = CreateTitle(),
				PublishYear = CreatePublishYear()
			};


		public string CreateCode() =>
			Enumerable.Range(0, General.Rand.Next(2, 5))
					  .Aggregate(new StringBuilder(), (builder, _) =>
						  builder.Append((char)General.Rand.Next('A', 'Z' + 1)))
					  .ToString();


		public uint CreateCount() => (uint)General.Rand.Next(100);

		public ushort CreatePublishYear() => (ushort)General.Rand.Next(1400, 3000);


		public string CreateTitle()
		{
			string[] titles =
			{
				"Чистейшая душа", "Начать всё заново", "Вечное счастье", "Мы друзья, верно?",
				"Шрам", "Игра богов", "Реальный человек", "Миры безумия", "Утопая в бездне",
				"Клятва смерти", "Звучанье сердца", "Тайные помыслы", "Тень моей души", "Голод",
				"За гранью: Две Души"
			};

			return titles[General.Rand.Next(titles.Length)];
		}
	}
}