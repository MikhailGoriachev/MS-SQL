﻿using System;
using Main.Utilities.Menu;


namespace Sharp_Homework
{
	public sealed class App : MenuWrapper
	{
		private Controller _controller = new((8, 14));


		public App() =>
			Menu = new Menu("Главное меню приложения", new[]
			{
				new MenuItem("Начальное заполнение коллекции книг", Fill),
				new MenuItem("Вывод коллекции книг", Show),
				new MenuItem("Добавление книги", Add),
				new MenuItem("Изменение количества экземпляров", ChangeCount),
				new MenuItem("Посчитать количество книг для каждого автора", CountAuthorBooks),
				new MenuItem("Удаление книги по коду", RemoveByCode),
				new MenuItem("Выдача сведений о всех книгах, упорядоченных по авторам", OrderByAuthor),
				new MenuItem("Выдача сведений о всех книгах, упорядоченных по годам издания", OrderByPublishYear),
			});


		/// Начальное заполнение коллекции книг (иницализация или генерация – по Вашему выбору)
		private void Fill()
		{
			_controller.Fill();

			_controller.Show();
		}


		private void Show() => _controller.Show();


		/// Добавление данных о книге, вновь поступающей в библиотеку – не вводите с клавиатуры,
		/// формируйте данные книги;
		private void Add()
		{
			var book = new BookFactory().CreateBook();

			Console.WriteLine($"Будет добавлена книга с названием {book.Title}");
			Console.WriteLine($"От автора {book.Title}, год выпуска: {book.PublishYear}, с кодом: {book.Code}\n\n");

			_controller.Add(book);
			_controller.Show(x => x.Equals(book));
		}


		/// Изменения количества экземпляров заданной книги – индекс изменяемой
		/// книги задавайте случайным числом, изменение количества – также случайное число; 
		private void ChangeCount()
		{
			_controller.Show();

			var (old, changed, index) = _controller.ChangeCount();

			Console.WriteLine($"Номер измененной книги: {index + 1}");
			Console.WriteLine($"Старое значение количества: {old}, новое: {changed.Count}");

			_controller.Show(x => x.Equals(changed));
		}


		/// Создать Dictionary<string, int> для пар «автор – суммарное количество книг»
		private void CountAuthorBooks()
		{
			_controller.Show();

			var stats = _controller.CountAuthorBooks();

			var header = $"\n\n{"Автор",-30}\t{"Кол-во книг",-10}";
			Console.WriteLine(header);
			Console.WriteLine(new string('—', header.Length));
			foreach (var stat in stats)
				Console.WriteLine($"{stat.Key,-30}\t{stat.Value,-10}");
			Console.WriteLine("\n\n");
		}


		/// Удаление данных о списываемой книге по коду библиотечного учета, код вводить с клавиатуры;
		private void RemoveByCode()
		{
			_controller.Show();

			Console.Write("Введите код книги: ");
			string code = Console.ReadLine();

			_controller.RemoveByCode(code);
			_controller.Show();
		}


		/// Выдача сведений о всех книгах, упорядоченных по авторам
		private void OrderByAuthor()
		{
			_controller.Sort((lhs, rhs) => string.Compare(lhs.Author, rhs.Author, StringComparison.CurrentCulture));

			_controller.Show();
		}


		/// Выдача сведений о всех книгах, упорядоченных по годам издания
		private void OrderByPublishYear()
		{
			_controller.Sort((lhs, rhs) => lhs.PublishYear.CompareTo(rhs.PublishYear));

			_controller.Show();
		}
	}
}