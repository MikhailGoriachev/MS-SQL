﻿using System;
using System.Text.RegularExpressions;
using Main.Utilities.Guards;


namespace Main.Utilities.TableFormatter
{


	[AttributeUsage(AttributeTargets.Property)]
	public sealed class TableDataAttribute : Attribute
	{
		/// <summary>
		///     Регулярное выражение позволяющие узнать настройки в строке форматирования
		///     Ссылка для демонстрации: https://regex101.com/r/320eqs/3
		/// </summary>
		private static readonly Regex RegexForFormat = new Regex(
			@"^{(?'ArgumentIndex'0),\s?[-]?(?'Width'\d+)[:]?(?'Format'[\w]+[\d]?)?}$",
			RegexOptions.Compiled | RegexOptions.Multiline);
		private static readonly int SpacesAroundColumnName = 2;


		public TableDataAttribute(string columnName, string valuesFormat)
		{
			Guard.Against.NullEmptyWhitespace(columnName, nameof(columnName));
			Guard.Against.NullEmptyWhitespace(valuesFormat, nameof(valuesFormat));

			if (!RegexForFormat.IsMatch(valuesFormat))
				throw new FormatException(
					$"Параметр {nameof(valuesFormat)} обязан представлять действительную строку форматирования!");

			ColumnName = columnName;
			ValuesFormat = valuesFormat;
			WidthOfValueOutput = int.Parse(RegexForFormat.Match(ValuesFormat).Groups["Width"].Value);
		}


		public string ColumnName { get; }
		public string ValuesFormat { get; }
		public int WidthOfValueOutput { get; }
		public int WidthOfColumnName => WidthOfValueOutput + SpacesAroundColumnName;
	}


}
