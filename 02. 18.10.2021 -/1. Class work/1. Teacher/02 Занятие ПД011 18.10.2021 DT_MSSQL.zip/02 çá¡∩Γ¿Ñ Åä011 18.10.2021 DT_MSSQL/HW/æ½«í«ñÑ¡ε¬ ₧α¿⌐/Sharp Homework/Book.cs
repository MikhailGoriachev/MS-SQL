﻿using System;
using Main.Utilities.TableFormatter;


namespace Sharp_Homework
{
	public sealed class Book : IEquatable<Book>
	{
		[TableData("Код", "{0, -9}")]
		public string Code { get; set; }

		[TableData("Название", "{0, -27}")]
		public string Title { get; set; }

		[TableData("Автор", "{0, -25}")]
		public string Author { get; set; }

		[TableData("Год", "{0, -8}")]
		public ushort PublishYear { get; set; }

		[TableData("Количество", "{0, -12}")]
		public uint Count { get; set; }


		public bool Equals(Book other)
		{
			if (ReferenceEquals(null, other))
				return false;
			if (ReferenceEquals(this, other))
				return true;

			var currentCulture = StringComparison.CurrentCulture;

			return string.Equals(Code, other.Code, currentCulture) &&
				   string.Equals(Title, other.Title, currentCulture) &&
				   string.Equals(Author, other.Author, currentCulture) &&
				   PublishYear == other.PublishYear &&
				   Count == other.Count;
		}


		public override bool Equals(object obj) => ReferenceEquals(this, obj) || obj is Book other && Equals(other);
	}
}