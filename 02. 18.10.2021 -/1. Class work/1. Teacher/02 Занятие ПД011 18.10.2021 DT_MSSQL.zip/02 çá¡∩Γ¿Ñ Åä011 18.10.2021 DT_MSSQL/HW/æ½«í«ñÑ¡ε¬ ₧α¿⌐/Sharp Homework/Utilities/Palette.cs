﻿using System;


namespace Main.Utilities
{


	public static class Palette
	{
		public static ConsoleColor DefaultForeground => ConsoleColor.Black;
		public static ConsoleColor DefaultBackground => ConsoleColor.DarkGray;
		public static ConsoleColor DefaultBackgroundDedicated => ConsoleColor.Gray;


		public static Color Default => new Color(DefaultForeground, DefaultBackground);
		public static Color Info => new Color(ConsoleColor.Cyan, DefaultBackground);
		public static Color Error => new Color(ConsoleColor.DarkRed, ConsoleColor.Black);


		public static Color Accent => new Color(ConsoleColor.Green, DefaultBackground);
		public static Color AccentDedicated => new Color(ConsoleColor.Green, DefaultBackgroundDedicated);


		public static Color Secondary => new Color(ConsoleColor.Magenta, DefaultBackground);
		public static Color SecondaryDedicated => new Color(ConsoleColor.Magenta, DefaultBackgroundDedicated);


		public static Color Tertiary => new Color(ConsoleColor.Yellow, DefaultBackground);
		public static Color TertiaryDedicated => new Color(ConsoleColor.DarkYellow, DefaultBackgroundDedicated);
	}


}
