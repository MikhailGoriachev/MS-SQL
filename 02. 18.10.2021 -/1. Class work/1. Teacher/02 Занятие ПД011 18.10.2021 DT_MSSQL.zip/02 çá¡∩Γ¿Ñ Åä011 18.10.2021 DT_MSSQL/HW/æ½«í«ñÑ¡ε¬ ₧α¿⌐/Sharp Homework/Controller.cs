﻿using System;
using System.Collections.Generic;
using Main.Utilities;
using Main.Utilities.TableFormatter;


namespace Sharp_Homework
{
	public sealed class Controller
	{
		private static readonly BookFactory        Factory = new();
		private readonly        List<Book>         _books  = new();
		private readonly        (int min, int max) _sizeRanges;


		public Controller((int min, int max) sizeRanges) => _sizeRanges = sizeRanges;


		public void Fill()
		{
			int size = General.Rand.Next(_sizeRanges.min, _sizeRanges.max);

			_books.Clear();
			for (int i = 0; i < size; i++)
				_books.Add(Factory.CreateBook());
		}


		public void Show() => new TableFormatter<Book>().Show(_books);


		public void Show(Predicate<Book> colorIf) => new TableFormatter<Book>().Show(_books, colorIf);


		public void Add(Book book) => _books.Add(book);


		public (uint old, Book changed, int index) ChangeCount()
		{
			int index = General.Rand.Next(_books.Count);

			uint old = _books[index].Count;
			_books[index].Count = Factory.CreateCount();

			return (old, _books[index], index);
		}


		public Dictionary<string, uint> CountAuthorBooks()
		{
			Dictionary<string, uint> stats = new();

			foreach (var book in _books)
				if (!stats.TryAdd(book.Author, book.Count))
					stats[book.Author] += book.Count;

			return stats;
		}


		public void RemoveByCode(string code)
		{
			int index = _books.FindIndex(x =>
				string.Equals(x.Code, code, StringComparison.CurrentCulture));

			if (index == -1)
				throw new InvalidOperationException("Книга с таким кодом не найдена");

			_books.RemoveAt(index);
		}


		public void Sort(Comparison<Book> comparison) => _books.Sort(comparison);
	}
}