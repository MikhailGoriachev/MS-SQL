﻿namespace Sharp_Homework
{
	internal class Program
	{
		public static void Main(string[] args)
		{
			App app = new();

			app.Run();
		}
	}
}