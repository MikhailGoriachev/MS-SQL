﻿-- 1
-- Выбирает из таблицы Clients все столбцы всех записей
SELECT * FROM Clients


-- 2
-- Выбирает из таблицы Clients информацию о клиентах, 
-- процент скидки для которых находится в диапазоне от 0,3% до 0,5 %
-- (between 0.3 and 0.5)
SELECT * FROM CLIENTS 
WHERE DiscountPercent between 0.3 and 0.5


-- 3
-- Выбирает из таблицы Clients информацию о клиентах с процентом скидки, меньшим 0,3%
-- Выводить идентификатор, фамилию, имя, отчество и процент скидки
SELECT Id, FirstName, Patronymic, DiscountPercent
FROM CLIENTS 
WHERE DiscountPercent < 0.3


-- 4
-- Выбирает из таблицы Clients информацию о клиентах с процентом скидки, большим 0,6%
-- Выводить все поля 
SELECT * FROM Clients
WHERE DiscountPercent > 0.6


-- 5
-- Выбирает из таблицы Clients информацию о клиентах, с годом рождения, большим 2000. 
-- Выводить фамилию, имя, отчество и год рождения 
SELECT Surname, FirstName, Patronymic, BirthYear
FROM Clients
WHERE BirthYear > 2000


-- 6
-- Выбирает из таблицы Clients информацию о клиентах с годом рождения в диапазоне от 1960 до 1996. 
-- Выводить все поля таблицы 
SELECT * FROM Clients
WHERE BirthYear between 1960 and 1996


-- 7
-- Выбирает из таблицы Clients информацию о клиентах, с годом рождения, меньшим 1996. 
-- Выводить идентификатор, фамилию, имя, отчество и год рождения
SELECT Id, Surname, FirstName, Patronymic, BirthYear
FROM Clients
WHERE BirthYear < 1996