﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryTask.Models
{
    // Библиотека имеет название, хранит книги в коллекции List<Book>,
    // реализуеат следующий функционал:
    //     • начальное заполнение коллекции книг
    //     • добавление данных о книге, вновь поступающей в библиотеку
    //     • изменение количества экземпляров заданной книги на заданное число 
    //     • создание Dictionary<string, int> для пар «автор – суммарное 
    //       количество книг»
    //     • удаление данных о списываемой книге по коду библиотечного учета
    //     • сортировка коллекции книг по авторам;
    //     • сортировка коллекции книг по годам издания.
    internal class Library
    {
        // название библиотеки
        private string _name;
        public string Name {
            get => _name;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Library. Пустое название библиотеки недопустимо");

                _name = value;
            } // set
        } // Name

        // коллекция книг
        private List<Book> _books;

        // количество книг в коллекции библиотеки
        public int BookCounter => _books.Count;

        #region конструкторы
        // по умолчанию
        public Library():this("Библиотека им. Н.К. Крупской", new List<Book>()) {
            Initialize();
        } // Library

        // с внедрением зависимостей :)
        public Library(string name, List<Book> books) {
            _name = name;
            _books = books;
        } // Library
        #endregion

        // начальное заполнение коллекции книг - инициализация данных библиотеки
        public void Initialize() {
            _books.Clear();

            _books.AddRange(new[] {
                new Book {Lbc = "32.973.26-018.2",    Author = "Дронов В.А.",     Title = "Laravel. Быстрая разработка веб-сайтов",            Year = 2017, Number = 7},
                new Book {Lbc = "32.973.26-018.2.75", Author = "Зандстра М.",     Title = "PHP: объекты, шаблоны и методики програмиирования", Year = 2015, Number =  6},
                new Book {Lbc = "32.988.02-018.1",    Author = "Никсон Р.",       Title = "Создаем динамически веб-сайты с помощью PHP",       Year = 2016, Number =  1},
                new Book {Lbc = "32.988.02-018",      Author = "Стаффер М.",      Title = "laravel. Полное руководство",                       Year = 2020, Number =  3},
                new Book {Lbc = "32.973.02-018.1",    Author = "Дейтел П.",       Title = "Исусственный интеллект, большие данные",            Year = 2020, Number =  2},
                new Book {Lbc = "32.973.26-018.1",    Author = "Прохоренок Н.А.", Title = "Python 3 и pyQt 5. разработка приложений",          Year = 2016, Number =  3},
                new Book {Lbc = "32.972.26-018.2",    Author = "Уилкс М.",        Title = "Профессиональная разработка на Python",             Year = 2021, Number =  7},
                new Book {Lbc = "32.973.26-018.2",    Author = "Дронов В.А.",     Title = "Стандартная библиотека Python 3",                   Year = 2019, Number = 12},
                new Book {Lbc = "32.974.23-018.9",    Author = "Прохоренок Н.А.", Title = "Unity и C#. Геймдев: от идеи до реализации",        Year = 2019, Number =  4},
                new Book {Lbc = "32.973.02-018",      Author = "Хокинг Дж.",      Title = "Unity. Мультиплатформенная обработка на C#",        Year = 2016, Number =  8},
                new Book {Lbc = "32.973.26-028.2",    Author = "Никсон Р.",       Title = "Сюрреализм на JavaScript",                          Year = 2014, Number =  2},
                new Book {Lbc = "32.988.02-018.2",    Author = "Дейтел П.",       Title = "Веб-разработка с применением Node и Express",       Year = 2017, Number = 23}
            });
        } // Initialize


        // вывод коллекции книг в табличном формате
        public void Show(string title, int indent) {
            Console.Write($"{title}\"{Name}\"\n{Book.Header(indent)}");

            foreach (var book in _books) {
                Console.WriteLine(book.ToTableRow(indent));
            } // foreach

            Console.Write(Book.Footer(indent));
        } // Show

        // добавление данных о книге, вновь поступающей в библиотеку
        public void AddBook(Book book) => _books.Add(book);


        // изменение количества экземпляров заданной книги на заданное число 
        public void BookNumberModify(int index, int value) {
            Book book = _books[index];
            book.Number = value;
            _books[index] = book;
        } // BookNumberModify


        // создание Dictionary<string, int> для пар «автор – суммарное 
        // количество книг»
        public Dictionary<string, int> ReportAuthorBooks() {
            var report = new Dictionary<string, int>();

            foreach (var book in _books) {
                if (report.ContainsKey(book.Author))
                    report[book.Author] += book.Number;
                else
                    report[book.Author] = book.Number;
            } // foreach

            return report;
        } // ReportAuthorBooks


        // удаление данных о списываемой книге по коду библиотечного учета
        public void RemoveByLbc(string lbc) =>
            _books.RemoveAll(b => b.Lbc == lbc);


        // сортировка коллекции книг по авторам;
        public void OrderByAuthor() => _books.Sort((b1, b2) => 
            b1.Author.CompareTo(b2.Author));


        // сортировка коллекции книг по годам издания.
        public void OrderByYear() => _books.Sort((b1, b2) =>
            b1.Year.CompareTo(b2.Year));

    } // class Library


}
