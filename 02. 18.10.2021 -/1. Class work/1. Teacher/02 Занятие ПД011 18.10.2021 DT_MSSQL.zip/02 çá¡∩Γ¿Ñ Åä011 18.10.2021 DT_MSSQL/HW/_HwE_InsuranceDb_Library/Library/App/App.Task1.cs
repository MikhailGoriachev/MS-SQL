﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

using LibraryTask.Helpers;
using LibraryTask.Models;

namespace LibraryTask.App
{
    /*
     * Методы для решения задачи 1 
     */
    internal partial class Application
    {
        // Начальное заполнение коллекции книг
        public void InitializeAndShow() {
            Utils.ShowNavBarTask("  Начальное заполнение коллекции книг, вывод данных библиотеки");

            _library.Initialize();
            _library.Show("\n\n\n\n\t    Данные сформированы. ", 12);
        } // InitializeAndShow


        // Вывод коллекции книг в консоль        
        public void Show() {
            Utils.ShowNavBarTask("  Вывод коллекции книг библиотеки в консоль");

            _library.Show("\n\n\n\n\t    Данные сформированы. ", 12);
        } // Show


        // Добавление данных о книге, вновь поступающей в библиотеку
        public void AddBookToLibrary() {
            Utils.ShowNavBarTask("  Добавление данных о книге, вновь поступающей в библиотеку");

            // задаем значения свойствам конструктором по умолчанию, меням
            // свойства Year, Number
            Book book = new Book() {
                Year = Utils.GetRandom(2012, DateTime.Now.Year),
                Number = Utils.GetRandom(3, 12)
            };

            _library.AddBook(book);

            // показать измененную коллекцию
            _library.Show("\n\n\n\n\t    Книга добавлена в конец коллекции. ", 12);
        } // AddBookToLibrary

        // Изменение количества экземпляров заданной книги на заданное число
        public void UpdateBookNumber() {
            Utils.ShowNavBarTask("  Изменение количества экземпляров заданной книги на заданное число");

            int index = Utils.GetRandom(0, _library.BookCounter - 1);
            int value = Utils.GetRandom(1, 22);
            _library.BookNumberModify(index, value);

            _library.Show($"\n\n\n\n\t    Количество книг с индексом {index} изменено. ", 12);
        } // UpdateBookNumber


        // Вывод суммарного количества книг авторов в библиотеке
        public void ReportBooksNumberByAuthor() {
            Utils.ShowNavBarTask("  Вывод суммарного количества книг авторов в библиотеке");

            string sp = " ".PadRight(12);
            Dictionary<string, int> report = _library.ReportAuthorBooks();

            Console.Write(
                $"\n\n\n\n\t      Суммарное количестов книг авторов\n" +
                $"{sp}┌──────────────────────┬────────────┐\n" +
                $"{sp}│ Автор                │ Количество │\n" +
                $"{sp}├──────────────────────┼────────────┤\n");

            foreach (var key in report.Keys) {
                Console.WriteLine($"{sp}│ {key, -20} │ {report[key], 6:f0}     │");
            } // foreach

            Console.WriteLine($"{sp}└──────────────────────┴────────────┘");
        } // ReportBooksNumberByAuthor


        // Удаление данных о списываемой книге по коду библиотечного учета
        public void RemoveBookByLbc() {
            Utils.ShowNavBarTask("  Удаление данных о списываемой книге/книгах по коду библиотечного учета");
            
            _library.Show("\n\n\n\n\t    Данные для удаления. ", 12);

            Console.Write("\n\n\t    Введите ББК для удаления: ");
            string lbc = Console.ReadLine();

            // собственно удаление
            _library.RemoveByLbc(lbc);
            
            // выводим те книги, что остались в коллекции
            Console.Clear();
            Utils.ShowNavBarTask("  Удаление данных о списываемой книге по коду библиотечного учета");
            _library.Show($"\n\n\n\n\t    Книга/книги с ББК {lbc} удалены", 12);
        } // RemoveBookByLbc


        // Сортировка коллекции книг по авторам
        public void OrderBooksByAuthor() {
            Utils.ShowNavBarTask("  Сортировка коллекции книг по авторам");
        
            _library.OrderByAuthor();
            _library.Show($"\n\n\n\n\t    Книги отсортированы по автору. ", 12);
        } // OrderBooksByAuthor


        // Сортировка коллекции книг по годам издания
        public void OrderBooksByYear() {
            Utils.ShowNavBarTask("  Сортировка коллекции книг по годам издания");

            _library.OrderByYear();
            _library.Show($"\n\n\n\n\t    Книги отсортированы по году издания. ", 12);
        } // OrderBooksByAuthor
    } // class Application
}