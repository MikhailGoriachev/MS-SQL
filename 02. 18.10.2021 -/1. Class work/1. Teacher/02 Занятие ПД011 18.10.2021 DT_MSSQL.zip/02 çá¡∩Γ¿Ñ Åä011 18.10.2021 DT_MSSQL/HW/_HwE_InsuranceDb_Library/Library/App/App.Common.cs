﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

using LibraryTask.Helpers;
using LibraryTask.Models;

namespace LibraryTask.App
{
    // Общая часть приложения, создание объекта для выполнения задания
    internal partial class Application
    {
        // объект для обработки
        private Library _library;

        public Application() : this(new Library()) { } // Application

        public Application(Library library) {
            _library = library;
        } // Application
    } // class Application
}
