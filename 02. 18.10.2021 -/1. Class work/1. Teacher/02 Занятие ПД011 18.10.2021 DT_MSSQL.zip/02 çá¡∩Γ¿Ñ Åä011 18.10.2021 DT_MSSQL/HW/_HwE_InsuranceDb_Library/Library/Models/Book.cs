﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryTask.Models
{
    // Сведения о книге: фамилия и инициалы автора, название, год издания,
    // количество экземпляров данной книги в библиотеке, код библиотечного
    // учета (ББК)
    internal class Book
    {
        // фамилия и инициалы автора книги
        private string _author;
        public string Author {
            get => _author;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Books. Пустое имя  автора недопустимо");

                _author = value;
            } // set
        } // Author

        // название книги
        private string _title;
        public string Title {
            get => _title;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Books. Пустое название книги недопустимо");

                _title = value;
            } // set
        } // Title

        // год издания книги
        private int _year;
        public int Year {
            get => _year;
            set {
                if (value < 0 || value > DateTime.Now.Year)
                    throw new ArgumentException("Books. Некорректный год издания");

                _year = value;
            } // set
        } // Year

        // количество экземпляров книги в библиотеке
        private int _number;
        public int Number {
            get => _number;
            set {
                if (value < 0)
                    throw new ArgumentException("Books. Некорректное количество книг");

                _number = value;
            } // set
        } // Number

        // код библиотечного учета (ББК) книги
        private string _lbc;
        public string Lbc {
            get => _lbc;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Books. Пустой код ББК недопустим");

                _lbc = value;
            } // set
        } // Lbc


        #region Конструкторы

        public Book():this("Веллинг Л.", "Разработка веб-приложений с помощью PHP и MySQL",
            2017, 12, "32.973.2-018.2.75") { } // Book

        public Book(string author, string title, int year, int number, string lbc) {
            Author = author;
            Title = title;
            Year = year;
            Number = number;
            Lbc = lbc;
        } // Book

        #endregion

        // строковое представление объекта
        public override string ToString() =>
            $"{_lbc}, {_author} - {_title} - {_year}, {_number} экз.";


        // формирование строки таблицы
        public string ToTableRow(int indent) =>
            $"{" ".PadRight(indent)}" +
            $"│ {_lbc, -20} " +
            $"│ {_author,-20} " +
            // если длина названия превышает 40 символов, выводим первые 37 символов
            // и затем троеточие
            $"│ {$"{(_title.Length <= 40?_title:_title.Substring(0, 37) + "...")}", -40} " +
            $"│ {_year, 4:f0} " +
            $"│ {_number, 6:n0}     │";


        // шапка таблицы, статическое свойство
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            return
                $"{spaces}┌──────────────────────┬──────────────────────┬──────────────────────────────────────────┬──────┬────────────┐\n" +
                $"{spaces}│ Код ББК              │ Автор                │ Название книги                           │ Год  │ Количество │\n" +
                $"{spaces}├──────────────────────┼──────────────────────┼──────────────────────────────────────────┼──────┼────────────┤\n";
        } // Header

        // подвал таблицы, статическое свойство
        public static string Footer(int indent) {
            string spaces = " ".PadRight(indent);
            return
                $"{spaces}└──────────────────────┴──────────────────────┴──────────────────────────────────────────┴──────┴────────────┘\n";
        } // Footer
    } // class Book
}
