﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;

using LibraryTask.Helpers;
using LibraryTask.App;


/*
 * Разработайте консольное приложение для учета книг в библиотеке. Сведения
 * о книгах содержат: фамилию и инициалы автора, название, год издания,
 * количество экземпляров данной книги в библиотеке, код библиотечного учета
 * (ББК).
 * Требуется хранить книги в коллекции List<Book>, реализовать следующий
 * функционал:
 *     • Начальное заполнение коллекции книг (иницализация или генерация – по
 *       Вашему выбору)
 *     • добавление данных о книге, вновь поступающей в библиотеку – не вводите
 *       с клавиатуры, формируйте данные книги;
 *     • изменения количества экземпляров заданной книги – индекс изменяемой
 *       книги задавайте случайным числом, изменение количества – также
 *       случайное число; 
 *     • создать Dictionary<string, int> для пар «автор – суммарное количество
 *       книг»
 *     • удаление данных о списываемой книге по коду библиотечного учета, код
 *       вводить с клавиатуры;
 *     • выдача сведений о всех книгах, упорядоченных по авторам;
 *     • выдача сведений о всех книгах, упорядоченных по годам издания.
 *
 */
namespace LibraryTask
{
    class Program
    {
        static void Main(string[] args) {
            Console.Title = "Задание на 18.10.2021 - обработка обобщенных коллекций в C#";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem {HotKey = ConsoleKey.Q, Text = "Начальное заполнение коллекции книг"},
                new MenuItem {HotKey = ConsoleKey.W, Text = "Вывод коллекции книг в консоль"},
                new MenuItem {HotKey = ConsoleKey.E, Text = "Добавление данных о книге, вновь поступающей в библиотеку"},
                new MenuItem {HotKey = ConsoleKey.R, Text = "Изменение количества экземпляров заданной книги на заданное число"},
                new MenuItem {HotKey = ConsoleKey.T, Text = "Вывод суммарного количества книг авторов в библиотеке"},
                new MenuItem {HotKey = ConsoleKey.Y, Text = "Удаление данных о списываемой книге по коду библиотечного учета"},
                new MenuItem {HotKey = ConsoleKey.U, Text = "Сортировка коллекции книг по авторам"},
                new MenuItem {HotKey = ConsoleKey.I, Text = "Сортировка коллекции книг по годам издания"},
                //----------------------------------------------------------------------------------------------
                new MenuItem {HotKey = ConsoleKey.Z, Text = "Выход"},
            };

            // Создание экземпляра класса приложения
            Application app = new Application();

            // главный цикл приложения
            while (true) {
                try {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  ООП C# - обобощенные коллекции");
                    Utils.ShowMenu(12, 5, "Меню приложения для демонстрации работы с обобщенными коллекциями в C#", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg =
                        "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch (key)
                    {

                        // начальное заполнение коллекции книг
                        case ConsoleKey.Q:
                            app.InitializeAndShow();
                            break;

                        // вывод коллекции книг в консоль
                        case ConsoleKey.W:
                            app.Show();
                            break;

                        // добавление данных о книге, вновь поступающей в библиотеку
                        case ConsoleKey.E:
                            app.AddBookToLibrary();
                            break;

                        // изменение количества экземпляров заданной книги на заданное число 
                        case ConsoleKey.R:
                            app.UpdateBookNumber();
                            break;

                        // вывод суммарного количества книг авторов в библиотеке
                        case ConsoleKey.T:
                            app.ReportBooksNumberByAuthor();
                            break;


                        // удаление данных о списываемой книге по коду библиотечного учета
                        case ConsoleKey.Y:
                            app.RemoveBookByLbc();
                            break;

                        // сортировка коллекции книг по авторам
                        case ConsoleKey.U:
                            app.OrderBooksByAuthor();
                            break;

                        // сортировка коллекции книг по годам издания
                        case ConsoleKey.I:
                            app.OrderBooksByYear();
                            break;

                        // Выход из приложения назначен на клавишу F10 или клавишу M или клавишу Escape
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor(); // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                } // try

                // обработка исключений - просто вывести сообщение
                catch (Exception ex)
                {
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                } // try-catch
            } // while
        } // Main
    }
}
