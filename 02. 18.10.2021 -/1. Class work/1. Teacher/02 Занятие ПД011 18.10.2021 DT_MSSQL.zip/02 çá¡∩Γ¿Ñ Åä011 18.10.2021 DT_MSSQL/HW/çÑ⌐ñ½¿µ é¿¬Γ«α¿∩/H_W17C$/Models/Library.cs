﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W17C_.Models
{
    // класс библиотека для хранения данных о книгах
    internal class Library
    {
        List<Book> _books;

        public Library()
        {
            Inizialize();
        }

        public Library(List<Book> books)
        {
            _books = books;
        }

        public void Inizialize() {
            _books = new List<Book>(new[] {
                new Book { FullNameAuthor = "Харт Д., Стеллмен Э.", NameBook = "Head First C#",                  Year = 2020, NumCopyBook = 2, BBK = "22.1с7"}, 
                new Book { FullNameAuthor = "Игорь Савчук",         NameBook = "Отъявленный программист",        Year = 2016, NumCopyBook = 1, BBK = "22.1у5"}, 
                new Book { FullNameAuthor = "Кристофер Вильсон",    NameBook = "The Clean Arhchitecture in PHP", Year = 2015, NumCopyBook = 4, BBK = "22.1л0"}, 
                new Book { FullNameAuthor = "Томас Х.Кормен",       NameBook = "Алгоритмы.Построение и анализ",  Year = 1989, NumCopyBook = 3, BBK = "2ф2.18"}, 
                new Book { FullNameAuthor = "Герберт Шилтд",        NameBook = "C#.Учебный курс",                Year = 2003, NumCopyBook = 1, BBK = "22.6я9"}, 
                new Book { FullNameAuthor = "Яцек Галовиц",         NameBook = "С++17 STL",                      Year = 2018, NumCopyBook = 3, BBK = "2м2.14"}, 
                new Book { FullNameAuthor = "Кузнецов М.В.",        NameBook = "MySQL 5",                        Year = 2010, NumCopyBook = 2, BBK = "22.19"}, 
                new Book { FullNameAuthor = "Алан Бьюли",           NameBook = "Изучаем SQL",                    Year = 2007, NumCopyBook = 1, BBK = "22.1р3"} 

            });

        }// Inizialize

        public IEnumerable<Book> GetAllBooks
        {
            get {
                return _books;
            }
        }// GetAllBooks

        public void AddBook(Book b) => _books.Add(b);

        // индексатор 
        public Book this[int index]
        {
            get {
                if (index < 0 || index >= _books.Count)
                    throw new Exception("Library: Попытка обращения за пределы списка");

                return _books[index];
            } // Аксессор.

            set {
                if (index < 0 || index >= _books.Count)
                    throw new Exception("Library: Попытка обращения за пределы списка");

                _books[index] = value;
            } // Мутатор
        }

        // изменения количества экземпляров заданной книги
        public void ChangeCopiesBookInLibrary()
        {
            //Hashtable ht = new Hashtable();


        }// ChangeCopiesBookInLibrary

        // создать Dictionary<string, int> для пар «автор – суммарное количество книг»
        public void DemoDictionary()
        {
            Dictionary<string, int> obj = new Dictionary<string, int>();
            foreach(var item in _books) {
                obj.Add(item.FullNameAuthor, item.NumCopyBook);
            }
            foreach(var item in obj) {
                Console.WriteLine($" Автор : {item.Key, -22}, количество книг :{item.Value, 4}");
            }
        }// DemoDictionary

        // удаление данных о списываемой книге по коду библиотечного учета
        public void RemoveByCodeLibraryBook(string str)
        {
            bool Match(Book b) => b.PredicateBBK(str);

            _books.RemoveAll(Match);
        }// RemoveByCodeLibraryBook

        // выдача сведений о всех книгах, упорядоченных по авторам
        public void SortByName()
        {
            _books.Sort((b1, b2) => b1.FullNameAuthor.CompareTo(b2.FullNameAuthor));
        }// SortByName

        // выдача сведений о всех книгах, упорядоченных по годам издания.
        public void SortByYearPublishing()
        {
            _books.Sort((b1, b2) => b1.Year.CompareTo(b2.Year));
        }// SortByYearPublishing


    }// class Library
}
