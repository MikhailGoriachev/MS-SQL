﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W17C_.Models
{
    /// <summary>
    ///  Задача 1. Разработайте консольное приложение для учета книг в библиотеке.
    /// Сведения о книгах содержат: фамилию и инициалы автора, название, год издания,
    /// количество экземпляров данной книги в библиотеке, код библиотечного учета (ББК).
    ///  Требуется хранить книги в коллекции List<Book>, реализовать следующий функционал:
    /// •	Начальное заполнение коллекции книг (иницализация или генерация – по Вашему выбору)
    /// •	добавление данных о книге, вновь поступающей в библиотеку –
    /// не вводите с клавиатуры, формируйте данные книги;
    /// •	изменения количества экземпляров заданной книги –
    /// индекс изменяемой книги задавайте случайным числом,
    /// изменение количества – также случайное число; 
    /// •	создать Dictionary<string, int> для пар «автор – суммарное количество книг»
    /// •	удаление данных о списываемой книге по коду библиотечного учета,
    /// код вводить с клавиатуры;
    /// •	выдача сведений о всех книгах, упорядоченных по авторам;
    /// •	выдача сведений о всех книгах, упорядоченных по годам издания.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {

            Console.Title = "Домашнее задание № 17.";
            try
            {
                // меню приложения
                MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Начальное заполнение коллекции книг." },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Добавление данных о книге, поступающей в библиотеку." },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Изменения количества экземпляров заданной книги." },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Создать Dictionary для пар «автор – суммарное количество книг»" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Удаление данных о списываемой книге по коду библиотечного учета." },
                new MenuItem { HotKey = ConsoleKey.Y, Text = "Упорядочивание всех книг по авторам." },
                new MenuItem { HotKey = ConsoleKey.U, Text = "Упорядочивание всех книг по годам издания." },
                new MenuItem { HotKey = ConsoleKey.Escape, Text = "Выход" },
            };

                // Создание экземпляра класса приложения
                App app = new App();

                // главный цикл приложения
                while (true)
                {
                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.BackgroundColor = ConsoleColor.DarkCyan;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowMenu(25, 5, "Меню приложения : ", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key)
                    {
                        // Начальное заполнение коллекции книг
                        case ConsoleKey.Q:
                            app.InizializeCollection();
                            break;

                        // Добавление данных о книге, поступающей в библиотеку
                        case ConsoleKey.W:
                            app.AppendBookInLibrary();
                            break;

                        // Изменения количества экземпляров заданной книги
                        case ConsoleKey.E:
                            app.ChangeCopiesBook();
                            break;

                        // Создать Dictionary для пар «автор – суммарное количество книг»
                        case ConsoleKey.R:
                            app.ShowDictionary();
                            break;

                        // Удаление данных о списываемой книге по коду библиотечного учета
                        case ConsoleKey.T:
                             app.RemoveBookByBBK();
                            break;

                        // Упорядочивание всех книг по авторам
                        case ConsoleKey.Y:
                             app.SortLibraryBookByNameAutor();
                            break;

                        // Упорядочивание всех книг по годам издания
                        case ConsoleKey.U:
                             app.SortLibraryBookByYearPublishing();
                            break;

                        // Выход клавиша Esc
                        case ConsoleKey.Escape:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.White);
                            Console.CursorVisible = true;
                            return;
                        default:
                            continue;
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.White);
                    Console.ReadKey(true);
                } // while

            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine($"\n{ex.Message}");
                //throw;
            }
            finally
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nКод финализации");
                Console.ForegroundColor = ConsoleColor.Gray;
            }// try- catch- finally
            Console.ForegroundColor = ConsoleColor.White;
        }// Main
    }// class Program
}
