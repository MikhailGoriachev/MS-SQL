﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace H_W17C_.Models
{
    internal class App
    {
        
        Func<Book, string> outItem = t => $"{t}\n"; 
        Library  _books;
        
        
        // конструктор по умолчанию
        public App() : this(new Library()) { }

        // конструктор с внедрением зависимостей
        public App(Library books)
        {
            _books = books;
        } // App

        // Начальное заполнение коллекции книг
        public void InizializeCollection()
        {
            Utils.ShowNavBarTask("   Начальное формирование библиотеки книг");
  
            _books.Inizialize();
            Show("\n\t\t\tДанные сформированы:\n", _books.GetAllBooks, outItem);

        }// InizializeCollection

        // Добавление данных о книге, поступающей в библиотеку
        public void AppendBookInLibrary()
        {
            Utils.ShowNavBarTask("   Добавление данных о книге, вновь поступающей в библиотеку");

            _books.AddBook(new Book { FullNameAuthor = "Мэтью Макдональд", NameBook = "Pro WPF in C# 2008", Year = 2008, NumCopyBook = 1, BBK = "22.17" });
            Show("\n\t\tКнига добавлена в библиотеку:\n", _books.GetAllBooks, outItem);

        }// AppendBookInLibrary

        // Изменения количества экземпляров заданной книги
        public void ChangeCopiesBook()
        {
            Utils.ShowNavBarTask("   Изменения количества экземпляров заданной книги");
            //_books.ChangeCopiesBookInLibrary();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n\n\t\t\t Метод в разработке....\n");
            Console.ForegroundColor = ConsoleColor.Gray;
        }// ChangeCopiesBook

        // Создать Dictionary для пар «автор – суммарное количество книг»
        public void ShowDictionary()
        {
            Utils.ShowNavBarTask("   Создать Dictionary для пар «автор – суммарное количество книг»");

            Console.WriteLine("\n\n Пара : «автор – суммарное количество книг»\n");
            _books.DemoDictionary();
        }// ShowDictionary

        // Удаление данных о списываемой книге по коду библиотечного учета
        public void RemoveBookByBBK()
        {
            Utils.ShowNavBarTask("   Удаление данных о списываемой книге по коду библиотечного учета");

            Show("\t\t\tБиблиотека книг:\n", _books.GetAllBooks, outItem);
            
            Console.Write("   Введите код библиотечного учета  ");
            Console.CursorVisible = true;
            string str = Console.ReadLine();
            Console.CursorVisible = false;

            _books.RemoveByCodeLibraryBook(str);
            Show("\t\tБиблиотека после удаления данных о книге:\n", _books.GetAllBooks, outItem);
        }// RemoveBookByBBK

        // Упорядочивание всех книг по авторам
        public void SortLibraryBookByNameAutor()
        {
            Utils.ShowNavBarTask("   Упорядочивание всех книг по авторам");

            _books.SortByName();
            Show("\n\t\tКниги упорядочены по авторам:\n", _books.GetAllBooks, outItem);
        }// SortLibraryBookByNameAutor

        // Упорядочивание всех книг по годам издания
        public void SortLibraryBookByYearPublishing()
        {
            Utils.ShowNavBarTask("   Упорядочивание всех книг по годам издания");

            _books.SortByYearPublishing();
            Show("\n\t\tКниги упорядочены по годам издания:\n", _books.GetAllBooks, outItem);
        }// SortLibraryBookByYearPublishing

        // Вывод коллекции
        public static void Show<T>(string title, IEnumerable<T> items, Func<T, string> outItem)
        {
            // собрать строку и вывести в консоль
            StringBuilder sb = new StringBuilder($"\n\n{title}\n{Book.Header()}");

            foreach (var item in items)
            {
                sb.Append(outItem(item));
            } // foreach

            //Console.WriteLine(sb);
            Console.WriteLine(sb.Append($"{Book.Footer()}\n").ToString());
        } // Show

    }// class App
}
