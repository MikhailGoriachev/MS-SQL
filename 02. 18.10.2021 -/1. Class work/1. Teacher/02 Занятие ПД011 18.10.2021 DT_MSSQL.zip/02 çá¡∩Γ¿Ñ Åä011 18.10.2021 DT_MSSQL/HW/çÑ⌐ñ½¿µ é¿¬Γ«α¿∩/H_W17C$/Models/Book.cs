﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W17C_.Models
{   
    // Сведения о книгах содержат:
    // * фамилию и инициалы автора,
    // * название,
    // * год издания,
    // * количество экземпляров данной книги в библиотеке,
    // * код библиотечного учета (ББК).
    internal class Book
    {
        // фамилию и инициалы автора
        private string _fullNameAuthor;
        public string FullNameAuthor
        {
            get => _fullNameAuthor;
            set {
               if (string.IsNullOrWhiteSpace(value))
                   throw new Exception("Book: Некорректное ФИО автора");
                _fullNameAuthor = value;
            }
        }// FullNameAuthor

        // название книги
        private string _nameBook;
        public string NameBook
        {
            get => _nameBook;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Book: Некорректное название книги");
                _nameBook = value;
            }
        }// NameBook

        // год издания книги
        private int _year;
        public int Year
        {
            get => _year;
            set {
                if (value <= 0)
                    throw new Exception("Book: Некорректное значение года издания книги");
                _year = value;
            }
        }// Year

        // количество экземпляров книги в библиотеке
        private int _numCopyBook;
        public int NumCopyBook
        {
            get => _numCopyBook;
            set {
                if (value <= 0)
                    throw new Exception("Book: Некорректное значение для количества экземпляров данной книги");
                _numCopyBook = value;
            }
        }// NumCopyBook

        // код библиотечного учета (ББК)
        private string _codeLibraryBook;
        public string BBK
        {
            get => _codeLibraryBook;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Book: Некорректный код библиотечного учета");
                _codeLibraryBook = value;
            }
        }// BBK

        public bool PredicateBBK(string str)
        { 
             foreach (var item in _codeLibraryBook) {
                  if (item.Equals(BBK) == str.Equals(BBK)) return false;
             }

             return true;
        }// PredicateBBK


        public static string Header()
        {
            return
            $" ┌──────────────────────┬────────────────────────────────┬─────────┬─────────────┬───────────┐\n" +
            $" │   ФИО автора         │         Название               │   Год   │ Количество  │ Код библ. │\n" +
            $" │              книги   │                  книги         │ издания │ экземпляров │   учёта   │\n" +
            $" ├──────────────────────┼────────────────────────────────┼─────────┼─────────────┼───────────┤\n";
        } // Header

        // Подвал таблицы, статическое свойство
        public static string Footer() =>
            $" └──────────────────────┴────────────────────────────────┴─────────┴─────────────┴───────────┘\n";

        // вывод в табличном формате
        public string ToTableRow(int row) =>
            $" │ {row,5} │ {FullNameAuthor,-20} │ {NameBook,-30} │ {Year,7} │ {NumCopyBook,11} │ {BBK,9} │";


        public override string ToString() =>
            $" │ {FullNameAuthor,-20} │ {NameBook,-30} │ {Year,7} │ {NumCopyBook,11} │ {BBK,9} │";
        
        
    }// class Book
}
