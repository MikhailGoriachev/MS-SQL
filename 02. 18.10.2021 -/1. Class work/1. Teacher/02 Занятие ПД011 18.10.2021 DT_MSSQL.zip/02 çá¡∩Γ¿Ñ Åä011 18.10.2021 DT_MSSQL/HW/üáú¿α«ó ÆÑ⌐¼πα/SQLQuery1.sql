﻿
--						Запрос №1 
--   Выбирает из таблицы Clients все столбцы всех записей
select * from Clients

--						Запрос №2 
--   Выбирает из таблицы Clients информацию о клиентах,
--   процент скидки для которых находится в диапазоне от 0,3% до 0,5%
select
	* 
from
    Clients
where
	DiscountPercentage between 0.3 and 0.5

--						Запрос №3 
--   Выбирает из таблицы Clients информацию о клиентах с процентом скидки, меньшим 0,3%
--   Выводить идентификатор, фамилию, имя, отчество и процент скидки
select
	Surname,
	Name,
	Patronymic,
	DiscountPercentage
from
	Clients
where 
	DiscountPercentage < 0.3

--						Запрос №4 
--   Выбирает из таблицы Clients информацию о клиентах с процентом скидки, большим 0,6%
--								Выводить все поля
select
	*
from 
	Clients
where DiscountPercentage > 0.6

--						Запрос №5 
--  Выбирает из таблицы Clients информацию о клиентах, с годом рождения, большим 2000.
--	Выводить фамилию, имя, отчество и год рождения 
select
	Surname,
	Name,
	Patronymic,
	YearBirth
from
	Clients
where
	YearBirth > 2000

--						Запрос №6 
--  Выбирает из таблицы Clients информацию о клиентах с годом рождения в диапазоне от 1960 до 1996. 
--					Выводить все поля таблицы 
select 
	*
from
	Clients
where
	YearBirth between 1960 and 1996

--						Запрос №7 
--  Выбирает из таблицы Clients информацию о клиентах, с годом рождения, меньшим 1996.
--  Выводить идентификатор, фамилию, имя, отчество и год рождения
select
	id,
	Surname,
	Name,
	Patronymic,
	YearBirth
from
	Clients
where
	YearBirth < 1996
