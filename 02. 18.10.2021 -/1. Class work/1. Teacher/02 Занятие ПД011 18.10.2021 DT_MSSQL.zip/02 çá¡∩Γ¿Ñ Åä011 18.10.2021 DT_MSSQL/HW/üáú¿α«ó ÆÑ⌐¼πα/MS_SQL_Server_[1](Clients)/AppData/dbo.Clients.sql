﻿CREATE TABLE [dbo].[Clients] (
    [Id]                 INT       NOT NULL PRIMARY KEY IDENTITY,
    [Surname]            NVARCHAR (50) NOT NULL,
    [Name]               NVARCHAR (40) NOT NULL,
    [Patronymic]         NVARCHAR (60) NOT NULL,
    [YearBirth]          INT           NOT NULL,
    [DiscountPercentage] FLOAT     NOT NULL DEFAULT 0
  
);

