﻿
--Выбор всех столбцов всех записей
select
	*
from
	Clients;

-- Процент скидки от 0,3 до 0,5
select
	*
from 
	Clients
where
	Discount between 0.3 and 0.5;

-- Процент скидки меньше 0,3
select
	Id
	, Surname
	, Name
	, Patronymic
	, Discount
from 
	Clients
where
	Discount < 0.3;

-- процент скидки > 0,6
select
	*
from 
	Clients
where 
	Discount > 0.6;

-- год рождения больше 2000
select
	Surname
	, Name
	, Patronymic
	, YearOfBirth
from
	Clients
where
	YearOfBirth > 2000;

-- год рождения от 1960 до 1996
select 
	*
from
	Clients
where
	YearOfBirth between 1960 and 1996;

-- год рождения меньше 1996
select
	Id
	, Surname
	, Name
	, Patronymic
	, YearOfBirth
from
	Clients
where
	YearOfBirth < 1996;
	