﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_17.Models
{
    class Book
    {
        public string _fullName { get; set; }
        public string _nameBook { get; set; }
        public int _year{ get; set; }
        public int _count { get; set; }
        public int _code { get; set; }


        public override string ToString() =>
            $"ФИО: {_fullName,-22} Название книги: {_nameBook,-22} Год издания: {_year,4}  Количество: {_count,3} Код: {_code,4}";

    }
}
