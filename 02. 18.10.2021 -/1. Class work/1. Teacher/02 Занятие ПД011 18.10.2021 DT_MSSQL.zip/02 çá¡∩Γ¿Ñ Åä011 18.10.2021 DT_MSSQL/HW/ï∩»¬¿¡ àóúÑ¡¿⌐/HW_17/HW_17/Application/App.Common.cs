﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW_17.Models;
using HW_17.Helpers;

namespace HW_17.Application
{

    public class App_Common
    {
        List<Book> _books { get; set; }


        public void Show() 
        {
            if (_books == null)
            {
                Console.WriteLine("Пусто!");
                return;
            }

            foreach (var item in _books)
                Console.WriteLine(item);
        }
        
        //создание и вывод коллекции
        public void Initialization() 
        {

            _books = new List<Book>() 
            {
               new Book{ _fullName = "Рей Брэдбери",            _nameBook = "Вино из одуванчиков",             _year = 1957,    _count = 4, _code = 2},
               new Book{ _fullName = "Харпер Ли",               _nameBook = "Убить пересмешника",              _year = 1960,    _count = 6, _code = 3},
               new Book{ _fullName = "Эрих Мария Ремарк",       _nameBook = "Жизнь взаймы",                    _year = 1959,    _count = 3, _code = 4},
               new Book{ _fullName = "Маркус Зусак",            _nameBook = "Книжный вор",                     _year = 2005,    _count = 9, _code = 5},
               new Book{ _fullName = "Уильям Голдинг",          _nameBook = "Повелитель мух",                  _year = 1954,    _count = 5, _code = 6},
               new Book{ _fullName = "Колин Маккалоу",          _nameBook = "Поющие в терновнике",             _year = 1977,    _count = 7, _code = 8},
               new Book{ _fullName = "Стивен Кинг",             _nameBook = "11/22/63",                        _year = 2011,    _count = 8, _code = 9},
               new Book{ _fullName = "Габриэль Гарсиа Маркес",  _nameBook = "Сто лет одиночества",             _year = 1967,    _count = 4, _code = 11},
               new Book{ _fullName = "Энди Вейер",              _nameBook = "Марсианин",                       _year = 2011,    _count = 9, _code = 12}
            };

            Show();
        }

        //добавление данных книги
        public void AddBook() 
        {
            if (_books == null)
            {
                Console.WriteLine("Принициализируйте коллекцию");
                return;
            }

            Console.WriteLine("Данные до изменения: \n");
            Show();

            Book book = new Book { _fullName = "Test", _nameBook = "Test", _year = 1111, _count = 99, _code = 99 };

            Console.WriteLine($"\nДобавлена книга:\n {book}\n\n");

            _books.Add(book);

            Console.WriteLine("Данные после изменения: \n");
            Show();
        }

        //изменение количества заданной книги
        public void ChageBook() 
        {
            if (_books == null)
            {
                Console.WriteLine("Принициализируйте коллекцию");
                return;
            }

            Console.WriteLine("Данные до изменения: \n");
            Show();

            int index = Utils.Random.Next(0, 8);
            int count = Utils.Random.Next(1, 10);

            _books[index]._count = count;

            Console.WriteLine($"\nИзмененный элемент: \n{_books[index]}\n Новое количество книг: {count}");

            Console.WriteLine("\nДанные после изменения: \n");
            Show();

        }

        //создание Dictionary<sting, int> - автор - кол-во
        public void DictionaryShow() 
        {
            if (_books == null)
            {
                Console.WriteLine("Принициализируйте коллекцию");
                return;
            }

            Dictionary<string, int> books = new Dictionary<string, int>
            {
                ["Default"] = 222
            };


            foreach (var item in _books)
                books.Add(item._fullName, item._count);

            books.Remove("Default");

            foreach (var item in books)
                Console.WriteLine($"{item.Key,-22} - {item.Value}");
        }

        //удаление по коду с клавиатуры
        public void DeleteCode()
        {

            if (_books == null)
            {
                Console.WriteLine("Принициализируйте коллекцию");
                return;
            }

            Console.WriteLine("Данные до изменения: \n");
            Show();

            Console.WriteLine("\nВведите код удаляемого элемента: ");
            string str = Console.ReadLine();
            int.TryParse(str, out int n);

            int index = _books.FindIndex(x => x._code == n);

            Console.WriteLine($"\nУдалена книга: {_books[index]._nameBook}, под кодом {n}\n");

            _books.RemoveAt(index);

            Console.WriteLine("\nДанные после изменения: \n");
            Show();
        }


        // упорядочить по авторам
        public void SortAuthors() 
        {
            if (_books == null)
            {
                Console.WriteLine("Принициализируйте коллекцию");
                return;
            }
            _books.Sort((x, y) => x._fullName.CompareTo(y._fullName));

            Console.WriteLine("\nДанные после изменения: \n");
            Show();
        }

        //упорядочить по году
        public void SortYear() 
        {
            if (_books == null)
            {
                Console.WriteLine("Принициализируйте коллекцию");
                return;
            }
            _books.Sort((x, y) => x._year.CompareTo(y._year));

            Console.WriteLine("\nДанные после изменения: \n");
            Show();
        }

    } // class App_Common
}
