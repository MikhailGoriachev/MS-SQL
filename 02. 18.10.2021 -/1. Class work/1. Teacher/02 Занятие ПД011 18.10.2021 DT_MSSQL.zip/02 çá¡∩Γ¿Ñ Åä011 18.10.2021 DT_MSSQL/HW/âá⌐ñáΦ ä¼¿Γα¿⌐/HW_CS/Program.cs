﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;

using HW_CS.Helpers;
using HW_CS.Application;

namespace HW_CS
{
    internal class Program{
        static void Main(string[] args)
        {
            Console.Title = "HW";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem {HotKey = ConsoleKey.Q, Text = "Показать коллекцию книг"},
                new MenuItem {HotKey = ConsoleKey.W, Text = "Добавить в коллекцию новую книгу(всегда одна и таже)"},
                new MenuItem {HotKey = ConsoleKey.E, Text = "Изменить кол-во экземпляров книги"},
                new MenuItem {HotKey = ConsoleKey.R, Text = "Создать Dictionary<string, int>"},
                new MenuItem {HotKey = ConsoleKey.T, Text = "Удалить данные о книге по ББК"},
                new MenuItem {HotKey = ConsoleKey.Y, Text = "Сортировка по авторам"},
                new MenuItem {HotKey = ConsoleKey.U, Text = "Сортировка по году издания"},
                //----------------------------------------------------------------------------------------------
                new MenuItem {HotKey = ConsoleKey.Z, Text = "Выход"},
            };

            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true)
            {
                try
                {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.Black);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowMenu(12, 5, "Меню приложения для работы с массивами объектов", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg = "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.Black);
                    Console.Clear();

                    switch (key){

                        // Показать коллекцию книг
                        case ConsoleKey.Q:
                            app.Show();
                            break;

                        // добавить еще 1 книгу в коллекцию
                        case ConsoleKey.W:
                            app.AddBook();
                            break;

                        // изменить кол-во экземпляров книги
                        case ConsoleKey.E:
                            app.EditBook();
                            break;

                        // cоздать Dictionary<string, int>
                        case ConsoleKey.R:
                            Utils.ShowUnderConstruction();
                            break;

                        // Удалить данные о книге по ББК
                        case ConsoleKey.T:
                            app.RemoveBook();
                            break;

                        // сортировка по автору
                        case ConsoleKey.Y:
                            app.SortAuthor();
                            break;

                        // сортировка по году издания
                        case ConsoleKey.U:
                            app.SortYear();
                            break;


                        // Выход из приложения назначен на клавишу F10 или клавишу M или клавишу Escape
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor(); // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                } // try

                // обработка исключений - просто вывести сообщение
                catch (Exception ex){
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                } // try-catch
            } // while
        } // Main
    } // class Program
}
