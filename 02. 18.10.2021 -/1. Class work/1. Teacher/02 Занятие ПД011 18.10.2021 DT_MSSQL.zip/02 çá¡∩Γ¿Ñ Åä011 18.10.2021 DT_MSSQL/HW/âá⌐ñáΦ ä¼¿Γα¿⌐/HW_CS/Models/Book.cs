﻿using System;

namespace HW_CS.Models{
    internal class Book{

        // конструктор с параметрами по умолчанию
        public Book(string author = "Иванов И. И.", string name = "Победный шорох", int year = 1998, int count = 1041, string bbk = "121.н6"){
            Author = author;
            Name = name;
            Year = year;
            Count = count;
            BBK = bbk;
        } // Book

        private string _author;
        public string Author{
            get => _author;
            set => _author = !(string.IsNullOrWhiteSpace(value)) ? value : throw new Exception("Данный имя и инициалы не подходят!");
        } // Author

        private string _name;
        public string Name{
            get => _name;
            set => _name = !(string.IsNullOrWhiteSpace(value)) ?value: throw new Exception("Данное название для книги не подходит!");
        } // name

        private int _year;
        public int Year{
            get => _year;
            set => _year = !(value>2021||value<1600) ? value : throw new Exception("Нельзя присвоить данный год издания для книги!");
        } // Year

        private int _count;
        public int Count{
            get => _count;
            set => _count = value >= 0 ? value : throw new Exception("Нельзя присвоить данное кол-во экземляров для книги!");
        } // Count

        private string _bbk;
        public string BBK{
            get => _bbk;
            set => _bbk = !(string.IsNullOrWhiteSpace(value)) ? value : throw new Exception("Нельзя присовить данное ББК для книги!");
        } // BBK

        public string Header(){
            string str = $"\t+-------------------+--------------------+--------+--------+----------------+\n" +
                         $"\t|       Автор       |      Название      |   Год  | Кол-во |       ББК      |\n" +
                         $"\t+-------------------+--------------------+--------+--------+----------------+\n";
            return str;
        } // Header

        public string Footer() => "\t+-------------------+--------------------+--------+--------+----------------+\n";

        public override string ToString() => $"\t| {_author,17} | {_name,18} | {_year,6} | {_count,6} | {_bbk,14} |\n";

    } // Book
}
