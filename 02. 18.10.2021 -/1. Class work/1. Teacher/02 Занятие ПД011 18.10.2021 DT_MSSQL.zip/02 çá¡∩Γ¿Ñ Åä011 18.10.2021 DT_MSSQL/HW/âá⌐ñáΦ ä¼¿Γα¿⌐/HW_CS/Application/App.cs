﻿using System;
using System.Collections.Generic;
using HW_CS.Models;
using HW_CS.Helpers;

namespace HW_CS.Application{
    internal class App{
        private List<Book> _books; // колеекция книг

        // конструтор по умолчанию
        public App() : this(new List<Book>()) { Init(); }
        // конструкто рс параметрами
        public App(List<Book> books){
            _books = books;
        } // App

        // заполнение листа книгами
        private void Init(){
            _books.AddRange(new Book[] { // заполняем значениями коллекцию
                new Book("Платонова А. Ф.", "Черная молния", 1778, 5322, "328.2"),
                new Book("Яковлев Р. Л.", "Летящей походкой", 1678, 1345, "32.6"),
                new Book("Лаптев Д. Я.", "Зарядник", 1778, 9843, "4352"),
                new Book("Платонова А. Ф.", "Убийство в коробке", 1820, 2341, "65.21"),
                new Book("Наумов М. В.", "Кубир кота", 1787, 7234, "2345.21")
                });
        } // Init

        // показать книги
        public void Show(string title = "\n\t\t\t\tКоллекция книг"){
            Console.WriteLine(title); // выводим текст
            Console.Write($"{_books[0].Header()}"); // выводим шапку
            foreach (var item in _books) // выводим каждый элемент коллекции, т.к. есть IEnumerable
                Console.Write($"{item}");
            Console.Write($"{_books[0].Footer()}"); // выводим подвал
        } // Show

        // добавить в коллекцию новую книгу
        private Book NewBook(){
            string[] author= {
                "Васильев А.Н.",    "Швайко О.А.",    "Дёмина Д.П.",  "Лысюк А.В.",
                "Якубовская Ю.В.",  "Пачкория Г.В.",  "Аникеев В.О.", "Мироненко Н.Я.",
                "Решетникова Н.А.", "Свиридова Т.Л.", "Репеко Д.А.",  "Лысенко Б.П.",
            };
            string[] names= {
                "Взлет", "Падение", "Упор", "Кувырок", "Вплавь"
            };
            string[] bbk ={
                "425.2", "324.2", "238", "f2.2", "178.21", "3298.1", "9243.ип", "2025.2"
            };
            return new Book(author[Utils.Random.Next(0, author.Length - 1)]
                , names[Utils.Random.Next(0, names.Length - 1)]
                , Utils.Random.Next(1600, 2022)
                , Utils.Random.Next(0, 10_000)
                , bbk[Utils.Random.Next(0, bbk.Length-1)]
                );
        } // NewBook

        public void AddBook() {
            _books.Add(NewBook()); // добавить книгу
            Show(); // вывести коллекцию книг
        } // AddBook

        // изменить кол-во экземпляров книги
        public void EditBook(){
            int index = Utils.Random.Next(0, _books.Count - 1); // выбрать книгу
            int count = Utils.Random.Next(0, 10_000); // выбрать кол-во
            _books[index].Count = count; // изменить на новое кол-во
            ShowEditedBook(index); // показать коллекцию с выделенной измененной книгой
        } // EditBook

        // показать коллекцию с выделенной измененной книгой
        private void ShowEditedBook(int index, string title = "Коллекция книг с измененной книгой"){
            Console.WriteLine(title); // выводим текст
            Console.Write($"{_books[0].Header()}"); // выводим шапку
            for (int i = 0;i<_books.Count;i++){
                Console.ForegroundColor = i == index ? ConsoleColor.Yellow : ConsoleColor.Gray; // изменяем цвет если индекс совпадает с данной книгой
                Console.Write($"{_books[i]}"); // выводим книгу из коллекции
            } // foreach
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write($"{_books[0].Footer()}"); // выводим подвал
        } // ShowEditedBook

        // cоздать Dictionary<string, int>
        public void DictionarySolve(){
            string author = _books[0].Author;
            int count = 0;
            for (int i = 0;i<_books.Count;i++)
                if (author == _books[i].Author) count += _books[i].Count;

            Dictionary<string, int> dict = new Dictionary<string, int> { [author] = count};
            for (int i = 1; i < _books.Count; i++){
                count = 0;
                author = _books[i].Author;
                foreach (var item in dict)
                    if (author == item.Key){
                        i++;
                        author = _books[i].Author;
                        break;
                    } // if
                for (int j = 0;j<_books.Count;j++)
                    if (author == _books[j].Author) count += _books[j].Count;
                dict.Add(author, count);
            } // for i

            Console.WriteLine("\n\tDictionary<string, int>\n");
            foreach (var item in dict){
                Console.WriteLine($"\t{item.Key,-12} - {item.Value}");
            } // foreach
        } // DictionarySolve

        // удалить книгу по ББК
        public void RemoveBook(){
            Show();
            Console.Write("\n\nВпишите ББК книги, котору, хотите удалить> ");
            string str = Console.ReadLine();
            bool fl = false;
            for (int i = 0; i < _books.Count; i++)
                if(str == _books[i].BBK){
                    _books.RemoveAt(i);
                    break;
                } // if
            Show();
        } // RemoveBook

        // сортировка по автору
        public void SortAuthor(){
            _books.Sort((x, y) => x.Author.CompareTo(y.Author));
            Show("\n\t\t\tКоллекция книг, отсортированная автору");
        } // SortAuthor

        // сортировка по году издания
        public void SortYear(){
            _books.Sort((x, y) => y.Year.CompareTo(x.Year));
            Show("\n\t\t\tКоллекция книг, отсортированная по году издания");
        } // SortAuthor

    } // App
}
