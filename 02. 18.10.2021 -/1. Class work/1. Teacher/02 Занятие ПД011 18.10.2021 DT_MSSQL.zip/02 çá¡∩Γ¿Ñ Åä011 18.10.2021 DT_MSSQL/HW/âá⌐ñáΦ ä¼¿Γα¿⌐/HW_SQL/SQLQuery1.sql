﻿


 -- выбирает из таблицы Clients все столбцы всех записей
select 
	*
from
	Clients;


-- выбирает из таблицы Clients информацию о клиентах,
-- процент скидки для которых находится в диапазоне от 0,3% до 0,5 %
select 
	surname
	, name
	, middleName
	, discount
from 
    Clients
where 
	discount between 0.3 and 0.5;


-- выбирает из таблицы Clients информацию о клиентах с процентом скидки, меньшим 0,3%
-- выводить идентификатор, фамилию, имя, отчество и процент скидки
select
	id
	, surname
	, name
	, middleName
	, discount
from
	Clients
where
	discount < 0.3;


-- выбирает из таблицы Clients информацию о клиентах с процентом скидки, большим 0,6%
-- выводить все поля
select 
	*
from
	Clients
where 
	discount < 0.6;


-- выбирает из таблицы Clients информацию о клиентах, с годом рождения, большим 2000.
-- выводить фамилию, имя, отчество и год рождения 
select
	surname
	, name
	, middleName
	, yearOfBirth
from
	Clients
where
	yearOfBirth > 2000;


-- выбирает из таблицы Clients информацию о клиентах с годом рождения в диапазоне от 1960 до 1996. 
-- выводить все поля таблицы 
select
	*
from
	Clients
where
	yearOfBirth between 1960 and 1996;


-- выбирает из таблицы Clients информацию о клиентах, с годом рождения, меньшим 1996.
-- выводить идентификатор, фамилию, имя, отчество и год рождения
select
	id
	, surname
	, name
	, middleName
	, yearOfBirth
from
	Clients
where
	yearOfBirth < 1996;