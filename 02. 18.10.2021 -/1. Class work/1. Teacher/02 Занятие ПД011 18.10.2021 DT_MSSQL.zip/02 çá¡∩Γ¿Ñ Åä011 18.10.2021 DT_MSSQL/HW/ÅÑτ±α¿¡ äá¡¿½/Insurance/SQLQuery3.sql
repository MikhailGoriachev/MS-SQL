﻿--Выбирает из таблицы Clients все столбцы всех записей
SELECT * FROM Clients
--Выбирает из таблицы Clients информацию о клиентах, процент скидки для которых находится в диапазоне от 0,3% до 0,5 %
SELECT * FROM Clients WHERE Discount BETWEEN 0.3 AND 0.5
--Выбирает из таблицы Clients информацию о клиентах с процентом скидки, меньшим 0,3% 
--Выводить идентификатор, фамилию, имя, отчество и процент скидки
SELECT Id, Surname,Name,Patronymic FROM Clients WHERE Discount <0.3
--Выбирает из таблицы Clients информацию о клиентах с процентом скидки, большим 0,6%
SELECT * FROM Clients WHERE Discount >0.6
--Выбирает из таблицы Clients информацию о клиентах, с годом рождения, большим 2000
--Выводить фамилию, имя, отчество и год рождения 
SELECT Surname, Name, Patronymic, BirthYear FROM Clients WHERE BirthYear > 2000
--Выбирает из таблицы Clients информацию о клиентах с годом рождения в диапазоне от 1960 до 1996
SELECT * FROM Clients WHERE BirthYear BETWEEN 1960 AND 1996
--Выбирает из таблицы Clients информацию о клиентах, с годом рождения, меньшим 1996
--Выводить идентификатор, фамилию, имя, отчество и год рождения
SELECT Id, Surname,Name,Patronymic FROM Clients