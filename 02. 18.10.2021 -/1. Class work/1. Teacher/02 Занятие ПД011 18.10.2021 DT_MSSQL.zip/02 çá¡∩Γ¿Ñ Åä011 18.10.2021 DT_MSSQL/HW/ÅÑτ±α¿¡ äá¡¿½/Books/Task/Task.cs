﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Books.Tasks
{
    class Task
    {
        List<Book> library;
        
        Dictionary<string, int> libs; 
        public void Initialize()
        {
            library = new List<Book>();
            for(int i = 0; i<10; ++i)
            {
                library.Add(Book.GenerateBook());
            }

            Show();
            

        }

        public void AddBook()
        {
            library.Add(Book.GenerateBook()); 
        }

        public void ChangeBookCopy()
        {
            int copy = Utils.GetRandomInt(10, 20); // новое количество копий
            int index = Utils.GetRandomInt(0, 11);
            Show();
            //  поиск книги по индексу и замена количества книг
            for(int i =0; i<library.Count(); ++i)
            {
                if(i+1 == index)
                {
                    library[i].NumberOfCopies = copy;
                }
            }
            Console.Write($"Новое количество книг {copy} изменено в по индексу {index}");
            Show();
        }

        public void CreateDictionary()
        {
            
            //инициализация словара
            libs = new Dictionary<string, int>();


            //заполнение словаря парой ключ/ значение: «автор – суммарное количество книг» 
            foreach (var item in library)
            {
                bool add = libs.TryGetValue(item.AuthorName, out int value);
                if (add) { libs[item.AuthorName]+=item.NumberOfCopies; }
                else { libs.Add(item.AuthorName, item.NumberOfCopies); }
            }
            Show();
            // вывод получившего словара в консоль
            foreach (var item in libs)
            {
                Console.WriteLine($"Автор : {item.Key, -18}   Количество книг : {item.Value, 7}");
            }

        }

        public void DeleteBook()
        {
            Show();

            Console.WriteLine("Введите код книги для удаления");
            string code = Console.ReadLine();
           for(int i =0; i<library.Count(); ++i)
            {
                if(library[i].Code == code)
                {
                    library.RemoveAt(i);
                    break;
                }
            }
            Show();


        }

        public void SortByAuthor()
        {
           
            
            library.Sort((a, b) => a.AuthorName.CompareTo(b.AuthorName));
            Console.WriteLine("Коллекция отсортирована по авторам");
            Show();

        }

        public void SortByYear()
        {
            library.Sort((a, b) => a.Year.CompareTo(b.Year));
            Console.WriteLine("Коллекция отсортирована по году издания");
            Show();
        }

        public void Show()
        {
            Console.WriteLine($"     Список книг");
            Console.WriteLine(Book.Header(10));
            for(int i = 0; i<library.Count(); i++)
            {
                Console.WriteLine(library[i].ToTableRow(i+1, 10)); 
            }
            Console.WriteLine(Book.Footer(10)); 

        }
    }
}
