﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Books.Tasks;

namespace Books.App_Data
{
    /*Задача 1. Разработайте консольное приложение для учета книг в библиотеке. 
     * Сведения о книгах содержат: фамилию и инициалы автора, название, год издания, 
     * количество экземпляров данной книги в библиотеке, код библиотечного учета (ББК).
     * 
Требуется хранить книги в коллекции List<Book>, реализовать следующий функционал:
•	Начальное заполнение коллекции книг (иницализация или генерация – по Вашему выбору)
•	добавление данных о книге, вновь поступающей в библиотеку – не вводите с клавиатуры, формируйте данные книги;
•	изменения количества экземпляров заданной книги – индекс изменяемой книги задавайте случайным числом, 
    изменение количества – также случайное число; 
•	создать Dictionary<string, int> для пар «автор – суммарное количество книг»
•	удаление данных о списываемой книге по коду библиотечного учета, код вводить с клавиатуры;
•	выдача сведений о всех книгах, упорядоченных по авторам;
•	выдача сведений о всех книгах, упорядоченных по годам издания.
*/
    internal partial class App
    {
        Task task = new Task();
        public void Initialize()
        {
            Utils.ShowNavBarTask(" Инициализации коллекции книг");

           task. Initialize();

            Console.ReadKey();
        }

        public void AddBook()
        {
            Utils.ShowNavBarTask("Добавление книг в коллекцию");

            task.AddBook();
            task.Show();
            Console.ReadKey();

        }

        public void ChangeBookCopy()
        {
            Utils.ShowNavBarTask("Изменение количества экземпляров книги");

            task.ChangeBookCopy();
            Console.ReadKey();
        }

        public void CreateDictionary()
        {
            Utils.ShowNavBarTask("Создание Dictionary");

            task.CreateDictionary();

            Console.ReadKey();
        }

        public void DeleteBook()
        {
            Utils.ShowNavBarTask("Удаление данных о списываемой книги");

            task.DeleteBook();

            Console.ReadKey();
        }

        public void SortByAuthor()
        {
            Utils.ShowNavBarTask("Упорядочить по автору");

            task.SortByAuthor();

            Console.ReadKey();
        }

        public void SortByYear()
        {
            Utils.ShowNavBarTask("Упорядочить по году издания");

            task.SortByYear();

            Console.ReadKey();
        }
    }
}
