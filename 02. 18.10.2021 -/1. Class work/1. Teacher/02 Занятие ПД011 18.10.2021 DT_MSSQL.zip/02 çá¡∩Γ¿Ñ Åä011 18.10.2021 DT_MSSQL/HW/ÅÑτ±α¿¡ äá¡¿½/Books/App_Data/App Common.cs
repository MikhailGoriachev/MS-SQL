﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Books.Tasks;

namespace Books.App_Data
{
    internal partial class App_Common
    {
    }
}
