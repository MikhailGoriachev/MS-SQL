﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Books.App_Data;

namespace Books
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 18.09.2021 . Коллекции";

            MenuItem[] menu = new[]
            {
                new MenuItem{ HotKey =ConsoleKey.Q, Text = "Инициализации коллекции книг"},
                new MenuItem{ HotKey =ConsoleKey.W, Text = "Добавление книг в коллекцию"},
                new MenuItem{ HotKey =ConsoleKey.E, Text = "Изменение количества экземпляров книги"},
                new MenuItem{HotKey = ConsoleKey.R, Text = "Создание Dictionary"}, 
                new MenuItem{HotKey = ConsoleKey.A, Text = "Удаление данных о списываемой книги"}, 
                new MenuItem{HotKey = ConsoleKey.S, Text = "Упорядочить по автору "}, 
                new MenuItem {HotKey = ConsoleKey.D, Text =" Упорядочить по году издания"}

            };

            App app = new App(); 

            while(true)
            {
                try
                {
                    //настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  ООП С# - Коллекции книг");
                    Utils.ShowMenu(12, 5, "Меню приложения для работы с коллекциями книг", menu);

                    // получения кода клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg = " Нажмите выделенныую цветом клавишу для выбора ".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch(key)
                    {
                        case ConsoleKey.Q:
                            app.Initialize();
                            break;

                        case ConsoleKey.W:
                            app.AddBook();
                            break;

                        case ConsoleKey.E:
                            app.ChangeBookCopy();
                            break;

                        case ConsoleKey.R:
                            app.CreateDictionary();
                            break;

                        case ConsoleKey.A:
                            app.DeleteBook();
                            break;

                        case ConsoleKey.S:
                            app.SortByAuthor();
                            break;

                        case ConsoleKey.D:
                            app.SortByYear();
                            break;
                    }

                }
                catch(Exception ex)
                {
                    Console.WriteLine("\n");
                    Console.WriteLine(ex);
                    Console.ReadKey();
                }
            }
        }
    }
}
