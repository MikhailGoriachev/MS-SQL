﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Books.Tasks
{
    /*
     * Сведения о книгах содержат: фамилию и инициалы автора, название, год издания, 
     * количество экземпляров данной книги в библиотеке, код библиотечного учета (ББК).
     */
    public class Book
    {
        public string AuthorName {get; set;}

        public string BookTitle { get; set; }

        public int Year { get; set; }

        public int NumberOfCopies { get; set; }

        public string Code { get; set; }

        
       
        
        public static string Header(int indent)
        {
            string spaces = " ".PadRight(indent);
            return
                $"{spaces}┌───────┬────────────────────────┬──────────────────────┬─────────┬────────────────────┬──────────┐\n" +
                $"{spaces}│ N п/п │ Имя и инициалы автора  │ Название книги       │   Год   │  Количество копий  |   Код    | \n" +
                $"{spaces}├───────┼────────────────────────┼──────────────────────┼─────────┼────────────────────┼──────────┤ ";
        }// Header

        // Подвал таблицы,  статическое свойство
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└───────┴────────────────────────┴──────────────────────┴─────────┴────────────────────┴──────────┘\n";

        // строковое представление класса
        public override string ToString() => $"| {AuthorName,12}, | {BookTitle,12} | {Year, 6} | {NumberOfCopies, 10} | {Code, 7} |";


        public string ToTableRow(int row, int indent) =>
            $"{" ".PadRight(indent)}| {row,5} | {AuthorName,-22} | {BookTitle,-20} | {Year,7} | {NumberOfCopies,18} | {Code,8} |";

        // компаратор по свойству год издание
        public static int CompareToYear(Book a, Book b) => a.Year.CompareTo(b.Year);

        // компаратор по автору
        public int CompareToAuthor(Book a,Book b) => a.AuthorName.CompareTo(b.AuthorName);

        // методы для генерации книг 
        public static string GenerateAuthor()
        {
            string[] data = { "Лебедев С.В.", "Параманов В.А.", "Смрнов А.И.", "Кононов П.А.",
                "Филимонов Е.К.", "Устинов М.А.", "Новиков К.Е.", "Грашман Н.К.", "Сухой Т.В.", "Давыдов Г.А", 
                "Заславская О.А", };

            return data[(Utils.GetRandomInt(0, data.Length))];
        }

        public static string GenerateTitle()
        {
            string[] data = {"Выход извне", "Высший суд", "Опасный поворот",
                "Забыть навсегда", "Алое пламя", "Заговор небес", "Возращение, Полночь", "Искуство Империи", "Замкнутый круг", "Сознание на грани", 
                "Здесь и сейчас", "Из осколков души", "И снова она", "Идеальный дневник", "Перекресток душ", "Возвращая душу", 
                 "Ветер душ", "Визаж", "Некролит", "За гранью: Две Души"};

            return data[Utils.GetRandomInt(0, data.Length)];
        }

        public static string GenerateCode()
        {
            StringBuilder code = new StringBuilder();

            int numbers = Utils.GetRandomInt(1, 4); 

            for(int i = 0; i<numbers; ++i)
            {
                code.Append((char)Utils.GetRandomInt('A', 'Z'+1));
            }

            return code.ToString();
        }

        public static Book GenerateBook()
        {
            return new Book
            {
                AuthorName = GenerateAuthor(),
                BookTitle = GenerateTitle(),
                Year = Utils.GetRandomInt(1990, 2010),
                NumberOfCopies = Utils.GetRandomInt(3, 10),
                Code = GenerateCode()
            };
        }

        







       



    }
}
