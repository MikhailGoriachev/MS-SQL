﻿-- Выбрать из таблицы Clients все столбцы всех записей
select
	*
from
	Clients


-- Выбрать из таблицы Clients информацию о клиентах, 
-- процент скидки для которых находится в диапазоне 
-- от 0,3% до 0,5 %
select
	*
from
	Clients
where 
	Discount between 0.3 and 0.5


-- Выбрать из таблицы Clients информацию о клиентах 
-- с процентом скидки, меньшим 0,3%
-- Выводить идентификатор, фамилию, имя, отчество и процент скидки
select
	Id
	, Surname
	, Name
	, Patronymic
	, Discount
from 
	Clients
where
	Discount < 0.3


-- Выбрать из таблицы Clients информацию о клиентах 
-- с процентом скидки, большим 0,6%
select
	*
from
	Clients
where
	Discount > 0.6


-- Выбрать из таблицы Clients информацию о клиентах,
-- с годом рождения, большим 2000.
-- Выводить фамилию, имя, отчество и год рождения 
select
	Surname
	, Name
	, Patronymic
	, YearOfBirth
from 
	Clients
where
	YearOfBirth > 2000


-- Выбирает из таблицы Clients информацию о клиентах 
-- с годом рождения в диапазоне от 1960 до 1996.
select
	*
from 
	Clients
where
	YearOfBirth between 1960 and 1996


-- Выбирает из таблицы Clients информацию о клиентах,
-- с годом рождения, меньшим 1996.
-- Выводить идентификатор, фамилию, имя, отчество и год рождения
select
	Id
	, Surname
	, Name
	, Patronymic
	, YearOfBirth
from 
	Clients
where
	YearOfBirth < 1996