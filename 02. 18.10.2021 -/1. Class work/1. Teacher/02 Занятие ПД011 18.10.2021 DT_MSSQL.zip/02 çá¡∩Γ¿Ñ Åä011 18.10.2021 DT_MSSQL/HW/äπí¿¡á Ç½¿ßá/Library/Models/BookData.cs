﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Library.Helpers;

namespace Library.Models { 
    class BookData {
        private List<Book> _books;                 // коллекция книг
        private Dictionary<string, int> _authors;  // коллекция пар «автор – суммарное количество книг»
        public BookData() {
            Initialize();
        } // BookData

        public BookData(List<Book> books) {
            _books = books;
            CountAuthors();
        } // BookData

        public List<Book> Books { get => _books; }
        public int Count { get => _books.Count; }

        // Заполнение коллекции книг
        public void Initialize() {
            _books = new List<Book>(
                new Book[]{
                    new Book("Толстой А. Н.",     "Петр Первый",              1977, 12, "TPP77"),
                    new Book("Чехов А. П.",       "Избранное",                1984, 21, "CHI84"),
                    new Book("Булгаков М. А.",    "Мастер и Маргарита",       2000, 16, "BMM00"),
                    new Book("Шолохов М. А.",     "Тихий Дон",                1975, 26, "SHT75"),
                    new Book("Дойл А. К.",        "Записки о Шерлоке Холмсе", 1991, 18, "DZO91"),
                    new Book("Достоевский Ф. М.", "Преступление и наказание", 1988, 21, "DPN88"),
                    new Book("Островский А. Н.",  "Пъесы",                    1986, 11, "OSP86"),
                    new Book("Лагин Л. И.",       "Старик Хоттабыч",          1986, 14, "LSH86"),
                    new Book("Бронте Ш.",         "Джен Эйр",                 1988, 15, "BDE88")
                });
            CountAuthors();
        } // Initialize

        // расчет пар «автор – суммарное количество книг»
        private void CountAuthors() {
            _authors = new Dictionary<string, int>();
            _books.ForEach(item => AddAuthor(item));
        } // CountAuthors

        private void AddAuthor(Book book) {
            if (_authors.ContainsKey(book.Author)) _authors[book.Author] += book.Quantities;
            else _authors[book.Author] = book.Quantities;
        } // AddAuthor

        // обычный вывод коллекции в консоль
        public void Show(string caption, int indent) =>
            Show(caption, indent, (item, i) => Console.WriteLine($"{item.ToTableRow(i++)}"));

        // вывод коллекции в консоль с выделением элемента с заданным индексом
        public void Show(string caption, int indent, int index) =>
            Show(caption, indent, (item, i) => {
                if (index == i - 1) Utils.SetColor(ConsoleColor.Yellow, Console.BackgroundColor);
                Console.WriteLine($"{item.ToTableRow(i++)}");
                Utils.RestoreColor();
                });

        // Вывести данные коллекции в консоль - для вывода 
        public void Show(string caption, int indent, Action<Book, int> outItem) {
            // вывод заголовка таблицы данных 
            string space = " ".PadRight(indent);
            Console.Write($"\n\n{space}{caption}\n{Book.Header(indent)}");

            int i = 1;
            // вывод всех элементов массива объектов данных
            _books.ForEach(item => { Console.Write($"{space}"); outItem(item, i++); });

            // вывод подвала таблицы
            Console.WriteLine($"{Book.Footer(indent)}\n");
        } // Show

        // вывод коллекции пар «автор – суммарное количество книг»
        public void ShowAuthors(string caption, int indent) {
            // вывод заголовка таблицы данных 
            string space = " ".PadRight(indent);
            Console.Write($"\n\n{space}{caption}\n{BookData.HeaderAuthors(indent)}");

            int i = 1;
            // вывод всех элементов массива объектов данных
            foreach (var key in _authors.Keys) {
                Console.WriteLine($"{space}│ {i++, 3} │ {key,-19} │ {_authors[key], 11} │");
            } // foreach

            // вывод подвала таблицы
            Console.WriteLine($"{BookData.FooterAuthors(indent)}\n");
        } // ShowAuthors

        // Добавление данных о книге
        public void AddBook(Book book) {
            _books.Add(book);
            CountAuthors();
        } // AddBook
        // изменение количества экземпляров заданной книги 
        public void ChangeQuantities(int index, int newQuantities) {
            if (index < 0 || index >= _books.Count) throw new Exception("ChangeQuantities: недопустимый индекс!");
            _books[index].Quantities = newQuantities;
            CountAuthors();
        } // ChangeQuantities

        // Удаление данных о списываемой книге по коду библиотечного учета
        public void RemoveByCode(string code) {
            int index = _books.FindIndex(x => x.Code == code);
            if(index < 0) throw new Exception("RemoveByCode: Книга для удаления не найдена!");
            _books.RemoveAt(index);
            CountAuthors();
        } // RemoveByCode

        // Упорядочить коллекцию книг по авторам
        public void OrderByAuthor() => _books.Sort((x, y) => x.Author.CompareTo(y.Author));

        // Упорядочить коллекцию книг по годам издания
        public void OrderByYear() => _books.Sort((x, y) => x.Year.CompareTo(y.Year));

        // Шапка таблицы для пар «автор – суммарное количество книг»
        public static string HeaderAuthors(int indent) {
            string spaces = " ".PadRight(indent);
            return
            $"{spaces}┌─────┬─────────────────────┬─────────────┐\n" +
            $"{spaces}│  №  │     Фамилия И.О.    │    Кол-во   │\n" +
            $"{spaces}│     │       автора        │ экземпляров │\n" +
            $"{spaces}├─────┼─────────────────────┼─────────────┤\n";
        } // Header

        // Подвал таблицы для пар «автор – суммарное количество книг»
        public static string FooterAuthors(int indent) =>
            $"{" ".PadRight(indent)}└─────┴─────────────────────┴─────────────┘\n";
    }
}
