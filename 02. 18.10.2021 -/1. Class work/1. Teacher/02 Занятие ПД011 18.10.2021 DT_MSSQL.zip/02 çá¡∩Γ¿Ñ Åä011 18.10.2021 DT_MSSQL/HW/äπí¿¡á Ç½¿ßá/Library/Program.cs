﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;   // для доступа к возможностям класса Interaction
using Library.Helpers;
using Library.Application;

namespace Library
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 11.10.2021";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Начальное формирование коллекции книг" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Вывод коллекции книг" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Добавление данных о книге" },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Изменить количество экземпляров заданной книги" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Вывод пар \"автор – суммарное количество книг\"" },
                new MenuItem { HotKey = ConsoleKey.Y, Text = "Удаление данных о списываемой книге" },
                new MenuItem { HotKey = ConsoleKey.U, Text = "Упорядочить коллекцию книг по авторам" },
                new MenuItem { HotKey = ConsoleKey.I, Text = "Упорядочить коллекцию книг по годам издания" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };

            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true) {
                try {

                    // настройка цветового оформления
                    Utils.SetColor(ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Utils.SaveColor();
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  Задание на 11.10.2021 - работа с событиями в C#");
                    Utils.ShowMenu(12, 5, "Главное меню приложения", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key) {
                        // Начальное формирование массива электроприборов
                        case ConsoleKey.Q:
                            app.BooksInitialize();
                            break;

                        // Вывод коллекции книг
                        case ConsoleKey.W:
                            app.BooksShow();
                            break;

                        // Добавление данных о книге
                        case ConsoleKey.E:
                            app.AddBook();
                            break;

                        // Изменить количество экземпляров заданной книги
                        case ConsoleKey.R:
                            app.ChangeQuantities();
                            break;

                        // Вывод пар "автор – суммарное количество книг"
                        case ConsoleKey.T:
                            app.ShowAuthors();
                            break;

                        // Удаление данных о списываемой книге
                        case ConsoleKey.Y:
                            app.RemoveBook();
                            break;

                        // Упорядочить коллекцию книг по авторам
                        case ConsoleKey.U:
                            app.DemoOrderByAuthor();
                            break;

                        // Упорядочить коллекцию книг по годам издания
                        case ConsoleKey.I:
                            app.DemoOrderByYear();
                            break;

                        // выход из приложения назначен на клавишу F10 или кавишу Z
                        case ConsoleKey.F10:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Такого пункта нет в меню!");
                    } // switch

                }
                catch (Exception ex) {
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                    while (Console.KeyAvailable) Console.ReadKey(false);
                }
                finally { 
                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                    Console.ReadKey(true);
                }
            } // while
        } // Main
    }
}
