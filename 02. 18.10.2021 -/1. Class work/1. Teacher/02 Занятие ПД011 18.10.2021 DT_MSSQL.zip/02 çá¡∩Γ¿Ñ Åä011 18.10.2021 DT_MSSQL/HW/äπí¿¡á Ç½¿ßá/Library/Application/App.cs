﻿using System;
using Microsoft.VisualBasic;   // для доступа к возможностям класса Interaction
using Library.Models;
using Library.Helpers;

namespace Library.Application
{

    // Класс приложения - обработка по заданию
    internal partial class App {
        BookData _library;  // объект для решения задачи

        // конструктор по умолчанию
        public App() : this(new BookData()) { }


        // конструктор с внедрением зависимостей
        public App(BookData library) {
            _library = library;
        } // App


        // Начальное формирование коллекции книг
        public void BooksInitialize() {
            Utils.ShowNavBarTask("   Начальное формирование коллекции книг");
            _library.Initialize();
            _library.Show("Данные сформированы:", 12);
        } // BooksInitialize


        // Вывод коллекции книг
        public void BooksShow() {
            Utils.ShowNavBarTask("   Вывод коллекции книг");
            _library.Show("Коллекция книг:", 12);
        } // BooksShow


        // Добавление данных о книге
        public void AddBook() {
            Utils.ShowNavBarTask("   Добавление данных о книге");
            _library.AddBook(new Book("Верн Ж.", "Дети капитана Гранта", 1985, 23, "VDG85"));
            _library.Show("Книга усрешно добавлена:", 12, _library.Count - 1);
        } // AddBook


        // Изменить количество экземпляров заданной книги
        public void ChangeQuantities() {
            Utils.ShowNavBarTask("   Изменить количество экземпляров заданной книги");
            int index = Utils.Random.Next(_library.Count);
            _library.Show("Коллекция книг до изменений", 12, index);
            _library.ChangeQuantities(index, Utils.Random.Next(1, 15));
            _library.Show("Коллекция книг после изменений", 12, index);
        } // ChangeQuantities


        // Вывод пар "автор – суммарное количество книг"
        public void ShowAuthors() {
            Utils.ShowNavBarTask("   Вывод пар \"автор – суммарное количество книг\"");
            _library.ShowAuthors("Пары \"автор – суммарное количество книг\"", 12);
        } // ShowAuthors


        // Удаление данных о списываемой книге
        public void RemoveBook() {
            Utils.ShowNavBarTask("   Удаление данных о списываемой книге");
            _library.Show("Коллекция книг до удаления", 12);
            // ввод кода книги для удаления
            string code = Interaction.InputBox(
                    "Код библиотечного учета удаляемой книги:",
                    "Ввод данных");

            _library.RemoveByCode(code);
            _library.Show("Книга усрешно удалена", 12);
        } // RemoveBook


        // Упорядочить коллекцию книг по авторам
        public void DemoOrderByAuthor() {
            Utils.ShowNavBarTask("   Упорядочить коллекцию книг по авторам");
            _library.OrderByAuthor();
            _library.Show("Коллекция книг упорядочена по авторам", 12);
        } // DemoOrderByAuthor


        // Упорядочить коллекцию книг по годам издания
        public void DemoOrderByYear() {
            Utils.ShowNavBarTask("   Упорядочить коллекцию книг по годам издания");
            _library.OrderByYear();
            _library.Show("Коллекция книг упорядочена по годам издания", 12);
        } // DemoOrderByYear
    } // class App
}