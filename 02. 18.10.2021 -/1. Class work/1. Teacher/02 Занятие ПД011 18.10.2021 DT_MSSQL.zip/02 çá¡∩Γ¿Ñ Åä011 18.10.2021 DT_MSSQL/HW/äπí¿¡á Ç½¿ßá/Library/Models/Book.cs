﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Models
{
    class Book {
        private string _author; // фамилия и инициалы автора
        public string Author {
            get => _author;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Book: Некорректные фамилия и инициалы автора!"); _author = value; }
        } // Author

        private string _name;  // название книги
        public string Name {
            get => _name;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Book: Некорректное название книги!"); _name = value; }
        } // Name

        private int _year; // год издания
        public int Year {
            get => _year;
            set { if (value < 0 || value > DateTime.Today.Year) throw new Exception("Book: Некорректный год издания книги!"); _year = value; }
        } // Year

        private int _quantities; // количество экземпляров данной книги в библиотеке
        public int Quantities {
            get => _quantities;
            set { if (value < 0 ) throw new Exception("Book: Некорректное количество экземпляров!"); _quantities = value; }
        } // Count

        private string _code;  // код библиотечного учета (ББК).
        public string Code {
            get => _code;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Book: Некорректный код библиотечного учета книги!"); _code = value; }
        } // Code

        public Book(string author, string name, int year, int quantities, string code) {
            Author = author;
            Name = name;
            Year = year;
            Quantities = quantities;
            Code = code;
        } // Book

        // Шапка таблицы, статическое свойство
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            return
            $"{spaces}┌─────┬─────────────┬──────────────────────────┬─────────────────────┬─────────┬─────────────┐\n" +
            $"{spaces}│  №  │     ББК     │         Название         │     Фамилия И.О.    │   Год   │    Кол-во   │\n" +
            $"{spaces}│     │             │                          │       автора        │ издания │ экземпляров │\n" +
            $"{spaces}├─────┼─────────────┼──────────────────────────┼─────────────────────┼─────────┼─────────────┤\n";
        } // Header

        // Подвал таблицы, статическое свойство
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└─────┴─────────────┴──────────────────────────┴─────────────────────┴─────────┴─────────────┘\n";

        // вывод в табличном формате
        public string ToTableRow(int row) =>
             $"│ {row, 3} │ {_code,-11} │ {_name,-24} │ {_author, -19} │ {_year, 4} г. │ {_quantities, 7} шт. │";

    } // Book
}
