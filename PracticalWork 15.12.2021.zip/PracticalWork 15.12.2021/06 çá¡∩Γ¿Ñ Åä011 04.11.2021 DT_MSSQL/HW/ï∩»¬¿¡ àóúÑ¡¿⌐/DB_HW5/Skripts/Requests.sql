﻿--	1)Запрос с параметром
--	Выбирает из таблицы ПАЦИЕНТЫ информацию о пациентах,
--	фамилия которых начинается с заданной буквы (например, «И»)
select 
	*
from 
	Patients
where 
	Surname like N'П%';
go

--  2)Запрос на выборку
--	Выбирает из таблицы ВРАЧИ информацию о врачах,
--  имеющих заданную специальность. Например, «хирург»
select
	*
from 
	Doctors
where 
	Speciality like N'Фармацевт';
go
	

--	3)Запрос на выборку
--	Выбирает из таблиц ВРАЧИ, ПАЦИЕНТЫ и ПРИЕМЫ информацию о приемах: 
--	фамилия и инициалы пациента, дата приема, 
--	дата рождения пациента, специальность врача, стоимость приема
select
	FORMATMESSAGE('%s.%s.', SUBSTRING(Patients.[Name], 0, 2),
		SUBSTRING(Patients.Patronymic, 0, 2)) as Initials
	, Reception.DateOfReception
	, Patients.DateOfBorn
	, Doctors.Speciality
	, Reception.Price
from
	Reception join Doctors on Reception.DoctorId = Doctor.Id
			  join Patients on Reception.PatientId = Patient.Id;
go

--	4)Запрос с параметром
--	Выбирает из таблицы ВРАЧИ информацию о врачах с заданным 
--	значением в поле Стоимость приема. Конкретное значение стоимости 
--	приема вводится при выполнении запроса
declare @price int = 3858
select
	*
from
	Doctors
where
	Doctors.Price = @price;

	

--	5)Запрос с параметром
--	Выбирает из таблицы ВРАЧИ информацию о врачах, Процент отчисления на зарплату 
--	которых находится в некотором заданном диапазоне. Нижняя и верхняя границы 
--	диапазона задаются при выполнении запроса
declare @min float = 3,
		@max float = 10;
select 
	* 
from 
	Doctors
where	
	Doctors.[Percent] between @min and @max
go

--	6)Запрос с вычисляемыми полями
--	Вычисляет размер заработной платы врача за каждый прием. Включает поля Фамилия врача, 
--	Имя врача, Отчество врача, Специальность врача, Стоимость приема, Зарплата. 
--	Сортировка по полю Фамилия врача
select 
	Doctors.Surname
	, Doctors.[Name]
	, Doctors.[Patronymic]
	, Doctors.[Speciality]
	, Doctors.[Price]
	, (Doctors.Price * (Doctors.[Percent] / 100)) - 
		(Doctors.Price * (Doctors.[Percent]/100)) * 0.13 as Salary
from 
	Doctors
order by
	Doctors.Surname;
go

--	7)Итоговый запрос
--	Выполняет группировку по полю Дата приема. Для каждой даты вычисляет минимальную
--	стоимость приема
select
	Reception.DateOfReception
	, MIN(Reception.Price) as Price
from 
	Reception
group by 
	Reception.DateOfReception;
go

--	8)Итоговый запрос
--	Выполняет группировку по полю Специальность. Для каждой специальности вычисляет 
--	максимальный Процент отчисления на зарплату от стоимости приема
select 
	Doctors.Speciality
	, MAX(Doctors.[Percent]) as MaxPercent
from 
	Doctors
group by
	Doctors.Speciality;
go
