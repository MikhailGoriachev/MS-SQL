﻿
--1.Выбирает из таблицы ПАЦИЕНТЫ информацию о пациентах, фамилия которых 
--начинается с заданной буквы (например, «И»)
select *
from Patients
where PtSurname like N'И%';
--2.Выбирает из таблицы ВРАЧИ информацию о врачах, имеющих заданную 
--специальность. Например, «хирург»
select * 
from Doctors
where Doctors.Speciality = N'хирург'
--3.Выбирает из таблиц ВРАЧИ, ПАЦИЕНТЫ и ПРИЕМЫ информацию о приемах: 
--фамилия и инициалы пациента, дата приема, дата рождения пациента, 
--специальность врача, стоимость прима
select 
	Patients.PtName				as Имя
	,Patients.PtSurname			as Фамилия
	,Patients.PtPatronymic		as Отчество
	,Visits.DateOfVisit			as [Дата посещения]
	,Patients.DateOfBorn		as [Дата рождения]
	,Doctors.Speciality			as Специальность
	,Doctors.CostOfAdmission	as [Стоимость посещения]
from 
	Visits join Patients on Visits.IdPatient = Patients.Id
			join Doctors on Visits.IdDoctor = Doctors.Id
--4.Выбирает из таблицы ВРАЧИ информацию о врачах с заданным значением 
--в поле Стоимость приема. Конкретное значение стоимости приема вводится 
--при выполнении запроса
select * 
from Doctors
where Doctors.CostOfAdmission = 500
--5.Выбирает из таблицы ВРАЧИ информацию о врачах, Процент отчисления 
--на зарплату которых находится в некотором заданном диапазоне. Нижняя и 
--верхняя границы диапазона задаются при выполнении запроса
select * 
from Doctors
where Doctors.PercDeduction between 50 and 70
--6.Вычисляет размер заработной платы врача за каждый прием. Включает 
--поля Фамилия врача, Имя врача, Отчество врача, Специальность врача, 
--Стоимость приема, Зарплата. Сортировка по полю Фамилия врача 
select
	Doctors.DrSurname
	,Doctors.DrName
	,Doctors.DrPatronymic
	,Doctors.Speciality
	,Doctors.CostOfAdmission
	,Doctors.CostOfAdmission / 100 * Doctors.PercDeduction - (Doctors.CostOfAdmission / 100 * Doctors.PercDeduction * 13 / 100)  as Зарплата 
from Doctors
order by Doctors.DrSurname
--7.Выполняет группировку по полю Дата приема. Для каждой даты вычисляет 
--минимальную стоимость приема
select
	Visits.DateOfVisit as [Дата визита]
	,Min(Doctors.CostOfAdmission) as [Минимальная стоимость приема]
from
	Visits join Doctors on Visits.IdDoctor = Doctors.Id
group by Visits.DateOfVisit;
--8.Выполняет группировку по полю Специальность. Для каждой специальности 
--вычисляет максимальный Процент отчисления на зарплату от стоимости приема
select 
	Doctors.Speciality as Специальность
	,max(Doctors.PercDeduction) as [Максимальный Процент отчисления]
from Doctors
group by Doctors.Speciality;


