﻿--drop table Patients
--drop table Doctors
--drop table Visits

--Создание таблиц

create table [dbo].[Patients]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY(1, 1), 
    [PtName] NVARCHAR(60) NOT NULL, 
    [PtSurname] NVARCHAR(60) NOT NULL, 
    [PtPatronymic] NVARCHAR(60) NOT NULL, 
    [DateOfBorn] DATE NOT NULL, 
    [PtAddress] NVARCHAR(60) NOT NULL, 
    CONSTRAINT [CK_Patients_DateOfBorn] CHECK (DateOfBorn > '1900-01-01'), 
)

go

create table [dbo].[Doctors]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY(1, 1), 
    [DrName] NVARCHAR(60) NOT NULL, 
    [DrSurname] NVARCHAR(60) NOT NULL, 
    [DrPatronymic] NVARCHAR(60) NOT NULL, 
    [Speciality] NVARCHAR(60) NOT NULL, 
    [CostOfAdmission] INT NOT NULL, 
    [PercDeduction] INT NOT NULL, 
    CONSTRAINT [CK_Doctors_CostOfAdmis] CHECK (CostOfAdmission > 0), 
    CONSTRAINT [CK_Doctors_PercDeduction] CHECK (PercDeduction > 0)
)

go

create table dbo.Visits
(
    Id int not null primary key identity(1,1),
    IdPatient int not null,
    IdDoctor int not null,
    DateOfVisit nvarchar(60) not null
    CONSTRAINT [CK_Visits_DateOfVisit] CHECK (DateOfVisit > '1900-01-01'), 
    CONSTRAINT [FK_Visits_Patient] FOREIGN KEY (IdPatient) REFERENCES Patients(Id),
    CONSTRAINT [FK_Visits_Doctor] FOREIGN KEY (IdDoctor) REFERENCES Patients(Id),
)

go