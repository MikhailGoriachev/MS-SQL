﻿-- Запрос 1. Вывести полную информацию обо всех книгах
select
    Books.Id
    , Authors.FullName  as Author
    , Categories.Category
    , Books.Title
    , Books.PubYear
    , Books.Price
    , Books.Amount
from
    Books inner join Authors on Books.IdAuthor = Authors.Id 
          inner join Categories on Books.IdCategory = Categories.Id;


-- Запрос 2. Запрос с параметрами. 
--          Вывести полную информацию по книгам заданного автора,
--          изданным в заданный период. Например, автор Абрамян М.Э.,
--          период с 2002 по 2019
declare @lo int = 2002, 
        @hi int = 2019,
        @author nvarchar(70) = N'Абрамян М.Э.';
select
    Books.Id
    , Authors.FullName  as Author
    , Categories.Category
    , Books.Title
    , Books.PubYear
    , Books.Price
    , Books.Amount
from
    Books inner join Authors on Books.IdAuthor = Authors.Id 
          inner join Categories on Books.IdCategory = Categories.Id
where
    Authors.FullName = @author and
    PubYear between @lo and @hi;
go


-- Запрос 3. Запрос с параметрами. 
--           Вывести название, год издания и количество 
--           (поле books.amount) книг заданной категории, 
--           имеющих заданную строку в названии. Например,
--           категория «задачник», строка в названии «LINQ». 
declare @category nvarchar(70) = N'задачник',
        @str      nvarchar(70) = '%LINQ%';
select
    Books.Title
    , Books.PubYear
    , Books.Amount
from
    Books inner join Categories on Books.IdCategory = Categories.Id
where
    Books.Title like @str and
    Categories.Category = @category;
go


-- Запрос 4. Запрос с параметрами.
--           Вывести автора, название, категорию и стоимость 
--           для каждой книги, количество которых от 4 до 6 
declare @lo int = 4, 
        @hi int = 6;
select
    Authors.FullName as Author
    , Books.Title
    , Categories.Category
    , Books.Price
    --, Books.Amount
from
    Books inner join Authors on Books.IdAuthor = Authors.Id 
          inner join Categories on Books.IdCategory = Categories.Id
where
    Amount between @lo and @hi;
go

-- Запрос 5. Итоговый запрос. 
--           Вывести фамилии и инициалы авторов, 
--           количество (сумма полей books.amount) книг этих авторов
select
    Authors.FullName as Author
    , SUM(Books.Amount) as SumAmount
from
    Books inner join Authors on Books.IdAuthor = Authors.Id 
group by 
    Authors.FullName


-- Запрос 6. Итоговый запрос. 
--           Для категорий книг вывести количество, 
--           минимальную стоимость книги, среднюю стоимость книги,
--           максимальную стоимость книги
select
    Categories.Category
    , COUNT(Categories.Category) as CountCategories  -- кол-во записей
    -- , SUM(Books.Amount) as SumAmount                 -- кол-во экземпляров 
    , MIN(Books.Price) as MinPrice
    , Avg(Books.Price) as AvgPrice
    , MAX(Books.Price) as MaxPrice
from
    Books inner join Categories on Books.IdCategory = Categories.Id
group by
    Categories.Category;
    

-- Запрос 7. Итоговый запрос. 
--           Вывести общее количество книг по C++ (сумма полей books.amount)
select
    SUM(Books.Amount) as SumAmount
from
    Books inner join Categories on Books.IdCategory = Categories.Id
where
    Books.Title like '% C++%'
    
