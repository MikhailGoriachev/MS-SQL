﻿--1	Запрос с параметром
--Выбирает из таблицы ПАЦИЕНТЫ информацию о пациентах,
--фамилия которых начинается с заданной буквы (например, «И»)
SELECT
	Patients.Surname,
	Patients.FirstName,
	Patients.Patronymic,
	Patients.BirthDate,
	Patients.LivingAddress
FROM Patients
WHERE Patients.Surname like N'И%';

--2	Запрос на выборку
--Выбирает из таблицы ВРАЧИ информацию о врачах,
--имеющих заданную специальность. Например, «хирург»
SELECT 
	Doctors.Surname,
	Doctors.FirstName,
	Doctors.Patronymic,
	Doctors.Speciality,
	Doctors.Deductions
FROM Doctors
WHERE Doctors.Speciality = N'хирург';

--3	Запрос на выборку
--Выбирает из таблиц ВРАЧИ, ПАЦИЕНТЫ и ПРИЕМЫ информацию о приемах:
--фамилия и инициалы пациента, дата приема, дата рождения пациента,
--специальность врача, стоимость прима
SELECT
	-- (фамилия и инициалы?)
	(Patients.SurName + N' ' + SUBSTRING(Patients.Firstname,1,1) + N'. ' +SUBSTRING(Patients.Patronymic,1,1) + N'.') as Patient,
	Appointments.SessionDate as Date,
	Patients.BirthDate,
	Doctors.Speciality,
	Appointments.Price
FROM 
	Appointments inner join Patients on Appointments.IdPatient = Patients.Id
				 inner join Doctors on Appointments.IdDoctor   = Doctors.Id
;			

--4	Запрос с параметром	
--Выбирает из таблицы ВРАЧИ информацию о врачах с заданным значением в поле Стоимость приема.
--Конкретное значение стоимости приема вводится при выполнении запроса
DECLARE @price int = 400
SELECT 
	Doctors.Surname,
	Doctors.FirstName,
	Doctors.Patronymic,
	Doctors.Speciality,
	Doctors.Price,
	Doctors.Deductions
FROM Doctors
WHERE Doctors.Price = @price;

--5	Запрос с параметром
--Выбирает из таблицы ВРАЧИ информацию о врачах, Процент отчисления на зарплату которых находится
--в некотором заданном диапазоне. Нижняя и верхняя границы диапазона задаются при выполнении запроса
DECLARE @lo real = 10, @hi real = 30

SELECT
	Doctors.Surname,
	Doctors.FirstName,
	Doctors.Patronymic,
	Doctors.Speciality,
	Doctors.Price,
	Doctors.Deductions
FROM Doctors
WHERE Doctors.Deductions between @lo and @hi;


--6	Запрос с вычисляемыми полями	
--Вычисляет размер заработной платы врача за каждый прием.
--Включает поля Фамилия врача, Имя врача, Отчество врача, Специальность врача, Стоимость приема, Зарплата.
--Сортировка по полю Фамилия врача 	 	 
SELECT
	Doctors.Surname,
	Doctors.FirstName,
	Doctors.Patronymic,
	Doctors.Speciality,
	Doctors.Price,
	--Размер начисляемой врачу заработной платы за каждый прием вычисляется по формуле:
	-- (Стоимость приема * Процент отчисления от стоимости приема на зарплату врача) - (подоходный налог, составляющий 13% от суммы)
	(Doctors.Price * (Doctors.Deductions / 100)) - (Doctors.Price * (Doctors.Deductions / 100)) * 0.13 as Salary
FROM Doctors
ORDER BY Doctors.Surname;

--7	Итоговый запрос
--Выполняет группировку по полю Дата приема. Для каждой даты вычисляет минимальную стоимость приема
SELECT
	Appointments.SessionDate,
	MIN(Appointments.Price) as Price
FROM Appointments 
GROUP BY Appointments.SessionDate;

--8	Итоговый запрос
--Выполняет группировку по полю Специальность. 
--Для каждой специальности вычисляет максимальный Процент отчисления на зарплату от стоимости приема

SELECT
	Doctors.Speciality,
	MAX(Doctors.Deductions) as MaxDeductions
FROM Doctors
GROUP BY Doctors.Speciality
