﻿-- создание таблицы категория книг
CREATE TABLE [dbo].[Categories] (
    [Id]       INT           IDENTITY (1, 1) NOT NULL,
    [Category] NVARCHAR (20) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

-- создание таблицы авторы
CREATE TABLE [dbo].[Authors]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Fullname] NVARCHAR(80) NOT NULL
)

-- создание таблицы книги
CREATE TABLE [dbo].[Books]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [IdAuthor] INT NOT NULL, 
    [Title] NVARCHAR(120) NOT NULL, 
    [IdCategory] INT NOT NULL, 
    [PubYear] INT NOT NULL, 
    [Price] INT NOT NULL, 
    [Amount] INT NOT NULL, 
    CONSTRAINT [CK_Books_PubYear] CHECK ([PubYear] > 1950), 
    CONSTRAINT [CK_Books_Price] CHECK ([Price] > 0), 
    CONSTRAINT [CK_Books_Amount] CHECK ([Amount] >= 0), 
    CONSTRAINT [FK_Books_Authors] FOREIGN KEY ([IdAuthor]) REFERENCES [Authors]([Id]), 
    CONSTRAINT [FK_Books_Categories] FOREIGN KEY ([IdCategory]) REFERENCES [Categories]([Id])
)

---------------------------------------------------------------------------------------
-- создание таблицы специальность врача
CREATE TABLE [dbo].[Specialties]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Speciality] NVARCHAR(30) NOT NULL
)

-- создание таблицы врачи
CREATE TABLE [dbo].[Doctors] (
    [Id]                 INT           IDENTITY (1, 1) NOT NULL,
    [SurnameDoc]         NVARCHAR (50) NOT NULL,
    [NameDoc]            NVARCHAR (40) NOT NULL,
    [PatronymicDoc]      NVARCHAR (60) NOT NULL,
    [IdSpeciality]       INT           NOT NULL,
    [CostOfAdmission]    INT           NOT NULL,
    [PercentOfDeduction] INT           NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Doctors_Specialties] FOREIGN KEY ([IdSpeciality]) REFERENCES [dbo].[Specialties] ([Id]),
    CONSTRAINT [CK_Doctors_CostOfAdmission] CHECK ([CostOfAdmission]>(0))
);

-- создание таблицы пациенты
CREATE TABLE [dbo].[Patients]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [SurnamePatient] NVARCHAR(50) NOT NULL, 
    [NamePatient] NVARCHAR(40) NOT NULL, 
    [PatronymicPatient] NVARCHAR(60) NOT NULL, 
    [DateOfBirth] DATE NOT NULL, 
    [AddressPatient] NVARCHAR(100) NOT NULL
);

-- создание таблицы приёмы
CREATE TABLE [dbo].[Receptions] (
    [Id]            INT  IDENTITY (1, 1) NOT NULL,
    [IdPatient]     INT  NOT NULL,
    [IdDoctor]      INT  NOT NULL,
    [DateOfReceipt] DATE NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Receptions_Patients] FOREIGN KEY ([IdPatient]) REFERENCES [dbo].[Patients] ([Id]),
    CONSTRAINT [FK_Receptions_Doctors] FOREIGN KEY ([IdDoctor]) REFERENCES [dbo].[Doctors] ([Id])
);