﻿

-- Запрос 1. 
-- Вывести полную информацию обо всех книгах
select
    Books.Id
    , Authors.FullName
    , Categories.Category
    , Books.Title
    , Books.PubYear
    , books.Price
    , Books.Amount
from
    Books join Authors on Books.IdAuthor = Authors.Id
          join Categories on Books.IdCategory = Categories.Id;
go


-- Запрос 2.  
-- Вывести полную информацию по книгам заданного автора, изданным в заданный
-- период. Например, автор Абрамян М.Э., период с 2002 по 2019
declare @fullname nvarchar(60) = N'Абрамян М.Э.';
declare @loYear int = 2002, @hiYear int = 2019;
select
    Books.id
    ,Categories.Category
    ,Authors.FullName
    ,Books.Title
    ,Books.PubYear
    ,Books.Price
    ,Books.Amount
from
    Books join Categories on Books.IdCategory = Categories.Id
          join Authors on Books.IdAuthor = Authors.Id
where
    Authors.FullName = @fullname and Books.PubYear between @loYear and @hiYear
go
;  

-- Запрос 3. Запрос с параметрами. 
-- Вывести название, год издания и количество (поле books.amount) книг заданной
-- категории, имеющих заданную строку в названии. 
-- Например, категория «задачник», строка в названии «LINQ». 
declare @category nvarchar(20) = N'задачник', @match nvarchar(10) = N'LINQ';

select
    Books.Id
    , Categories.Category
    , Books.Title 
    , Books.PubYear
    , Books.Amount
from
    Books join Categories on Books.IdCategory = Categories.Id
where
    Categories.Category = @category and Books.Title like ('%' + @match + '%');
go


-- Запрос 4. Запрос с параметрами. 
-- Вывести автора, название, категорию и стоимость для каждой книги, 
-- количество которых от 4 до 6
declare @loAmount int = 4, @hiAmount int = 6;

select
    Authors.FullName
    , Books.Title
    , Categories.Category
    , books.Price
    , Books.Amount
from
    Books join Authors on Books.IdAuthor = Authors.Id
          join Categories on Books.IdCategory = Categories.Id
where
    Books.Amount between @loAmount and @hiAmount 
go


-- Запрос 5. Итоговый запрос. 
-- Вывести фамилии и инициалы авторов, количество (сумма полей 
-- books.amount) книг этих авторов
select
    Authors.FullName
    , COUNT(Books.Amount) as Amount
    , SUM(Books.Amount) as SumAmount
from 
    Books join Authors on Books.IdAuthor = Authors.Id
group by
    Authors.FullName;
go


-- Запрос 6. Итоговый запрос. 
-- Для категорий книг вывести количество, минимальную стоимость книги, 
-- среднюю стоимость книги, максимальную стоимость книги
select
    Categories.Category
    , COUNT(*) as [Count]
    , SUM(Books.Amount) as SumAmount
    , MIN(Books.Price) as MinPrice
    , AVG(Books.Price) as AvgPrice
    , MAX(Books.Price) as MaxPrice
from
    Books join Categories on Books.IdCategory = Categories.Id
group by
    Categories.Category;
go


-- Запрос 7. Итоговый запрос. 
-- Вывести общее количество книг по C++ (сумма полей books.amount)
select
    SUM(Books.Amount) as TotalAmountCpp
from
    Books
where
    Books.Title like N'C++[ .,]%' or Books.Title like N'% C++ %' or Books.Title like N'% C++';
go