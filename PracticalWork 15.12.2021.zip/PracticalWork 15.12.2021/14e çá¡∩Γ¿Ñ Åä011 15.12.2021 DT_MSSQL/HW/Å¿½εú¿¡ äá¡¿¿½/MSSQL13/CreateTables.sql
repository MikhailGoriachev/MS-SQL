﻿--Скрипт создания таблиц
drop table if exists DistribUnits
drop table if exists StaffUnits
drop table if exists Units
drop table if exists Positions
drop table if exists Persons
drop table if exists UnitTypes


--создание таблицы Типов подразделения 
CREATE TABLE [dbo].UnitTypes
(
[Id] INT NOT NULL PRIMARY KEY IDENTITY,
[Type] NVARCHAR(50) NOT NULL			--Тип
)
go

--создание таблицы Персоны 
CREATE TABLE [dbo].Persons
(
[Id] INT NOT NULL PRIMARY KEY IDENTITY,
[Surname] NVARCHAR(50) NOT NULL,			--Фамилия
[Name] NVARCHAR(50) NOT NULL,				--Имя
[Patronymic] NVARCHAR(50) NOT NULL			--Отчество
)
go

--создание таблицы Наименований штатных единиц
CREATE TABLE [dbo].Positions
(
[Id] INT NOT NULL PRIMARY KEY IDENTITY,
[Position] NVARCHAR(50) NOT NULL		--Должность
)

go


--создание таблицы ПОДРАЗДЕЛЕНИй
CREATE TABLE [dbo].Units
(
[Id] INT NOT NULL PRIMARY KEY IDENTITY,
[idType] INT NOT NULL,					--Тип подразделения
[NameUnit] NVARCHAR(60) NOT NULL,		--Наименование подразделения
[Percent1] INT NOT NULL					--Процент_надбавки_1 
CONSTRAINT [FK_Units_ToUnitTypes] FOREIGN KEY ([idType]) REFERENCES UnitTypes(id),
CONSTRAINT [CK_Units_idType] CHECK (idType > 0),
CONSTRAINT [CK_Units_Percent1] CHECK (Percent1 > 0)
)

go

--создание таблицы ШТАТНЫЕ_ЕДИНИЦЫ
CREATE TABLE [dbo].StaffUnits
(
[Id] INT NOT NULL PRIMARY KEY IDENTITY,
[idPosition] INT NOT NULL,				--Наименование штатной единицы
[idPerson] INT NOT NULL,				--Фамилия и инициалы персоны
[Salary] INT NOT NULL,					--Должностной оклад для данной штатной единицы
[Rank] NVARCHAR(50) NOT NULL,			--Разряд
[Percent2] INT NOT NULL,				--Процент_надбавки_2
[Vacation] INT NOT NULL,				--Отпуск
CONSTRAINT [FK_StaffUnits_ToPositions] FOREIGN KEY ([idPerson]) REFERENCES Persons(id),
CONSTRAINT [FK_StaffUnits_ToPersons] FOREIGN KEY ([idPosition]) REFERENCES Positions(id),
CONSTRAINT [CK_StaffUnits_idPosition] CHECK (idPosition > 0),
CONSTRAINT [CK_StaffUnits_idPerson] CHECK (idPerson > 0),
CONSTRAINT [CK_StaffUnits_Salary] CHECK (Salary > 0),
CONSTRAINT [CK_StaffUnits_Percent2] CHECK (Percent2 > 0),
CONSTRAINT [CK_StaffUnits_Vacation] CHECK (Vacation >= 22)
)

go

--создание таблицы РАСПРЕДЕЛЕНИЕ_ШТАТНЫХ_ЕДИНИЦ
CREATE TABLE [dbo].DistribUnits
(
[Id] INT NOT NULL PRIMARY KEY IDENTITY,
[idStaffUnit] INT NOT NULL,				--Штатная еденица
[idUnit] INT NOT NULL,					--Подразделение
CONSTRAINT [FK_DistribUnits_ToStaffUnits] FOREIGN KEY ([idStaffUnit]) REFERENCES StaffUnits(id),
CONSTRAINT [FK_DistribUnits_ToUnits] FOREIGN KEY ([idUnit]) REFERENCES Units(id),
CONSTRAINT [CK_DistribUnits_idStaffUnit] CHECK (idStaffUnit > 0),
CONSTRAINT [CK_DistribUnits_idUnit] CHECK (idUnit > 0)
)
go

--Триггер для операций вставки, удаления записей и 
--изменения записей для таблицы РАСПРЕДЕЛЕНИЕ_ШТАТНЫХ_ЕДИНИЦ базы данных
--сообщает о количестве измененных в процессе работы операций строк
create TRIGGER OnDistribUnitsDIU ON DistribUnits
    FOR DELETE, INSERT, UPDATE
    AS
    BEGIN
        raiserror(N'Изменения в таблице "Распределения штатных едениц", затронуто: %d строк',0,1,@@rowcount);
    END
go

--Триггер сообщает о количестве измененных в 
--процессе работы операций строк таблицы ШТАТНЫЕ_ЕДИНИЦЫ. 
create trigger OnStaffUnitsInsert on StaffUnits
    for insert
    as
    begin
        raiserror('Изменения в таблице "Штатные еденицы", затронуто строк: %d',0,1,@@rowcount);
    end
go

--Триггер изменения таблицы ШТАТНЫЕ_ЕДИНИЦЫ должен предотвратить 
--изменение должности «инженер-электрик» и сообщить о количестве 
--измененных в процессе работы операций строк
alter trigger OnStaffUnitsUpdate on StaffUnits
    for update
    as
    begin
        declare @counter int = (select count(*) from deleted)
        declare @position nvarchar(60) = 'empty';

        --среди удаленных строк ищем ту, в которой должность: Инженер-электрик
        select
            @position = Positions.Position
        from 
            deleted join Positions on deleted.idPosition = Positions.Id
        where idPosition = (select id from Positions where Position = N'Инженер-электрик')

        --если в переменную попадет значение, отменяем изменение таблицы
        if @position != 'empty'
        begin
            print N'Изменение данных штатных едениц с должностью "Инженер-электрик" запрещено!';
            rollback tran;
        end
        --в противном случае уведомляем об количестве измененных строк
        else raiserror(N'При изменении таблицы "Штатные еденицы" затронуто: %d строк',0,1, @counter)

    end
go