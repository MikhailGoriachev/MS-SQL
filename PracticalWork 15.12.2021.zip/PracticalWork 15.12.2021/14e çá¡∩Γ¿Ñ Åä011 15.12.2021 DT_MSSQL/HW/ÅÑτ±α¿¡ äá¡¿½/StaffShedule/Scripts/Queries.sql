﻿--База данных "Штатное расписание"

--Персоны
select
     *
from
    Persons
go

--Подразделения
select
     Divisions.Id
     , Divisions.DivisionName as Division
     , DivisionTypes.DivisionTypeName as [Type]

from 
    Divisions join DivisionTypes on Divisions.IdDivisionType = DivisionTypes.Id
go


--Штатные единицы
select 
     StaffUnits.Id
     , StaffUnitTypes.StaffUnitName
     , Grade
     , SalaryPerk2
     , Leave
from 
     StaffUnits join StaffUnitTypes on StaffUnits.IdStaffUnitTypes = StaffUnitTypes.Id
go

-- Запросы по заданию
--1. Выбирает из таблицы ПОДРАЗДЕЛЕНИЯ информацию о подразделениях, имеющих тип «отдел» или «цех», 
--для которых Процент_надбавки_1 больше значения, заданного параметром

create procedure [dbo].[InformationAboutUnits]
        @perks float = 2.5

as
select 
     Divisions.Id
     ,Divisions.DivisionName
     ,DivisionTypes.DivisionTypeName
     ,Divisions.SalaryPerk
from 
      Divisions join DivisionTypes on Divisions.IdDivisionType = DivisionTypes.Id
where 
     DivisionTypeName = N'отдел' or DivisionTypeName = N'цех ' and SalaryPerk > @perks

go

exec InformationAboutUnits
go 

--2. Выбирает из таблицы ШТАТНЫЕ_ЕДИНИЦЫ информацию о штатных единицах с окладом в заданном 
--диапазоне и значением в поле Процент_надбавки_2 также равным заданному. Диапазон оклада 
--и процент надбавки задавать параметрами

create procedure [dbo].[InformationAboutSalary]
      @salaryFrom int = 32000, @salaryTo int  = 74000, @perk float = 4.7
    as
select 
      StaffUnits.Id
      , StaffUnitTypes.StaffUnitName
      , StaffUnits.Salary
      , StaffUnits.SalaryPerk2
from 
     StaffUnits join StaffUnitTypes on StaffUnits.IdStaffUnitTypes = StaffUnitTypes.Id
where 
     Salary between @salaryFrom and @salaryTo and SalaryPerk2 = @perk  
go

exec InformationAboutSalary
go

-- 3. Выбирает из таблицы ПОДРАЗДЕЛЕНИЯ информацию о подразделениях, для которых тип подразделения 
--равен заданному параметром или Процент_надбавки_1 равен заданному параметром 

create function [dbo].[InformationAboutPerks] (@divisionType nvarchar(60), @perk float )
returns table
as 
return
        
select
     Divisions.Id
     , Divisions.DivisionName as Division
     , DivisionTypes.DivisionTypeName as [Type]
     , Divisions.SalaryPerk

from 
    Divisions join DivisionTypes on Divisions.IdDivisionType = DivisionTypes.Id
where 
      DivisionTypeName = @divisionType or SalaryPerk = @perk
go

select
*
from 
    InformationAboutPerks(N'цех', 4.7)
go

--4. Выбирает из таблицы ШТАТНЫЕ_ЕДИНИЦЫ информацию о штатных единицах 
--с заданным параметром наименованием и заданной параметром величиной оклада

create procedure [dbo].[SalaryAmount]
        @name nvarchar(60) = N'механик', @salary int = 63000
as
select 
     StaffUnits.Id
     , StaffUnitTypes.StaffUnitName
     , Salary
     
from 
     StaffUnits join StaffUnitTypes on StaffUnits.IdStaffUnitTypes = StaffUnitTypes.Id
where 
     StaffUnitName = @name and Salary = @salary
go

exec SalaryAmount
go

--5. Выбирает из таблицы ШТАТНЫЕ_ЕДИНИЦЫ информацию о штатных единицах, 
--имеющих заданное параметром наименование, для которых Процент_надбавки_2 
--имеет значение из некоторого заданного диапазона. Нижняя и верхняя границы 
--диапазона также задаются параметрами функции

create function [dbo].[PerksDiapazone] (@perkFrom float, @perkTo float, @name nvarchar(60) )
returns table 
as 
return 
select 
     StaffUnits.Id
     , StaffUnitTypes.StaffUnitName
     , Grade
     , SalaryPerk2
     
from 
     StaffUnits join StaffUnitTypes on StaffUnits.IdStaffUnitTypes = StaffUnitTypes.Id
where
     StaffUnitName = @name and SalaryPerk2 between @perkFrom and @perkTo
go

select 
*
from 
    PerksDiapazone(3.7, 8.7,  N'штамповщик')
go


--6. Вычисляет размер подоходного налога с начисленной заработной платы для каждой 
--распределенной штатной единицы в соответствии с таблицей РАСПРЕДЕЛЕНИЕ_ШТАТНЫХ_ЕДИНИЦ. 
--Включает поля Наименование подразделения, Наименование единицы, Оклад, Процент_надбавки_1, 
--Процент_надбавки_2, Размер зарплаты, Налог. Сортировка по полю Наименование подразделения

create function [dbo].[TaxSalary] ()
returns table 
as
return
select top (select count(*) from 
             StaffDistribution join (StaffUnits join StaffUnitTypes on StaffUnits.IdStaffUnitTypes = StaffUnitTypes.Id) 
                                       on StaffDistribution.IdStaffUnit = StaffUnits.Id
                       join Divisions  on StaffDistribution.IdDivision = Divisions.Id       
)
        Divisions.DivisionName                                                                        -- наименование подразделения  
      , StaffUnitTypes.StaffUnitName                                                                 -- наименование единицы
      , StaffUnits.Salary                                                                             -- оклад
      , Divisions.SalaryPerk                                                                          -- размер первой надбавки
      , StaffUnits.SalaryPerk2                                                                        -- размер второй надбавки
      , Salary * (1 + Divisions.SalaryPerk/100 + StaffUnits.SalaryPerk2/100)         as GrossSalary   -- зарплата до вычитов
      , (Salary * (1 + Divisions.SalaryPerk/100 + StaffUnits.SalaryPerk2/100))* 0.13 as Tax           -- размер налога  
from 
     StaffDistribution join (StaffUnits join StaffUnitTypes on StaffUnits.IdStaffUnitTypes = StaffUnitTypes.Id) 
                                       on StaffDistribution.IdStaffUnit = StaffUnits.Id
                       join Divisions  on StaffDistribution.IdDivision = Divisions.Id
  order by 
          Divisions.DivisionName
go

select 
* 
from TaxSalary()
go

-- 7. Выполняет группировку по полю Тип подразделения в таблице ПОДРАЗДЕЛЕНИЯ. 
--Для каждой группы вычисляет среднее значение по полю Процент_надбавки_1

create function [dbo].[GroupByName] ()
returns table
as
return
select
       
       DivisionTypes.DivisionTypeName as [Type]
     , AVG(Divisions.SalaryPerk) as AveragePerk

from 
    Divisions join DivisionTypes on Divisions.IdDivisionType = DivisionTypes.Id
group by
        DivisionTypes.DivisionTypeName
go

select
*
from 
   GroupByName()
go

-- 8. Выполняет группировку по полю Наименование штатной единицы в таблице ШТАТНЫЕ_ЕДИНИЦЫ. 
--Для каждой группы вычисляет минимальное и максимальное значения по полю Отпуск

create function [dbo].[MaxMinLeave] ()
returns table
as
return
select 
     
      StaffUnitTypes.StaffUnitName as [Name]
      , MAX(Leave) as MaxDays   -- максимальное значение для поля Отпуск
      , MIN(Leave) as MinDays   -- минимальное значение для полня Отпуск 
from 
     StaffUnits join StaffUnitTypes on StaffUnits.IdStaffUnitTypes = StaffUnitTypes.Id

group by
        StaffUnitTypes.StaffUnitName
go

select
*
from 
    MaxMinLeave ()
go

 -- 9. Создает таблицу ШТАТНЫЕ_ЕДИНИЦЫ_ИНЖЕНЕР, содержащую информацию о штатных единицах с наименованием «инженер»

select 
       StaffUnitTypes.StaffUnitName
       , StaffUnits.Salary
       , StaffUnits.Grade
       , StaffUnits.Leave
into 
     StaffUnitEngineer
from 
     StaffUnits join StaffUnitTypes on StaffUnits.IdStaffUnitTypes = StaffUnitTypes.Id
go

-- 10. Создает копию таблицы ПОДРАЗДЕЛЕНИЯ с именем КОПИЯ_ПОДРАЗДЕЛЕНИЯ

create procedure [dbo].[CopyDivisions]
as 
select 
 * 
 into 
       CopyDivisions
 from 
      Divisions
go

exec CopyDivisions
go
      










