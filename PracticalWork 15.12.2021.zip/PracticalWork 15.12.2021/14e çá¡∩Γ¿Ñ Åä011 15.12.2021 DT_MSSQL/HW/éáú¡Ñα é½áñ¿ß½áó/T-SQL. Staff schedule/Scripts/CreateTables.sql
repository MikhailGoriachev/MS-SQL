﻿
-- Удаление всех таблиц
drop table if exists StaffDistribution;
drop table if exists StaffTable;
drop table if exists Divisions;
drop table if exists DivisionTypes;
drop table if exists StaffUnits;
drop table if exists UnitsNames;
drop table if exists Persons;


-- Таблица наименований едениц 
CREATE TABLE [dbo].[UnitsNames]
(
	[Id] INT NOT NULL PRIMARY KEY identity (1,1), 
    [UnitName] NVARCHAR(80) NOT NULL

	
);
go

-- Таблица штатных едениц 
create table dbo.StaffUnits (
	Id          int not null primary key identity (1, 1), -- 
	IdUnitName int not null,				  -- Внешний ключ имени 
	Salary int not null,					  -- Оклад 
	UnitRank nvarchar(15) not null,			  -- Разряд
	Increment_2 float not null default ( 0.1),-- Процент надбавки
	Vacation int not null,					  -- Кол-во отпускных дней

	-- Ограничения 
	
	constraint CK_StaffUnits_Salary  check (Salary > 0),

	-- Связи с другими таблицами
	constraint FK_StaffUnits_UnitsNames foreign key (IdUnitName) references dbo.UnitsNames(Id)

);
go	

-- Таблица типов подразделений 
create table dbo.DivisionTypes (
	Id           int not null primary key identity (1, 1),-- 
	DivType nvarchar(50) not null, 				  -- Название типа подразделения

);
go	

-- Таблица подразделений 
create table dbo.Divisions (

	Id      int not null primary key identity (1, 1), 
	IdType  int not null, 	    -- Тип подразделения 
	DivName nvarchar(90), 	    -- Название подразделения
	Increment_1 float not null, -- Процент надбавки
	
	-- Ограничение 
	constraint CK_Divisions_Increment check(Increment_1 > 0.009),

	-- Связи с другими таблицами
	constraint FK_Divisions_DivisionTypes foreign key (IdType) references dbo.DivisionTypes (Id) ,

);
go	

-- Итоговая таблица распределения едениц
create table dbo.StaffDistribution (
	Id          int not null primary key identity (1, 1), 
	IdDivision int not null,
	IdStaffUnit int not null,
	Amount int not null,

	-- Связи с другими таблицами
	constraint FK_StaffDistribution_IdDivision foreign key (IdDivision) references dbo.Divisions (Id) ,
	constraint FK_StaffDistribution_StaffUnits foreign key (IdStaffUnit) references dbo.StaffUnits (Id) ,
	
	-- Ограничение 
	constraint CK_StaffDistribution_Amount check(Amount > 0),
);
go	

-- Таблица персон 
create table dbo.Persons (
	Id          int not null primary key identity (1, 1), 
	Person_name nvarchar(60) not null,    -- Фамилия 
	Surname		nvarchar(50) not null,    -- Имя 
	Patronymic	nvarchar(60) not null,    -- Отчество 
);
go	

-- Таблица "штатное расписание"
create table dbo.StaffTable(

	Id          int not null primary key identity (1, 1), 
	IdDivision int not null, -- Подразделение
	IdStaffUnit int not null,-- Штатная еденица 
	IdPerson int not null,	 -- Персоны

	-- Связи с другими таблицами
	constraint FK_StaffTable_IdDivision foreign key (IdDivision) references dbo.Divisions (Id) ,
	constraint FK_StaffTable_StaffUnits foreign key (IdStaffUnit) references dbo.StaffUnits (Id) ,
	constraint FK_StaffTable_Persons foreign key (IdPerson) references dbo.Persons (Id) ,

);
go	


/*create table dbo. (
	Id          int not null primary key identity (1, 1), 
);
go	

-- Связи с другими таблицами
	constraint FK_ _ foreign key (Id) references dbo. (Id) ,
	constraint FK_ _    foreign key (Id)    references dbo.  (Id)
-- Ограничение 
	constraint CK__  check ()
*/