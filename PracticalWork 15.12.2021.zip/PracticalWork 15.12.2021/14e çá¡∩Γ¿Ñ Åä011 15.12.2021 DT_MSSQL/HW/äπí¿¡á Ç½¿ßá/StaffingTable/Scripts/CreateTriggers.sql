﻿-- триггеры для операций вставки, удаления записей и изменения записей для таблицы DistributionStaffUnits
-- триггер для операции вставки
drop trigger if exists onInsert;
go

create trigger onInsert on DistributionStaffUnits 
    for insert 
	as
	begin
	    raiserror('Триггер onInsert: В таблицу DistributionStaffUnits добавлено записей: %d', 0, 1, @@rowcount);
	end;	
go

-- Демонстрация работы триггера
insert DistributionStaffUnits
	(IdUnit, IdStaffUnit, Amount)
values 
	( 1,  1, 1);
go


-- триггер для операции изменения
drop trigger if exists onUpdate;
go

create trigger onUpdate on DistributionStaffUnits 
    for update 
	as
	begin
	    raiserror('Триггер onUpdate: В таблице DistributionStaffUnits изменено записей: %d', 0, 1, @@rowcount);
	end;	
go

-- Демонстрация работы триггера
update
    DistributionStaffUnits
set
    IdStaffUnit = 2,
    IdUnit = 2,
    Amount = 2
where
    IdUnit = 1 and IdStaffUnit = 1 and Amount = 1;
go


-- триггер для операции удаления
drop trigger if exists onDelete;
go

create trigger onDelete on DistributionStaffUnits 
    for delete 
	as
	begin
	    raiserror('Триггер onDelete: В таблице DistributionStaffUnits удалено записей: %d', 0, 1, @@rowcount);
	end;	
go

-- Демонстрация работы триггера
delete from 
	DistributionStaffUnits
where 
	IdUnit = 2 and IdStaffUnit = 2 and Amount = 2;
go


-- Для таблицы ШТАТНЫЕ_ЕДИНИЦЫ разработайте триггеры для операций вставки и изменения записей.
-- Триггер изменения таблицы ШТАТНЫЕ_ЕДИНИЦЫ должен предотвратить изменение должности «инженер-электрик». 
-- триггер для операции вставки

-- триггер для операций вставки и изменения записей
drop trigger if exists InsertStaffUnits;
go

create trigger InsertStaffUnits on StaffUnits 
    for insert 
	as
	begin
	    raiserror('Триггер InsertStaffUnits: В таблицу StaffUnits добавлено записей: %d', 0, 1, @@rowcount);
	end;	
go

-- Демонстрация работы триггера
insert StaffUnits
	(IdPosition, category, Salary, Vacation, [Percent])
values 
	( (select id from Positions where Position = N'инженер-электрик'), N'специалист', 60000, 30, 5.7);
go


-- триггер для операций вставки и изменения записей
drop trigger if exists UpdateStaffUnits;
go

create trigger UpdateStaffUnits on StaffUnits
    for update
	as
	begin
	    -- подсчитать количество удаленных записей
		declare @counter int;
		select @counter = count(*) from deleted;
		print N'Запрос на изменение ' + convert(nvarchar, @counter) + N' зап.';
		
		-- проверка наличия среди удаляемых записей должность «инженер-электрик»
		declare @position nvarchar(70) = N'';
		select 
		    @position = Positions.Position
		from 
		    deleted join Positions on deleted.IdPosition = Positions.Id
		where 
		    Positions.Position = N'инженер-электрик';  

		-- среди именяемых есть должность «инженер-электрик»
		if @position != N'' begin
			print N'Невозможно измененить должность «инженер-электрик»!';
		    rollback tran;
		end else begin
		    raiserror(N'Измененяем %d записей', 0, 1, @counter);
		end;
    end;	
go

-- Демонстрация работы триггера
update
    StaffUnits
set
    [Percent] = 10
where
    IdPosition = (select id from Positions where Position = N'инженер-электрик');
go