﻿-- процедура аналог представления ViewAllocations для демонстрации при проверке триггеров
create proc ProcShowAllocations
as begin
	select 
		Persons.Surname + N' ' + Substring(Persons.[Name], 1, 1) 
				  + N'.' + Substring(Persons.Patronymic, 1, 1) 
				  + N'.' as Staff 
		, Position
		, DivTypes.Type as DivisionType
		, Units.Salary
		, Units.Rank
		, Divisions.SalaryPerks as SalaryPerks1
		, Units.SalaryPerks as SalaryPerks2
		, Units.VacationDays
		, Units.Salary * (1 + Divisions.SalaryPerks/100 + Units.SalaryPerks/100) as AccruedWages
		, Units.Salary * (1 + Divisions.SalaryPerks/100 + Units.SalaryPerks/100) * 0.13 as Tax

	from StaffAllocations join (Divisions join DivTypes on Divisions.IdType = DivTypes.Id) on IdDivision = Divisions.Id
						  join (Units join Positions on Units.IdType = Positions.Id) on IdUnit = Units.Id
						  join Persons on IdPerson = Persons.Id;
end;
go


-- Выборка всех данных по представлению таблицы распределений
select
	*
from
	ViewAllocations
go





--1
--Хранимая процедура 
--Выбирает из таблицы ПОДРАЗДЕЛЕНИЯ информацию о подразделениях, имеющих тип «отдел» или «цех»,
--для которых Процент_надбавки_1 больше значения, заданного параметром 
drop procedure if exists ProcQuery01;
go

create proc ProcQuery01 @percent float
as begin
	select
		Divisions.Id
		,Type
		, SalaryPerks
	from
		Divisions join DivTypes on IdType = DivTypes.Id
	where
		Divisions.SalaryPerks > @percent and Type = N'Цех' or Type = N'Отдел';
end;
go

declare @percent float = 0;
exec ProcQuery01 @percent;
go

declare @percent float = 10;
exec ProcQuery01 @percent;
go


--2 
--Хранимая процедура 
--Выбирает из таблицы ШТАТНЫЕ_ЕДИНИЦЫ информацию о штатных единицах с окладом в заданном диапазоне и
--значением в поле Процент_надбавки_2 также равным заданному. Диапазон оклада и процент надбавки задавать параметрами 
drop procedure if exists ProcQuery02;
go

create proc ProcQuery02 @salaryFrom int, @salaryTo int, @perks float
as begin
	select 
		Position
		, Salary
		, SalaryPerks
		, VacationDays
	from 
		Units join Positions on Units.IdType = Positions.Id
	where 
		Units.Salary in (@salaryFrom, @salaryTo) and abs(Units.SalaryPerks - @perks) < 1e-6;
end;
go

declare @salaryFrom int = 30000, @salaryTo int = 40000, @perks float = 10;
exec ProcQuery02 @salaryFrom, @salaryTo, @perks;
go

declare @salaryFrom int = 35000, @salaryTo int = 40000, @perks float = 15;
exec ProcQuery02 @salaryFrom, @salaryTo, @perks;
go

--3 
--Однотабличная функция 
--Выбирает из таблицы ПОДРАЗДЕЛЕНИЯ информацию о подразделениях, для которых тип подразделения равен
--заданному параметром или Процент_надбавки_1 равен заданному параметром  
drop function if exists FuncQuery03;
go

create function FuncQuery03(@type nvarchar(60), @percent float) returns table
as return
	select 
		Name
		, Type
		, SalaryPerks
	from
		Divisions join DivTypes on Divisions.IdType = DivTypes.Id
	where
		Type = @type or SalaryPerks = @percent;
go


declare @type nvarchar(60) = N'Отдел', @percent float = 10;
select * from dbo.FuncQuery03(@type, @percent);
go

declare @type nvarchar(60) = N'Бригада', @percent float = 40;
select * from dbo.FuncQuery03(@type, @percent);
go

--4 
--Хранимая процедура 
--Выбирает из таблицы ШТАТНЫЕ_ЕДИНИЦЫ информацию о штатных единицах с заданным параметром наименованием
--и заданной параметром величиной оклада 
drop procedure if exists ProcQuery04;
go

create proc ProcQuery04 @position nvarchar(30), @salary int
as begin
	select 
		Position
		, Salary
		, Rank
		, SalaryPerks
		, VacationDays
	from
		Units join Positions on Units.IdType = Positions.Id
	where
		Position = @position and Salary = @salary;
end;
go

declare @position nvarchar(30) = N'Механик', @salary int = 37000;
exec ProcQuery04 @position, @salary
go

declare @position nvarchar(30) = N'Сварщик', @salary int = 42000;
exec ProcQuery04 @position, @salary
go

--5 
--Однотабличная функция 
--Выбирает из таблицы ШТАТНЫЕ_ЕДИНИЦЫ информацию о штатных единицах, имеющих заданное параметром наименование,
--для которых Процент_надбавки_2 имеет значение из некоторого заданного диапазона. 
--Нижняя и верхняя границы диапазона также задаются параметрами функции 
drop function if exists FuncQuery05;
go

create function FuncQuery05(@type nvarchar(30), @perksFrom float, @perksTo float) returns table
as return
	select 
		Position
		, Salary
		, Rank
		, SalaryPerks
		, VacationDays
	from
		Units join Positions on Units.IdType = Positions.Id
	where
		Position = @type and SalaryPerks in (@perksFrom, @perksTo);
go


declare @type nvarchar(30) = N'Металлург', @perksFrom float = 40, @perksTo float = 50;
select * from dbo.FuncQuery05(@type, @perksFrom, @perksTo);
go

declare @type nvarchar(30) = N'Механик', @perksFrom float = 10, @perksTo float = 11;
select * from dbo.FuncQuery05(@type, @perksFrom, @perksTo);
go

--6 
-- Однотабличная функция 
-- Вычисляет размер подоходного налога с начисленной заработной платы для каждой распределенной штатной единицы 
-- в соответствии с таблицей РАСПРЕДЕЛЕНИЕ_ШТАТНЫХ_ЕДИНИЦ.  
-- Включает поля Наименование подразделения, Наименование единицы, Оклад, Процент_надбавки_1, Процент_надбавки_2,
-- Размер зарплаты, Налог.
-- Сортировка по полю Наименование подразделения 
drop function if exists FuncQuery06;
go

create function FuncQuery06() returns table
as return
	select top (select count(*) from ViewAllocations)
		DivisionType
		, Position
		, Salary
		, SalaryPerks1
		, SalaryPerks2
		, AccruedWages
		, Tax
	from
		ViewAllocations
	order by DivisionType	
go

select * from dbo.FuncQuery06();
go

--7 
--Однотабличная функция 
--Выполняет группировку по полю Тип подразделения в таблице ПОДРАЗДЕЛЕНИЯ. Для каждой группы вычисляет 
--среднее значение по полю Процент_надбавки_1 
drop function if exists FuncQuery07;
go

create function FuncQuery07() returns table
as return
	select 
		Type
		, AVG(Divisions.SalaryPerks) as AvgPerks
		, Count(SalaryPerks) as Count
	from
		Divisions join DivTypes on IdType = DivTypes.Id
	group by Type
go

select * from dbo.FuncQuery07();
go

--8 
--Однотабличная функция 
--Выполняет группировку по полю Наименование штатной единицы в таблице ШТАТНЫЕ_ЕДИНИЦЫ. Для каждой группы
--вычисляет минимальное и максимальное значения по полю Отпуск 

drop function if exists FuncQuery08;
go

create function FuncQuery08() returns table
as return
	select 
		Position
		, Min(VacationDays) as MinVacationDays
		, Max(VacationDays) as MaxVacationDays
	from
		Units join Positions on Positions.Id = IdType
	group by Position;
go

select * from dbo.FuncQuery08();
go



--9 
--Запрос на создание базовой таблицы (просто запрос) 
--Создает таблицу ШТАТНЫЕ_ЕДИНИЦЫ_ИНЖЕНЕР, содержащую информацию о штатных единицах с наименованием «инженер» 
drop table if exists Units_Engineer;

select
	Units.Id
	, Position
	, Units.Salary
	, Units.SalaryPerks
	, Units.VacationDays
	into Units_Engineer
from 
	Units join Positions on Positions.Id = IdType
where Position = N'Инженер';
go

select * from Units_Engineer 
go

--10 
--Хранимая процедура 
--Создает копию таблицы ПОДРАЗДЕЛЕНИЯ с именем КОПИЯ_ПОДРАЗДЕЛЕНИЯ 
drop procedure if exists ProcQuery10;
go

create proc ProcQuery10 
as begin
	drop table if exists Copy_Divisions;
	select 
		*
		into Copy_Divisions
	from
		Divisions
end;
go

exec ProcQuery10;
go

select 
	Copy_Divisions.Id
	,Type
	,Copy_Divisions.Name
	,Copy_Divisions.SalaryPerks
from 
	Copy_Divisions join DivTypes on IdType = DivTypes.Id;
go

--11 
--Хранимая процедура 
--Удаляет из таблицы КОПИЯ_ПОДРАЗДЕЛЕНИЯ записи, в которых значение в поле Процент_надбавки_1 меньше заданного значения 

drop procedure if exists ProcQuery11;
go

create proc ProcQuery11 @percent float
as begin
	delete from
		Copy_Divisions
	where 
		SalaryPerks < @percent
end;
go

select 
	Copy_Divisions.Id
	,Type
	,Copy_Divisions.Name
	,Copy_Divisions.SalaryPerks
from 
	Copy_Divisions join DivTypes on IdType = DivTypes.Id;
go

declare @percent float = 5;
exec ProcQuery11 @percent;
go

select 
	Copy_Divisions.Id
	,Type
	,Copy_Divisions.Name
	,Copy_Divisions.SalaryPerks
from 
	Copy_Divisions join DivTypes on IdType = DivTypes.Id;
go

--12 
--Хранимая процедура 
--Увеличивает значение в поле Процент_надбавки_1 таблицы КОПИЯ_ПОДРАЗДЕЛЕНИЯ на заданное параметром значение
--для заданного параметром подразделения 


drop procedure if exists ProcQuery12;
go

create proc ProcQuery12 @percentOld float, @percentNew float
as begin
	update
		Copy_Divisions
	set
		SalaryPerks = @percentNew
	where 
		abs(SalaryPerks - @percentOld) < 1e-6
end;
go

select 
	Copy_Divisions.Id
	,Type
	,Copy_Divisions.Name
	,Copy_Divisions.SalaryPerks
from 
	Copy_Divisions join DivTypes on IdType = DivTypes.Id;
go

declare @percentOld float = 10, @percentNew float = 20;
exec ProcQuery12 @percentOld, @percentNew ;
go

select 
	Copy_Divisions.Id
	,Type
	,Copy_Divisions.Name
	,Copy_Divisions.SalaryPerks
from 
	Copy_Divisions join DivTypes on IdType = DivTypes.Id;
go
