﻿-- 1
-- Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
select * from dbo.GetAllOrdersWithLicenseNumber('Y421ET')
go


-- 2
-- Выбирает информацию обо всех фактах проката автомобиля с заданной моделью/брендом
execute dbo.GetAllOrdersWithBrandId @brandId = 3
go


-- 3
-- Выбирает информацию об автомобиле с заданным госномером
select * from dbo.GetCarWithLicenseNumber('Y421ET')
go


-- 4
-- Выбирает информацию о клиентах по серии и номеру паспорта
execute dbo.GetClientsByPassport @passport = 'BH25736525766254352348'
go


-- 5
-- Выбирает информацию обо всех зафиксированных фактах проката 
-- автомобилей в некоторый заданный интервал времени.
execute dbo.GetOrdersForCertainPeriod @from = '10.31.21', @to = '10.31.22'
go


-- 6
-- Вычисляет для каждого факта проката стоимость проката. Включает поля Дата проката, 
-- Госномер автомобиля, Модель автомобиля, Стоимость проката. Сортировка по полю Дата проката
select * from dbo.GetRentTotalForAllOrders() as Response
order by Response.StartDate asc
go


-- 7
-- Для всех клиентов прокатной фирмы вычисляет количество фактов проката, суммарное 
-- количество дней проката, упорядочивание по убыванию суммарного количества дней проката
execute dbo.GetAllClientsWithOrdersCountAndDuration
go


-- 8
-- Выбирает информацию о фактах проката автомобилей по госномеру: количество фактов 
-- проката, сумма за прокаты, суммарная длительность прокатов
select * from dbo.GetInfoAboutCarWithLicenseNumber('Y421ET')
go