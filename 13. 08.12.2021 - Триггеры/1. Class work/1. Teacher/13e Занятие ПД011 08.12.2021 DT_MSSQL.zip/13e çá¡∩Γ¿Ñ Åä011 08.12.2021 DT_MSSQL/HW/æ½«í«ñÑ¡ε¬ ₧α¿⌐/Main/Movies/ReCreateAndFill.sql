﻿drop table if exists MoviesActors;
drop table if exists Movies;
drop table if exists Persons;
drop table if exists Countries;
drop table if exists Genres;
go


begin -- Countries


CREATE TABLE [dbo].[Countries]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Country] NVARCHAR(50) NOT NULL, 
    CONSTRAINT [CK_Countries_Country] UNIQUE([Country])
);


INSERT INTO Countries
VALUES
    ('UK'),
    ('France'),
    ('Germany'),
    ('USA'),
    ('Spain')

end
go


begin -- Genres


CREATE TABLE [dbo].[Genres]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Genre] NVARCHAR(50) NOT NULL, 
    CONSTRAINT [CK_Countries_Genre] UNIQUE([Genre])
);


INSERT INTO Genres
VALUES
    ('Thriller'),
    ('Fantasy'),
    ('Historical'),
    ('Western'),
    ('Detective')


end
go


begin -- Persons


CREATE TABLE [dbo].[Persons]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Surname] NVARCHAR(60) NOT NULL,
    [Firstname] NVARCHAR(60) NOT NULL,
    [Patronymic] NVARCHAR(60) NOT NULL,
    [BirthDate] DATE NOT NULL,
);


INSERT INTO Persons
VALUES
  ('Collins','Gareth','N','04/13/2022'),
  ('Gregory','Arden','F','12/06/2020'),
  ('Doyle','Castor','K','04/09/2021'),
  ('Bradshaw','Jessica','R','09/13/2022'),
  ('Macdonald','Moses','H','12/01/2021'),
  ('Alvarado','Susan','X','06/20/2022'),
  ('Kane','Barry','A','10/11/2022'),
  ('Salas','Pearl','O','03/03/2021'),
  ('Morton','Chase','M','01/26/2022'),
  ('Tate','Camille','N','04/21/2021'),
  ('Gaines','Garth','F','06/07/2021'),
  ('Turner','Ishmael','G','01/29/2021'),
  ('Barlow','Maggie','F','04/10/2022'),
  ('Rowe','Maite','H','11/27/2022'),
  ('Beasley','Audrey','W','05/02/2022'),
  ('Tillman','Tad','A','03/15/2022'),
  ('Castro','Risa','R','12/23/2020'),
  ('Lane','Xyla','Y','11/09/2021'),
  ('Bailey','Galvin','S','10/15/2022'),
  ('Goff','Cade','U','05/25/2022'),
  ('Moses','Garth','W','03/20/2021'),
  ('David','Hadassah','O','04/16/2022'),
  ('Pitts','Fuller','D','09/08/2022'),
  ('Maldonado','Dieter','Y','09/19/2022'),
  ('Mercado','Yuli','S','12/18/2021'),
  ('Jacobs','Patrick','F','05/01/2022'),
  ('Colon','Lillith','G','01/17/2021'),
  ('Morales','Kieran','C','04/11/2021'),
  ('Mcfadden','Lois','F','10/11/2021'),
  ('Rhodes','Harriet','Q','05/23/2022'),
  ('Pennington','Kalia','W','07/02/2022'),
  ('Stokes','Carl','H','01/01/2022'),
  ('Lawrence','Kieran','M','07/01/2022'),
  ('Hampton','Ivor','F','03/19/2022'),
  ('Kidd','Tyler','R','03/05/2021'),
  ('Foreman','Kirestin','F','02/04/2022'),
  ('Silva','Buckminster','L','02/19/2021'),
  ('Kelly','Kirby','A','04/14/2021'),
  ('Hicks','Brent','D','02/18/2022'),
  ('Mcguire','Tarik','O','08/11/2021'),
  ('Tanner','Karleigh','S','04/29/2022'),
  ('Sloan','Mannix','E','08/16/2021'),
  ('Hutchinson','Orson','Z','04/13/2021'),
  ('Hoffman','Reed','C','01/31/2022'),
  ('Benson','Steel','X','04/09/2021'),
  ('Flores','Quamar','O','11/14/2022'),
  ('Davenport','Zeus','D','12/12/2020'),
  ('Mercado','Rose','D','12/16/2020'),
  ('Joyce','Abel','X','10/20/2022'),
  ('Stein','Daphne','B','01/25/2021'),
  ('Hancock','Fatima','K','10/29/2021'),
  ('Dunn','Ina','Q','04/09/2021'),
  ('Jones','Nita','X','01/23/2022'),
  ('Shannon','Melvin','P','06/13/2022'),
  ('Mcguire','Stuart','H','10/28/2021'),
  ('O''Neill','Wing','J','08/05/2021'),
  ('Moon','Mason','R','03/02/2021'),
  ('Hutchinson','Victoria','J','08/24/2021'),
  ('Potts','Kane','W','10/29/2022'),
  ('Joyce','Herman','Z','10/18/2022'),
  ('Huffman','Olivia','U','10/31/2021'),
  ('Duncan','Donna','U','11/25/2022'),
  ('Bond','Kelsey','I','03/29/2021'),
  ('Landry','Kevyn','B','06/21/2021'),
  ('Glass','Shay','R','01/23/2021'),
  ('Rose','Drew','S','09/08/2021'),
  ('Wolf','Marcia','R','07/24/2022'),
  ('Newton','Drew','F','12/26/2021'),
  ('Albert','Scarlet','G','03/04/2021'),
  ('Dillon','Sydney','F','06/02/2022'),
  ('Ferguson','Chava','O','05/23/2022'),
  ('Cooley','Charde','N','03/06/2022'),
  ('Pratt','Fay','O','09/21/2021'),
  ('Watkins','Iola','K','12/11/2020'),
  ('Horton','Zoe','K','01/10/2022'),
  ('Gonzalez','Judah','Y','10/22/2022'),
  ('Britt','Idola','M','10/07/2021'),
  ('Kline','Ori','Z','03/02/2022'),
  ('Vang','Constance','K','08/31/2022'),
  ('Atkins','Rylee','W','11/25/2022'),
  ('William','Dylan','F','03/29/2022'),
  ('Dickson','Rashad','M','07/24/2021'),
  ('Townsend','Lareina','X','05/09/2021'),
  ('Middleton','Amber','E','02/01/2022'),
  ('Sampson','Dean','X','07/02/2021'),
  ('Williamson','Ahmed','E','10/02/2022'),
  ('Oliver','Brielle','S','01/10/2021'),
  ('Miller','Idola','I','04/25/2022'),
  ('Albert','Bree','N','05/03/2022'),
  ('Robles','Rachel','W','04/12/2021'),
  ('Bailey','Gareth','I','02/13/2021'),
  ('Haney','Maile','I','11/13/2022'),
  ('Bailey','Aurora','H','08/22/2021'),
  ('Guthrie','Jessica','N','09/27/2021'),
  ('Mckee','Hilel','R','04/05/2022'),
  ('O''Neill','Xanthus','A','08/14/2021'),
  ('Baldwin','Simone','Q','05/29/2021'),
  ('Steele','Keane','C','06/30/2021'),
  ('Barlow','Marsden','K','07/24/2022'),
  ('Mendez','Jaime','O','08/10/2021');
    

end
go


begin -- Movies


CREATE TABLE [dbo].[Movies]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Title] NVARCHAR(40) NOT NULL,
    [ProducerId] INT NOT NULL,
    [CountryId] INT NOT NULL,
    [GenreId] INT NOT NULL,
    [ReleaseDate] DATE NULL,
    [Budget] MONEY NOT NULL,
    CONSTRAINT [CK_Movies_Budget] CHECK ([Budget] >= 0),
    CONSTRAINT [FK_Movies_Persons] FOREIGN KEY ([ProducerId]) REFERENCES [Persons]([Id]),
    CONSTRAINT [FK_Movies_Countries] FOREIGN KEY ([CountryId]) REFERENCES [Countries]([Id]),
    CONSTRAINT [FK_Movies_Genres] FOREIGN KEY ([GenreId]) REFERENCES [Genres]([Id])
);


INSERT INTO Movies
VALUES
  ('lobortis, nisi',42,1,5,'09/15/2021',239365313),
  ('litora torquent per',33,3,5,'12/20/2020',353725600),
  ('lectus sit',5,3,4,'09/18/2021',144056601),
  ('a tortor. Nunc commodo',14,4,5,'07/23/2021',661288734),
  ('orci sem',96,5,3,'04/10/2021',216477687),
  ('porta elit, a feugiat',44,1,2,'05/31/2021',492071986),
  ('gravida nunc sed',7,3,2,'10/03/2021',169997245),
  ('pellentesque. Sed',85,3,3,'04/09/2022',474471912),
  ('Sed congue,',85,5,3,'10/31/2021',191067571),
  ('arcu. Morbi',41,3,3,'03/28/2021',28766962),
  ('amet',20,1,3,'03/23/2021',363860494),
  ('molestie pharetra',83,2,3,'06/19/2022',350465371),
  ('dis',80,5,3,'02/24/2021',143923320),
  ('ut odio',35,2,2,'01/29/2021',482303516),
  ('sit amet nulla.',98,2,4,'04/24/2021',792347223),
  ('quis',22,4,3,'01/18/2022',647917649),
  ('sit',36,4,3,'09/10/2021',622509938),
  ('Curabitur sed tortor. Integer',42,2,1,'04/20/2021',525023863),
  ('non, feugiat',68,4,2,'06/29/2022',36270664),
  ('In faucibus. Morbi',66,2,5,'02/09/2022',113047774),
  ('nec ligula',75,4,2,'01/01/2021',278869715),
  ('Integer id magna',49,2,4,'04/15/2021',332043862),
  ('et,',51,4,4,'06/27/2022',392616592),
  ('diam at pretium',79,3,4,'02/13/2021',542135667),
  ('cursus',6,4,1,'05/20/2022',82104403),
  ('pharetra, felis',16,3,2,'08/08/2021',88982242),
  ('eget',39,5,3,'12/10/2021',723429995),
  ('eu, odio. Phasellus',6,4,1,'11/21/2022',251242600),
  ('dictum augue malesuada malesuada.',33,2,5,'12/11/2020',667202172),
  ('Quisque nonummy ipsum',58,3,3,'09/20/2021',95950276),
  ('Donec',10,3,3,'08/06/2022',196499278),
  ('eu enim. Etiam',8,3,1,'10/14/2021',52573712),
  ('hendrerit a,',4,2,2,'10/03/2022',753322743),
  ('auctor, velit',99,5,5,'11/23/2022',354951010),
  ('neque sed',35,3,4,'12/04/2020',661114794),
  ('dolor. Fusce',5,4,4,'02/13/2021',336276418),
  ('Duis dignissim tempor arcu.',69,1,2,'06/13/2021',21846430),
  ('nisl elementum',93,5,5,'03/21/2022',717227289),
  ('Cras vulputate',85,3,2,'03/16/2021',333859695),
  ('iaculis odio.',50,1,2,'01/06/2022',146006474),
  ('ante. Vivamus',37,3,2,'06/10/2022',293222586),
  ('imperdiet ullamcorper. Duis at',22,2,3,'06/22/2021',755721169),
  ('magna a neque. Nullam',15,4,2,'03/13/2021',488146378),
  ('augue',84,4,4,'08/07/2022',270056355),
  ('in molestie tortor',25,3,1,'05/03/2022',142911115),
  ('ad litora torquent per',51,2,2,'09/28/2022',435143103),
  ('nonummy',2,3,2,'05/05/2022',149675437),
  ('Nulla tempor augue',20,1,2,'06/05/2022',373574104),
  ('orci',78,2,3,'04/05/2022',544563036),
  ('cursus et, eros. Proin',83,4,3,'01/19/2022',191128688),
  ('parturient montes,',23,1,3,'12/01/2022',46372113),
  ('Duis at lacus.',90,4,1,'07/13/2022',109279223),
  ('mi eleifend',82,3,3,'09/11/2022',384148128),
  ('amet orci.',73,2,2,'01/28/2022',149683535),
  ('eu, eleifend nec,',10,4,4,'11/11/2021',594602703),
  ('Integer in magna. Phasellus',77,3,4,'04/15/2021',501633841),
  ('non quam.',97,4,2,'01/31/2022',297727627),
  ('Morbi neque',35,1,1,'09/03/2022',353260549),
  ('neque pellentesque',4,4,3,'12/06/2020',563984760),
  ('luctus et',81,5,3,'12/04/2021',748207587),
  ('justo nec ante.',55,3,1,'08/06/2021',629685001),
  ('vitae, erat.',46,3,1,'12/07/2021',338191851),
  ('interdum. Curabitur',1,2,4,'09/11/2021',208662906),
  ('Donec tempor,',93,3,3,'05/15/2021',76557176),
  ('nec urna et',75,4,2,'10/26/2021',179127876),
  ('turpis. In',76,4,4,'10/24/2021',738532798),
  ('nulla magna, malesuada vel,',38,2,4,'01/27/2021',175316215),
  ('Quisque nonummy',39,2,1,'06/25/2022',741392213),
  ('dolor. Fusce',13,3,3,'10/23/2022',195008996),
  ('in molestie tortor',46,4,3,'05/05/2021',369209276),
  ('Fusce feugiat.',64,3,2,'11/08/2021',178527738),
  ('sapien,',47,4,3,'06/11/2021',390886947),
  ('purus sapien, gravida non,',21,1,2,'04/01/2021',214180676),
  ('mollis nec,',70,4,4,'08/28/2022',534748339),
  ('Suspendisse sed',82,3,5,'03/21/2022',624385639),
  ('gravida nunc',86,5,4,'06/12/2022',269675240),
  ('est.',15,4,4,'06/10/2021',748935383),
  ('urna et',59,3,1,'07/28/2022',98374506),
  ('pede nec ante',58,4,3,'03/13/2022',418593096),
  ('justo. Praesent',5,4,2,'10/04/2021',249571648),
  ('tortor at',88,3,5,'09/11/2022',472367355),
  ('Nunc',82,3,4,'04/13/2021',87221332),
  ('augue id ante dictum',59,5,3,'08/11/2021',381785730),
  ('eu eros.',22,1,2,'08/18/2021',175589812),
  ('nisi. Mauris',78,3,3,'11/01/2021',253121059),
  ('a tortor. Nunc',39,3,3,'02/28/2022',677652910),
  ('pharetra, felis eget',21,2,2,'05/12/2022',644959004),
  ('non enim commodo',54,1,4,'12/15/2020',770592717),
  ('Aenean eget magna. Suspendisse',65,5,3,'03/29/2022',116316193),
  ('ultrices posuere',15,4,1,'06/18/2022',367141373),
  ('aliquet',27,3,3,'07/16/2022',642316926),
  ('nunc risus varius',84,1,1,'04/29/2022',394472449),
  ('egestas. Sed pharetra,',83,5,4,'10/13/2021',302723632),
  ('et malesuada',93,2,3,'04/21/2021',316496137),
  ('commodo at, libero.',65,4,5,'07/30/2022',543018006),
  ('Sed et libero.',95,2,4,'05/02/2021',310209442),
  ('sit amet, consectetuer',80,3,1,'11/21/2022',53752979),
  ('sociis natoque',19,1,3,'02/13/2022',359276671),
  ('et, euismod et,',15,1,3,'05/30/2022',533656328),
  ('eleifend egestas. Sed',17,3,1,'10/24/2021',767107111);
    

end
go


begin -- MoviesActors


CREATE TABLE [dbo].[MoviesActors]
(
    PRIMARY KEY (MovieId, ActorId),
    [MovieId] INT NOT NULL,
	[ActorId] INT NOT NULL,
    CONSTRAINT [FK_MoviesActors_Movies] FOREIGN KEY ([MovieId]) REFERENCES [Movies]([Id]),
    CONSTRAINT [FK_MoviesActors_Persons] FOREIGN KEY ([ActorId]) REFERENCES [Persons]([Id])
);


INSERT INTO MoviesActors
VALUES
  (41,32),
  (29,53),
  (20,57),
  (24,9),
  (46,39),
  (87,88),
  (55,46),
  (12,30),
  (57,36),
  (80,80),
  (66,39),
  (72,82),
  (34,27),
  (80,78),
  (60,22),
  (28,67),
  (52,25),
  (92,17),
  (59,93),
  (85,97),
  (98,11),
  (31,76),
  (21,73),
  (38,100),
  (22,12),
  (99,27),
  (79,30),
  (41,68),
  (63,42),
  (49,42),
  (62,73),
  (60,100),
  (44,68),
  (5,81),
  (51,7),
  (43,91),
  (2,47),
  (83,79),
  (10,32),
  (19,36),
  (68,20),
  (55,69),
  (47,91),
  (39,26),
  (17,31),
  (94,17),
  (54,16),
  (50,28),
  (20,89),
  (90,34),
  (59,67),
  (99,86),
  (86,42),
  (87,100),
  (95,40),
  (60,13),
  (78,32),
  (70,42),
  (4,84),
  (53,2),
  (64,18),
  (91,74),
  (10,40),
  (88,23),
  (74,68),
  (58,7),
  (53,90),
  (21,45),
  (4,41),
  (63,100),
  (46,94),
  (58,98),
  (75,64),
  (16,32),
  (96,3),
  (22,28),
  (24,72),
  (58,10),
  (2,9),
  (65,21),
  (62,21),
  (27,59),
  (8,41),
  (5,91),
  (95,6),
  (4,98),
  (13,10),
  (85,92),
  (32,2),
  (43,23),
  (59,86),
  (15,74),
  (78,7),
  (34,4),
  (32,38),
  (84,17),
  (14,41),
  (73,25),
  (85,70),
  (61,76);


end
go