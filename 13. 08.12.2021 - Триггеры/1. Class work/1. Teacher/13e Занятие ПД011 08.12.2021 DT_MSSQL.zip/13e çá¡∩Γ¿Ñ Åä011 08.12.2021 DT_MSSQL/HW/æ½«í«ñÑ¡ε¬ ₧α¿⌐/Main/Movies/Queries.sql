﻿-- 1
-- Вывести все фильмы, вышедшие на экран в текущем и прошлом году
select * from dbo.GetAllMoviesInCurrentandPastYear


-- 2
-- Вывести информацию об актерах, снимавшихся в заданном фильме.
select * from dbo.GetAllActorInMovie('a tortor. Nunc commodo')


-- 3
-- Вывести информацию об актерах, снимавшихся как минимум в N фильмах.
select * from dbo.GetActorsByShotCount(2)


-- 4
-- Вывести информацию об актерах, которые были режиссерами хотя бы одного из фильмов.
execute dbo.GetAllActorsWhoProducer


-- 5
-- Вывести все фильмы, дата выхода которых была более заданного числа лет назад.
execute dbo.GetMoviesDatedMoreThanYearsAgo @yearsAgo = 0


-- 6
-- Вывести всех актеров и количество фильмов, в которых они участвовали.
execute dbo.GetAllActorsAndMoviesCount