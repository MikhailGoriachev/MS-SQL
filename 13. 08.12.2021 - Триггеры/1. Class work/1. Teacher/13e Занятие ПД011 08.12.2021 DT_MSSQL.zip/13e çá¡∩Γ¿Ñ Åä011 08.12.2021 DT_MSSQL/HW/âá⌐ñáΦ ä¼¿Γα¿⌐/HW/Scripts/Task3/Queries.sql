﻿

-- 1
-- Выбирает информацию обо всех фактах проката автомобиля с заданным госномером

drop function if exists GetHiresWherePlate;
go

create function GetHiresWherePlate(@plate nvarchar(12))
returns table
as
return
	select
    Id
    , ClientSurname + N' ' + Substring(ClientName, 1, 1) + N'.' + 
          Substring(ClientPatronymic, 1, 1) + N'.' as Client
    , BrandModel
    , Plate
    , DateStart
    , Duration
from
    ViewHires
where
    Plate = @plate
go

-- вызов функции GetHiresWherePlate()
select 
    * 
from 
    dbo.GetHiresWherePlate(N'С167РК');
go

select 
    * 
from 
    dbo.GetHiresWherePlate(N'О169РК');
go

select 
    * 
from 
    dbo.GetHiresWherePlate(N'Т315РК');
go


-- 2
-- Выбирает информацию обо всех фактах проката автомобиля с заданной моделью/брендом

drop procedure if exists GetHiresWhereBrand;
go

create procedure GetHiresWhereBrand
    @brand nvarchar(30)
as
begin
select
    Id
    , ClientSurname + N' ' + Substring(ClientName, 1, 1) + N'.' + 
          Substring(ClientPatronymic, 1, 1) + N'.' as Client
    , BrandModel
    , Plate
    , DateStart
    , Duration
from
    ViewHires
where
    BrandModel = @brand
end;
go

-- вызов процедуры GetHiresWhereBrand
exec dbo.GetHiresWhereBrand N'Volkswagen Polo';
go

exec dbo.GetHiresWhereBrand N'Skoda Roomster';
go

exec dbo.GetHiresWhereBrand N'Skoda Fabia New';
go


-- 3
-- Выбирает информацию об автомобиле с заданным госномером

drop function if exists GetCarWherePlate;
go

create function GetCarWherePlate(@plate nvarchar(12))
returns table
as
return
select
    Id 
    , BrandModel
    , Color
    , Plate
    , YearManuf
    , InsurValue
    , Rental
from
    ViewCars
where
    Plate = @plate;
go

-- вызов функции GetCarWherePlate()
select 
    * 
from 
    dbo.GetCarWherePlate(N'С167РК');
go

select 
    * 
from 
    dbo.GetCarWherePlate(N'О169РК');
go

select 
    * 
from 
    dbo.GetCarWherePlate(N'Т315РК');
go


-- 4
-- Выбирает информацию о клиентах по серии и номеру паспорта

drop procedure if exists GetClientWherePassport;
go

create procedure GetClientWherePassport
    @passport nvarchar(15)
as
begin
select
    Id 
    , Surname
    , [Name]
    , Patronymic
    , Passport
from
    Clients
where
    Passport = @passport;
end;
go

-- вызов процедуры GetClientWherePassport
exec dbo.GetClientWherePassport '11 21 098181';
go

exec dbo.GetClientWherePassport '09 21 121921'
go

exec dbo.GetClientWherePassport '09 19 002165';
go


-- 5
-- Выбирает информацию обо всех зафиксированных фактах проката
-- автомобилей в некоторый заданный интервал времени.

drop procedure if exists GetHiresBetweenDate;
go

create procedure GetHiresBetweenDate
    @from date,
    @to   date
as
begin
select
    Id
    , ClientSurname + N' ' + Substring(ClientName, 1, 1) + N'.' + 
          Substring(ClientPatronymic, 1, 1) + N'.' as Client
    , BrandModel
    , Plate
    , DateStart
    , Duration
from
    ViewHires
where
    DateStart between @from and @to 
end;
go

-- вызов процедуры GetHiresBetweenDate
exec dbo.GetHiresBetweenDate '09-01-2021', '09-03-2021';
go

exec dbo.GetHiresBetweenDate '09-03-2021', '09-20-21';
go

exec dbo.GetHiresBetweenDate '09-20-2021', '10-22-2021';
go


-- 6
-- Вычисляет для каждого факта проката стоимость проката.
-- Включает поля Дата проката, Госномер автомобиля, Модель автомобиля,
-- Стоимость проката. Сортировка по полю Дата проката

drop function if exists GetHiresCost;
go

create function GetHiresCost()
returns table
as
return
select
    Id
    , DateStart
    , Plate
    , BrandModel
    , Rental            as RentalPerDay
    , Duration
    , Rental * Duration as Price 
from
    ViewHires
go

-- вызов функции GetHiresCost()
select 
    * 
from 
    dbo.GetHiresCost();
go


-- 7
-- Для всех клиентов прокатной фирмы вычисляет количество фактов проката,
-- суммарное количество дней проката,
-- упорядочивание по убыванию суммарного количества дней проката

drop procedure if exists GetClientsCountHires;
go

create procedure GetClientsCountHires
as
begin
select
    Clients.Id
    , Clients.Surname + N' ' + Substring(Clients.[Name], 1, 1) + N'.' + 
          Substring(Clients.Patronymic, 1, 1) + N'.' as ClientFullName
    , Count(Hires.IdCar) as Amount
    , IsNull(Sum(Duration), 0) as TotalDuration
from
    Clients left join Hires on Clients.Id = Hires.IdClient
group by
    Clients.Id, Clients.Surname, Clients.[Name], Clients.Patronymic
order by
    TotalDuration desc;
end;
go

-- вызов процедуры GetClientsCountHires
exec dbo.GetClientsCountHires;
go


-- 8
-- Выбирает информацию о фактах проката автомобилей по госномеру:
-- количество фактов проката, сумма за прокаты, суммарная длительность прокатов

drop function if exists GetHiresCarWherePlate;
go

create function GetHiresCarWherePlate()
returns table
as
return
select
    Plate
    , Count(Plate)           as Total
    , Sum(Rental * Duration) as TotalRental
    , Sum(Duration)          as TotalDuration
from  
    ViewHires
group by
    Plate;
go

-- вызов функции GetHiresCarWherePlate()
select 
    * 
from 
    dbo.GetHiresCarWherePlate();
go
