﻿

-- 1 функция
-- Вывести все фильмы, вышедшие на экран в текущем и прошлом году.

drop function if exists GetFilms;
go

create function GetFilms()
returns table
as
return
	select
		*
	from
		ViewFilms
	where
	   DATEPART(year, ReleaseDate) in (Year(GetDate()), Year(GetDate())-1);
go

-- вызов функции GetFilms()
select 
    * 
from 
    dbo.GetFilms();
go


-- 2
-- Вывести информацию об актерах, снимавшихся в заданном фильме.

drop function if exists GetActorsInFilm;
go

create function GetActorsInFilm(@title nvarchar(75))
returns table
as
return
select
    Persons.Surname as ActorSurname
    , Persons.[Name] as ActorName
    , Persons.Patronymic as ActorPatronymic
    , Films.Title
from
    ActorsFilms join Persons on ActorsFilms.IdActor = Persons.Id
                join Films   on ActorsFilms.IdFilm = Films.Id 
where
    Films.Title = @title;
go

-- вызов функции GetActorsInFilm()
select 
    * 
from 
    dbo.GetActorsInFilm(N'История без купюр');
go


-- 3
-- Вывести информацию об актерах, снимавшихся как минимум в N фильмах.

drop function if exists GetActorsInNFilms;
go

create function GetActorsInNFilms(@n int)
returns table
as
return
select
   Persons.Surname as ActorSurname
    , Persons.[Name] as ActorName
    , Persons.Patronymic as ActorPatronymic
    , count(ActorsFilms.IdFilm) as idFilm
from
    ActorsFilms join Persons on ActorsFilms.IdActor = Persons.Id
group by
    Persons.Surname, Persons.[Name], Persons.Patronymic
having
    count(ActorsFilms.IdFilm) >= @n;
go

-- вызов функции GetActorsInNFilms()
select 
    * 
from 
    dbo.GetActorsInNFilms(2);
go


-- 4
-- Вывести информацию об актерах, которые были режиссерами хотя бы одного из фильмов.

drop procedure if exists GetActorsWhoProducer;
go

create procedure GetActorsWhoProducer
as
begin
	select distinct
    ActorsFilms.IdActor
    , Persons.Surname as ActorSurname
    , Persons.[Name] as ActorName
    , Persons.Patronymic as ActorPatronymic
from
    ActorsFilms join Persons on ActorsFilms.IdActor = Persons.Id
where
    ActorsFilms.IdActor in (select distinct IdProducer from Films);
end;
go

-- вызов процедуры GetActorsWhoProducer()
exec dbo.GetActorsWhoProducer;
go


-- 5
-- Вывести все фильмы, дата выхода которых была более заданного числа лет назад.

drop procedure if exists GetFilmsWhereDate;
go

create procedure GetFilmsWhereDate
    @interval int
as
begin
select
   *
from
    ViewFilms
where
     Year(GetDate()) - Year(ReleaseDate) > @interval;
end;
go

-- вызов процедуры GetFilmsWhereDate()
exec dbo.GetFilmsWhereDate 2;
go


-- 6
-- Вывести всех актеров и количество фильмов, в которых они участвовали.

drop procedure if exists GetActorsAndFilms;
go

create procedure GetActorsAndFilms
as
begin
select
    ActorsFilms.IdActor
    , Persons.Surname
    , Persons.[Name]
    , Persons.Patronymic
    , count(ActorsFilms.IdFilm) as CountFilms
from
    ActorsFilms join Persons on ActorsFilms.IdActor = Persons.Id
group by
    ActorsFilms.IdActor, Persons.Surname, Persons.[Name], Persons.Patronymic;
end;
go

-- вызов процедуры GetActorsAndFilms()
exec dbo.GetActorsAndFilms;
go
