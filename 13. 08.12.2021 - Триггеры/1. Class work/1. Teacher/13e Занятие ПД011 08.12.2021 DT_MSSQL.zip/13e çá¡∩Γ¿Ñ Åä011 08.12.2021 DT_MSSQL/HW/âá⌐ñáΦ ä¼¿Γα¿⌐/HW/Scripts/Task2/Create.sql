﻿



/* Задача 2. Видеотека */

-- Видеотека. В БД хранится информация о домашней видеотеке: фильмы, актеры, 
-- режиссеры
--
-- Для фильмов необходимо хранить:
--     • название;
--     • имена актеров;
--     • имя режиссера;
--     • дату выхода;
--     • жанр фильма;
--     • бюджет фильма;
--     • страну, в которой выпущен фильм
--
-- Для актеров и режиссеров необходимо хранить:
--     • фамилию;
--     • имя;
--     • отчество;
--     • дату рождения

drop table if exists ActorsFilms;
drop table if exists Films;
drop table if exists Genres;
drop table if exists Countries;
drop table if exists Persons;


-- жанры фильмов
create table Genres (
    Id     int           not null primary key identity (1, 1),
    Genre  nvarchar(30)  not null
);
go

-- страны
create table Countries (
    Id       int           not null primary key identity (1, 1),
    Country  nvarchar(50)  not null
);
go


-- персональные данные для актеров и режиссеров
create table Persons (
	Id          int          not null primary key identity (1, 1),
	Surname     nvarchar(60) not null,    -- Фамилия
	[Name]      nvarchar(50) not null,    -- Имя
	Patronymic  nvarchar(60) not null,    -- Отчество
    DoB         date         not null     -- Дата рождения
);
go


-- фильмы в фильмотеке
create table Films (
    Id          int          not null primary key identity (1, 1),
    IdProducer  int          not null,
    IdGenre     int          not null,
    IdCountry   int          not null,
    Title       nvarchar(80) not null,
    ReleaseDate date         not null,
    Budget      int          not null,

    constraint CK_Films_Budget     check(Budget > 0),
    constraint FK_Films_Persons    foreign key (IdProducer) references dbo.Persons(Id),
    constraint FK_Films_Genres     foreign key (IdGenre)    references dbo.Genres(Id),
    constraint FK_Films_Countries  foreign key (IdCountry)  references dbo.Countries(Id)
);
go


-- актеры и фильмы, в которых они играли
create table ActorsFilms (
    Id          int   not null primary key identity (1, 1),
    IdActor     int   not null,
    IdFilm      int   not null,

    constraint  FK_ActorsFilms_Persons foreign key (IdActor) references dbo.Persons(Id),
    constraint  FK_ActorsFilms_Films   foreign key (IdFilm)  references dbo.Films(Id)
);
go








-- представление для фильмов
drop view if exists ViewFilms;
go

create view ViewFilms as
    select
        Films.Id
        , Persons.Surname    as ProducerSurname
        , Persons.[Name]     as ProducerName
        , Persons.Patronymic as ProducerPatronymic
        , Genres.Genre
        , Countries.Country
        , Films.Title
        , Films.ReleaseDate
        , Films.Budget
from
    Films join Persons on Films.IdProducer = Persons.Id
          join Genres on Films.IdGenre = Genres.Id
          join Countries on Films.IdCountry = Countries.Id;
go

-- представление режиссеров
drop view if exists ViewProducers;
go

create view ViewProducers as
    select distinct
        Persons.Surname    as ProducerSurname
        , Persons.[Name]     as ProducerName
        , Persons.Patronymic as ProducerPatronymic
from
    Films join Persons on Films.IdProducer = Persons.Id;
go


-- представление актеров
drop view if exists ViewActors;
go

create view ViewActors as
    select distinct
        Persons.Surname      as ActorSurname
        , Persons.[Name]     as ActorName
        , Persons.Patronymic as ActorPatronymic
from
    ActorsFilms join Persons on ActorsFilms.IdActor = Persons.Id;
go