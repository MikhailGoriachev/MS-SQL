﻿

-- Proc3

drop proc if exists Mean;
go

create proc Mean
	@x float,
	@y float,
	@AMean float out,
	@GMean float out
as
begin
	set	@AMean = (@x+@y)/2
	set	@GMean = sqrt(abs(@x)*abs(@y));
end
go

declare @amean float,
		@gmean float,
		@a float = 2.1,
		@b float = 4.4,
		@c float = 1.7,
		@d float = 12.4;

exec Mean @a, @b, @amean out, @gmean out;
select @a as 'a', @b as 'b', @amean as 'amean', @gmean as 'gmean';

exec Mean @a, @c, @amean out, @gmean out;
select @a as 'a', @b as 'b', @amean as 'amean', @gmean as 'gmean';

exec Mean @a, @d, @amean out, @gmean out;
select @a as 'a', @b as 'b', @amean as 'amean', @gmean as 'gmean';
go


-- Proc4

drop proc if exists TrianglePS;
go

create proc TrianglePS
		@a float,
		@P float out,
		@S float out
as
begin
	set @P = 3*@a;
	set @S = @a*@a*sqrt(3)/4;
end
go

declare @p float,
		@s float,
		@a float = 2;

exec TrianglePS @a, @p out, @s out;
select @a as 'a', @p as 'p', @s as 's';

set @a = 1.56;
exec TrianglePS @a, @p out, @s out;
select @a as 'a', @p as 'p', @s as 's';

set @a = 6.1;
exec TrianglePS @a, @p out, @s out;
select @a as 'a', @p as 'p', @s as 's';
go


-- Proc7

drop proc if exists InvertDigits;
go

create proc InvertDigits
	@k int out
as
begin
	declare @temp int = @k;
	set @k = 0;
	while @temp <> 0 begin
		set @k=@k*10+(@temp%10);
		set @temp/=10;
	end
end
go

declare @k int = 17;
exec InvertDigits @k out;
select @k as 'k';

set @k = 83;
exec InvertDigits @k out;
select @k as 'k';

set @k = 61;
exec InvertDigits @k out;
select @k as 'k';

set @k = 1;
exec InvertDigits @k out;
select @k as 'k';

set @k = 100;
exec InvertDigits @k out;
select @k as 'k';
go


-- Proc8

drop proc if exists AddRightDigit;
go

create proc AddRightDigit
	@d int,
	@k int out
as
begin
	set @k*=10;
	set @k+=@d;
end
go

declare @k int = 1,
		@d int = 8;

select @k as N'k до';
exec AddRightDigit @d, @k out;
select @d as 'd', @k as 'k после';

set @d = 6;
set @k = 18;
select @k as N'k до';
exec AddRightDigit @d, @k out;
select @d as 'd', @k as 'k после';

set @d = 1;
set @k = 99;
select @k as N'k до';
exec AddRightDigit @d, @k out;
select @d as 'd', @k as 'k после';
go


-- Proc9

drop proc if exists AddLeftDigit;
go

create proc AddLeftDigit
	@d int,
	@k int out
as
begin
	declare @temp int = 10;
	while(@k>@temp)
		set @temp*=10;
	set @k+=@d*@temp;
end
go

declare @k int = 1,
		@d int = 8;

select @k as N'k до';
exec AddLeftDigit @d, @k out;
select @d as 'd', @k as 'k после';

set @d = 6;
set @k = 18;
select @k as N'k до';
exec AddLeftDigit @d, @k out;
select @d as 'd', @k as 'k после';

set @d = 1;
set @k = 99;
select @k as N'k до';
exec AddLeftDigit @d, @k out;
select @d as 'd', @k as 'k после';
go
