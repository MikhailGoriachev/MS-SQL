﻿/* База данных «Прокат автомобилей» */

-- Вывод записей таблицы автомобилей с расшифровкой всех полей
select
    *
from
    ViewCars;
go

-- Вывод записей таблицы фактов проката с расшифровкой всех полей
select
    *
from
    ViewHires
-- order by
--    Plate
;
go

--  1. Запрос к представлению	
--     Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
create function [dbo].[AllCarFactsWithPlate] ()
returns table
as
return
select
    Id
    , ClientSurname + N' ' + Substring(ClientName, 1, 1) + N'.' + 
          Substring(ClientPatronymic, 1, 1) + N'.' as Client
    , BrandModel
    , Plate
    , DateStart
    , Duration
from
    ViewHires
where
    Plate = N'О169РК'

go

select
* from
AllCarFactsWithPlate ()
order by 
       DateStart
go


--  2. Запрос к представлению	
--     Выбирает информацию обо всех фактах проката автомобиля с заданной 
--     моделью/брендом
create procedure [dbo].[AllRentalFactsWithBrand] 
    @Brand nvarchar(max) = N'Volkswagen Polo'  
as
select
    Id
    , ClientSurname + N' ' + Substring(ClientName, 1, 1) + N'.' + 
          Substring(ClientPatronymic, 1, 1) + N'.' as Client
    , BrandModel
    , Plate
    , DateStart
    , Duration
from
    ViewHires
where
    BrandModel = @Brand

go

exec AllRentalFactsWithBrand
go

--  3. Запрос к представлению
--     Выбирает информацию об автомобиле с заданным госномером
-- declare @plate nvarchar(12) = N'О169РК';
create function [dbo].[CarWithCertainPlate] ()
returns table 
as
return
select
    Id 
    , BrandModel
    , Color
    , Plate
    , YearManuf
    , InsurValue
    , Rental
from
    ViewCars
where
    -- Plate = @plate;
    Plate like N'С' + N'%';
go

select
*
from 
CarWithCertainPlate ()
go

--  4. Запрос с параметром	
--     Выбирает информацию о клиентах по серии и номеру паспорта
create procedure [dbo].[ClientsByPassport] 
    @passport nvarchar(max) = N'11 21 098181'
as

select
    Id 
    , Surname
    , [Name]
    , Patronymic
    , Passport
from
    Clients
where
    Passport = @passport;
go

exec ClientsByPassport 
go


--  5. Запрос к представлению	
--     Выбирает информацию обо всех зафиксированных фактах проката автомобилей
--     в некоторый заданный интервал времени.

create procedure [dbo].[AllRentalsWithinPeriod] 
   @from date = '10-01-2021', @to date = '10-31-2021'

as
select
    Id
    , ClientSurname + N' ' + Substring(ClientName, 1, 1) + N'.' + 
          Substring(ClientPatronymic, 1, 1) + N'.' as Client
    , BrandModel
    , Plate
    , DateStart
    , Duration
from
    ViewHires
where
    DateStart between @from and @to
 order by
    DateStart;

go

exec AllRentalsWithinPeriod

go

--  6. Запрос к представленмю
--     Вычисляет для каждого факта проката стоимость проката. Включает поля 
--     Дата проката, Госномер автомобиля, Модель автомобиля, Стоимость проката.
--     Сортировка по полю Дата проката
create function [dbo].[RentalPriceForEachFact] ()
returns table
as
return
select
    Id
    , DateStart
    , Plate
    , BrandModel
    , Rental                  as RentalPerDay
    , Duration
    , Rental * Duration as Price 
from
    ViewHires

go

select
*
from 
    RentalPriceForEachFact ()
order by
    DateStart;
go



--  7. Запрос с левым соединением	
--     Для всех клиентов прокатной фирмы вычисляет количество фактов проката, 
--     суммарное количество дней проката, упорядочивание по убыванию 
--     суммарного количества дней проката
create procedure [dbo].[AllRentalFactsSumRentalDays]
       
as
select
    Clients.Id
    , Clients.Surname + N' ' + Substring(Clients.[Name], 1, 1) + N'.' + 
          Substring(Clients.Patronymic, 1, 1) + N'.' as ClientFullName
    , Count(Hires.IdCar) as Amount
    , IsNull(Sum(Duration), 0) as TotalDuration
from
    Clients left join Hires on Clients.Id = Hires.IdClient
group by
    Clients.Id, Clients.Surname, Clients.[Name], Clients.Patronymic
order by
    TotalDuration desc;
go

exec AllRentalFactsSumRentalDays
go


--  8. Итоговый запрос	
--     Выбирает информацию о фактах проката автомобилей по госномеру: 
--     количество фактов проката, сумма за прокаты, суммарная длительность 
--     прокатов
create procedure [dbo].[AllRentalFacts]

as
select
    Plate
    , Count(Plate)           as Total
    , Sum(Rental * Duration) as TotalRental
    , Sum(Duration)          as TotalDuration
from  
    ViewHires
group by
    Plate;
go

exec AllRentalFacts
go


