﻿--•	Proc3. Описать процедуру Mean(X, Y, AMean, GMean), 
--вычисляющую среднее арифметическое AMean = (X+Y)/2 и 
--среднее геометрическое GMean = Sqrt(Abs(X)·Abs(Y)) 
--двух положительных чисел X и Y (X и Y — входные, 
--AMean и GMean — выходные параметры вещественного типа). 
--С помощью этой процедуры найти среднее арифметическое и 
--среднее геометрическое для пар (A, B), (A, C), (A, D), если даны A, B, C, D.

create procedure [dbo].[Mean]
     @x float, 
     @y float, 
     @Amean float out,
     @Gmean float out 
as 
   
 begin
 
   
 set  @Amean = (@x + @y)/ 2;
 set  @Gmean = SQRT((ABS(@x) * ABS(@y)));
     
 end
 declare @rand1 float = 10 +5*rand(), @rand2 float = 10 +6*rand()
 declare @Amean float, @Gmean float
 exec Mean @x = @rand1, @y = @rand2, @Amean = @Amean out , @Gmean = @Gmean out
 print N'Среднее арифметическое : '+ cast(@Amean as varchar) + ' ' +N' Среднее геометрическое : '+ cast(@Gmean as varchar) 
 go

 --•Proc4. Описать процедуру TrianglePS(a, P, S), 
 --вычисляющую по стороне a равностороннего треугольника 
 --его периметр P = 3·a и площадь S = a2·Sqrt(3)/4 
 --(a — входной, P и S — выходные параметры; все параметры являются вещественными).
 --С помощью этой процедуры найти периметры и площади трех равносторонних треугольников с данными сторонами.

create procedure [dbo].[TrianglePS] 
    @a float, 
    @S float out, 
    @P float out
as 
   begin 

   set @S = 2*@a*SQRT(3)/4;
   set @P = 3*@a;

   end

declare @rand float = 10 +7*rand()
declare @S float, @P float
exec TrianglePS @a = @rand, @S = @S out, @P = @P out
print N'Периметр треугольника : ' + cast(@P as varchar) + ' ' + N'Площадь треугольника : ' + cast(@S as varchar) 

--•	Proc7. Описать процедуру InvertDigits(K), меняющую порядок следования цифр 
--целого положительного числа K на обратный (K — параметр целого типа, 
--являющийся одновременно входным и выходным). С помощью этой процедуры 
--поменять порядок следования цифр на обратный для каждого из пяти данных целых чисел.




        


   