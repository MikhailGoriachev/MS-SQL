﻿--Cоздание процедур и функций для второй задачи

--Вывести все фильмы, вышедшие на экран в текущем и прошлом году.
drop function if exists ShowThisNPrevYear
go
create function ShowThisNPrevYear()
returns table
as
return
(
    select
        *
    from
        ViewFilms
    where
        DATEPART(year, ViewFilms.ReleaseDate) 
                    in (DATEPART(year, GETDATE()), DATEPART(year, GETDATE())-1)
);
go
--Вывести информацию об актерах, снимавшихся в заданном фильме.
drop function if exists ShowActByFilm
go
create function ShowActByFilm(@title nvarchar(80))
returns table
as
return
(
    select
        Persons.Surname as ActorSurname
        , Persons.[Name] as ActorName
        , Persons.Patronymic as ActorPatronymic
        , Films.Title
    from
        ActorsFilms join Persons on ActorsFilms.IdActor = Persons.Id
                    join Films   on ActorsFilms.IdFilm = Films.Id 
    where
        Films.Title = @title
);
go
--Вывести информацию об актерах, снимавшихся как минимум в N фильмах.
drop function if exists ShowActByPlays
go
create function ShowActByPlays(@n int)
returns table
as
return
(
    select
        Persons.Surname as ActorSurname
        , Persons.[Name] as ActorName
        , Persons.Patronymic as ActorPatronymic
        , count(ActorsFilms.IdFilm) as Amnt
    from
        ActorsFilms join Persons on ActorsFilms.IdActor = Persons.Id
    group by
        Persons.Surname, Persons.[Name], Persons.Patronymic
    having
        count(ActorsFilms.IdFilm) >= @n
);
go

--Вывести информацию об актерах, которые были режиссерами хотя бы одного из фильмов.
drop proc if exists ShowActorsDirectors 
go
create proc ShowActorsDirectors
as
begin
    select distinct
    ActorsFilms.IdActor
    , Persons.Surname as ActorSurname
    , Persons.[Name] as ActorName
    , Persons.Patronymic as ActorPatronymic
from
    ActorsFilms join Persons on ActorsFilms.IdActor = Persons.Id
where
    ActorsFilms.IdActor in (select distinct IdProducer from Films)
end;
go
--Вывести все фильмы, дата выхода которых была более заданного числа лет назад.
drop proc if exists ShowFilmReleasedThen
go
create proc ShowFilmReleasedThen(@years int)
as 
begin
    select
       *
    from
        ViewFilms
    where
         Year(GetDate()) - Year(ViewFilms.ReleaseDate) > @years;
    end;
go
--Вывести всех актеров и количество фильмов, в которых они участвовали.
drop proc if exists ShowAllActorsNFilms
go
create proc ShowAllActorsNFilms
as
begin
    select
        ActorsFilms.IdActor
        , Persons.Surname
        , Persons.[Name]
        , Persons.Patronymic
        , count(ActorsFilms.IdFilm) [Amount films]
    from
        ActorsFilms join Persons on ActorsFilms.IdActor = Persons.Id
    group by
        ActorsFilms.IdActor, Persons.Surname, Persons.[Name], Persons.Patronymic
end;
go