﻿--Создание процедур и функций
drop function if exists ShowByPlate
go
drop proc if exists ShowByBrand
go
drop function if exists ShowAutoByPlate
go
drop proc if exists ShowByPassport
go
drop proc if exists ShowBetweenDates
go
drop function if exists GetRental
go
drop proc if exists GetStat
go
--1	Запрос к представлению. Однотабличная функция	
--Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
create function ShowByPlate(@plate nvarchar(80))
returns table
as
return
(
	select
		DateStart
		,Dur
		,Plate
		,Surname
		,[Name]
		,Patronymic
		,Passport
	from ViewRentals
	where Plate = @plate
);
go
--2	Запрос к представлению Хранимая процедура	
--Выбирает информацию обо всех фактах проката автомобиля с 
--заданной моделью/брендом
create proc ShowByBrand
		@brand nvarchar(80)
as
begin
	select
		DateStart
		,Dur
		,Plate
		,Surname
		,[Name]
		,Patronymic
		,Passport
	from ViewRentals
	where Brand =@brand
end;
go
--3	Запрос к представлению. Однотабличная функция	
--Выбирает информацию об автомобиле с заданным госномером
create function ShowAutoByPlate(@plate nvarchar(80))
returns table
as
return
(
	select
		Brand
		,Color
		,InsurancePay
		,Plate
		,Rental
		,YearMount
	from ViewRentals
	where Plate = @plate
);
go
--4	Запрос с параметром Хранимая процедура
--Выбирает информацию о клиентах по серии и номеру паспорта
create proc ShowByPassport
	@passport nvarchar(80)
as
	begin
	select
		Surname
		,[Name]
		,Patronymic
		,Passport
	from ViewRentals
	where Passport = @passport
end;
go
--5	Запрос к представлению. Хранимая процедура	
--Выбирает информацию обо всех зафиксированных 
--фактах проката автомобилей в некоторый заданный интервал времени.
create proc ShowBetweenDates(@d1 date, @d2 date)
as 
begin
	select
		*
	from ViewRentals
	where DateStart between @d1 and @d2
	end;
go
--6	Запрос к представлению. Однотабличная функция	
--Вычисляет для каждого факта проката стоимость проката. 
--Включает поля Дата проката, Госномер автомобиля, 
--Модель автомобиля, Стоимость проката. Сортировка по полю Дата проката
create function GetRental()
returns table
return
(
	select top 100
		DateStart	as [Дата проката]
		,Brand		as [Модель автомобиля]
		,Plate		as [Госномер автомобиля]
		,Rental		as [Стоимость проката]
		,Dur		as [Длительность проката]
		,Rental * Dur as [Общая стоимость]
	from ViewRentals
	order by DateStart
);
go
--7	Запрос с левым соединением. Хранимая процедура 	
--Для всех клиентов прокатной фирмы вычисляет 
--количество фактов проката, суммарное количество дней проката, 
--упорядочивание по убыванию суммарного количества дней проката
create proc GetStat
as
begin
	select top 100
		Surname
		,count(*)	as [Kоличество фактов проката]
		,sum(Dur)	as [Cуммарное количество дней проката] 
	from Clients left join Rentals on Clients.Id = Rentals.idClient
	group by Surname
	order by [Cуммарное количество дней проката] desc
end;
go
