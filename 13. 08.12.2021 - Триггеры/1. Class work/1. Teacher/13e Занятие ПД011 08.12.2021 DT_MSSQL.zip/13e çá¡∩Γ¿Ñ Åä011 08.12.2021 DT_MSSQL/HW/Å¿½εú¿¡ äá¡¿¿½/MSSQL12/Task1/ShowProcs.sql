﻿--Proc3.
declare @A float = 4, @B float = 2,
		@C float = 5, @D float = 7, 
		@AMean float , @GMean float;

print char(10) +
      N'    Задача Proc3.' + char(10) +
      N'    --------------------------------------------' + char(10);
exec Mean @A, @B, @AMean out, @GMean out;
print char(9) + 'A = ' + ltrim(str(@A)) + char(9) + ' B = ' + ltrim(str(@B)) + char(9) 
			+ ' AVG = ' + ltrim(str(@AMean,10,2)) + char(9) + ' GVG = ' + ltrim(str(@GMean,10,2)) +
+ char(10) + N'    --------------------------------------------' + char(10);
exec Mean @A, @C, @AMean out, @GMean out;
print char(9) + 'A = ' + ltrim(str(@A)) + char(9) + ' C = ' + ltrim(str(@C)) + char(9) 
			+ ' AVG = ' + ltrim(str(@AMean,10,2)) + char(9) + ' GVG = ' + ltrim(str(@GMean,10,2)) +
+ char(10) + N'    --------------------------------------------' + char(10);
exec Mean @A, @D, @AMean out, @GMean out;
print char(9) + 'A = ' + ltrim(str(@A)) + char(9) + ' D = ' + ltrim(str(@D)) + char(9) 
			+ ' AVG = ' + ltrim(str(@AMean,10,2)) + char(9) + ' GVG = ' + ltrim(str(@GMean,10,2));


--Proc4.
declare @a float, @P float, @S float, @i int = 0;
print char(10) +
      N'    Задача Proc4.' + char(10);

while (@i < 3)
begin
	set @a = 1.0 + 10.0*rand();
	exec TrianglePS @a, @P out, @S out;
     print N'    --------------------------------------------' + char(10) +
		char(9) + 'A = ' + ltrim(str(@a,5,2)) + char(9) + 
					'P = ' + ltrim(str(@P,5,2)) + char(9) + 
					'S = ' + ltrim(str(@S,5,2)) + char(9);
	set @i += 1;
end;

--Proc7.
declare @a int, @i int = 0;
print char(10) +
      N'    Задача Proc7.' + char(10);

while (@i < 5)
begin
	set @a = 10000*rand();

     print N'    -----------------------' + char(10) +
		char(9) + N'До   ' + str(@a);
		exec InvertDigits @a out;
		print  + char(9) + N'После' + str(@a) + char(9);
	set @i += 1;
end;

--Proc8.
declare @a int, @i int = 0, @d1 int, @d2 int;
print char(10) +
      N'    Задача Proc8.' + char(10);

while (@i < 3)
begin
	set @a = 1000*rand();
	set @d1 = 10*rand();
	set @d2 = 10*rand();

     print N'    -----------------------' + char(10) +
		char(9) + N'До ' + str(@a);
		exec AddRightDigit @a out, @d1;
		print  + char(9) + N'+' + ltrim(@d1) + char(9) + str(@a) + char(9);
		exec AddRightDigit @a out, @d2;
		print  + char(9) + N'+' + ltrim(@d2) + char(9) + str(@a) + char(9);
	set @i += 1;
end;

--Proc9.
declare @a int, @i int = 0, @d1 int, @d2 int;
print char(10) +
      N'    Задача Proc9.' + char(10);

while (@i < 3)
begin
	set @a = 1000*rand();
	set @d1 = 10*rand();
	set @d2 = 10*rand();

     print N'    -----------------------' + char(10) +
		char(9) + N'До ' + str(@a);
		exec AddLeftDigit @a out, @d1;
		print  + char(9) + N'+' + ltrim(@d1) + char(9) + str(@a) + char(9);
		exec AddLeftDigit @a out, @d2;
		print  + char(9) + N'+' + ltrim(@d2) + char(9) + str(@a) + char(9);
	set @i += 1;
end;