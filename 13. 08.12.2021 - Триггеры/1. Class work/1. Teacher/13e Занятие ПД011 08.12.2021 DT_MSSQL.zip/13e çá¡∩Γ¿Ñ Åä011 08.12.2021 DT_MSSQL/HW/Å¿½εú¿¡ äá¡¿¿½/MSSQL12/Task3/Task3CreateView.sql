﻿
--Создание главного представления 


create view ViewRentals as
select
	Brand
	,Color
	,Surname
	,[Name]
	,Patronymic
	,Passport
	,Plate
	,YearMount
	,InsurancePay
	,Rental
	,DateStart
	,Dur
from Rentals join (Autos join Brands on Autos.idBrand = Brands.id
							join Colors on Autos.idColor = Colors.id)
					on Rentals.idAuto = Autos.Id
			join Clients on Rentals.idClient = Clients.Id
go
	