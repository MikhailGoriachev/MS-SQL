﻿--Создание процедур


--Proc3. 
--Описать процедуру Mean(X, Y, AMean, GMean), вычисляющую
--среднее арифметическое AMean = (X+Y)/2 и среднее геометрическое
--GMean = Sqrt(Abs(X)·Abs(Y)) двух положительных чисел X и Y (X и Y — входные,
--AMean и GMean — выходные параметры вещественного типа). С помощью
--этой процедуры найти среднее арифметическое и среднее геометрическое
--для пар (A, B), (A, C), (A, D), если даны A, B, C, D.

drop proc if exists Mean;
go

create proc Mean 
	@a float 
	,@b float 
	,@AMean float output
	,@GMean float output
as
begin
	set @AMean = (@a + @b) / 2;
	set @GMean = SQRT(abs(@a) * abs(@b));	
end
go
--Proc4. 
--Описать процедуру TrianglePS(a, P, S), вычисляющую по стороне a
--равностороннего треугольника его периметр P = 3·a и площадь 
--S = a^2·√(3)/4 (a — входной, P и S — выходные параметры; все 
--параметры являются вещественными). С помощью этой процедуры найти
--периметры и площади трех равносторонних треугольников с данными 
--сторонами.

drop proc if exists TrianglePS;
go

create proc TrianglePS 
	@a float
	,@P float out
	,@S float out
as
begin
	set @P = 3 * @a;
	set @S = @a * @a * SQRT(3) / 4;
end;
go

--Proc7. Описать процедуру InvertDigits(K), меняющую порядок следования 
--цифр целого положительного числа K на обратный (K — параметр целого 
--типа, являющийся одновременно входным и выходным). С помощью этой 
--процедуры поменять порядок следования цифр на обратный для каждого 
--из пяти данных целых чисел.

drop proc if exists InvertDigits;
go

create proc InvertDigits
	@K int out
as
begin
	if(@K < 0) return @K;

	declare @temp int = 0;

	while(@K > 0)
	begin
		set @temp = @temp * 10 + @K % 10;
		set @K /= 10;
	end;

	set @K = @temp;
end;
go

--Proc8. Описать процедуру AddRightDigit(D, K), добавляющую к целому 
--положительному числу K справа цифру D (D — входной параметр целого типа, 
--лежащий в диапазоне 0–9, K — параметр целого типа, являющийся одновременно 
--входным и выходным). С помощью этой процедуры последовательно добавить к 
--данному числу K справа данные цифры D1 и D2, выводя результат каждого добавления.

drop proc if exists AddRightDigit;
go

create proc AddRightDigit
	@K int out
	,@D int 
as
begin
	if(@K > 0 and @D between 0 and 9)
	begin
		set @K = @K*10 + @D;
	end;
end;
go

--Proc9. Описать процедуру AddLeftDigit(D, K), добавляющую к целому 
--положительному числу K слева цифру D (D — входной параметр целого типа, 
--лежащий в диапазоне 1–9, K — параметр целого типа, являющийся одновременно 
--входным и выходным). С помощью этой процедуры последовательно добавить к данному
--числу K слева данные цифры D1 и D2, выводя результат каждого добавления. 

drop proc if exists AddLeftDigit;
go

create proc AddLeftDigit
	@K int out
	,@D int 
as
begin
	if(@K > 0 and @D between 1 and 9)
	begin
		declare @n int = @K;
		while (@n != 0) 
		begin
                set @n /= 10;
                set @D *= 10;
        end;
            set @K += @D;
	end;
end;
go
