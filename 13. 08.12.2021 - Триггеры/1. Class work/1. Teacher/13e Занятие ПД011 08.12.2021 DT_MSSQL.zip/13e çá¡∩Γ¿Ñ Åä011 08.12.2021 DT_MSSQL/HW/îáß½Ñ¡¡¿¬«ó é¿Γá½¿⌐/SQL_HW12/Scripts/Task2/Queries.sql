﻿
---- •	1 Вывести все фильмы, вышедшие на экран в текущем и прошлом году.

drop function if exists LastTwoYearsMovies;
go
-- создание функции
create function LastTwoYearsMovies() returns table
as return 
	select
		Title
		, ReleaseDate
	from ViewMovies
	where year(ReleaseDate) in (year(Getdate()), year(getdate()) -1); 
go

-- вызов функции
select * from LastTwoYearsMovies();

---- •	2 Вывести информацию об актерах, снимавшихся в заданном фильме.

drop function if exists MoviesWithActor;
go
-- создание функции
create function MoviesWithActor(@title nvarchar(100)) returns table
return
	select
		Title
		, Name
		, Surname
		, Patronymic
	from ViewCasts
	where Title = @title;
go


declare @title nvarchar(100) = N'Сестры'
-- вызов функции
select * from MoviesWithActor(@title);
set @title = N'Довод';
select * from MoviesWithActor(@title);
set @title = N'Огонь';
select * from MoviesWithActor(@title);

-- •	3 Вывести информацию об актерах, снимавшихся как минимум в N фильмах.

drop function if exists ActorWithNRoles;
go
-- создание функции
create function ActorWithNRoles(@n int) returns table
return select
	Name
	, Surname
	, Patronymic
	, count(Title) as Roles
from 
	ViewCasts
group by
	Name, Surname, Patronymic
having count(Title) >= @n;
go

declare @n int = 3;
-- вызов функции
select * from ActorWithNRoles(@n);
set @n = 2;
select * from ActorWithNRoles(@n);
set @n = 1;
select * from ActorWithNRoles(@n);
go



-- •	4 Вывести информацию об актерах, которые были режиссерами хотя бы одного из фильмов.

drop proc if exists SelectActorsDirectors;
go
create proc SelectActorsDirectors
as begin
	select
		Persons.Name
		, Persons.Surname
		, Persons.Patronymic	
	from
		Actors join Persons on Persons.Id = Actors.IdPerson			  
	where Actors.IdPerson in (select IdPerson from Directors);
end;
go

exec SelectActorsDirectors;
go


-- •	5 Вывести все фильмы, дата выхода которых была более заданного числа лет назад.
drop proc if exists MoviesOlderThan;
go
create proc MoviesOlderThan @interval int
as begin
	select
		Title
		, ReleaseDate
	from ViewMovies
	where Year(GetDate()) - Year(ViewMovies.ReleaseDate) > @interval;
end;
go

declare @yearsAgo int = 16;
exec MoviesOlderThan @yearsAgo;
set @yearsAgo = 20;
exec MoviesOlderThan @yearsAgo;
set @yearsAgo = 1;
exec MoviesOlderThan @yearsAgo;

-- •	6 Вывести всех актеров и количество фильмов, в которых они участвовали.
drop proc if exists ActorsAndTheirsMovies;
go
create proc ActorsAndTheirsMovies
as begin
	select
		Name
		, Surname
		, Patronymic
		, Count(Title) as TotalMovies
	from ViewCasts
	group by Name, Surname, Patronymic;
end;
go

exec ActorsAndTheirsMovies;
go
