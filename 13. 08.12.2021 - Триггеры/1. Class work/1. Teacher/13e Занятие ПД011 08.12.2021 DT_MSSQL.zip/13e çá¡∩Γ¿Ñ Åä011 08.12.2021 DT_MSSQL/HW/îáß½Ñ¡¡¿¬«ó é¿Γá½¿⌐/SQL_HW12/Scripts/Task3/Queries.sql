﻿
--1	Запрос к представлению. Однотабличная функция
--	Выбирает информацию обо всех фактах проката автомобиля с заданным госномером

drop function if exists RentsCarsWhereRegNumber;
go

create function RentsCarsWhereRegNumber(@number nvarchar(6)) returns table
as return 
	select
		RegNumber
		, BrandModel
		, Client
		, Passport
		, BeginDate
		, RentDays
	from 
		RentalFactsView
	where
		RegNumber = @number;
go

declare @number nvarchar(6) = N'В467АР';
select * from RentsCarsWhereRegNumber(@number);
set @number = N'С441УЕ';
select * from RentsCarsWhereRegNumber(@number);
set @number = N'А247ВВ';
select * from RentsCarsWhereRegNumber(@number);

--2	Запрос к представлению. Хранимая процедура
--	Выбирает информацию обо всех фактах проката автомобиля с заданной моделью/брендом

drop proc if exists RentsCarsWhereModel;
go

create proc RentsCarsWhereModel @model nvarchar(30)
as begin
	select
		RegNumber
		, BrandModel
		, Client
		, Passport
		, BeginDate
		, RentDays
	from 
		RentalFactsView
	where
		BrandModel = @model;
end;
go

declare @model nvarchar(30) = N'Mercedes Vito';
exec RentsCarsWhereModel @model;
set @model = N'Volkswagen Passat';
exec RentsCarsWhereModel @model;
set @model = N'Honda Accord';
exec RentsCarsWhereModel @model;

--3	Запрос к представлению 
--  Однотабличная функция
--	Выбирает информацию об автомобиле с заданным госномером
drop function if exists CarInfo;
go

create function CarInfo(@number nvarchar(6)) returns table
as return 
select
	Id
	, RegNumber
	, BrandModel
	, Color
	, YearMade
	, InsuranceCost
	, DayCost
from 
	CarsView
where
	RegNumber = @number;
go

declare @number nvarchar(6) = N'В467АР';
select * from CarInfo(@number);
set @number = N'С441УЕ';
select * from CarInfo(@number);
set @number = N'А247ВВ';
select * from CarInfo(@number);
go

--4	Запрос с параметром
--  Хранимая процедура
--	Выбирает информацию о клиентах по серии и номеру паспорта
drop proc if exists ClientInfo;
go

create proc ClientInfo @passport nvarchar(15)
as begin
select
	Id
	, Surname
	, Name
	, Patronymic
	, Passport
from	
	Clients
where Passport = @passport;
end;
go


declare @passport nvarchar(15) = N'9317024758';
exec ClientInfo @passport;
set @passport = N'9319005575';
exec ClientInfo @passport;
set @passport = N'9319063779';
exec ClientInfo @passport;


--5	Запрос к представлению	
--  Хранимая процедура
--	Выбирает информацию обо всех зафиксированных фактах проката автомобилей
--	в некоторый заданный интервал времени.
drop proc if exists RentalFactsTimeRange;
go

create proc RentalFactsTimeRange @from date, @to date
as begin
select
	RegNumber
	, BrandModel
	, Client
	, Passport
	, BeginDate
	, RentDays
from 
	RentalFactsView
where 
	BeginDate between @from and @to;
end;
go

declare @from date = '2021-01-01', @to date = '2021-05-01'
exec RentalFactsTimeRange @from, @to;
set @from = '2021-05-02'; set @to = '2021-08-01'
exec RentalFactsTimeRange @from, @to;
set @from = '2021-08-01'; set @to = '2021-10-01'
exec RentalFactsTimeRange @from, @to;



--6	Запрос к представлению	
--  Однотабличная функция
--	Вычисляет для каждого факта проката стоимость проката. Включает поля Дата проката,
--	Госномер автомобиля, Модель автомобиля, Стоимость проката. Сортировка по полю Дата проката
drop function if exists RentalFactsCosts;
go

create function RentalFactsCosts() returns table
as return 
select top (select count(*) from RentalFactsView)
	BeginDate
	, RegNumber
	, BrandModel
	, RentPrice
from 
	RentalFactsView
order by
	BeginDate;
go

select * from RentalFactsCosts();
go

--7	Запрос с левым соединением	
--  Хранимая процедура 
--	Для всех клиентов прокатной фирмы вычисляет количество фактов проката,
--	суммарное количество дней проката, упорядочивание по убыванию суммарного
--	количества дней проката
drop proc if exists ClientsRentalFacts;
go

create proc ClientsRentalFacts
as begin
	select top (select count(*) from Clients left join RentalFactsView on Clients.Passport = RentalFactsView.Passport)
		Clients.Surname
		, Clients.Name
		, Clients.Patronymic
		, Clients.Passport
		, Sum(RentDays) as TotalRentDays
		, Count(RentDays) as RentsCount
	from  
		Clients left join RentalFactsView on Clients.Passport = RentalFactsView.Passport 
	group by
		Clients.Name
		, Clients.Surname
		, Clients.Patronymic
		, Clients.Passport
	order by
		TotalRentDays;
end;
go

exec ClientsRentalFacts;

--8	Итоговый запрос	
--  Однотабличная функция
--	Выбирает информацию о фактах проката автомобилей по госномеру:
--  количество фактов проката, сумма за прокаты, суммарная длительность прокатов
drop function if exists CarsSatistics;
go

create function CarsSatistics() returns table
as return 
select
	RegNumber
	, Count(RegNumber) as Total
	, Sum(RentDays * RentPrice)	  as TotalRental
	, Sum(RentalFactsView.RentDays) as TotalDuration
from	
	RentalFactsView
group by
	RegNumber;
go


select * from CarsSatistics();
go
