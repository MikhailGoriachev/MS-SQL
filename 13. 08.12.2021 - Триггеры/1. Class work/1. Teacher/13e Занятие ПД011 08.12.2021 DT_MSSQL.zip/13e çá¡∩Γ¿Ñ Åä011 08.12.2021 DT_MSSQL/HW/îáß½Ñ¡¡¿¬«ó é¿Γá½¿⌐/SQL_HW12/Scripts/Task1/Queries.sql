﻿--  Proc3. 
--  Описать процедуру Mean(X, Y, AMean, GMean), вычисляющую
--  среднее арифметическое AMean = (X+Y)/2 и среднее геометрическое
--  GMean = Sqrt(Abs(X)·Abs(Y)) двух положительных чисел X и Y (X и Y — входные,
--  AMean и GMean — выходные параметры вещественного типа). С помощью
--  этой процедуры найти среднее арифметическое и среднее геометрическое
--  для пар (A, B), (A, C), (A, D), если даны A, B, C, D.

drop proc if exists Mean; 
go 
create proc Mean
			@X int,
			@Y int,
			@Amean float out,
			@GMean float out
as
begin
	set @Amean = (@X + @Y) / 2;
	set @GMean = Sqrt(Abs(@X) * Abs(@Y));
end;
go

declare @A int = 1 + 20 * rand(),
		@B int = 1 + 20 * rand(),
		@C int = 1 + 20 * rand(),
		@D int = 1 + 20 * rand(),
		@amean float,
		@gmean float;

exec Mean @A, @B, @amean out, @gmean out;
select @A as A, @B as B, @amean as AMean, round(@gmean,2) as GMean;

exec Mean @A, @C, @amean out, @gmean out;
select @A as A, @C as C, @amean as AMean, round(@gmean,2) as GMean;

exec Mean @A, @D, @amean out, @gmean out;
select @A as A, @D as D, @amean as AMean, round(@gmean,2) as GMean;

go

--  Proc4. 
--  Описать процедуру TrianglePS(a, P, S), вычисляющую по стороне a
--  равностороннего треугольника его периметр P = 3·a и площадь 
--  S = a^2·√(3)/4 (a — входной, P и S — выходные параметры; все 
--  параметры являются вещественными). С помощью этой процедуры найти
--  периметры и площади трех равносторонних треугольников с данными 
--  сторонами.

drop proc if exists TrianglePs;
go
create proc TrianglePs
	@a float,
	@P float out,
	@S float out
as
	set @P = 3*@a;
	set @S = (sqrt(3) * @a*@a) / 4;
go


declare @a float, @P float, @S float, @i int = 1;

while @i <= 3
begin
	set @a = 1 + 10 * rand();
	exec TrianglePs @a, @P out, @S out;
	select round(@a,2) as SideA, round(@P,2) as Perimeter, round(@S,2) as Square;
	set @i += 1;
end;
go

--	Proc7. 
--  Описать процедуру InvertDigits(K), меняющую порядок следования 
--  цифр целого положительного числа K на обратный (K — параметр целого типа, 
--  являющийся одновременно входным и выходным). С помощью этой процедуры поменять
--  порядок следования цифр на обратный для каждого из пяти данных целых чисел.
drop proc if exists InvertDigits;
go
create proc InvertDigits @K int out
as begin
	declare @inverted int = 0;
	while @K != 0 begin
		set @inverted = @inverted * 10 + @K % 10;
		set @K /= 10;
	end;
	set @K = @inverted;
end;
go

declare @K int, @i int = 1;

while @i <= 5 begin
	set @K = 1000 + rand()*100000;
	print char(9) + N'Сгенерированное число: ' + ltrim(@K);
	exec InvertDigits @K out;
	print char(9) + N'Цифры интвертированы:  ' + ltrim(@K);
	set @i += 1;
end;
go


--  Proc8. 
--  Описать процедуру AddRightDigit(D, K), добавляющую к целому по-
--  ложительному числу K справа цифру D (D — входной параметр целого
--  типа, лежащий в диапазоне 0–9, K — параметр целого типа, являющийся
--  одновременно входным и выходным). С помощью этой процедуры после-
--  довательно добавить к данному числу K справа данные цифры D1 и D2,
--  выводя результат каждого добавления.

drop proc if exists AddRightDigit;
go
create proc AddRightDigit @D int, @K int out
as
	set @K = @K * 10 + @D;	
go


declare @K int = 10 + rand()*1000, @D1 int = rand()*10, @D2 int = rand()*10;

print char(10) + char(9) + N' Число до добавления: ' + ltrim(@K);
exec AddRightDigit @D1, @K out;
print char(10) + char(9) + N' Число после добавления '+ ltrim(@D1) + N': ' + ltrim(@K);
exec AddRightDigit @D2, @K out;
print char(10) + char(9) + N' Число после добавления '+ ltrim(@D2) + N': ' + ltrim(@K);



--	Proc9. Описать процедуру AddLeftDigit(D, K), добавляющую к целому положительному числу K слева цифру D 
-- (D — входной параметр целого типа, лежащий в диапазоне 1–9, K — параметр целого типа, являющийся 
-- одновременно входным и выходным). С помощью этой процедуры последовательно добавить к данному числу K 
-- слева данные цифры D1 и D2, выводя результат каждого добавления. 

drop proc if exists AddLeftDigit;
go
create proc AddLeftDigit @D int, @K int out
as begin
	declare @tmp int = @K;
end;
	while @tmp != 0 begin
		set @D *= 10;
		set @tmp /= 10;
	end;
	set @K = @K + @D;
go

declare @K int = 10 + rand()*1000, @D1 int = rand()*10, @D2 int = rand()*10;

print char(10) + char(9) + N' Число до добавления: ' + ltrim(@K);
exec AddLeftDigit @D1, @K out;
print char(10) + char(9) + N' Число после добавления '+ ltrim(@D1) + N': ' + ltrim(@K);
exec AddLeftDigit @D2, @K out;
print char(10) + char(9) + N' Число после добавления '+ ltrim(@D2) + N': ' + ltrim(@K);
