﻿/* 
 * База данных «Видеотека» 
 */

-- создание таблиц базы данных


drop table if exists Actors;
drop table if exists Films;
drop table if exists Countries;
drop table if exists Genres;   
drop table if exists Persons;  

-- таблица персональных данных (для актеров и режиссеров)
create table dbo.Persons (
	Id          int          not null primary key identity (1, 1),
	Surname     nvarchar(60) not null,    -- Фамилия 
	[Name]      nvarchar(50) not null,    -- Имя 
	Patronymic  nvarchar(60) not null,    -- Отчество 
	DateOfBirth date         not null,    -- дата рождения
);
go


-- таблица жанров фильмов
create table dbo.Genres(
	Id     int          not null primary key identity (1, 1),
	Genre  nvarchar(25) not null,   -- жанр 
); 
go

-- таблица стран
create table dbo.Countries(
	Id       int          not null primary key identity (1, 1),
	Country  nvarchar(60) not null   -- наименование страны
); 
go


-- таблица фильмов
create table dbo.Films(
	Id          int           not null primary key identity (1, 1),
	Title       nvarchar(120) not null, -- •	название
	IdGenre     int           not null, -- внешнией ключ, ссылка на Genres, жанр фильма
	IdProducer  int           not null, -- внешнией ключ, ссылка на Persons, персональные данные режиссера
	ReleaseDate date          not null, -- дата выхода
	Budget      int           not null, -- бюджет фильма
	IdCountry   int           not null, -- внешнией ключ, ссылка на Countries, страна, в которой выпущен фильм

	-- ограничения по значением полей/столбцов
	constraint CK_Films_Budget check (Budget > 0),

	-- внешние ключи
	constraint FK_Films_Genres    foreign key (IdGenre)    references dbo.Genres(Id),
	constraint FK_Films_Persons   foreign key (IdProducer) references dbo.Persons(Id),
	constraint FK_Films_Countries foreign key (IdCountry)  references dbo.Countries(Id),
);
go


-- таблица актеров
create table dbo.Actors(
	Id       int          not null primary key identity (1, 1),
	IdActor  int          not null, -- внешнией ключ, ссылка на Persons, персональные данные актера
	IdFilm  int          not null, -- внешнией ключ, ссылка на Films, фильм, в котором снимался актер

	-- внешние ключи
	constraint FK_Actors_Persons foreign key (IdActor) references dbo.Persons(Id),
	constraint FK_Actors_Films foreign key (IdFilm) references dbo.Films(Id),
);
go