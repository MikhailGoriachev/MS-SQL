﻿---------------------------- Создание функций для задачи 1 ----------------------------


-- Proc3. Описать процедуру Mean(X, Y, AMean, GMean), вычисляющую
--		  среднее арифметическое AMean = (X+Y)/2 и среднее геометрическое
--		  GMean = Sqrt(Abs(X)·Abs(Y)) двух положительных чисел X и Y (X и Y — входные,
--		  AMean и GMean — выходные параметры вещественного типа). С помощью
--		  этой процедуры найти среднее арифметическое и среднее геометрическое
--		  для пар (A, B), (A, C), (A, D), если даны A, B, C, D.
drop proc if exists dbo.Mean;
go

create proc Mean
   @x float,
   @y float,
   @aMean float out,
   @gMean float out
as
begin
	set @aMean = (@x + @y) / 2.;
	set @gMean = SQRT(ABS(@x) * ABS(@y));
end
go

-- Proc4. Описать процедуру TrianglePS(a, P, S), вычисляющую по стороне a равностороннего 
--        треугольника его периметр P = 3·a и площадь S = a^2·Sqrt(3)/4 
--        (a — входной, P и S — выходные параметры; все параметры являются вещественными). 
drop proc if exists dbo.TrianglePS;
go

create proc TrianglePS
   @a float,
   @p float out,
   @s float out
as
begin
	-- неверный входной параметр
	if @a <= 0 begin 
		set @p = -1; set @s = -1;
		return;
	end;
	
	set @p = 3 * @a;
	set @s = @a * @a * SQRT(3.) / 4.;
end
go

-- Proc7. Описать процедуру InvertDigits(K), меняющую порядок следования цифр целого 
--        положительного числа K на обратный (K — параметр целого типа, являющийся 
--        одновременно входным и выходным).
drop proc if exists dbo.InvertDigits;
go

create proc InvertDigits
   @k int out
as
begin
	declare @temp int = 0;
	while @k > 0 begin
		set @temp *= 10;
		set @temp += @k % 10;
		set @k /= 10;
	end;
	
	set @k = @temp;
end
go

-- Proc8. Описать процедуру AddRightDigit(D, K), добавляющую к целому положительному
--        числу K справа цифру D (D — входной параметр целого типа, лежащий в 
--        диапазоне 0–9, K — параметр целого типа, являющийся одновременно входным и выходным).
drop proc if exists dbo.AddRightDigit;
go

create proc AddRightDigit
   @d int,
   @k int out
as
begin
	-- неверный входной параметр
	if @d not between 0 and 9 return;  
	set @k = @k * 10 + @d
end
go

-- Proc9. Описать процедуру AddLeftDigit(D, K), добавляющую к целому положительному 
--        числу K слева цифру D (D — входной параметр целого типа, лежащий в 
--        диапазоне 1–9, K — параметр целого типа, являющийся одновременно входным и выходным).
drop proc if exists dbo.AddLeftDigit;
go

create proc AddLeftDigit
   @d int,
   @k int out
as
begin
	-- неверный входной параметр
	if @d not between 0 and 9 return; 
	
	declare @temp int = @k;
	while @temp > 0 begin
		set @temp /= 10;
		set @d *= 10;
	end;
	
	set @k += @d;
end
go