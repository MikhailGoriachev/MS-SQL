﻿-------------------------------------- Задача 3 --------------------------------------

/* База данных «Прокат автомобилей» */

-- 1. Запрос к представлению. Однотабличная функция	
--    Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
drop function if exists GetHiresByPlate;
go

create function GetHiresByPlate(@plate nvarchar(12))
returns table
as
return 
    select
        Id
        , ClientSurname + N' ' + Substring(ClientName, 1, 1) + N'.' + 
              Substring(ClientPatronymic, 1, 1) + N'.' as Client
        , BrandModel
        , Plate
        , DateStart
        , Duration
    from
        ViewHires
    where
        Plate = @plate;
go

-- вызов функции
select * from dbo.GetHiresByPlate(N'О169РК');
select * from dbo.GetHiresByPlate(N'Т315РК');
select * from dbo.GetHiresByPlate(N'Т306РК');


-- 2. Запрос к представлению. Хранимая процедура	
--    Выбирает информацию обо всех фактах проката автомобиля с заданной моделью/брендом
drop proc if exists GetHiresByBrand;
go

create proc GetHiresByBrand
    @brandModel nvarchar(30)
as
begin
    select
        Id
        , ClientSurname + N' ' + Substring(ClientName, 1, 1) + N'.' + 
              Substring(ClientPatronymic, 1, 1) + N'.' as Client
        , BrandModel
        , Plate
        , DateStart
        , Duration
    from
        ViewHires
    where
        BrandModel = @brandModel;
end;
go

-- выполнение
exec dbo.GetHiresByBrand N'Volkswagen Polo';
go

exec dbo.GetHiresByBrand N'Skoda Fabia New';
go

exec dbo.GetHiresByBrand N'Toyota Camry';
go


-- 3. Запрос к представлению. Однотабличная функция
--    Выбирает информацию об автомобиле с заданным госномером
drop function if exists GetCarByPlate;
go

create function GetCarByPlate(@plate nvarchar(12))
returns table
as
return 
    select
        Id 
        , BrandModel
        , Color
        , Plate
        , YearManuf
        , InsurValue
        , Rental
    from
        ViewCars
    where
        Plate = @plate;
go

-- вызов функции
select * from dbo.GetCarByPlate(N'О169РК');
select * from dbo.GetCarByPlate(N'Т315РК');
select * from dbo.GetCarByPlate(N'Т306РК');


-- 4. Запрос с параметром Хранимая процедура	
--    Выбирает информацию о клиентах по серии и номеру паспорта
drop proc if exists GetClientByPassport;
go

create proc GetClientByPassport
    @passport nvarchar(15)
as
begin
    select
        Id 
        , Surname
        , [Name]
        , Patronymic
        , Passport
    from
        Clients
    where
        Passport = @passport;
end;
go

-- выполнение
exec dbo.GetClientByPassport N'11 21 121212';
go

exec dbo.GetClientByPassport N'12 21 187651';
go

exec dbo.GetClientByPassport N'09 19 002129';
go


-- 5. Запрос к представлению. Хранимая процедура	
--    Выбирает информацию обо всех зафиксированных фактах проката автомобилей 
--    в некоторый заданный интервал времени.
drop proc if exists GetHiresByDate;
go

create proc GetHiresByDate
    @from date,
    @to date
as
begin
    select
        Id
        , ClientSurname + N' ' + Substring(ClientName, 1, 1) + N'.' + 
              Substring(ClientPatronymic, 1, 1) + N'.' as Client
        , BrandModel
        , Plate
        , DateStart
        , Duration
    from
        ViewHires
    where
        DateStart between @from and @to;
end;
go

-- выполнение
exec dbo.GetHiresByDate '10-01-2021', '10-31-2021';
go

exec dbo.GetHiresByDate '09-01-2021', '09-30-2021';
go

exec dbo.GetHiresByDate '11-01-2021', '11-30-2021';
go

-- 6. Запрос к представлению. Однотабличная функция	
--    Вычисляет для каждого факта проката стоимость проката. 
--    Включает поля Дата проката, Госномер автомобиля, Модель автомобиля, Стоимость проката.
--    Сортировка по полю Дата проката

drop function if exists GetHirePrice;
go

create function GetHirePrice()
returns table
as
return 
    select top (select COUNT(*) from ViewHires)
        Id
        , DateStart
        , Plate
        , BrandModel
        , Rental                  as RentalPerDay
        , Duration
        , Rental * Duration as Price 
    from
        ViewHires
    order by
        ViewHires.DateStart ;
go

-- вызов функции
select * from dbo.GetHirePrice();


-- 7. Запрос с левым соединением. Хранимая процедура 	
--    Для всех клиентов прокатной фирмы вычисляет количество фактов проката,
--    суммарное количество дней проката, упорядочивание по убыванию суммарного количества дней проката

drop proc if exists GetClients;
go

create proc GetClients
as
begin
    select
        Clients.Id
        , Clients.Surname + N' ' + Substring(Clients.[Name], 1, 1) + N'.' + 
              Substring(Clients.Patronymic, 1, 1) + N'.' as ClientFullName
        , Count(Hires.IdCar) as Amount
        , IsNull(Sum(Duration), 0) as TotalDuration
    from
        Clients left join Hires on Clients.Id = Hires.IdClient
    group by
        Clients.Id, Clients.Surname, Clients.[Name], Clients.Patronymic
    order by
        TotalDuration desc;
end;
go

-- выполнение
exec dbo.GetClients;


-- 8. Итоговый запрос. Однотабличная функция	
--    Выбирает информацию о фактах проката автомобилей по госномеру: 
--    количество фактов проката, сумма за прокаты, суммарная длительность прокатов
drop function if exists GetHiresByCarPlate;
go

create function GetHiresByCarPlate(@plate nvarchar(12))
returns table
as
return 
    select
        Plate
        , Count(Plate)           as Total
        , Sum(Rental * Duration) as TotalRental
        , Sum(Duration)          as TotalDuration
    from  
        ViewHires
    where
        Plate = @plate
    Group by
        Plate;
go

-- вызов функции
select * from dbo.GetHiresByCarPlate(N'О169РК');
select * from dbo.GetHiresByCarPlate(N'Т315РК');
select * from dbo.GetHiresByCarPlate(N'Т306РК');