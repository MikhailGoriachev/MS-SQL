﻿-------------------------------------- Задача 2 --------------------------------------

-------------------------------- Однотабличные функци --------------------------------

-- 1. Вывести все фильмы, вышедшие на экран в текущем и прошлом году.
drop function if exists GetFilmsYear;
go

create function GetFilmsYear()
returns table
as
return 
	select
		Title
		, Genre
		, Country
		, ReleaseDate
	from
		ViewFilms
	where
		year(ReleaseDate) in (year(GETDATE()), year(GETDATE())-1);
go

-- вызов функции
select 
    * 
from 
    dbo.GetFilmsYear();


-- 2. Вывести информацию об актерах, снимавшихся в заданном фильме.
drop function if exists GetActors;
go

create function GetActors(@film nvarchar(120))
returns table
as
return 
	select
		ActorName
		, ActorSurname
		, ActorPatronymic
		, ActorDOB
	from 
		ViewActors
	where
		Title = @film;
go

-- вызов функции
select * from dbo.GetActors(N'Невидимый гость');
select * from dbo.GetActors(N'Назад в будущее');
select * from dbo.GetActors(N'Титаник');


-- 3. Вывести информацию об актерах, снимавшихся как минимум в N фильмах.
drop function if exists GetActorsByFilmsAmount;
go

create function GetActorsByFilmsAmount(@n int)
returns table
as
return 
	select
		ActorName
		, ActorSurname
		, ActorPatronymic
		, ActorDOB
		, COUNT(*) as AmountFilms
	from 
		ViewActors
	group by
		ActorName
		, ActorSurname
		, ActorPatronymic
		, ActorDOB
	having 
		COUNT(*) >= @n;
go

-- вызов функции
select * from dbo.GetActorsByFilmsAmount(3);
select * from dbo.GetActorsByFilmsAmount(4);
select * from dbo.GetActorsByFilmsAmount(1);


--------------------------------- Хранимые процедуры ---------------------------------

-- 1. Вывести информацию об актерах, которые были режиссерами хотя бы одного из фильмов.
drop proc if exists GetActorsProducers;
go

create proc GetActorsProducers
as
begin
	select
		ActorName
		, ActorSurname
		, ActorPatronymic
		, ActorDOB
	from 
		ViewActors
	where
		ViewActors.IdActor in (select IdProducer from ViewFilms);
end;
go

-- выполнение
exec dbo.GetActorsProducers;
go

-- 2. Вывести все фильмы, дата выхода которых была более заданного числа лет назад.
drop proc if exists FilmsTableYear;
go

create proc FilmsTableYear
     @year int
as
begin
	select
		Title
		, Genre
		, Country
		, ReleaseDate
	from
		ViewFilms
	where
		year(GETDATE()) - year(ReleaseDate) > @year;
end;
go

-- выполнение
exec dbo.FilmsTableYear 5;
go

exec dbo.FilmsTableYear 10;
go

exec dbo.FilmsTableYear 15;
go


-- 3. Вывести всех актеров и количество фильмов, в которых они участвовали.
drop proc if exists AmountFilmsByActors;
go

create proc AmountFilmsByActors
as
begin
	select
		ActorName
		, ActorSurname
		, ActorPatronymic
		, ActorDOB
		, COUNT(*) as AmountFilms
	from 
		ViewActors
	group by
		ActorName
		, ActorSurname
		, ActorPatronymic
		, ActorDOB
end;
go

-- выполнение
exec dbo.AmountFilmsByActors;
go