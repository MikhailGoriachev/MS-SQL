﻿-- База данных «Прокат автомобилей»


-- создание представления для таблицы АВТОМОБИЛИ
create view ViewCars as
   select
      Models.Model
      , Colors.Color
      , Cars.CarNumber
      , Cars.[Year]
      , Cars.InsurancePay
      , Cars.PayRentalDay
from
   Cars join Models on Cars.IdModel = Models.Id
        join Colors on Cars.IdColor = Colors.Id;
go


-- использование представления для таблицы АВТОМОБИЛИ
select 
   *
from
   ViewCars;
go


-- создание представления для таблиц КЛИЕНТЫ, АВТОМОБИЛИ и ФАКТЫ_ПРОКАТА
create view ViewAllRentals as
   select
      Clients.Surname
      , Clients.[Name]
      , Clients.Patronymic
      , Models.Model
      , Cars.CarNumber
      , Rentals.RentalStartDate
      , Cars.PayRentalDay
      , Rentals.Duration
   from
      Rentals join(Cars join Models on Cars.IdModel = Models.Id)
              on Rentals.IdCar = Cars.Id
              join Clients on Rentals.IdClient = Clients.Id;
go


-- использование представления для таблиц КЛИЕНТЫ, АВТОМОБИЛИ и ФАКТЫ_ПРОКАТА
select 
   *
from
   ViewAllRentals;
go


-- 1. Запрос к представлению.
-- Однотабличная функция
-- Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
create function GetAllCars(@numCar nvarchar(10))
returns table
as
return 
     select
   *
from
   ViewAllRentals
where
   CarNumber = @numCar;
go

-- вызов функции GetAllCars()
declare @numberCar nvarchar(10) = N'X739OC';
select 
    * 
from 
    dbo.GetAllCars(@numberCar);

go


-- 2. Запрос к представлению.
-- Хранимая процедура.
-- Выбирает информацию обо всех фактах проката автомобиля с заданной моделью/брендом
create procedure AllRentalModelCar
     @modelCar nvarchar(20)
as
begin
    select
       *
    from
       ViewAllRentals
    where
       Model = @modelCar;
end
go

-- выполнение c параметром
declare @modelCar nvarchar(15) ='Lexus';
exec dbo.AllRentalModelCar @modelCar;
go

exec dbo.AllRentalModelCar 'Kia';
go


-- 3. Запрос к представлению.
-- Однотабличная функция.
-- Выбирает информацию об автомобиле с заданным госномером
create function GetAllCarsNum(@numCar nvarchar(10))
returns table
as
return
     select
        *
     from
        ViewCars
     where
        CarNumber = @numCar;
go

-- вызов функции GetAllCarsNum()
declare @numberCar nvarchar(10) = N'H730CA';
select 
    * 
from 
    dbo.GetAllCarsNum(@numberCar);
go


-- 4. Запрос с параметром.
-- Хранимая процедура.
-- Выбирает информацию о клиентах по серии и номеру паспорта
create procedure ClientsToNumPassport
     @passportNum nvarchar(10)
as
begin
    select
       *
    from
       Clients
    where
       PassportNum = @passportNum;
end
go

-- выполнение c параметром
declare @passportNum nvarchar(10) = N'OH830853';
exec dbo.ClientsToNumPassport @passportNum;
go


-- 5. Запрос к представлению.
-- Хранимая процедура.
-- Выбирает информацию обо всех зафиксированных фактах проката
-- автомобилей в некоторый заданный интервал времени.
create procedure AllCarRenalBetweenDate
     @loDate date, @hiDate date
as
begin
    select
       *
    from
       ViewAllRentals
    where
       RentalStartDate between @loDate and @hiDate;
end
go

-- выполнение c параметром
declare @loDate date = '05-01-2021', @hiDate date = '10-01-2021';
exec dbo.AllCarRenalBetweenDate @loDate, @hiDate;
go


-- 6. Запрос к представлению.
-- Однотабличная функция.
-- Вычисляет для каждого факта проката стоимость проката.
-- Включает поля Дата проката, Госномер автомобиля,
-- Модель автомобиля, Стоимость проката.
-- Сортировка по полю Дата проката
create function GetCarRentalPrice()
returns table
as
return
     select 
         RentalStartDate
        , CarNumber
        , Model
         -- Стоимость проката автомобиля определяется как 
         -- Стоимость одного дня проката * Количество дней проката. 
        , (PayRentalDay * Duration) as CostRental 
     from
        ViewAllRentals;
     --order by 
     --   RentalStartDate;
go

-- вызов функции GetCarRentalPrice()
select 
    * 
from 
    dbo.GetCarRentalPrice();
go


-- 7. Запрос с левым соединением.
-- Хранимая процедура.
-- Для всех клиентов прокатной фирмы вычисляет количество фактов проката,
-- суммарное количество дней проката, 
-- упорядочивание по убыванию суммарного количества дней проката
create procedure AllClientsRental
as
begin
    select
       Clients.Surname + N' ' + Substring(Clients.[Name], 1, 1) + N'.' + 
                      Substring(Clients.Patronymic, 1, 1) + N'.' as Client
      , Count(Rentals.Id) as AmountRental
      , IsNull(Sum(Rentals.Duration), 0) as SumRentalDays
    from
       Clients left join Rentals on Clients.Id = Rentals.IdClient
    group by
       Clients.Surname, Clients.[Name], Clients.Patronymic
    order by
       SumRentalDays
end;
go


-- выполнение 
exec dbo.AllClientsRental;
go


-- 8. Итоговый запрос.
-- Однотабличная функция.
-- Выбирает информацию о фактах проката автомобилей по госномеру:
-- количество фактов проката, сумма за прокаты, суммарная длительность прокатов
create function GetResultRental()
returns table
as
return
     select
        Models.Model
       , Count(Rentals.Id) as AmountRental
       , Sum(Cars.PayRentalDay * Rentals.Duration) as SumRental
     from 
       Rentals join(Cars join Models on Cars.IdModel = Models.Id)
               on Rentals.IdCar = Cars.Id
     group by
       Models.Model;
go

-- вызов функции GetResultRental()
select 
    * 
from 
    dbo.GetResultRental();
go












