﻿-- База данных «Прокат автомобилей»

/*
База данных должна включать как минимум таблицы КЛИЕНТЫ, АВТОМОБИЛИ, ФАКТЫ_ПРОКАТА,
содержащие следующую информацию:
* Фамилия клиента
* Имя клиента
* Отчество клиента
* Серия, и номер паспорта клиента
* Модель автомобиля, включая бренд (это лучше разместить в отдельной таблице)
* Цвет автомобиля (это лучше разместить в отдельной таблице)
* Год выпуска автомобиля
* Госномер автомобиля
* Страховая стоимость автомобиля
* Стоимость одного дня проката
* Дата начала проката
* Количество дней проката
*/

-- при повторном запуске скрипта удаляем старые варианты таблиц, не разбирая пустые они или нет
-- таблицы удаляем в порядке, обратном порядку создания
drop table if exists Rentals;
drop table if exists Cars;
drop table if exists Clients;
drop table if exists Colors;
drop table if exists Models;


-- таблица - название модель авто
CREATE TABLE [dbo].[Models]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Model] NVARCHAR(20) NOT NULL
);
go


-- таблица - цвет автомобиля
CREATE TABLE [dbo].[Colors]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Color] NVARCHAR(20) NOT NULL
);
go


-- таблица - клиенты
CREATE TABLE [dbo].[Clients]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Surname] NVARCHAR(50) NOT NULL, 
    [Name] NVARCHAR(40) NOT NULL, 
    [Patronymic] NVARCHAR(60) NOT NULL, 
    [PassportNum] NVARCHAR(15) NOT NULL
);
go


-- таблица - автомобили
CREATE TABLE [dbo].[Cars]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [IdModel] INT NOT NULL, 
    [IdColor] INT NOT NULL, 
    [CarNumber] NVARCHAR(8) NOT NULL, 
    [Year] INT NOT NULL, 
    [InsurancePay] INT NOT NULL, 
    [PayRentalDay] INT NOT NULL, 
    CONSTRAINT [CK_Cars_InsurancePay] CHECK ([InsurancePay] >= 0), 
    CONSTRAINT [CK_Cars_PayRentalDay] CHECK ([PayRentalDay] >= 0), 
    CONSTRAINT [FK_Cars_Models] FOREIGN KEY ([IdModel]) REFERENCES [Models]([Id]), 
    CONSTRAINT [FK_Cars_Colors] FOREIGN KEY ([IdColor]) REFERENCES [Colors]([Id])
);
go


-- таблица - факты проката авто
CREATE TABLE [dbo].[Rentals]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [IdClient] INT NOT NULL, 
    [IdCar] INT NOT NULL, 
    [RentalStartDate] DATE NOT NULL, 
    [Duration] INT NOT NULL, 
    CONSTRAINT [CK_Rentals_Duration] CHECK ([Duration] <= 30), 
    CONSTRAINT [FK_Rentals_Clients] FOREIGN KEY ([IdClient]) REFERENCES [Clients]([Id]), 
    CONSTRAINT [FK_Rentals_Cars] FOREIGN KEY ([IdCar]) REFERENCES [Cars]([Id])
);
go




