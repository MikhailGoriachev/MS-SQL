﻿-- Proc3. 
-- Описать процедуру Mean(X, Y, AMean, GMean),
-- вычисляющую среднее арифметическое AMean = (X+Y)/2 и 
-- среднее геометрическое GMean = Sqrt(Abs(X)·Abs(Y)) 
-- двух положительных чисел X и Y (X и Y — входные,
-- AMean и GMean — выходные параметры вещественного типа).
-- С помощью этой процедуры найти среднее арифметическое и 
-- среднее геометрическое для пар (A, B), (A, C), (A, D), если даны A, B, C, D.
create proc Mean
    @x float,
    @y float,
    @AMean float out,
    @GMean float out
as
begin
    set @AMean = (@x + @y)/ 2;
    set @GMean = SQRT(Abs(@x) * Abs(@y));
end
go


-- заголовок вывода
print char(10) +
      N'Задача Proc3.' + char(10) +
      N'Найти среднее арифметическое и геометрическое для пар (A, B), (A, C), (A, D)';
-- переменные для решения
declare @a float = 20 * rand(),
        @b float = 20 * rand(),
        @c float = 20 * rand(),
        @d float = 20 * rand(),
        @amean float, @gmean float;
exec dbo.Mean @a, @b, @amean out, @gmean out;

print char(10) + N'A = ' +
      str(@a, 5, 3) + N'  B = ' + str(@b, 5, 3) + N'  Cреднее арифметическое = ' + 
      str(@amean, 5, 3)+ N'  Cреднее геометрическое = ' + str(@gmean, 5, 3)+ char(10) ;

exec dbo.Mean @a, @c, @amean out, @gmean out;

print char(10) + N'A = ' +
      str(@a, 5, 3) + N'  C = ' + str(@c, 5, 3) + N'  Cреднее арифметическое = ' + 
      str(@amean, 5, 3)+ N'  Cреднее геометрическое = ' + str(@gmean, 5, 3)+ char(10) ;    

exec dbo.Mean @a, @d, @amean out, @gmean out;

print char(10) + N'A = ' +
      str(@a, 5, 3) + N'  D = ' + str(@d, 5, 3) + N'  Cреднее арифметическое = ' + 
      str(@amean, 5, 3)+ N'  Cреднее геометрическое = ' + str(@gmean, 5, 3)+ char(10) ;
go

-- Proc4.
-- Описать процедуру TrianglePS(a, P, S),
-- вычисляющую по стороне a равностороннего треугольника
-- его периметр P = 3·a и площадь S = a2·Sqrt(3)/4 
-- (a — входной, P и S — выходные параметры; все параметры являются вещественными).
-- С помощью этой процедуры найти периметры и площади 
-- трех равносторонних треугольников с данными сторонами
create proc TrianglePS
    @a float,
	@P float out, -- периметр
	@S float out  -- площадь
as
begin
	 set @P = 3 * @a;
	 set @S = power(@a,2) * Sqrt(3)/4;
end
go


declare @x float = 20 * rand(), @perim float, @square float;
exec dbo.TrianglePS @x, @perim out, @square out;
--select @x as side, @perim as Perim, @square as Area;
--go

declare   @i int = 1
        , @n int = 3 -- кол-во треугольников

print char(10) +
      N'    Задача Proc4.' + char(10) +
      N'    Найти периметры и площади трех равносторонних треугольников' + char(10) +
      N'    --------------------------------------------------' + char(10) +
      N'     №       Сторона a    Периметр     Площадь ' + char(10) +
      N'    --------------------------------------------------';
while @i <= @n begin
    -- случайные значения
	--set @x = 20 * rand();

    print str(@i, 6) + str(@x, 14, 3) + str(@perim, 11, 3) + str(@square , 13, 3)
         + char(10) +
    N'    --------------------------------------------------';
    set @i += 1;
end;
go


-- Proc7.
-- Описать процедуру InvertDigits(K), меняющую порядок следования цифр
-- целого положительного числа K на обратный (K — параметр целого типа,
-- являющийся одновременно входным и выходным). 
-- С помощью этой процедуры поменять порядок следования цифр на обратный
-- для каждого из пяти данных целых чисел.
alter proc InvertDigits
     @x int,
     @k int out
as
begin
    set @x = @k;
    set @k = 0;
    while @x != 0 begin
        set @k = @k *10+(@x % 10);
        set @x /= 10;
    end
end
go


declare @temp int, @k int = 20 * rand();;
--exec InvertDigits @temp, @k out;

declare   @i int = 1
          , @n int = 5 -- кол-во целых чисел
      print char(10) +
      N'    Задача Proc7.' + char(10) +
      N'    поменять порядок следования цифр на обратный для каждого из пяти чисел' + char(10)+
      N'     №        Целое число  ' + char(10) +
      N'    ---------------------------';
while @i <= @n begin
    -- случайные значения
	set @k = 20 * rand();
    print str(@i, 6) + str(@k, 14) + char(10) ;

exec InvertDigits @temp, @k out;
    print str(@i, 6) + str(@k, 14) + char(10) +
    N'    ---------------------------';
    set @i += 1;
end;
go


-- Proc8. 
-- Описать процедуру AddRightDigit(D, K), добавляющую к целому 
-- положительному числу K справа цифру D (D — входной параметр целого типа,
-- лежащий в диапазоне 0–9, K — параметр целого типа, являющийся одновременно
-- входным и выходным). С помощью этой процедуры последовательно добавить
-- к данному числу K справа данные цифры D1 и D2, выводя результат каждого добавления
create proc AddRightDigit
    @d int,
    @k int out
as
begin
    set @k *=10;
    set @k += @d;
end
go


declare @d1 int, @d2 int, @k int = 20 * rand();
print  + char(10) + str(@k, 14) + str(@d1, 14)+ char(10) +
    N'    ---------------------------';
exec AddRightDigit @d1 , @k out;
    set @d1 = (rand() * (9)) + 1 ;
    --print str(@d1, 6) + str(@k, 14) + char(10)+
    print str(@k, 6) + str(@d1, 14)+ char(10) +
    N'    ---------------------------';
go


-- Proc9.
-- Описать процедуру AddLeftDigit(D, K), добавляющую к целому
-- положительному числу K слева цифру D (D — входной параметр целого типа,
-- лежащий в диапазоне 1–9, K — параметр целого типа, 
-- являющийся одновременно входным и выходным). 
-- С помощью этой процедуры последовательно добавить к данному
-- числу K слева данные цифры D1 и D2, выводя результат каждого добавления
create proc AddLeftDigit
    @d int,
    @k int out
as
begin
   declare @temp int = 10;
   while (@k>@temp) 
   set @temp *= 10;
   set @k += @d * @temp;
end
go


  

