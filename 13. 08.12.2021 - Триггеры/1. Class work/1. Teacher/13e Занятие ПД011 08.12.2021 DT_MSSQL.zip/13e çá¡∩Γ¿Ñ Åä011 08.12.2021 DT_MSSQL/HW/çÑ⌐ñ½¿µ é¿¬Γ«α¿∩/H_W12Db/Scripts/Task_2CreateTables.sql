﻿-- База данных «Видеотека»

-- В БД хранится информация о домашней видеотеке: фильмы, актеры, режиссеры.
-- Для фильмов необходимо хранить:
-- •	название;
-- •	имена актеров;
-- •	имя режиссера;
-- •	дату выхода;
-- •	жанр фильма;
-- •	бюджет фильма;
-- •	страну, в которой выпущен фильм.
-- Для актеров и режиссеров необходимо хранить:
-- •	фамилию;
-- •	имя;
-- •	отчество;
-- •	дату рождения.


-- при повторном запуске скрипта удаляем старые варианты таблиц, не разбирая пустые они или нет
-- таблицы удаляем в порядке, обратном порядку создания
drop table if exists ActorsFilms;
drop table if exists Films;
drop table if exists Countries;
drop table if exists Genres;
drop table if exists Persons;


-- таблица - персоны ФИО
CREATE TABLE [dbo].[Persons]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Surname] NVARCHAR(50) NOT NULL,    -- фамилия 
    [Name] NVARCHAR(40) NOT NULL,       -- имя
    [Patronymic] NVARCHAR(60) NOT NULL,  -- отчество
    [DateOfBirth] DATE NOT NULL          -- дата рождения
);
go


-- таблица - жанры фильмов
CREATE TABLE [dbo].[Genres]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Variety] NVARCHAR(20) NOT NULL  -- жанр фильма
);
go


-- таблица - страны, в которой выпущен фильм
CREATE TABLE [dbo].[Countries]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Coutry] NVARCHAR(25) NOT NULL  -- название страны
);
go



-- таблица - фильмы
CREATE TABLE [dbo].[Films]
(
	[Id]               INT NOT NULL PRIMARY KEY IDENTITY, 
    [NameFilm]         NVARCHAR(80) NOT NULL,  -- название фильма
    [IdProducer]       INT NOT NULL, -- внешний ключ, ссылка на таблицу Persons
    [DateMorieRelease] DATE NOT NULL, --  дату выхода фильма
    [IdGenre]          INT NOT NULL, -- внешний ключ, ссылка на Genres, жанр фильма
    [Budget]           INT NOT NULL, -- бюджет фильма
    [IdCountry]        INT NOT NULL, -- внешний ключ, ссылка на Countries, страну, в которой выпущен фильм
    -- проверочное ограничение
    CONSTRAINT [CK_Films_Budget] CHECK ([Budget] >= 0),
    -- внешние ключи
    CONSTRAINT [FK_Films_Persons] FOREIGN KEY ([IdProducer]) REFERENCES [Persons]([Id]),
    CONSTRAINT [FK_Films_Genres] FOREIGN KEY ([IdGenre]) REFERENCES [Genres]([Id]),
    CONSTRAINT [FK_Films_Countries] FOREIGN KEY ([IdCountry]) REFERENCES [Countries]([Id])
);
go


-- актеры и фильмы, в которых они играли
create table dbo.ActorsFilms
(
    [Id]      INT NOT NULL PRIMARY KEY IDENTITY,
    [IdActor] INT NOT NULL, -- внешний ключ, ссылка на таблицу Persons
    [IdFilm]  INT NOT NULL, -- внешний ключ, ссылка на таблицу Films
    -- внешние ключи
    CONSTRAINT  [FK_ActorsFilms_Persons] FOREIGN KEY ([IdActor]) REFERENCES [Persons]([Id]),
    CONSTRAINT  [FK_ActorsFilms_Films]   FOREIGN KEY ([IdFilm])  REFERENCES [Films]([Id])
);
go