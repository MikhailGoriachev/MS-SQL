﻿-- База данных «Видеотека»

-- представление для фильмов
drop view if exists ViewFilms;
go

create view ViewFilms as
    select
        Films.Id
        , Persons.Surname    as ProducerSurname
        , Persons.[Name]     as ProducerName
        , Persons.Patronymic as ProducerPatronymic
        , Genres.Variety
        , Countries.Coutry
        , Films.NameFilm
        , Films.DateMorieRelease
        , Films.Budget
from
    Films join Persons on Films.IdProducer = Persons.Id
          join Genres on Films.IdGenre = Genres.Id
          join Countries on Films.IdCountry = Countries.Id;
go

-- представление режиссеров
drop view if exists ViewProducers;
go

create view ViewProducers as
    select distinct
        Persons.Surname    as ProducerSurname
        , Persons.[Name]     as ProducerName
        , Persons.Patronymic as ProducerPatronymic
from
    Films join Persons on Films.IdProducer = Persons.Id;
go


-- представление актеров
drop view if exists ViewActors;
go

create view ViewActors as
    select distinct
        Persons.Surname      as ActorSurname
        , Persons.[Name]     as ActorName
        , Persons.Patronymic as ActorPatronymic
from
    ActorsFilms join Persons on ActorsFilms.IdActor = Persons.Id;
go


-- Разработайте запросы в виде однотабличных функций,
-- проверьте их работу на трех наборах параметров 
-- (первый запрос, естественно, без параметров)

-- 1. Вывести все фильмы, вышедшие на экран в текущем и прошлом году.
create function GetFilmsAll(@currentYear int, @prevYear int)
returns table
as
return 
     select
        *
     from
        ViewFilms
    where
        DATEPART(year, ViewFilms.DateMorieRelease) in (@currentYear, @prevYear);
go

-- вызов функции GetFilmsAll()
declare @currentYear int = Year(GetDate());
declare @prevYear int = @currentYear - 1;
select 
    * 
from 
    dbo.GetFilmsAll(@currentYear,@prevYear);
go

-- 2. Вывести информацию об актерах, снимавшихся в заданном фильме
create function GetActorsInFilm(@nameFilm nvarchar(80))
returns table
as
return
     select
        Persons.Surname as ActorSurname
       , Persons.[Name] as ActorName
       , Persons.Patronymic as ActorPatronymic
       , Films.NameFilm
    from
       ActorsFilms join Persons on ActorsFilms.IdActor = Persons.Id
                   join Films   on ActorsFilms.IdFilm = Films.Id 
    where
       Films.NameFilm = @nameFilm;
go

-- вызов функции GetActorsInFilm()
declare @nameFilm nvarchar(80) = N'Отель «Гранд Будапешт»';
select 
    * 
from 
    dbo.GetActorsInFilm(@nameFilm);
go

select 
    * 
from 
    dbo.GetActorsInFilm(N'Брат Баджранги');
go

-- 3. Вывести информацию об актерах, снимавшихся как минимум в N фильмах
create function GetActorsInNFilms(@n int)
returns table
as
return
     select
         Persons.Surname as ActorSurname
        , Persons.[Name] as ActorName
        , Persons.Patronymic as ActorPatronymic
        , count(ActorsFilms.IdFilm) as CountFilms
     from
         ActorsFilms join Persons on ActorsFilms.IdActor = Persons.Id
     group by
         Persons.Surname, Persons.[Name], Persons.Patronymic
having
    count(ActorsFilms.IdFilm) >= @n;
go

-- вызов функции GetActorsInNFilms()
declare @nFilms int = 2;
select 
    * 
from 
    dbo.GetActorsInNFilms(@nFilms);
go


-- Разработайте запросы в виде хранимых процедур,
-- проверьте их работу на трех наборах параметров 
-- (последний запрос, естественно, без параметров)

-- 1. Вывести информацию об актерах, которые были режиссерами хотя бы одного из фильмов
create procedure FilmActorAndProducer
as
begin
    select distinct
       ActorsFilms.IdActor
      , Persons.Surname as ActorSurname
      , Persons.[Name] as ActorName
      , Persons.Patronymic as ActorPatronymic
    from
       ActorsFilms join Persons on ActorsFilms.IdActor = Persons.Id
    where
       ActorsFilms.IdActor in (select distinct IdProducer from Films);
end;
go
     
-- выполнение
exec dbo.FilmActorAndProducer;
go


-- 2. Вывести все фильмы, дата выхода которых была более заданного числа лет назад
create procedure FilmsReleaseBackYear
     @yearInterval int
as
begin
    select
       *
    from
       ViewFilms
    where
       Year(GetDate()) - Year(ViewFilms.DateMorieRelease) > @yearinterval
    order by
       ViewFilms.DateMorieRelease;
end
go

-- выполнение c параметрами
exec dbo.FilmsReleaseBackYear 9;
go

exec dbo.FilmsReleaseBackYear 12;
go


-- 3. Вывести всех актеров и количество фильмов, в которых они участвовали
create procedure AllActorInFilm
as
begin
    select
       ActorsFilms.IdActor
      , Persons.Surname
      , Persons.[Name]
      , Persons.Patronymic
      , Count(ActorsFilms.IdFilm) as CountFilms
   from
      ActorsFilms join Persons on ActorsFilms.IdActor = Persons.Id
   group by
      ActorsFilms.IdActor, Persons.Surname, Persons.[Name], Persons.Patronymic;
end
go

-- выполнение
exec dbo.AllActorInFilm;
go

-- 6. Вывести всех актеров и количество фильмов, в которых они участвовали
select
    ActorsFilms.IdActor
    , Persons.Surname
    , Persons.[Name]
    , Persons.Patronymic
    , Count(ActorsFilms.IdFilm) as CountFilms
from
    ActorsFilms join Persons on ActorsFilms.IdActor = Persons.Id
group by
    ActorsFilms.IdActor, Persons.Surname, Persons.[Name], Persons.Patronymic;
go


