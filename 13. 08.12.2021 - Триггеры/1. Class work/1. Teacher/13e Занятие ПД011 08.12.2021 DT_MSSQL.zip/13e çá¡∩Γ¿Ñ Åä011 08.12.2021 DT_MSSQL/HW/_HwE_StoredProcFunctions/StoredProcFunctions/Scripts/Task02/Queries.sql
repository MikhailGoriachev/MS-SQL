﻿/* Задача 2. Домашняя видеотека */

-- Видеотека. В БД хранится информация о домашней видеотеке: фильмы, актеры, 
-- режиссеры

-- режиссеры
select
   *
from
   ViewProducers;
go

-- актеры
select
    *
from
    ViewActors;
go

-- фильмы
select
    *
from
    ViewFilms;
go

-- запросы по заданию

-- Разработайте запросы в виде однотабличных функций, проверьте их работу 
-- на трех наборах параметров (первый запрос, естественно, без параметров):

-- 1. Вывести все фильмы, вышедшие на экран в текущем и прошлом году.
drop function if exists FuncQuery01;
go

create function FuncQuery01() returns table
as
return 
    select
        *
    from
        ViewFilms
    where
        DATEPART(year, ViewFilms.ReleaseDate) in (Year(GetDate()), Year(GetDate())-1);
go

-- проверочный запрос
select
    *
from
    dbo.FuncQuery01()
order by
    ReleaseDate;
go

-- 2. Вывести информацию об актерах, снимавшихся в заданном фильме.
drop function if exists FuncQuery02;
go

create function FuncQuery02(@title nvarchar(80)) returns table
as
return
    select
        Persons.Surname as ActorSurname
        , Persons.[Name] as ActorName
        , Persons.Patronymic as ActorPatronymic
        , Films.Title
    from
        ActorsFilms join Persons on ActorsFilms.IdActor = Persons.Id
                    join Films   on ActorsFilms.IdFilm = Films.Id 
    where
        Films.Title = @title;
go

-- проверочные запросы
declare 
    @title1 nvarchar(80) = N'Вечерний звон в Тамани',
    @title2 nvarchar(80) = N'Купюры без истории',
    @title3 nvarchar(80) = N'Парнас в тумане';
select * from dbo.FuncQuery02(@title1);
select * from dbo.FuncQuery02(@title2);
select * from dbo.FuncQuery02(@title3);
go

-- 3. Вывести информацию об актерах, снимавшихся как минимум в N фильмах
drop function if exists FuncQuery03;
go

create function FuncQuery03(@total int) returns table
as
return
   select
       Persons.Surname as ActorSurname
       , Persons.[Name] as ActorName
       , Persons.Patronymic as ActorPatronymic
       , count(ActorsFilms.IdFilm) as TotalFilms
   from
       ActorsFilms join Persons on ActorsFilms.IdActor = Persons.Id
   group by
       Persons.Surname, Persons.[Name], Persons.Patronymic
   having
       count(ActorsFilms.IdFilm) >= @total;
go

-- проверочные запросы
select * from dbo.FuncQuery03(2);
select * from dbo.FuncQuery03(3);
select * from dbo.FuncQuery03(4);
go

-- Разработайте запросы в виде хранимых процедур, проверьте их работу 
-- на трех наборах параметров (первый и последний запросы, естественно, 
-- без параметров):

-- 4. Вывести информацию об актерах, которые были режиссерами хотя бы одного из фильмов
drop proc if exists ProcQuery04;
go

create proc ProcQuery04 as
begin
    select distinct
        ActorsFilms.IdActor
        , Persons.Surname as ActorSurname
        , Persons.[Name] as ActorName
        , Persons.Patronymic as ActorPatronymic
    from
        ActorsFilms join Persons on ActorsFilms.IdActor = Persons.Id
    where
        ActorsFilms.IdActor in (select distinct IdProducer from Films);
end;
go

exec dbo.ProcQuery04
go

-- 5. Вывести все фильмы, дата выхода которых была более заданного числа лет назад.
drop proc if exists ProcQuery05;
go

create proc ProcQuery05
    @interval int
as
begin
    select
       *
    from
        ViewFilms
    where
         Year(GetDate()) - Year(ViewFilms.ReleaseDate) > @interval;
end;
go

exec dbo.ProcQuery05 1;
exec dbo.ProcQuery05 2;
exec dbo.ProcQuery05 3;
go

-- 6. Вывести всех актеров и количество фильмов, в которых они участвовали
drop proc if exists ProcQuery06;
go

create proc ProcQuery06
as
begin
    select
        ActorsFilms.IdActor
        , Persons.Surname
        , Persons.[Name]
        , Persons.Patronymic
        , count(ActorsFilms.IdFilm) as TotalFilm
    from
        ActorsFilms join Persons on ActorsFilms.IdActor = Persons.Id
    group by
        ActorsFilms.IdActor, Persons.Surname, Persons.[Name], Persons.Patronymic
    order by
        TotalFilm desc;
end;
go

exec dbo.ProcQuery06
go