﻿/* База данных «Прокат автомобилей» */

-- Вывод записей таблицы автомобилей с расшифровкой всех полей
select
    *
from
    ViewCars;
go

-- Вывод записей таблицы фактов проката с расшифровкой всех полей
select
    *
from
    ViewHires
-- order by
--    Plate
;
go

--  1. Запрос к представлению. Однотабличная функция	
--     Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
drop function if exists FuncQuery01;
go

create function FuncQuery01(@plate nvarchar(12)) returns table
as
return
    select top (select count(*) from ViewHires)
        Id
        , ClientSurname + N' ' + Substring(ClientName, 1, 1) + N'.' + 
              Substring(ClientPatronymic, 1, 1) + N'.' as Client
        , BrandModel
        , Plate
        , DateStart
        , Duration
    from
        ViewHires
    where
        Plate = @plate 
    order by
        DateStart;
go

declare @plate nvarchar(12) = N'О169РК';
select * from dbo.FuncQuery01(@plate);
go

declare @plate nvarchar(12) = N'Т315РК';
select * from dbo.FuncQuery01(@plate);
go

declare @plate nvarchar(12) = N'Н177РК';
select * from dbo.FuncQuery01(@plate);
go

--  2. Запрос к представлению. Хранимая процедура	
--     Выбирает информацию обо всех фактах проката автомобиля с заданной 
--     моделью/брендом
drop procedure if exists ProcQuery02;
go

create procedure ProcQuery02
   @brandModel nvarchar(30)
as
begin
    select
        Id
        , ClientSurname + N' ' + Substring(ClientName, 1, 1) + N'.' + 
              Substring(ClientPatronymic, 1, 1) + N'.' as Client
        , BrandModel
        , Plate
        , DateStart
        , Duration
    from
        ViewHires
    where
        BrandModel = @brandModel 
    order by
        DateStart;
end;
go

exec dbo.ProcQuery02 N'Volkswagen Polo';
go

exec dbo.ProcQuery02 N'Skoda Roomster';
go

exec dbo.ProcQuery02 N'Skoda Fabia New';
go


--  3. Запрос к представлению. Однотабличная функция
--     Выбирает информацию об автомобиле с заданным госномером
-- declare @plate nvarchar(12) = N'О169РК';
drop function if exists FuncQuery03;
go

create function FuncQuery03(@plate nvarchar(12)) returns table
as
return
    select
        Id 
        , BrandModel
        , Color
        , Plate
        , YearManuf
        , InsurValue
        , Rental
    from
        ViewCars
    where
        Plate like @plate + N'%';
go

declare @plate nvarchar(12) = N'С';
select * from dbo.FuncQuery03(@plate);
go

--  4. Запрос с параметром. Хранимая процедура	
--     Выбирает информацию о клиентах по серии и номеру паспорта
drop procedure if exists ProcQuery04;
go

create procedure ProcQuery04
    @passport nvarchar(15)
as
begin
select
    Id 
    , Surname
    , [Name]
    , Patronymic
    , Passport
from
    Clients
where
    Passport = @passport;
end;
go

declare @passport1 nvarchar(15) = N'11 21 098181'; 
exec ProcQuery04 @passport1;
go

declare @passport2 nvarchar(15) = N'12 21 123122'
exec ProcQuery04 @passport2;
go

declare @passport3 nvarchar(15) = N'11 21 121212';
exec ProcQuery04 @passport3;
go

--  5. Запрос к представлению. Хранимая процедура	
--     Выбирает информацию обо всех зафиксированных фактах проката автомобилей
--     в некоторый заданный интервал времени.
drop proc if exists ProcQuey05
go

create proc ProcQuery05
    @from date, 
    @to date
as
begin
select
    Id
    , ClientSurname + N' ' + Substring(ClientName, 1, 1) + N'.' + 
          Substring(ClientPatronymic, 1, 1) + N'.' as Client
    , BrandModel
    , Plate
    , DateStart
    , Duration
from
    ViewHires
where
    DateStart between @from and @to 
order by
    DateStart;
end;
go


declare @from date = '10-01-2021', @to date = '10-15-2021';
exec ProcQuery05 @from, @to;
go

declare @from date = '10-16-2021', @to date = '10-31-2021';
exec ProcQuery05 @from, @to;
go

declare @from date = '11-01-2021', @to date = '11-15-2021';
exec ProcQuery05 @from, @to;
go


--  6. Запрос к представлению. Однотабличная функция
--     Вычисляет для каждого факта проката стоимость проката. Включает поля 
--     Дата проката, Госномер автомобиля, Модель автомобиля, Стоимость проката.
--     Сортировка по полю Дата проката
drop function if exists FuncQuery06;
go

create function FuncQuery06() returns table
as
return
    select top (select count(*) from ViewHires)
        Id
        , DateStart
        , Plate
        , BrandModel
        , Rental                  as RentalPerDay
        , Duration
        , Rental * Duration as Price 
    from
        ViewHires
    order by
        DateStart;
go

select * from dbo.FuncQuery06();
go


--  7. Запрос с левым соединением. Хранимая процедура 	
--     Для всех клиентов прокатной фирмы вычисляет количество фактов проката, 
--     суммарное количество дней проката, упорядочивание по убыванию 
--     суммарного количества дней проката
drop proc if exists ProcQuery07;
go

create proc ProcQuery07
as
begin
    select
        Clients.Id
        , Clients.Surname + N' ' + Substring(Clients.[Name], 1, 1) + N'.' + 
              Substring(Clients.Patronymic, 1, 1) + N'.' as ClientFullName
        , Count(Hires.IdCar) as Amount
        , IsNull(Sum(Duration), 0) as TotalDuration
    from
        Clients left join Hires on Clients.Id = Hires.IdClient
    group by
        Clients.Id, Clients.Surname, Clients.[Name], Clients.Patronymic
    order by
        TotalDuration desc;
    end
go

exec ProcQuery07;
go


--  8. Итоговый запрос. Однотабличная функция	
--     Выбирает информацию о фактах проката автомобилей по госномеру: 
--     количество фактов проката, сумма за прокаты, суммарная длительность 
--     прокатов
drop function if exists FuncQuery08;
go

create function FuncQuery08() returns table
return
    select
        Plate
        , Count(Plate)           as Total
        , Sum(Rental * Duration) as TotalRental
        , Sum(Duration)          as TotalDuration
    from  
        ViewHires
    group by
        Plate;
go

select * from dbo.FuncQuery08();
go
