﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary; // для сериализации
// для сериализации/десериализации в XML-формате
using System.Xml.Serialization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W21C_.Models
{
    // Класс для работы коллекции заявок на авиабилеты
    [Serializable]
    public class CollectionRequest
    {
        // коллекция заявок
        private List<RequestAirTicket> _listRequest;

        public int Count => _listRequest.Count;
        public List<RequestAirTicket> Requests => _listRequest;

        public CollectionRequest() => Initialize();

        public CollectionRequest(List<RequestAirTicket> requests)
        {
            _listRequest = requests;
        }// CollectionRequest

        public void Initialize() {
            _listRequest = new List<RequestAirTicket>(
                new RequestAirTicket[] {
                    new RequestAirTicket(98, "Финляндия",  "LM381", "Филатов О.Д.", new DateTime(2021, 11, 1)),
                    new RequestAirTicket(55, "Гибралтар",  "SU256", "Митин Ю.А.",   new DateTime(2021, 11, 25)),
                    new RequestAirTicket(32, "Нидерланды", "SR384", "Богдан С.Р.",  new DateTime(2021, 11, 4)),
                    new RequestAirTicket(77, "Австралия",  "NS591", "Романов А.Р.", new DateTime(2021, 12, 18)),
                    new RequestAirTicket(104, "Стамбул",   "LM563", "Заяц С.И.",    new DateTime(2021, 12, 27)),
                    new RequestAirTicket(22, "Греция",     "OM254", "Шульга М.О.",  new DateTime(2021, 11, 10)),
                    new RequestAirTicket(15, "Италия",     "HU362", "Потапов Л.Д.", new DateTime(2021, 11, 8)),
                    new RequestAirTicket(68, "Сингапур",   "SL581", "Тюрина О.Ю.",  new DateTime(2021, 12, 12)),
                    new RequestAirTicket(75, "Египет",     "NM836", "Полякова В.Д.",new DateTime(2022, 1, 6)),
                    new RequestAirTicket(93, "Стамбул",    "LM563", "Жуков А.Н.",   new DateTime(2021, 12, 27))
                });
        }// Initialize

        // бинарная сериализация
        public void BinarySerialization(string fileName) {
            // форматтер для бинарной сериализации
            BinaryFormatter bf = new BinaryFormatter();
            using (FileStream fs = new FileStream(fileName, FileMode.Create)) {
                bf.Serialize(fs, _listRequest);
            }// using

            ShowList($"\n\n\tСериализация выполнена, данные сохранены в файле \"{fileName}\":");
        }// BinarySerialization

        // бинарная десериализация
        public void BinaryDeserialize(string fileName)
        {
            // форматтер для бинарной десериализации
            BinaryFormatter bf = new BinaryFormatter();
            using (FileStream fs = new FileStream(fileName, FileMode.Open))
            {
                _listRequest = bf.Deserialize(fs) as List<RequestAirTicket>;
            }// using
            ShowList("\n\n\tДесериализация восстановление данных:");
        } // BinaryDeserialize

        // XML сериализация
        public void XMLSerialization(string fileName) {
            // форматтер для сериализации
            XmlSerializer formatter = new XmlSerializer(typeof(List<RequestAirTicket>));

            // запись коллекции в поток данных
            using (FileStream fs = new FileStream(fileName, FileMode.Create)) {
                formatter.Serialize(fs, _listRequest);
            } // using

            ShowList($"\n\n\tСериализация в формате XML выполнена, данные сохранены в файле \"{fileName}\":");
        }// XMLSerialization

        // XML десериализация
        public void XMLDeserialization(string fileName)
        {
            _listRequest.Clear();
            // форматтер для сериализации
            XmlSerializer formatter = new XmlSerializer(typeof(List<RequestAirTicket>));

            // запись коллекции в поток данных
            using (FileStream fs = new FileStream(fileName, FileMode.OpenOrCreate)) {
                _listRequest = formatter.Deserialize(fs) as List<RequestAirTicket>;
            } // using

            ShowList($"\n\n\tДесериализация восстановление данных в формате XML выполнена." +
                $"\n\t Данные сохранены в файле \"{fileName}\":");
        }// XMLDeserialization

        // именованный итератор для фильтрации коллекции заявок
        // по заданному номеру рейса и дате вылета 
        public IEnumerable GetFlightNumberDate(string flightNumber, DateTime date)
        {
            foreach (var req in _listRequest)
            {
                if (req.FlightNumber == flightNumber && req.DepartureDate == date)
                    yield return req;
            } // foreach
        } // GetFlightNumberDate

        // метод для добавления заявки в коллекцию
        public void Add(RequestAirTicket requestAir) => _listRequest.Add(requestAir);

        // удаление заявки по предикату
        public void Remove(Predicate<RequestAirTicket> predicate)
        {
            // просмотр коллекции заявок и удаление, 
            // если предикат вернет true
            int n = _listRequest.Count;
            for (int i = 0; i < n; ++i) {
                if (predicate(_listRequest[i])) {
                    _listRequest.RemoveAt(i);
                    --i;                     // остаться на той же позиции после удаления
                    n = _listRequest.Count;  // перечитать размер коллекции
                } // if
            } // for i
        } // Remove

        // удаление всех заявок
        public void RemoveAllRequest()
        {
            _listRequest.Clear();
        } // RemoveAllRequest

        // сортировка списка заявок по дате вылета
        public void SortByDepartureDate() => _listRequest.Sort((r1, r2) => r1.DepartureDate.CompareTo(r2.DepartureDate));

        // сортировка списка заявок по номеру рейса
        public void SortByFlightNumber() => _listRequest.Sort((r1, r2) => r1.FlightNumber.CompareTo(r2.FlightNumber));

        // вывод коллекции в консоль
        public void ShowList(string title)
        {
            Console.Write($"{title}\n{RequestAirTicket.Header()}");

            foreach (var route in _listRequest)
            {
                Console.WriteLine($"\t{route.ToTableRow()}");
            } // foreach

            Console.WriteLine($"{RequestAirTicket.Footer()}\n");
        } // ShowList

         // реализация итератора для коллекции
        public IEnumerator GetEnumerator() => _listRequest.GetEnumerator();
    }// class CollectionRequest
}
