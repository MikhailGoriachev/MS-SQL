﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using H_W21C_.Models;

namespace H_W21C_.Application
{
    // решение для задачи 
    internal partial class App
    {
        // Бинарная сериализация коллекции заявок
        public void InitializeSerialize()
        {
            Utils.ShowNavBarTask("   Бинарная сериализация коллекции заявок");
            _requests.Initialize();
            _requests.BinarySerialization(_filenameRequest);

        }// InitializeSerialize

        // Бинарная десериализация заявок
        public void CollectionDeserialize()
        {
            Utils.ShowNavBarTask("   Бинарная десериализация заявок");

            _requests.RemoveAllRequest();
            _requests.BinaryDeserialize(_filenameRequest);
        }// CollectionDeserialize

        // Вывод всех заявок из коллекции в консоль
        public void ShowCollection()
        {
            Utils.ShowNavBarTask("   Вывод всех заявок из коллекции в консоль");

            _requests.ShowList("\n\n\tКоллекция заявок:");

        }// ShowCollection

        // Выборка заявок по заданному номеру рейса и дате вылета при помощи именованного итератора
        public void EnumerateByFlightNum()
        {
            Utils.ShowNavBarTask("   Выборка заявок по заданному номеру рейса и дате вылета");

            int index = Utils.Random.Next(0, _requests.Count - 1);
            string flightnum = _requests.Requests[index].FlightNumber;
            DateTime date = _requests.Requests[index].DepartureDate;

            Console.WriteLine($"\n\t    Заданный номер рейса: {flightnum}\n\t    Заданная дата вылета: {date:dd.MM.yyyy}");

            // список заявок по номеру рейса и дате вылета
            List<RequestAirTicket> list = new List<RequestAirTicket>();
            foreach (RequestAirTicket req in _requests.GetFlightNumberDate(flightnum, date))
                list.Add(req);

            Show("\n\t Заявки по заданному номеру рейса и дате вылета : ", list);
        }// EnumerateByFlightNum

        // Добавление заявки в список, бинарная сериализация модифицированной коллекции
        public void AddRequestAirTicket()
        {
            Utils.ShowNavBarTask("   Добавление заявки в список, бинарная сериализация модифицированной коллекции");

            RequestAirTicket req = new RequestAirTicket(55, "Москва", "KL382", "Иванов И.И.", new DateTime(2022, 01, 10));
            _requests.Add(req);

            _requests.BinarySerialization(_filenameRequest);
        }// AddRequestAirTicket

        // Удаление заявок из списка по номеру заявки, бинарная сериализация модифицированной коллекции
        public void RemoveRequestAirTicket()
        {
            Utils.ShowNavBarTask("   Удаление заявок из списка по номеру заявки, бинарная сериализация модифицированной коллекции");

            _requests.ShowList("\n\t Коллекция для удаления заявки:");

            Console.CursorVisible = true;
            Console.Write("\tВведите номер заявки для удаления: ");
            string str = Console.ReadLine();
            Console.CursorVisible = false;

            if (!int.TryParse(str, out int nRequest)) throw new Exception("Некорректный ввод!");
            _requests.Remove(req => req.NumberRequest == nRequest);
            _requests.BinarySerialization(_filenameRequest);

        }// RemoveRequestAirTicket

        // Удаление всех заявок из списка, бинарная сериализация модифицированной коллекции
        public void RemoveAllCollectionRequest()
        {
            Utils.ShowNavBarTask("   Удаление всех заявок из списка, бинарная сериализация модифицированной коллекции");

            _requests.RemoveAllRequest();

            Console.WriteLine($"\n\n{" ".PadLeft(12)}Данные успешно удалены.");
           // _requests.BinarySerialization(_filenameRequest);

        }// RemoveAllCollectionRequest

        // Упорядочивание списка заявок по номеру рейса
        public void SortCollectionByFlightNumber()
        {
            Utils.ShowNavBarTask("   Упорядочивание списка заявок по номеру рейса, бинарная сериализация модифицированной коллекции");

            _requests.SortByFlightNumber();
            Console.Write($"\n\n{" ".PadLeft(8)}Заявки отсортированы по номеру рейса.");
            _requests.BinarySerialization(_filenameRequest);
            
        }// SortCollectionByFlightNumber


        // Упорядочивание списка заявок по желаемой дате вылета
        public void SortCollectionByDateFlight()
        {
            Utils.ShowNavBarTask("   Упорядочивание списка заявок по желаемой дате вылета, бинарная сериализация модифицированной коллекции");

            _requests.SortByDepartureDate();
            Console.Write($"\n\n{" ".PadLeft(8)}Заявки отсортированы по желаемой дате вылета.");
            _requests.BinarySerialization(_filenameRequest);
        }// SortCollectionByDateFlight

        // Сериализация коллекции в формате XML
        public void CollectionXMLSerialize()
        {
            Utils.ShowNavBarTask("   Сериализация коллекции в формате XML");
           // _requests.Initialize();
            _requests.XMLSerialization(_filenameReqXml);
        }// CollectionXMLSerialize

        // Десериализация коллекции из формата XML
        public void CollectionXMLDeserialize()
        {
            Utils.ShowNavBarTask("   Десериализация коллекции в формате XML");
            // _requests.Initialize();
            _requests.XMLDeserialization(_filenameReqXml);
        }// CollectionXMLDeserialize


        // Вывод заявок сформированных итератором списка
        private void Show(string title, IEnumerable<RequestAirTicket> users)
        {            
            Console.Write($"{title}\n{RequestAirTicket.Header()}");

            foreach (var user in users) {
                Console.WriteLine($"\t{user.ToTableRow()}");
            } // foreach

            Console.WriteLine($"{RequestAirTicket.Footer()}");
        } // Show

    }// class App
}
