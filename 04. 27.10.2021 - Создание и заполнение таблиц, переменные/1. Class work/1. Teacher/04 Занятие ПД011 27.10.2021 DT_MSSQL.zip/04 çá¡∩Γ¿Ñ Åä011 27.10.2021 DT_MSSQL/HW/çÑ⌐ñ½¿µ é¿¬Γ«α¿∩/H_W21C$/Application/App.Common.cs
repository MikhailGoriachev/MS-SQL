﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using H_W21C_.Models;

namespace H_W21C_.Application
{
    internal partial class App
    {
        // название файла для хранения данных в бинарном формате
        private string _filenameRequest;
        // название файла для хранения данных в XML формате
        private string _filenameReqXml;
        private CollectionRequest _requests;

        public App(): this("..\\..\\request.dat", "../../requests.xml", new CollectionRequest()) { }

        public App(string filenameReq, string filenameReqXml, CollectionRequest requests)
        {
            _filenameRequest = filenameReq;
            _filenameReqXml = filenameReqXml;
            _requests        = requests;
        } // App


    }// class App
}
