﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W21C_.Application
{
    /// <summary>
    /// Напишите консольное приложение для учета заявок на авиабилеты.
    /// Каждая заявка содержит: номер заявки, пункт назначения,
    /// номер рейса, фамилию и инициалы пассажира, желаемую дату вылета.
    /// Для хранения данных использовать класс List<>.
    /// Приложение должно обеспечивать выбор с помощью меню и 
    /// выполнение одной из следующих функций:
    /// •	Бинарная сериализация коллекции заявок
    /// •	Бинарная десериализация заявок
    /// •	вывод всех заявок из коллекции в консоль
    /// •	выборка в еще один список заявок по заданному
    ///  номеру рейса и дате вылета при помощи именованного итератора;
    /// •	добавление заявки в список, бинарная сериализация
    ///  модифицированной коллекции;
    /// •	удаление заявок из списка по номеру заявки,
    ///  бинарная сериализация модифицированной коллекции;
    /// •	удаление всех заявок из списка, 
    ///  бинарная сериализация модифицированной коллекции;
    /// •	упорядочивание списка заявок по номеру рейса,
    ///  бинарная сериализация модифицированной коллекции
    /// •	упорядочивание списка заявок по желаемой дате рейса
    ///  бинарная сериализация модифицированной коллекции
    /// •	Сериализация коллекции в формате XML
    /// •	Десериализация коллекции из формата XML
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {

            Console.Title = "Домашнее задание № 21.";
            try
            {
                // меню приложения
                MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Бинарная сериализация коллекции заявок." },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Бинарная десериализация заявок." },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Вывод всех заявок из коллекции в консоль." },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Выборка заявок по заданному номеру рейса и дате вылета." },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Добавление заявки в список, бинарная сериализация мод-й коллекции." },
                new MenuItem { HotKey = ConsoleKey.Y, Text = "Удаление заявок из списка по номеру заявки, бинарная сериализация мод-й коллекции." },
                new MenuItem { HotKey = ConsoleKey.U, Text = "Удаление всех заявок из списка, бинарная сериализация модифицированной коллекции." },
                new MenuItem { HotKey = ConsoleKey.I, Text = "Упорядочивание списка заявок по номеру рейса." },
                new MenuItem { HotKey = ConsoleKey.O, Text = "Упорядочивание списка заявок по желаемой дате вылета." },
                new MenuItem { HotKey = ConsoleKey.A, Text = "Сериализация коллекции в формате XML." },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Десериализация коллекции из формата XML." },
                new MenuItem { HotKey = ConsoleKey.Escape, Text = "Выход" },
            };

                // Создание экземпляра класса приложения
                App app = new App();
                // главный цикл приложения
                while (true)
                {
                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.BackgroundColor = ConsoleColor.DarkCyan;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowMenu(20, 5, "Меню приложения : ", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key)
                    {
                        // Бинарная сериализация коллекции заявок
                        case ConsoleKey.Q:
                            app.InitializeSerialize();
                            break;

                        // Бинарная десериализация заявок
                        case ConsoleKey.W:
                            app.CollectionDeserialize();
                            break;

                        // Вывод всех заявок из коллекции в консоль
                        case ConsoleKey.E:
                            app.ShowCollection();
                            break;

                        // Выборка заявок по заданному номеру рейса и дате вылета
                        case ConsoleKey.R:
                            app.EnumerateByFlightNum();
                            break;

                        // Добавление заявки в список, бинарная сериализация модифицированной коллекции
                        case ConsoleKey.T:
                             app.AddRequestAirTicket();
                            break;
  
                        // Удаление заявок из списка по номеру заявки
                        case ConsoleKey.Y:
                             app.RemoveRequestAirTicket();
                            break;

                        // Удаление всех заявок из списка, бинарная сериализация модифицированной коллекции
                        case ConsoleKey.U:
                            app.RemoveAllCollectionRequest();
                            break;

                        // Упорядочивание списка заявок по номеру рейса
                        case ConsoleKey.I:
                            app.SortCollectionByFlightNumber();
                            break;
      
                        // Упорядочивание списка заявок по желаемой дате вылета
                        case ConsoleKey.O:
                            app.SortCollectionByDateFlight();
                            break;

                        // Сериализация коллекции в формате XML
                        case ConsoleKey.A:
                            app.CollectionXMLSerialize();
                            break;

                        // Десериализация коллекции из формата XML
                        case ConsoleKey.S:
                            app.CollectionXMLDeserialize();
                            break;

                        // Выход клавиша Esc
                        case ConsoleKey.Escape:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.White);
                            Console.CursorVisible = true;
                            return;
                        default:
                            continue;
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.White);
                    Console.ReadKey(true);
                } // while

            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine($"\n{ex.Message}");
                //throw;
            }
            finally
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nКод финализации");
                Console.ForegroundColor = ConsoleColor.Gray;
            }// try- catch- finally
            Console.ForegroundColor = ConsoleColor.White;
        }// Main
    }// class Program
}
