﻿CREATE TABLE [dbo].[Editions]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [IndexPublication] INT NOT NULL, 
    [TypePublication] NVARCHAR(60) NOT NULL, 
    [NamePublication] NVARCHAR(80) NOT NULL, 
    [Price] FLOAT NOT NULL, 
    [DateSubscription] DATE NOT NULL, 
    [DurationSubscription] INT NOT NULL
)
