﻿CREATE TABLE [dbo].[Издания] (
    [Id]          INT           IDENTITY (1, 1) NOT NULL,
    [index]       INT      NOT NULL,
    [Viev]        NVARCHAR (50) NOT NULL,
    [Name]        NVARCHAR (70) NOT NULL,
    [Price]       FLOAT (53)    NOT NULL,
    [Date]        DATE          NOT NULL,
    [SubDuration] SMALLINT      NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [CK_Издания_index] CHECK ([index]>=(10000) AND [index]<=(99999)),
    CONSTRAINT [CK_Издания_SubDuration] CHECK ([SubDuration]>=(1) AND [SubDuration]<=(12)), 
    CONSTRAINT [CK_Издания_Price] CHECK (Price > 0) 
);

