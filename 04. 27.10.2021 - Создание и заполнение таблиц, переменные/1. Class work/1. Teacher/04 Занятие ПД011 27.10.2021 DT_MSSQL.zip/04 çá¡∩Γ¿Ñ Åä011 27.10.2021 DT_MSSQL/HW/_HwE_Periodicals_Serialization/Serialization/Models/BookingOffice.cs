﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Serialization.Models
{
    // Коллекция заказов на авиабилеты, обработки коллекции по заданию
    [Serializable]
    public class BookingOffice
    {
        // коллекция заявок на билеты
        private List<Ticket> _tickets;

        // название фирмы по заказу авиабилетов
        private string _name;
        public string Name {
            get => _name;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentNullException("BookingOffice. Не указано название фирмы заказов авиабилетов");
                _name = value;
            }
        } // Name


        // количество заявок на билеты
        public int Count => _tickets.Count;

        // конструкторы для коллекции заявок на билеты
        public BookingOffice():this(new List<Ticket>(), "Закажем все") { }

        public BookingOffice(List<Ticket> tickets, string name) {
            _tickets = tickets;
            _name = name;
        }

        // Заполнение коллекции заявок на авиабилеты
        public void Initialize(int n = 12) {
            _tickets.Clear();

            // генерация коллекции заявок на авибилеты с уникальными номерами заказов
            for (int i = 0; i < n; i++) {
                Ticket ticket = Ticket.Generate();
                if (_tickets.FindIndex(t => t.Number == ticket.Number) >= 0) {
                    --i;
                    continue;
                }  // if

                _tickets.Add(ticket);
            } // for i
        } // Initialize

        // Индексатор
        public Ticket this[int index] {
            get => _tickets[index];
            set => _tickets[index] = value; 
        } // indexer


        // Формирование строкового представления данных коллекции заказов
        // на билеты в табличном формате
        public string ToTable(string caption, int indent = 12) => ToTable(caption, indent, _tickets);

        // Формирование строкового представления коллекции заказов на авиабилеты в табличном формате
        public string ToTable(string caption, int indent, IEnumerable<Ticket> tickets) {
            // вывод заголовка таблицы данных
            string space = " ".PadRight(indent);
            StringBuilder sb = new StringBuilder($"\n\n\n\n{space}{caption}\n{Ticket.Header(indent)}");

            // вывод всех элементов коллекции
            int row = 1;
            foreach (var ticket in tickets) {
                sb.Append($"{space}{ticket.ToTableRow(row++)}\n");
            } // foreach

            // вывод подвала таблицы
            sb.Append($"{Ticket.Footer(indent)}\n");
            return sb.ToString();
        } // ToTable

        // Бинарная сериализация коллекции заявок
        public void Serialize(string fileName) {
            BinaryFormatter bf = new BinaryFormatter();

            // собственно сериализация
            using (FileStream fs = new FileStream(fileName, FileMode.Create)) {
                bf.Serialize(fs, this);
            } // using
        } // Serialize


        // Бинарная десериализация заявок
        public static BookingOffice Deserialize(string fileName) {
            BinaryFormatter bf = new BinaryFormatter();
            BookingOffice obj;

            // собственно десериализация
            using (FileStream fs = new FileStream(fileName, FileMode.Open)) {
                obj = bf.Deserialize(fs) as BookingOffice;
            } // using

            return obj;
        } // Deserialize


        // Выборка в еще один список заявок по заданному номеру рейса и желаемой
        // дате вылета при помощи именованного итератора
        public IEnumerable GetByFlightNumberAndDepartureDate(string flightNumber, DateTime departureDate) {
            foreach (var ticket in _tickets) {
                if (ticket.Flight == flightNumber && ticket.DepartureDate == departureDate)
                    yield return ticket;
            } // foreach
        } // IteratorFlightNumberAndDepartureDate

        // Добавление заявки в список
        public void Add(Ticket ticket) => _tickets.Add(ticket);

        // Удаление заявок из списка по номеру заявки
        public int RemoveByNumber(int number) => 
            _tickets.RemoveAll(t => t.Number == number);

        // Удаление всех заявок из списка, возвращаем количество
        // удаленных элементов
        public int RemoveAll() {
            int count = _tickets.Count;
            _tickets.Clear();
            return count;
        } // RemoveAll

        // Упорядочивание списка заявок по номеру рейса
        public void OrderByFlight() => 
            _tickets.Sort((t1, t2) => 
                t1.Flight.CompareTo(t2.Flight));

        // Упорядочивание списка заявок по желаемой дате рейса
        public void OrderByDepartureDate() => 
            _tickets.Sort((t1, t2) => 
                t1.DepartureDate.CompareTo(t2.DepartureDate));

        // Сериализация коллекции в формате XML
        public void SerializeXml(string fileName) {
            // создать модель для сериализации
            SerializeModel serializeModel = new SerializeModel {
                Name = this._name,
                Tickets = _tickets
            };

            // форматтер для сериализации
            XmlSerializer formatter = new XmlSerializer(typeof(SerializeModel));

            // запись коллекции в поток данных
            using (FileStream fs = new FileStream(fileName, FileMode.Create)) {
                formatter.Serialize(fs, serializeModel);
            } // using
        } // SerializeXml


        // Десериализация коллекции из формата XML
        public static BookingOffice DeserializeXml(string fileName) {
            XmlSerializer bf = new XmlSerializer(typeof(SerializeModel));
            SerializeModel obj;

            // собственно десериализация
            using (FileStream fs = new FileStream(fileName, FileMode.Open)) {
                obj = bf.Deserialize(fs) as SerializeModel;
            } // using

            return new BookingOffice(obj.Tickets, obj.Name);
        } // DeserializeXml
    } // class BookingOffice
}
