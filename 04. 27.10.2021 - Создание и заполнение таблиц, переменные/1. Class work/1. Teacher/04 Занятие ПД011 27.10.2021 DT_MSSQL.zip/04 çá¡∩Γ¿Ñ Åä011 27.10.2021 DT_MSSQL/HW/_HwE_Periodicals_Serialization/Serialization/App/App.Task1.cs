﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

using Serialization.Helpers;
using Serialization.Models;

namespace Serialization.App
{
    /*
     * Методы для решения задачи 1 
     */
    internal partial class Application
    {
        // Заполнение коллекции заявок на авиабилеты начальными данными
        public void InitializeAndShow() {
            Utils.ShowNavBarTask("  Заполнение коллекции заявок на авиабилеты начальными данными");

            _bookingOffice.Initialize();
            _bookingOffice.Serialize(@"..\..\" + _bookingOfficeFileName + ".dat");
            Console.WriteLine(_bookingOffice.ToTable("\n\n\n\n\t    Данные сформированы. ", 12));
        } // InitializeAndShow


        // Вывод в консоль коллекции заявок на авиабилеты        
        public void Show() {
            Utils.ShowNavBarTask("   Вывод в консоль коллекции заявок на авиабилеты");

            Console.WriteLine(_bookingOffice.ToTable(
                "\n\n\n\n\t    Коллекция заявок на авиабилеты. ", 12));
        } // Show


        // При помощи именованного итератора вывести в список и консоль
        // заявки по номеру рейса и желаемой дате вылета
        public void EnumerateByFlightNumberAndDepartureDate() {
            Utils.ShowNavBarTask("  Выборка записей с заданным номером рейса и желаемой датой вылета " +
                                 "именованным итератором");

            // сформируем номер рейса для выборки из коллекции 
            // !!! тут использован индексатр !!!
            int index = Utils.GetRandom(0, _bookingOffice.Count - 1);
            string flight = _bookingOffice[index].Flight;
            DateTime departureDate = _bookingOffice[index].DepartureDate;

            // список заявок на авиабилеты с заданным номером рейса и желаемой дате вылета
            List<Ticket> list = new List<Ticket>();
            foreach (Ticket ticket in _bookingOffice.GetByFlightNumberAndDepartureDate(flight, departureDate))
                list.Add(ticket);

            // вывести список отобранных заявок на авиабилеты
            Console.WriteLine(_bookingOffice.ToTable(
                $"\tЗаявки на авиабилеты, рейс {flight} на дату {departureDate:dd/MM/yyyy}:",
                12, list));
        } // EnumerateBySurname


        // Добавление заявки на авиабилет в коллекцию
        // бинарная сериализация модифицированной коллекции
        public void AddTicket() {
            Utils.ShowNavBarTask("  Добавление заявки на авиабилет в коллекцию");

            // добавляемая заявка
            Ticket ticket = Ticket.Generate();

            Console.WriteLine(_bookingOffice.ToTable(
                $"\t   Заявки на авиабилеты до добавления заявки с номером {ticket.Number}"));
            Console.ReadKey(true);

            Console.Clear();
            Utils.ShowNavBarTask("  Добавление заявки на авиабилет в коллекцию");

            _bookingOffice.Add(ticket);
            _bookingOffice.Serialize(@"..\..\" + _bookingOfficeFileName + ".dat");

            Console.WriteLine(_bookingOffice.ToTable(
                $"\n\t   Заявки на авиабилеты после добавления заявки с номером {ticket.Number}, " +
                $"выполнена сериализация"));
        } // AddTicket


        // Удаление заявки на авиабилет по номеру заявки
        // бинарная сериализация модифицированной коллекции
        public void RemoveTicketByFlightNumber() {
            Utils.ShowNavBarTask("  Удаление заявки на авиабилет по номеру заявки");

            // получить номер заявки для удаления
            // !!! тут использован индексатр !!!
            int number = _bookingOffice[Utils.GetRandom(0, _bookingOffice.Count - 1)].Number;
            Console.WriteLine(_bookingOffice.ToTable(
                $"\t   Заявки на авиабилеты до удаления заявки с номером {number}"));

            _bookingOffice.RemoveByNumber(number);
            _bookingOffice.Serialize(@"..\..\" + _bookingOfficeFileName + ".dat");
            Console.ReadKey(true);

            Console.Clear();
            Utils.ShowNavBarTask("  Удаление заявки на авиабилет по номеру заявки");
            Console.WriteLine(_bookingOffice.ToTable(
                $"\n\t    Удалена заявка на авиабилет с номером {number}, выполнена сериализация"));
        } // RemoveTicketByFlightNumber


        // Удаление всех заявок на авиабилеты из коллекции
        // бинарная сериализация модифицированной коллекции
        public void RemoveAllTickets() {
            Utils.ShowNavBarTask("  Удаление всех заявок на авиабилеты из коллекции");

            Console.WriteLine(_bookingOffice.ToTable($"\n\n\n\n\t   Заявки на авиабилеты до удаления"));

            _bookingOffice.RemoveAll();
            _bookingOffice.Serialize(_bookingOfficeFileName);

            Console.WriteLine(_bookingOffice.ToTable(
                "\t    Все заявки на авиабилеты удалены, сериализация выполнена"));
        } // RemoveAllTickets


        // Сортировка коллекции заявок на авиабилеты по номеру рейса,
        // бинарная сериализация модифицированной коллекции
        public void OrderByFlightNumber() {
            Utils.ShowNavBarTask("  Сортировка коллекции заявок на авиабилеты по номеру рейса");

            _bookingOffice.OrderByFlight();
            _bookingOffice.Serialize(@"..\..\" + _bookingOfficeFileName + ".dat");

            Console.WriteLine(_bookingOffice.ToTable(
                "\n\n\n\n\t    Заявки на авиабилеты, упорядоченные по номеру рейса, " +
                "выполнена сериализация"));
        } // OrderByFlightNumber


        // Сортировка коллекции заявок на авиабилеты по желаемой дате вылета, бинарная
        // сериализация модифицированной коллекции
        public void OrderByDepartureDate() {
            Utils.ShowNavBarTask("  Вывод записей, упорядоченных по желаемой дате вылета");

            _bookingOffice.OrderByDepartureDate();
            _bookingOffice.Serialize(@"..\..\" + _bookingOfficeFileName + ".dat");

            Console.WriteLine(_bookingOffice.ToTable(
                "\n\n\n\n\t    Заявки на авиабилеты, упорядоченные по желаемой дате вылета, " +
                "выполнена сериализация"));
        } // OrderByDepartureDate


        // Сериализация коллекции заявок на авиабилеты в формате XML
        public void SerializatonByXml() {
            Utils.ShowNavBarTask("  Сериализация коллекции заявок на авиабилеты в формате XML");

            _bookingOffice.SerializeXml(@"..\..\" + _bookingOfficeFileName + ".xml");

            Console.WriteLine(
                _bookingOffice.ToTable($"\n\n\n\n\t    Данные, сериализованы в файл " +
                                       $"{_bookingOfficeFileName + ".xml"} в формате XML"));
        } // SerializatonByXml


        // Десериализация коллекции заявок на авиабилеты в формате XML
        public void DeserializatonByXml() {
            Utils.ShowNavBarTask("  Десериализация коллекции заявок на авиабилеты в формате XML");

            _bookingOffice.RemoveAll();
            _bookingOffice = BookingOffice.DeserializeXml(@"..\..\" + _bookingOfficeFileName + ".xml");

            Console.WriteLine(
                _bookingOffice.ToTable($"\n\n\n\n\t    Данные, десериализованы из файла " +
                                       $"{_bookingOfficeFileName + ".xml"} в формате XML"));
        } // SerializatonByXml

    } // class Application
}