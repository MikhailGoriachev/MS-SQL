﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Serialization.Models
{
    // модель для сериализации в формате XML
    [Serializable]
    public class SerializeModel
    {
        public string Name { get; set; }
        public List<Ticket> Tickets { get; set; }

        public SerializeModel() {}
    } // SerializeModel
}
