﻿/* 
 * Запросы по заданию, данные по изданиям: https://www.pressa-rf.ru/cat/
 */

-- Запрос  1. Запрос на выборку	
-- Выбирает из таблицы ИЗДАНИЯ информацию о доступных для подписки газетах, 
-- название которых начинается с буквы «П»
select
    *
from
    Publications
where
    PubType = N'газета' and Title like N'П%';


-- Запрос  2. Запрос на выборку	
-- Выбирает из таблицы ИЗДАНИЯ информацию об издании с заданным индексом.
select
    Id
    , PubIndex
    , PubType
    , Title
    , Price
    , StartDate
    , Duration
from
    Publications
where
    PubIndex like '88981'; -- '8%'


-- тот же запрос с использованием переменных T-SQL
declare @pubIndex nvarchar(5);
set @pubIndex = '8%';

select
    Id
    , PubIndex
    , PubType
    , Title
    , Price
    , StartDate
    , Duration
from
    Publications
where
    PubIndex like @pubIndex; -- '8%'
go   -- оператор запуска пакета, ограничение области видимости переменных


-- Запрос  3. Запрос на выборку	
-- Выбирает из таблицы ИЗДАНИЯ информацию обо всех изданиях, для которых 
-- цена 1 экземпляра есть значение из некоторого диапазона.
select
    *
from
    Publications
where
    Price between 200 and 1500;

-- тот же запрос с использованием переменных T-SQL
declare @lo int, @hi int;
set @lo = 200;
set @hi = 1500;

select
    *
from
    Publications
where
    Price between @lo and @hi;
go   -- оператор запуска пакета, ограничение области видимости переменных


-- Запрос  4. Запрос на выборку	
-- Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, имеющих вид издания
-- «газета», наименование которых начинается со слова «Земля».
select
    Id
    , PubIndex
    , PubType
    , Title
    , Price
    , StartDate
    , Duration
from
    Publications
where
    PubType like N'газета' and 
    -- довольно слабое решение... предполагаем, что других вариантов не будет...
    -- (Title like N'Земля %' or Title like N'Земля.%');
    Title like N'[Зз]емля[ .,!?:]%';  -- так лучше, но это новый материал :) 


-- Запрос  5. Запрос на выборку	
-- Выбирает из таблицы ИЗДАНИЯ информацию обо всех изданиях, для которых 
-- Длительность подписки равна 3 месяцам
select
    *
from
    Publications
where
    Duration = 3;


-- Запрос  6. Запрос на выборку	
-- Выбирает из таблиц ИЗДАНИЯ информацию об изданиях с заданным значением
-- в поле Вид издания. 
select
    PubIndex
    , PubType
    , Title
    , Price
    , StartDate
    , Duration
from
    Publications
where
    PubType = N'газета'
order by
    PubIndex;


-- Запрос  7. Запрос на выборку	
-- Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, для которых 
-- Длительность подписки есть значение из диапазона от 1 до 6 месяцев. 		
select
    *
from
    Publications
where
    Duration between 1 and 6
order by
    Duration;


-- Запрос  8. Итоговый запрос – агрегатные функции	
-- Выполняет группировку по полю Вид издания. Для каждого вида вычисляет 
-- среднюю цену 1 экземпляра
select
    PubType                     -- поле, по которому выполняется группировка записей
    , COUNT(*) as Amount        -- количество записей в группе
    , AVG(Price) as AvgPrice    -- средняя цена одного экземпляра в группе
from
    Publications
group by
    PubType;


-- Запрос  9. Итоговый запрос – агрегатные функции	
-- Выполняет группировку по полю Вид издания. Для каждого вида вычисляет 
-- максимальную и минимальную цену 1 экземпляра
select
    PubType                    -- поле, по которому выполняется группировка записей
    , COUNT(*)   as Amount     -- количество записей в группе
    , Min(Price) as MinPrice   -- минимальная цена одного экземпляра в группе
    -- , AVG(Price) as AvgPrice    -- средняя цена одного экземпляра в группе
    , Max(Price) as MaxPrice   -- максимальная цена одного экземпляра в группе
from
    Publications
group by
    PubType;


-- Запрос 10. Итоговый запрос – агрегатные функции	
-- Выполняет группировку по полю Длительность подписки. Для каждого срока вычисляет 
-- среднюю цену 1 экземпляра
select
    Duration                   -- поле, по которому выполняется группировка записей
    , COUNT(*)   as Amount     -- количество записей в группе
    , Avg(Price) as AvgPrice   -- средняяя цена одного экземпляра в группе
from
    Publications
group by
    Duration;