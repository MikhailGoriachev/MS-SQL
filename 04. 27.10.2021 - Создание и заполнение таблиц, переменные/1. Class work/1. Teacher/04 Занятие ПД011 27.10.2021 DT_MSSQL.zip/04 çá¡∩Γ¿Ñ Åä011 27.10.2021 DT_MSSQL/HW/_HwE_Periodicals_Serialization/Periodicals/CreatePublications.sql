﻿-- создание таблицы [Publications]
CREATE TABLE [dbo].[Publications]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [PubIndex] NVARCHAR(5) NOT NULL, -- Индекс издания по каталогу
    [PubType] NVARCHAR(15) NOT NULL, 
    [Title] NVARCHAR(120) NOT NULL, 
    [Price] INT NOT NULL, 
    [StartDate] DATE NOT NULL, 
    [Duration] INT NOT NULL, 
    CONSTRAINT [CK_Publications_Price] CHECK (Price > 0), 
    CONSTRAINT [CK_Publications_Duration] CHECK (Duration between 1 and 12)
)
