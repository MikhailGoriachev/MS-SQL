﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace HomeWork26._10._21.Models
{
    [Serializable]
    public class ListRequest
    {
        // список заявок
        private List<Request> _requests;
        public List<Request> Requests
        {
            get { return _requests; }
            set { _requests = value; }
        }


        // обязательный стандартный конструктор без параметров
        public ListRequest()
        {
            _requests = null;           
        } // 

        public ListRequest(List<Request> requests)
        {
            Requests = requests;
        } // 


        public ListRequest(int n)
        {
            Init(n);
        } // 
        // вывод на экран списка заявок
        public static void Show(string tittle, List<Request> requests) {
            Console.WriteLine(tittle);
            Console.WriteLine(Request.Header());
            Array.ForEach(requests.ToArray(), a => Console.WriteLine(a));
            Console.WriteLine(Request.Footer());
        }


        // инициализация
        public void Init(int n) {

            _requests = new List<Request>();

            for (int i = 0; i < n; i++)
            {
                _requests.Add(Request.Create());
            }
        
        }

        // сериализация
        public void Serialize(string fileName)
        {
            BinaryFormatter bf = new BinaryFormatter();

            // собственно сериализация
            using (FileStream fs = new FileStream(fileName, FileMode.Create))
            {
                bf.Serialize(fs, this);
            } // using
        }

        // десериализация - удобно выполнять статическим методом
        public static ListRequest Deserialize(string fileName)
        {
            BinaryFormatter bf = new BinaryFormatter();
            ListRequest obj;

            // собственно десериализация
            using (FileStream fs = new FileStream(fileName, FileMode.Open))
            {
                obj = bf.Deserialize(fs) as ListRequest;
            } // using

            return obj;
        } // Deserialize


        // сериализацияXML
        public void SerializeXML(string fileName)        
        {           
            XmlSerializer formatterXML = new XmlSerializer(typeof(ListRequest));
            // собственно сериализация
            using (FileStream fs = new FileStream(fileName, FileMode.Create))
            {
                formatterXML.Serialize(fs, this);
            } 
        }

        // десериализацияXML - удобно выполнять статическим методом
        public static ListRequest DeserializeXML(string fileName)
        {
            XmlSerializer formatterXML = new XmlSerializer(typeof(ListRequest));
            ListRequest obj;

            // собственно десериализация
            using (FileStream fs = new FileStream(fileName, FileMode.Open))
            {
                obj = formatterXML.Deserialize(fs) as ListRequest;
            } 

            return obj;
        } 


    }
}
