﻿using HomeWork26._10._21.Application;
using HomeWork26._10._21.Controllers;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace HomeWork26._10._21
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.Title = "Домашние задание на 06.10.21";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem {HotKey = ConsoleKey.Q, Text = "Вывод всех заявок из коллекции в консоль"},
                new MenuItem {HotKey = ConsoleKey.W, Text = "Бинарная сериализация коллекции заявок"},
                new MenuItem {HotKey = ConsoleKey.E, Text = "Бинарная десериализация заявок"},
                new MenuItem {HotKey = ConsoleKey.R, Text = "-"},
                new MenuItem {HotKey = ConsoleKey.A, Text = "Добавление заявки в список, бинарная сериализация модифицированной коллекции"},
                new MenuItem {HotKey = ConsoleKey.S, Text = "Удаление заявок из списка по номеру заявки, бинарная сериализация модифицированной коллекции"},
                new MenuItem {HotKey = ConsoleKey.D, Text = "Удаление всех заявок из списка, бинарная сериализация модифицированной коллекции"},
                new MenuItem {HotKey = ConsoleKey.F, Text = "Упорядочивание списка заявок по номеру рейса, бинарная сериализация модифицированной коллекции"},
                new MenuItem {HotKey = ConsoleKey.X, Text = "Упорядочивание списка заявок по желаемой дате рейса, бинарная сериализация модифицированной коллекции"},
                new MenuItem {HotKey = ConsoleKey.C, Text = "Сериализация коллекции в формате XML"},
                new MenuItem {HotKey = ConsoleKey.V, Text = "Десериализация коллекции из формата XML"},
               
                //----------------------------------------------------------------------------------------------
                new MenuItem {HotKey = ConsoleKey.Z, Text = "Выход"},
            };

            // Создание экземпляра класса приложения
            App app = new App();


            // главный цикл приложения
            while (true)
            {
                try
                {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("Делегаты, лямба выражения");
                    Utils.ShowMenu(12, 5, "Меню ", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg =
                        "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch (key)
                    {
                        // вывод всех заявок из коллекции в консоль
                        case ConsoleKey.Q:
                            app.DemoPart1();
                            break;

                        // Бинарная сериализация коллекции заявок
                        case ConsoleKey.W:
                            app.DemoPart2();
                            break;

                        // Бинарная десериализация заявок
                        case ConsoleKey.E:
                            app.DemoPart3();
                            break;

                        // -***
                        case ConsoleKey.R:
                            //app.ShuffleTask2();
                            break;

                        // добавление заявки в список, бинарная сериализация модифицированной коллекции;
                        case ConsoleKey.A:
                            app.DemoPart5();
                            break;

                        // удаление заявок из списка по номеру заявки, бинарная сериализация модифицированной коллекции;
                        case ConsoleKey.S:
                            app.DemoPart6();
                            break;

                        // удаление всех заявок из списка, бинарная сериализация модифицированной коллекции;
                        case ConsoleKey.D:
                            app.DemoPart7();
                            break;

                        // упорядочивание списка заявок по номеру рейса, бинарная сериализация модифицированной коллекции
                        case ConsoleKey.F:
                            app.DemoPart8();
                            break;

                        // упорядочивание списка заявок по желаемой дате рейса , бинарная сериализация модифицированной коллекции
                        case ConsoleKey.X:
                            app.DemoPart9();
                            break;

                        // Сериализация коллекции в формате XML
                        case ConsoleKey.C:
                            app.DemoPart10();
                            break;

                        // Десериализация коллекции из формата XML
                        case ConsoleKey.V:
                            app.DemoPart11();
                            break;




                        // Выход из приложения назначен на клавишу F10 или клавишу M или клавишу Escape
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor(); // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                } // try

                // обработка исключений - просто вывести сообщение
                catch (Exception ex)
                {
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                } // try-catch
            } // while


        }
    }
}
