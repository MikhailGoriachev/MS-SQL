﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork26._10._21.Models
{
    [Serializable]
    public class Request
    {
        // номер заявки
        private int _id;
        public int Id
        {
            get { return _id; }
            set { if (value <= 0)
                    throw new Exception("Request: ошибка номера заявки");
                _id = value; }
        }

        // пункт назначения
        private string _destination;
        public string Destination
        {
            get { return _destination; }
            set { if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Request: ошибка пункта назначения");
                _destination = value; }
        }

        // номер рейса
        private string _flightNumber;
        public string FlightNumber
        {
            get { return _flightNumber; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Request: ошибка номера рейса");
                _flightNumber = value;
            }
        }


        // фамилию и инициалы пассажира
        private string _fullName;
        public string FullName
        {
            get { return _fullName; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Request: ошибка фамилии и инициалов пассажира");
                _fullName = value;
            }
        }


        //желаемую дату вылета
        private DateTime _date;

        public DateTime Date
        {
            get { return _date; }
            set { //if(_date.Year < DateTime.Now.Year)
                    //throw new Exception("Request: ошибка желаемой даты вылета");
             _date = value; }
        }

        public Request() { } 

        public Request(int id, string dest, string flightNumber, string name, DateTime date)
        {
            Id = id;
            Destination = dest;
            FlightNumber = flightNumber;
            FullName = name;
            Date = date;


        } 



        public override string ToString()
        {
            return $"│ {_id,4} │ {_destination,-22} │ {_fullName,-14} │ {_flightNumber,25} │ {Date.ToShortDateString(),14 } │";
        }
        //

        public static string Header()
        {

            return $"┌──────┬────────────────────────┬────────────────┬───────────────────────────┬────────────────┐\n" +
                   $"│  ID  │ Пункт назначения       │ Номер рейса    │ ФИО пассажира             │ Дату вылета    │\n" +
                   $"├──────┼────────────────────────┼────────────────┼───────────────────────────┼────────────────┤";   //60

        }

        public static string Footer() =>
            $"└──────┴────────────────────────┴────────────────┴───────────────────────────┴────────────────┘";

        private static string[] destinations = {
            "Баку",
            "Буэнос-Айрес",
            "Минск",
            "Сараево",
            "Лондон",
            "Ханой",
            "Аккра",
            "Афины",
            "Багдад",
            "Рига",
            "Люксембург",
            "Осло",
            "Москва",
            "Белград",
        };

        // коллекция имен
        private static string[] names = {
           
            "Степанов А. Д.",
            "Ильина В. А.",
            "Николаева Е. В.",
            "Карасева К. М.",
            "Гусев А. В.",
            "Моисеева В. А.",
            "Литвинова К. И.",
            "Сухарев Н. М.",
            "Медведев Т. А.",
            "Копылов В. А.",
            "Иванов М. М.",
            "Злобин Е. М.",
            "Федорова Е. Т.",
            "Ильина М. Б.",
            "Сергеева В. С.",
            "Крюкова М. Т.",
            "Сергеев Д. Д.",
            "Романов Т. Е.",
            "Поляков М. П.",
            "Прокофьева А. С.",

        };

        // коллеццкия знаков зодиака
        private static List<string> flights = new List<string> {
            "SDW1458",
            "WDW753",
            "FDW386",
            "FDW3484",
            "HDW194",
            "DKW3697",
            "LDW1856",
            "BDW2034",
            "EDW7415",
            "KDT3874",
            "DQW9647",
            "EUW1145"
        };

        [NonSerialized] public static int id =1 ;

        // фабрика для создание User`ов
        public static Request Create()
        {
            return new Request
                (
                id++, // случайнае число
                destinations[Utils.GetRandom(0, destinations.Length)], // случайнай пункт назначения
                names[Utils.GetRandom(0, names.Length)], // случайное фио
                flights[Utils.GetRandom(0, flights.Count)], // случайный номер рейса
                new DateTime(
                    DateTime.Now.Year,  // год
                    Utils.GetRandom(1, 12),        // месяц
                    Utils.GetRandom(1, 25)          // день
                    )
                );
        }
    }
}
