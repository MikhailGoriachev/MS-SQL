﻿using HomeWork26._10._21.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork26._10._21.Application
{
    internal partial class App
    {
        // массив уровнений
        private Task1Control _task1;

      
        // ансамбль конструкторов
        public App() : this(new Task1Control())
        {
            

        } // App

        public App(Task1Control task1)
        {
            _task1 = task1;
            
        } // App

    }
}
