﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork26._10._21.Application
{
    internal partial class App
    {

        public void DemoPart1()
        {
           _task1.ShowCollection();
        }

        public void DemoPart2()
        {
            _task1.SerializeList();
        }

        public void DemoPart3()
        {
            _task1.DeSerializeList();
        }


        public void DemoPart5()
        {
            _task1.AddRequest();
        }

        public void DemoPart6()
        {
            _task1.DeleteRequest();
        }

        public void DemoPart7()
        {
            _task1.DeleteAllRequest();
        }
        public void DemoPart8()
        {
            _task1.SortByFlightNumber();
        }

        public void DemoPart9()
        {
            _task1.SortByDate();
        }

        public void DemoPart10()
        {
            _task1.SerializeListXML();
        }

        public void DemoPart11()
        {
            _task1.DeSerializeListXML();
        }

        //SortByFlightNumber()


        //DeleteAllRequest()
    }
}
