﻿using HomeWork26._10._21.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork26._10._21.Controllers
{
    class Task1Control
    {
        private ListRequest list;

        private string filename = @"..\..\SerializeListAll.dat";
        private string filenameXML = @"..\..\SerializeListAllXML.xml";

        public Task1Control() {

            list = new ListRequest();
            list.Init(10);

        }

        // Бинарная сериализация коллекции заявок
        public void SerializeList() {
            list.Serialize(filename);
            Console.WriteLine("Бинарная сериализация коллекции заявок завершена");
            Console.WriteLine($"Имя файла {filename}"); 
        }


        // Бинарная десериализация заявок
        public void DeSerializeList()
        {
            list = (ListRequest)ListRequest.Deserialize(filename);
            ListRequest.Show("Коллекция после бинарная десериализации заявок", list.Requests);
        }


        // вывод всех заявок из коллекции в консоль
        public void ShowCollection() {

            ListRequest.Show("Вывод всех заявок из коллекции в консоль", list.Requests);

        }

        //	добавление заявки в список, бинарная сериализация модифицированной коллекции
        public void AddRequest() {

            ListRequest.Show("Коллекция заявок до изменения", list.Requests);
            Request request = Request.Create();
            Console.WriteLine("Новая заявка:");
            Console.WriteLine(Request.Header());
            Console.WriteLine(request);
            Console.WriteLine(Request.Footer());

            list.Requests.Add(request);
            SerializeList();
            DeSerializeList();
        }

        // удаление заявок из списка по номеру заявки, бинарная сериализация модифицированной коллекции;
        public void DeleteRequest()
        {

            ListRequest.Show("Коллекция заявок до изменения", list.Requests);            
            Console.WriteLine("Заявка, которая будет удалена:");
            int currentId = list.Requests[Utils.GetRandom(0, list.Requests.Count)].Id;
            Console.WriteLine(currentId);

            list.Requests.Remove(list.Requests.Find(a=>a.Id== currentId));
            SerializeList();
            DeSerializeList();
        }

        // удаление всех заявок из списка, бинарная сериализация модифицированной коллекции;

        public void DeleteAllRequest()
        {

            ListRequest.Show("Коллекция заявок до изменения", list.Requests);
            list.Requests.Clear();
            ListRequest.Show("Из коллекции удалены все данные", list.Requests);
            
            SerializeList();
            
        }



        // упорядочивание списка заявок по номеру рейса, бинарная сериализация модифицированной коллекции
        public void SortByFlightNumber()
        {

            ListRequest.Show("Коллекция заявок до изменения", list.Requests);
            list.Requests.Sort((a, b) => a.FlightNumber.CompareTo(b.FlightNumber));
            ListRequest.Show("Коллекция после сортировки", list.Requests);
            SerializeList();
            
        }

        // упорядочивание списка заявок по желаемой дате рейса бинарная сериализация модифицированной коллекции
        public void SortByDate()
        {

            ListRequest.Show("Коллекция заявок до изменения", list.Requests);
            list.Requests.Sort((a, b) => a.Date.CompareTo(b.Date));
            ListRequest.Show("Коллекция после сортировки", list.Requests);
            SerializeList();

        }

        // Сериализация коллекции в формате XML
        public void SerializeListXML()
        {
            list.SerializeXML(filenameXML);
            Console.WriteLine("Сериализация коллекции в формате XML");
            Console.WriteLine($"Имя файла {filenameXML}");
        }


        // Десериализация коллекции из формата XML
        public void DeSerializeListXML()
        {
            list = ListRequest.DeserializeXML(filenameXML);
            ListRequest.Show("Коллекция после десериализации заявок из формата XML", list.Requests);
        }
    }
}
