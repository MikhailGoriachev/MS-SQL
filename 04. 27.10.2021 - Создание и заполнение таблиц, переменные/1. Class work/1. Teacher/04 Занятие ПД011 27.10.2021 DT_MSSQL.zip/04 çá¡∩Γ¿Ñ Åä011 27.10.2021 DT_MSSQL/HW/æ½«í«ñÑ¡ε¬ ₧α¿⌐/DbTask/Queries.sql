﻿-- 1
-- Выбирает из таблицы ИЗДАНИЯ информацию о доступных для подписки газетах, 
-- название которых начинается с буквы «П»
select * from Editions
where Type = N'Газета' and 
	  Title like N'П%'


-- 2
-- Выбирает из таблицы ИЗДАНИЯ информацию об издании с заданным индексом. 
select * from Editions
where [Index] = 6 


-- 3
-- Выбирает из таблицы ИЗДАНИЯ информацию обо всех изданиях, 
-- для которых цена 1 экземпляра есть значение из некоторого диапазона.  
select * from Editions
where Price between 60 and 130 


-- 4
-- Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, имеющих вид 
-- издания «газета», наименование которых начинается со слова «Земля».  
select * from Editions
where Type = N'Газета' and
	  Title like N'Земля%'


-- 5
-- Выбирает из таблицы ИЗДАНИЯ информацию обо всех изданиях, 
-- для которых Длительность подписки равна 3 месяцам 
select * from Editions
where SubscribeDuration = 3


-- 6
-- Выбирает из таблиц ИЗДАНИЯ информацию об изданиях 
-- с заданным значением в поле Вид издания. 
select * from Editions
where Type = N'Журнал'


-- 7
-- Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, для которых 
-- Длительность подписки есть значение из диапазона от 1 до 6 месяцев.  
select * from Editions
where SubscribeDuration between 1 and 6


-- 8
-- Выполняет группировку по полю Вид издания. 
-- Для каждого вида вычисляет среднюю цену 1 экземпляра  
select Type, AVG(Price) as AveragePrice 
from Editions
group by Type


-- 9
-- Выполняет группировку по полю Вид издания. Для каждого вида вычисляет 
-- максимальную и минимальную цену 1 экземпляра
select 
	Type, 
	Min(Price) as MinPrice, 
	Max(Price) as MaxPrice 
from Editions
group by Type


-- 10
-- Выполняет группировку по полю Длительность подписки. 
-- Для каждого срока вычисляет среднюю цену 1 экземпляра
select 
	SubscribeDuration,
	Avg(Price) as AveragePrice
from Editions
group by SubscribeDuration