﻿#nullable enable
using System;


namespace SharpTask.Utilities
{


	public static class Palette
	{
		public static ConsoleColor DefaultForeground => ConsoleColor.Black;
		public static ConsoleColor DefaultBackground => ConsoleColor.DarkGray;
		public static ConsoleColor DefaultBackgroundDedicated => ConsoleColor.Gray;


		public static Color Default => new(DefaultForeground, DefaultBackground);
		public static Color Info    => new(ConsoleColor.Cyan, DefaultBackground);
		public static Color Error   => new(ConsoleColor.DarkRed, ConsoleColor.Black);


		public static Color Accent          => new(ConsoleColor.Green, DefaultBackground);
		public static Color AccentDedicated => new(ConsoleColor.Green, DefaultBackgroundDedicated);


		public static Color Secondary          => new(ConsoleColor.Magenta, DefaultBackground);
		public static Color SecondaryDedicated => new(ConsoleColor.Magenta, DefaultBackgroundDedicated);


		public static Color Tertiary          => new(ConsoleColor.Yellow, DefaultBackground);
		public static Color TertiaryDedicated => new(ConsoleColor.DarkYellow, DefaultBackgroundDedicated);
	}


}
