﻿using System;
using SharpTask.Utilities;
using SharpTask.Utilities.Menu;


namespace SharpTask
{
	public sealed class App : MenuWrapper
	{
		private static readonly string BinaryDataFile = "Tickets.dat";
		private static readonly string XmlDataFile = "Tickets.xml";
		private readonly Controller _controller = new(
			new(15, 26) { RandomFunc = General.Rand.Next },
			BinaryDataFile, XmlDataFile);


		public App() =>
			Menu = new("Главное меню приложения", new[]
			{
				new MenuItem("Заполнить коллекцию билетов", Fill),
				new MenuItem("Вывод коллекции билетов", Show),
				new MenuItem("Бинарная сериализация", BinarySerialize),
				new MenuItem("XML сериализация", XmlSerialize),
				new MenuItem("Бинарная десериализация", BinaryDeserialize),
				new MenuItem("XML десериализация", XmlDeserialize),
				new MenuItem("Выборка в еще один список заявок по заданному номеру рейса и дате вылета", Where),
				new MenuItem("Добавление заявки, бинарная сериализация", Add),
				new MenuItem("Удаление заявки по номеру, бинарная сериализация", Remove),
				new MenuItem("Удаление всех заявок из списка и из бинарного файла", Clear),
				new MenuItem("Упорядочивание списка по номеру рейса, бинарная сериализация", OrderByFlightNumber),
				new MenuItem("Упорядочивание списка по желаемой дате, бинарная сериализация", OrderByWishfulDate)
			});


		private void Fill()
		{
			_controller.Fill();

			_controller.Show();
		}


		private void Show() => _controller.Show();


		public void BinarySerialize()
		{
			_controller.BinarySave();

			Console.WriteLine($"Данные сохранены в файл {BinaryDataFile}");
		}  


		public void XmlSerialize()
		{
			_controller.XmlSave();

			Console.WriteLine($"Данные сохранены в файл {XmlDataFile}");
		}


		public void BinaryDeserialize()
		{
			_controller.BinaryLoad();

			Console.WriteLine("Загруженные данные:\n");

			_controller.Show();
		}


		public void XmlDeserialize()
		{
			_controller.XmlLoad();

			Console.WriteLine("Загруженные данные:\n");

			_controller.Show();
		}


		public void Where()
		{
			_controller.Show();

			Console.Write("Введите номер рейса: ");
			string flightNumber = Console.ReadLine();

			Console.Write("\n\nВведите дату вылета: ");
			DateTime wishfulDate = DateTime.Parse(Console.ReadLine());

			var selected = _controller.Where(t =>
				t.FlightNumber.Equals(flightNumber, StringComparison.CurrentCulture)
				&& wishfulDate.Equals(wishfulDate));

			_controller.Show(selected);
		}


		public void Add()
		{
			_controller.Show();

			var newTicket = new TicketFactory().Create();

			Console.WriteLine(
				$"\nБудет добавлена заявка с номером {newTicket.FlightNumber} и кодом {newTicket.Code}\n\n");
			_controller.Add(newTicket);

			_controller.Show();
		}


		public void Remove()
		{
			_controller.Show();

			Console.Write("Введите код: ");
			string code = Console.ReadLine();

			_controller.Remove(code);

			_controller.Show();
		}


		public void Clear()
		{
			_controller.Show();

			_controller.Clear();

			_controller.Show();
		}


		public void OrderByFlightNumber()
		{
			var tickets = _controller.OrderBy(t => t.FlightNumber);

			_controller.Replace(tickets);

			_controller.Show();
		}


		public void OrderByWishfulDate()
		{
			var tickets = _controller.OrderBy(t => t.WishfulDate);

			_controller.Replace(tickets);

			_controller.Show(tickets);
		}
	}
}