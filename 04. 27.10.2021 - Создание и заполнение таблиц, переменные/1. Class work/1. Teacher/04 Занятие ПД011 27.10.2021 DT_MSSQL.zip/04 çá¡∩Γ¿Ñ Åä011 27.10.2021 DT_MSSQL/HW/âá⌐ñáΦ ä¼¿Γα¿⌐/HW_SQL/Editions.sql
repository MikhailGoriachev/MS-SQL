﻿CREATE TABLE [dbo].[Editions]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Index] INT NOT NULL, 
    [View] NVARCHAR(35) NOT NULL, 
    [Name] NVARCHAR(75) NOT NULL, 
    [Price] INT NOT NULL, 
    [Date] DATE NOT NULL, 
    [Duration] INT NOT NULL, 
    CONSTRAINT [Price_Check] CHECK ([Price] > 0), 
    CONSTRAINT [Duration_Check] CHECK ([Duration] > 0)
)
