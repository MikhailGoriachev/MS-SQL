﻿using System;
using System.Collections.Generic;

namespace HW_CS.App{
    internal partial class App{

        // бинарная сериализация данных
        public void task1Solve(){
            _task.Show();
            _task.SerializeBin();
        } // task1Solve

        // бинарная десериализация данных
        public void task2Solve(){
            _task.DeSerealizeBin();
            _task.Show();
        } // task2Solve
        
        // вывод всех заявок из коллекции в консоль
        public void task3Solve() => _task.Show();

        // Добавление заявки в список, бинарная сериализация
        public void task5Solve(){
            _task.Show();
            _task.AddRequest();
            _task.Show();
            _task.SerializeBin();
        } // task5Solve

        // Удаление заявки из списка, бинарная сериализация
        public void task6Solve(){
            _task.Show();
            Console.WriteLine("\t\tНомер удаляемой заявки: 104");
            _task.RemoveRequests(104);
            _task.Show();
            _task.SerializeBin();
        } // task6Solve

        // Удаление всех заявок из списка, бинарная сериализация
        public void task7Solve(){
            Console.WriteLine("\n\tДо удаления:");
            _task.Show();
            _task.RemoveAllRequests();
            Console.WriteLine("\n\tПосле удаления:");
            _task.Show();
            _task.SerializeBin();
        } // task7Solve

        // Сортировка заявок по номеру рейса
        public void task8Solve(){
            Console.WriteLine("\n\tДо сортировки:");
            _task.Show();
            _task.SortByFlightNumber();
            Console.WriteLine("\n\tПосле сортировки:");
            _task.Show();
            _task.SerializeBin();
        } // task8Solve

        // Сортировка заявок по желаемой дате
        public void task9Solve(){
            Console.WriteLine("\n\tДо сортировки:");
            _task.Show();
            _task.SortByDateTime();
            Console.WriteLine("\n\tПосле сортировки:");
            _task.Show();
            _task.SerializeBin();
        } // task9Solve

        // Сериализация коллекции в формате XML
        public void task10Solve(){
            _task.Show();
            _task.SerializeXml();
        } // task10Solve

        // Десериализация коллекции из формата XML
        public void task11Solve(){
            _task.DeserializeXml();
            _task.Show();
        } // task11Solve

    } // App
}
