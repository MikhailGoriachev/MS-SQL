﻿using System;

using HW_CS.Controller;

namespace HW_CS.App{
    internal partial class App{

        private Task _task;

        public App() : this(new Task()) { }
        public App(Task task) {
            _task = task;
        } // App

    } // App
}
