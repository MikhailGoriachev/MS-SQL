﻿using System;

namespace HW_CS.Models{
    [Serializable]
    public class Request{

        private int _number;
        public int Number{
            get => _number;
            set => _number = value > 0 ? value :throw new Exception("Недопустимое значение для номера заявки!");
        } // Number

        private string _point;
        public string Point{
            get => _point;
            set => _point = !string.IsNullOrWhiteSpace(value) ?value:throw new Exception("Недопустимое значение для пункта назначения!");
        } // Point

        private string _flightNumber;
        public string FlightNumber{
            get => _flightNumber;
            set=>_flightNumber = !string.IsNullOrWhiteSpace(value) ? value : throw new Exception("Недопустимое значение для номера рейса!");
        } // FlightNumber

        private string _name;
        public string Name{
            get => _name;
            set=>_name = !string.IsNullOrWhiteSpace(value) ? value : throw new Exception("Недопустимое значение для фамилии и инициалов пассажира!");
        } // Name

        private DateTime _date;
        public DateTime Date{
            get => _date;
            set => _date = value;
        } // Date

        public Request() { }
        // public Request() : this(101, "Москва", "SU0001", "Иванов И. И.", new DateTime(2021, 10, 27)) { }
        public Request(int n, string p, string fn, string name, DateTime dt){
            Number = n;
            Point = p;
            FlightNumber = fn;
            Name = name;
            Date = dt;
        } // Request

        public override string ToString() => $"\t| {Number,5} | {Point, -16} | {FlightNumber, 11} | {Name, -18} | {Date.Day, 3} {Date.Month, 3} {Date.Year, 6} |\n";

    } // Request
}
