﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;

using HW_CS.Helpers;
using HW_CS.App;

namespace HW_CS{
    class Program{
        static void Main(string[] args){
            MenuItem[] menu = new[] {
                new MenuItem {HotKey = ConsoleKey.Q, Text = "Бинарная сериализация"},
                new MenuItem {HotKey = ConsoleKey.W, Text = "Бинарная десериализация"},
                new MenuItem {HotKey = ConsoleKey.E, Text = "Вывод всех заявок из коллекции в консоль"},
                new MenuItem {HotKey = ConsoleKey.R, Text = "Выборка в другую коллекцию по заданному номеру рейса и дате вылета"},
                new MenuItem {HotKey = ConsoleKey.T, Text = "Добавление заявки в список, бинарная сериализация"},
                new MenuItem {HotKey = ConsoleKey.Y, Text = "Удаление заявок из списка, бинарная сериализация"},
                new MenuItem {HotKey = ConsoleKey.U, Text = "Удаление всех заявок из списка, бинарная сериализация"},
                new MenuItem {HotKey = ConsoleKey.A, Text = "Упорядочивание списка по номеру рейса"},
                new MenuItem {HotKey = ConsoleKey.S, Text = "Упорядочивание списка по желаемой дате вылета"},
                new MenuItem {HotKey = ConsoleKey.D, Text = "Сериализация коллекции в формате XML"},
                new MenuItem {HotKey = ConsoleKey.F, Text = "Десериализация коллекции из формата XML"},
                //----------------------------------------------------------------------------------------------
                new MenuItem {HotKey = ConsoleKey.Z, Text = "Выход"},
            };

            // Создание экземпляра класса приложения
            App.App app = new App.App();

            // главный цикл приложения
            while (true)
            {
                try
                {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.Black);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowMenu(12, 5, "Меню приложения для работы с массивами объектов", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg = "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.Black);
                    Console.Clear();

                    switch (key)
                    {

                        // Бинарная сериализация
                        case ConsoleKey.Q:
                            app.task1Solve();
                            break;

                        // Бинарная десериализация
                        case ConsoleKey.W:
                            app.task2Solve();
                            break;

                        // Вывод всех заявок из коллекции в консоль
                        case ConsoleKey.E:
                            app.task3Solve();
                            break;

                        // Выборка в другую коллекцию по заданному номеру рейса и дате вылета
                        case ConsoleKey.R:
                            Utils.ShowUnderConstruction();
                            break;

                        // Добавление заявки в список, бинарная сериализация
                        case ConsoleKey.T:
                            app.task5Solve();
                            break;

                        // Удаление заявки из списка, бинарная сериализация
                        case ConsoleKey.Y:
                            app.task6Solve();
                            break;

                        // Удаление всех заявок из коллекции, бинарная сериализация
                        case ConsoleKey.U:
                            app.task7Solve();
                            break;

                        // Упорядочивание списка по номеру рейса
                        case ConsoleKey.A:
                            app.task8Solve();
                            break;

                        // Упорядочивание списка по желаемой дате вылета
                        case ConsoleKey.S:
                            app.task9Solve();
                            break;

                        // Сериализация коллекции в формате XML
                        case ConsoleKey.D:
                            app.task10Solve();
                            break;

                        // Десериализация коллекции из формата XML
                        case ConsoleKey.F:
                            app.task11Solve();
                            break;


                        // Выход из приложения назначен на клавишу F10 или клавишу M или клавишу Escape
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor(); // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                } // try

                // обработка исключений - просто вывести сообщение
                catch (Exception ex)
                {
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                } // try-catch
            } // while
        } // Main
    }
}
