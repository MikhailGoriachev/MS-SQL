﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Xml.Serialization;

using HW_CS.Models;
using HW_CS.Helpers;

namespace HW_CS.Controller{
    internal class Task{

        private string _fileNameBin;
        private string _fileNameXml;
        private List<Request> _list;

        public Task(string fileNameBin = "RequestsBin.dat", string fileNameXml = "RequestsXml.xml"){
            _fileNameBin = fileNameBin;
            _fileNameXml = fileNameXml;
            Init();
        } // task

        public void Init(){
            List<Request> tempList = new List<Request>();
            Request[] requests ={
                new Request(102, "Киев", "JF724", "Зайцева А. М.", new DateTime(2021,3,28)),
                new Request(104, "Киев", "AF9184", "Калмыков А. С.", new DateTime(2021,12,1)),
                new Request(105, "Стокгольм", "AF9584", "Андреев П. А.", new DateTime(2019,11,6)),
                new Request(107, "Лондон", "AV213", "Михеев М. А.", new DateTime(2023,8,21)),
                new Request(151, "Москва", "OB213", "Романова А. К.", new DateTime(2022,11,6)),
                new Request(124, "Киев", "KF213", "Давыдов Я. И.", new DateTime(2017,5,21)),
                new Request(134, "Лондон", "LK123", "Казаков М. Р.", new DateTime(2016,2,12)),
                new Request(191, "Анапа", "OK244", "Симонов А. Д.", new DateTime(2018,3,8)),
                new Request(106, "Стокгольм", "AF9584", "Родионова М. И.", new DateTime(2019,11,6)),
                new Request(162, "Киев", "SA4284", "Алексеев А. М.", new DateTime(2021,9,15))
            };

            tempList.AddRange(requests);

            _list = tempList;

        } // Init

        // вывод коллекции
        public void Show(){
            string Header = "\t┌───────┬──────────────────┬─────────────┬────────────────────┬────────────────┐\n" +
                            "\t| Номер | Пункт назначения | Номер рейса | Фамилия и инициалы | Дата(желаемая) |\n" +
                            "\t├───────┼──────────────────┼─────────────┼────────────────────┼────────────────┤\n";
            string items = "";

            if(_list!=null)
                foreach (var item in _list)
                    items += item;

            string Footer = "\t└───────┴──────────────────┴─────────────┴────────────────────┴────────────────┘\n";

           Console.WriteLine($"{Header}{items}{Footer}");
        } // Show

        private Request NewRequest(){

            string[] names = {
                "Никифоров И. А.", "Софронова В. А.", "Гусева Е. Д.", "Сорокин С. В.", "Тихонова А. Д.",
                "Акимова А. М.", "Мальцев А. В.", "Шишкина А. И.", "Лыков Д. А.", "Маркин Т. А.",
                "Денисова К. Г.", "Кузнецов С. А.", "Волков М. А.", "Сахаров А. Е.", "Мешков Г. Т."
            };

            string[] flightNumbers = {
                "AA012", "JF345","IO6212","IO512","BW452","DF525","IDS63",
                "VO234","BO124","BOD245","VO234","AI23","OWE45","PS345","VP521"
            };

            DateTime[] dateTimes ={
                new DateTime(2019,8,8), new DateTime(2016,3,28), new DateTime(2021,8,19),new DateTime(2020,2,22),
                new DateTime(2021,12,21),new DateTime(2021,3,4),new DateTime(2020,4,5),new DateTime(2022,2,6),
                new DateTime(2022,4,4),new DateTime(2021,1,7),new DateTime(2019,8,12),new DateTime(2021,7,12)
            };

            string[] points ={
                "Лондон", "Киев", "Москва", "Стокгольм", "Сухум", "Анапа", "Геленджик", "Алания", "Кемер", "Крит", "Белек", "Сочи"
            };

            int number = Utils.Random.Next(0, 1000);
            return new Request{
                Number = number,
                FlightNumber = flightNumbers[Utils.GetRand(0, flightNumbers.Length-1)],
                Point = points[Utils.GetRand(0, points.Length-1)],
                Name = names[Utils.GetRand(0, names.Length-1)],
                Date = dateTimes[Utils.GetRand(0, dateTimes.Length-1)],
            };
        } // NewRequest

        // сериализация данных
        public void SerializeBin(){
            BinaryFormatter bf = new BinaryFormatter();
            using (FileStream fs = new FileStream(@"..\..\" + _fileNameBin, FileMode.Create))
                bf.Serialize(fs, _list);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\tДанные успешно сериализированы");
            Console.ForegroundColor = ConsoleColor.Gray;
        } // SerializeBin

        // десереализация данных
        public void DeSerealizeBin(){
            _list.Clear();
            BinaryFormatter bf = new BinaryFormatter();
            using (FileStream fs = new FileStream(@"..\..\" + _fileNameBin, FileMode.Open))
                _list = bf.Deserialize(fs) as List<Request>;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n\n\tДанные успешно десериализированы");
            Console.ForegroundColor = ConsoleColor.Gray;
        } // DeSerealizeBin

        // добавление заявки в список
        public void AddRequest(){
            _list.Add(NewRequest());
        } // AddRequest

        // удаления заявок из коллекции
        public void RemoveRequests(int number){
            Request tempR = new Request();
            foreach (var item in _list)
                if (item.Number == number)
                    tempR = item;
            _list.Remove(tempR);
        } // RemoveRequests

        // удаление всех заявок из коллекции
        public void RemoveAllRequests() => _list.Clear();

        // Сортировка по номеру рейса
        public void SortByFlightNumber()=>
            _list.Sort((a, b) => a.FlightNumber.CompareTo(b.FlightNumber));

        // Сортировка по желаемой дате рейса
        public void SortByDateTime() =>
           _list.Sort((a, b) => a.Date.CompareTo(b.Date));

        // Сериализация коллекции в формате XML
        public void SerializeXml(){
            XmlSerializer xs = new XmlSerializer(typeof(List<Request>));
            using (FileStream fs = new FileStream(@"..\..\" + _fileNameXml, FileMode.Create))
                xs.Serialize(fs, _list);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n\n\tДанные успешно десериализированы");
            Console.ForegroundColor = ConsoleColor.Gray;
        } // SerializeXml

        // Десериализация коллекции из формата XML
        public void DeserializeXml(){
            _list.Clear();
            XmlSerializer xs = new XmlSerializer(typeof(List<Request>));
            using (FileStream fs = new FileStream(@"..\..\" + _fileNameXml, FileMode.OpenOrCreate))
                _list = xs.Deserialize(fs) as List<Request>;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n\n\tДанные успешно десериализированы");
            Console.ForegroundColor = ConsoleColor.Gray;
        } // DeserializeXml

    } // Task
}
