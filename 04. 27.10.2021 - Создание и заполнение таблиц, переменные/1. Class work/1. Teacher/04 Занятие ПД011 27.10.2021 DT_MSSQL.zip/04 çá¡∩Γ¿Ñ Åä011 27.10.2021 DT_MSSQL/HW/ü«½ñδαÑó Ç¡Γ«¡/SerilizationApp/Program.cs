﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;


using SerilizationApp.Contollers;
using SerilizationApp.Helpers;

namespace SerilizationApp
{
    class Program
    {
        static void Main(string[] args)
        {

            // простейшее меню приложения
                MenuItem[] menu = new[] {
                new MenuItem {HotKey = ConsoleKey.Q, Text = "Бинарная сериализация коллекции заявок"},
                new MenuItem {HotKey = ConsoleKey.W, Text = "Бинарная десериализация заявок"},
                new MenuItem {HotKey = ConsoleKey.E, Text = "вывод всех заявок из коллекции в консоль"},
                new MenuItem {HotKey = ConsoleKey.R, Text = "выборка в еще один список по заданному номеру рейса и дате вылета при помощи именованного итератора;"},
                new MenuItem {HotKey = ConsoleKey.T, Text = "добавление заявки в список, бинарная сериализация модифицированной коллекции;"},
                new MenuItem {HotKey = ConsoleKey.Y, Text = "удаление заявок из списка по номеру заявки,бинарная сериализация модифицированной коллекции;"},
                new MenuItem {HotKey = ConsoleKey.A, Text = "удаление всех заявок из списка, бинарная сериализация модифицированной коллекции;"},
                new MenuItem {HotKey = ConsoleKey.S, Text = "упорядочивание списка заявок по номеру рейса,бинарная сериализация модифицированной коллекции"},
                new MenuItem {HotKey = ConsoleKey.D, Text = "упорядочивание списка заявок по желаемой дате рейса бинарная сериализация модифицированной коллекции"},
             
                new MenuItem {HotKey = ConsoleKey.G, Text = "Сериализация коллекции в формате XML"},
                new MenuItem {HotKey = ConsoleKey.H, Text = "Десериализация коллекции из формата XML"},
                //----------------------------------------------------------------------------------------------
                new MenuItem {HotKey = ConsoleKey.Z, Text = "Выход"},
            };

            // Создание экземпляра класса приложения
            AppsController app = new AppsController();

            // главный цикл приложения
            while (true)
            {
                try
                {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.White, ConsoleColor.Black);
                    Console.Clear();
                    Console.CursorVisible = false;
                    Utils.ShowMenu(12, 5, "Меню приложения для демонстрации работы", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Black;
                    string msg =
                        "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.White, ConsoleColor.Black);
                    Console.Clear();

                    switch (key)
                    {

                        // Бинарная сериализация коллекции заявок
                        case ConsoleKey.Q:
                            app.BinSerialize();
                            break;

                        // Бинарная десериализация заявок
                        case ConsoleKey.W:
                            app.BinDeserialize();
                            break;

                        // вывод всех заявок из коллекции в консоль
                        case ConsoleKey.E:
                            app.ShowStorage();
                            break;
                        //выборка в еще один список по заданному номеру рейса и дате вылета при помощи именованного итератора;
                        case ConsoleKey.R:
                            app.AddChosenAppsDemo();
                            break;
                        //добавление заявки в список, бинарная сериализация модифицированной коллекции;
                        case ConsoleKey.T:
                            app.AddToListDemo();
                            break;
                        //удаление заявок из списка по номеру заявки,бинарная сериализация модифицированной коллекции;
                        case ConsoleKey.Y:
                            app.RemoveDemo();
                            break;
                        //удаление всех заявок из списка, бинарная сериализация модифицированной коллекции;
                        case ConsoleKey.A:
                            app.RemoveAllDemo();
                            break;
                        //упорядочивание списка заявок по номеру рейса,бинарная сериализация модифицированной коллекции
                        case ConsoleKey.S:
                            app.SortByFlightNumDemo();
                            break;
                        //упорядочивание списка заявок по желаемой дате рейса бинарная сериализация модифицированной коллекции
                        case ConsoleKey.D:
                            app.SortByDateDemo();
                            break;
                        case ConsoleKey.G:
                            app.SerializeXMLDemo();
                            break;
                        case ConsoleKey.H:
                            app.DeSerializeXmlDemo();
                            break;

                        // 
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor(); // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Black;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                } // try

                // обработка исключений - просто вывести сообщение
                catch (Exception ex)
                {
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                } // try-catch
            } // while
        }
    }
}
