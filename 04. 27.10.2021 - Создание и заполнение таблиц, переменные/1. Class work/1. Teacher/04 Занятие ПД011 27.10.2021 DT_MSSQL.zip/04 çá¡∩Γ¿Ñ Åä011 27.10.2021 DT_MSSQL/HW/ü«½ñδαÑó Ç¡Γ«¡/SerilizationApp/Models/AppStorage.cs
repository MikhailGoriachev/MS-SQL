﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SerilizationApp.Helpers;

namespace SerilizationApp.Models
{
    [Serializable]

    public class AppStorage:IEnumerable
    {
        public List<Application> applications;


        //конструкторы
        public AppStorage():this(new List<Application>())
        {

        }
        public AppStorage(List<Application> apps)
        {
            applications = apps;
        }

        //Инициилизация
        public void Init()
        {
            applications.Clear();

            for (int i = 0; i < 15; i++)
            {
                applications.Add(Application.Generate());
            }
        }

     

        // удаление данных о заявке по коду ёё номеру
        public void RemoveByNum(int num) =>
            applications.RemoveAll(b => b.Number == num);

        // вывод коллекции заявок в табличном формате
        public void Show(int indent)
        {
            Console.Write($"\t\tКоллекция заявок на {DateTime.Now}\n{Application.Header(indent)}");

            foreach (var item in applications)
            {
                Console.WriteLine(item.ToTableRow(indent));
            } // foreach

            Console.Write(Application.Footer(indent));
        } // Show

        //реализация интерфейса IEnumarble
        public IEnumerator GetEnumerator() => applications.GetEnumerator();


        //выборка по заданному номеру рейса и дате вылета при помощи именованного итератора
        public IEnumerable GetFlightNum(string flightnum,DateTime d)
        {
            

            foreach (var item in applications)
            {
                if (item.FlightNumber.Contains(flightnum) && item.FlightDate == d)
                {
                    yield return item;
                }
                else 
                {
                    Console.WriteLine("К сожалению совпадений не найдено!");
                    break;
                }
                   
            }
        }
    }
}
