﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using SerilizationApp.Helpers;
using SerilizationApp.Models;


namespace SerilizationApp.Contollers
{
    
    public partial class AppsController
    {
        public AppStorage appStorage;

        //конструкторы
        public AppsController():this(new AppStorage())
        {
            appStorage.Init();
        }
        public AppsController(AppStorage storage)
        {
            appStorage = storage;
        }

        //вывод заявок в консоль
        public void ShowStorage()
        {
            appStorage.Show(12);
        }
        
        //Бинарная сериализация коллекции заявок
        public void BinSerialize()
        {

            //сериализация
            var binformatter = new BinaryFormatter();

            using (var file = new FileStream("..//..//DataFiles//Applications.bin", FileMode.OpenOrCreate))
            {
                binformatter.Serialize(file, appStorage);

                
                Console.WriteLine("Данные успешно сериализованы");
                

            }

        }//BinSerialize


        //Бинарная десериализация заявок
        public void BinDeserialize()
        {
            var binformatter = new BinaryFormatter();
            //Десериализация
            using (var file = new FileStream("..//..//DataFiles//Applications.bin", FileMode.OpenOrCreate))
            {
                var applications = binformatter.Deserialize(file) as AppStorage;

                if (applications != null)
                {
                    //вывод заявок в консоль
                    foreach (var item in applications)
                    {
                        Console.WriteLine(item);
                    }
                }
            }
        }//BinDeserialize

        //выборка в еще один список заявок по заданному номеру рейса и дате вылета при помощи именованного итератора
        public void AddChosenAppsDemo()
        {

            //генерация заявки для поиска
            string flightnum = appStorage.applications[Utils.GetRandom(0, appStorage.applications.Count - 1)].FlightNumber;
            DateTime date = appStorage.applications[Utils.GetRandom(0, appStorage.applications.Count - 1)].FlightDate;


            Console.WriteLine($"Поиск по номеру полета {flightnum} и по дате вылета {date}");



            var cloneStorage = new List<Application>();
            foreach (var item in appStorage.GetFlightNum(flightnum,date))
            {               
                cloneStorage.Add((Application)item);
            }

            Console.WriteLine("Вывод нового списка с заданной заявкой");
            if (cloneStorage.Count != 0)
            {
                foreach (var item in cloneStorage)
                {
                    Console.WriteLine(item);

                }
            }
            else
            {   
                Console.WriteLine("К сожалению список пуст!");
            }
            
          
        }//AddChosenApps

        //добавление заявки в список, бинарная сериализация модифицированной коллекции;
        public void AddToListDemo()
        {
            //генерация заявки 
            Application app = new Application();
            app = Application.Generate();
            appStorage.applications.Add(app);

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"{app}-успешно была добавлена!");
            Console.ForegroundColor = ConsoleColor.White;
            appStorage.Show(12);
            //сериализация
            var binformatter = new BinaryFormatter();

            using (var file = new FileStream("..//..//DataFiles//Applications.bin", FileMode.OpenOrCreate))
            {
                binformatter.Serialize(file, appStorage);
                
                Console.WriteLine("Данные успешно сериализованы");
                
            }

        }//AddToListDemo

        //удаление заявок из списка по номеру заявки, бинарная сериализация модифицированной коллекции;
        public void RemoveDemo()
        {
            
            appStorage.Show(12);
            Console.WriteLine("Введите номер для удаления: ");
            string s = Console.ReadLine();
            int.TryParse(s, out int result);

            for (int i = 0; i < appStorage.applications.Count; i++)
            {
                if (result == appStorage.applications[i].Number)
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"{appStorage.applications[i]} - был успешно удален"); ;
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
            //Удаление
            appStorage.RemoveByNum(result);
           

            Console.WriteLine("Данные после удаления");
            appStorage.Show(12);

            //сериализация
            var binformatter = new BinaryFormatter();

            using (var file = new FileStream("..//..//DataFiles//Applications.bin", FileMode.OpenOrCreate))
            {
                binformatter.Serialize(file, appStorage);

                if (file != null)
                {
                    Console.WriteLine("Данные успешно сериализованы");
                }
            }
        }//RemoveDemo


        
    }
}
