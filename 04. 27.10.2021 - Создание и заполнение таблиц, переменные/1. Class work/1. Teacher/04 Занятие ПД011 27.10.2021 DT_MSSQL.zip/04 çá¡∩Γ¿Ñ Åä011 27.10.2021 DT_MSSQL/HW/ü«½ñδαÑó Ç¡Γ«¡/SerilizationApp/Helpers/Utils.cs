﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SerilizationApp.Helpers
{
    public static class Utils
    {
        // формирование случайных целых чисел в заданном диапазоне (lo, hi),
        // исключая указанное параметром exclude число
        public static int GetRandomExclude(int lo, int hi, int exclude)
        {
            int number = 0;
            do
                number = Random.Next(lo, hi);
            while (number == exclude);

            return number;
        } // GetRandomExclude

        // объект для получения случайных чисел
        public static readonly Random Random = new Random(Environment.TickCount);

        // Получение случайного числа
        // краткая форма записи метода - это не лямбда выражение
        public static int GetRandom(int lo, int hi) => Random.Next(lo, hi + 1);
        public static double GetRandom(double lo, double hi) => lo + (hi - lo) * Random.NextDouble();

        // формирует и выводит верхнюю строку для задач
        public static void ShowNavBarTask(string line)
        {
            // сохранить цвет фона
            (ConsoleColor oldBg, ConsoleColor oldFg) = (Console.BackgroundColor, Console.ForegroundColor);

            // при выводе немного используем методы класса string :)
            // PadRight() дополняет строку справа пробелами до заданной длины
            Console.BackgroundColor = ConsoleColor.Gray;
            WriteXY(0, 0, line.PadRight(Console.WindowWidth), ConsoleColor.Black);

            // восстановить цвет фона
            (Console.BackgroundColor, Console.ForegroundColor) = (oldBg, oldFg);
        } // ShowNavBarTask

        
        // Вспомогательный метод для вывода в заданных координатах окна консоли текста
        // заданным цветом
        public static void WriteXY(int x, int y, string s, ConsoleColor color)
        {
            // сохранить текущий цвет консоли и установить заданный
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = color;

            Console.SetCursorPosition(x, y);
            Console.Write(s);

            // восстановить цвет консоли
            Console.ForegroundColor = oldColor;
        } // WriteXY

        // Вывод меню приложения
        public static void ShowMenu(int x, int y, string title, MenuItem[] menu)
        {
            WriteXY(x, y, title, ConsoleColor.Gray);
            int offsetY = 2;

            foreach (var menuItem in menu)
            {
                WriteXY(x, y + offsetY, menuItem.HotKey.ToString(), ConsoleColor.Cyan);
                WriteXY(x + 2, y + offsetY++, menuItem.Text, ConsoleColor.Gray);
            } // foreach menuItem
        } // ShowMenu

        // Вывод сообщения "Метод в разработке" по центру экрана
        public static void ShowUnderConstruction()
        {
            (ConsoleColor fg, ConsoleColor bg) = (Console.ForegroundColor, Console.BackgroundColor);
            (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Black, ConsoleColor.Gray);

            string[] lines = {
                 " ".PadRight(40),
                 " ".PadRight(40),
                 "     [К сведению]".PadRight(40),
                 " ".PadRight(40),
                 "     Метод в разработке".PadRight(40),
                 " ".PadRight(40),
                 " ".PadRight(40),
            };

            int x = (Console.WindowWidth - 40) / 2;
            int y = (Console.WindowHeight - lines.Length) / 2;
            foreach (var line in lines)
                WriteXY(x, y++, line, ConsoleColor.DarkGray);

            (Console.ForegroundColor, Console.BackgroundColor) = (fg, bg);
            Console.SetCursorPosition(0, Console.WindowHeight - 1);
        } // ShowUnderConstruction

       
    } // class Utils
}

