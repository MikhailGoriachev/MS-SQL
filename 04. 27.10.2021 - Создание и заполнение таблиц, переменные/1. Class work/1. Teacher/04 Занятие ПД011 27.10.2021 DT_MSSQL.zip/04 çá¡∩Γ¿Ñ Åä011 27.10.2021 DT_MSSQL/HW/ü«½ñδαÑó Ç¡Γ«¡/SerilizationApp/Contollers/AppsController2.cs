﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using SerilizationApp.Models;
using System.Xml.Serialization;

namespace SerilizationApp.Contollers
{
    public partial class AppsController
    {


        //удаление всех заявок из списка, бинарная сериализация модифицированной коллекции;
        public void RemoveAllDemo()
        {
            //вывод коллекции до
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\t\tКоллекция до удаления всех элементов\n");
            Console.ForegroundColor = ConsoleColor.White;
            appStorage.Show(12);

            //Удаление всех элементов
            for (int i = 0; i < appStorage.applications.Count; i++)
            {
                appStorage.applications.RemoveRange(0, appStorage.applications.Count);
            }

            //вывод коллекции после
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n\t\tКоллекция после удаления после удаления всех элементов\n");
            Console.ForegroundColor = ConsoleColor.White;
            appStorage.Show(12);

            //сериализация
            var binformatter = new BinaryFormatter();

            using (var file = new FileStream("..//..//DataFiles//Applications.bin", FileMode.OpenOrCreate))
            {
                binformatter.Serialize(file, appStorage);
                
                 Console.WriteLine("Данные успешно сериализованы");
                
            }
        }//RemoveAllDemo


        //упорядочивание списка заявок по номеру рейса, бинарная сериализация модифицированной коллекции
        public void SortByFlightNumDemo()
        {
            //вывод коллекции до
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\t\tКоллекция до сортировки элементов по номеру рейса\n");
            Console.ForegroundColor = ConsoleColor.White;
            appStorage.Show(12);
           
            //сортировка
            appStorage.applications.Sort((a, b) => a.FlightNumber.CompareTo(b.FlightNumber));


            //вывод коллекции после
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n\t\tКоллекция после сортировки по номеру рейса\n");
            Console.ForegroundColor = ConsoleColor.White;
            appStorage.Show(12);


            //сериализация
            var binformatter = new BinaryFormatter();

            using (var file = new FileStream("..//..//DataFiles//Applications.bin", FileMode.OpenOrCreate))
            {
                binformatter.Serialize(file, appStorage);
               
                 Console.WriteLine("Данные успешно сериализованы");
                
            }


        }//SortByFlightNumDemo

        //упорядочивание списка заявок по желаемой дате рейса бинарная сериализация модифицированной коллекции
        public void SortByDateDemo()
        {
            //вывод коллекции до
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\t\tКоллекция до сортировки элементов по желаемой дате рейса\n");
            Console.ForegroundColor = ConsoleColor.White;
            appStorage.Show(12);

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("Введите желаемую дату ");
            Console.Write("Год: ");
            string year = Console.ReadLine();
            int.TryParse(year, out int resultyear);
            Console.Write("\nМесяц: ");
            string month = Console.ReadLine();
            int.TryParse(month, out int resultmonth);
            Console.Write("\nДень: ");
            string day = Console.ReadLine();
            int.TryParse(day, out int resultday);
            

            DateTime date = new DateTime(resultyear,resultmonth,resultday);

            //сортировка
            appStorage.applications.Sort((a,b)=>a.FlightDate.CompareTo(date));



            //вывод коллекции после
          
            Console.WriteLine("\n\t\tКоллекция после сортировки по желаемой дате рейса\n");
            Console.ForegroundColor = ConsoleColor.White;
            appStorage.Show(12);


            //сериализация
            var binformatter = new BinaryFormatter();

            using (var file = new FileStream("..//..//DataFiles//Applications.bin", FileMode.OpenOrCreate))
            {
                binformatter.Serialize(file, appStorage);
               
                Console.WriteLine("Данные успешно сериализованы");
                
            }



        }//SortByDateDemo

        //Сериализация коллекции в формате XML
        public void SerializeXMLDemo()
        {
            List<Application> newlist = new List<Application>();
            foreach (var item in appStorage.applications)
            {
                newlist.Add(item);
            }
            //сериализация
            // передаем в конструктор тип класса
            XmlSerializer formatter = new XmlSerializer(typeof(List<Application>));

            // получаем поток, куда будем записывать сериализованный объект
            using (FileStream fs = new FileStream("..//..//DataFiles//Applications.xml", FileMode.Create))
            {
                formatter.Serialize(fs, newlist);

                Console.WriteLine("Объект сериализован");
            }
        }//SerializeXMLDemo


        public void DeSerializeXmlDemo()
        {
            var binformatter = new BinaryFormatter();
            //Десериализация
            // передаем в конструктор тип класса
            XmlSerializer formatter = new XmlSerializer(typeof(List<Application>));

            using (FileStream fs = new FileStream("..//..//DataFiles//Applications.xml", FileMode.OpenOrCreate))
            {
                List<Application> newList = (List<Application>)formatter.Deserialize(fs);

                Console.WriteLine("Объект десериализован");
                foreach (var item in newList)
                {
                    Console.WriteLine(item);
                }
            }
        }
    }
}
