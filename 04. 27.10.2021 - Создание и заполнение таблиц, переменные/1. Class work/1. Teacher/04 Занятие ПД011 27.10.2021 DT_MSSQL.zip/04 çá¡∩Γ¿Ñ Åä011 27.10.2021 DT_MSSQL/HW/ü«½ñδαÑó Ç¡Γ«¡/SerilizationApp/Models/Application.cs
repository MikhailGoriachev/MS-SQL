﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SerilizationApp.Helpers;

namespace SerilizationApp.Models
{

    //заявка содержит: номер заявки, пункт назначения, номер рейса, фамилию и инициалы пассажира, желаемую дату вылета
    [Serializable]
    public class Application
    {
        //номер заявки
        private int _number;

        public int Number
        {
            get { return _number; }
            set { _number = value >= 0 ? value
                    : throw new Exception("Некорректный номер заявки");
            }
        }

        //пункт назначения
        private string _destination;

        public string Destination
        {
            get { return _destination; }
            set { _destination = string.IsNullOrEmpty(value)
                    ? throw new Exception($"Пустое значение в поле 'Пункт назначения'")
                    : value; }
        }

        //номер рейса
        private string _numflight;

        public string FlightNumber
        {
            get { return _numflight; }
            set { _numflight = string.IsNullOrEmpty(value)
                    ? throw new Exception($"Пустое значение в поле 'Номер полета'")
                    : value;
            }
        }

        //ФИО пассажира
        private string _name;

        public string Name
        {
            get { return _name; }
            set { _name = string.IsNullOrEmpty(value)
                    ? throw new Exception($"Пустое значение в поле 'ФИО пассажира'")
                    : value; }
        }

        //Желаемая дата полета
        private DateTime _flightdate;

        public DateTime FlightDate
        {
            get { return _flightdate; }
            set { _flightdate = value.Year >= d.Year
                    ? value
                    : throw new Exception($"Недопустимое значение в поле 'Желаемая дата полета - нельзя заказать билет на дату которая уже прошла'"); }
        }

        //текущее время для проверки на корректность данных в поле дата полета
        DateTime d = DateTime.Now;

        //конструктор без параметров
        public Application()
        {

        }
        //строковое представление заявки
        public override string ToString() => $"[ Завка {_number}; № Рейса {_numflight} ;ФИО пассажира: {_name} " +
            $"; Пункт пребывания: {_destination}; Дата вылета {_flightdate} ]";


        // формирование строки таблицы
        public string ToTableRow(int indent) =>
            $"{" ".PadRight(indent)}" +
            $"│ {_number,-13} " +
            $"│ {_numflight,-15} " +
            // если длина названия превышает 40 символов, выводим первые 37 символов
            // и затем троеточие
            $"│ {$"{_destination}",-24} " +
            $"│ {_name,-19} " +
            $"│ {_flightdate,-19} │";


        // шапка таблицы, статическое свойство
        public static string Header(int indent)
        {
            string spaces = " ".PadRight(indent);
            return
                $"{spaces}┌───────────────┬─────────────────┬──────────────────────────┬─────────────────────┬─────────────────────┐\n" +
                $"{spaces}│ Номер заявки  │ Номер полета    │ Пункт назначения         │ ФИО пассажира       │ Дата вылета         │\n" +
                $"{spaces}├───────────────┼─────────────────┼──────────────────────────┼─────────────────────┼─────────────────────┤\n";
        } // Header

        // подвал таблицы, статическое свойство
        public static string Footer(int indent)
        {
            string spaces = " ".PadRight(indent);
            return
                $"{spaces}└───────────────┴─────────────────┴──────────────────────────┴─────────────────────┴─────────────────────┘\n";
        } // Footer
        public static Application Generate()
        {
            string[] destinations = {
                "Москва,Россия", "Ростов-на-Дону,Россия", "Каир,Египет", "Нью-Йорк,США", "Киев,Украина", "Париж,Франция",
                "Иркутск,Россия", "Кабул,Афганистан", "Багдад,Ирак", "Бангкок,Тайланд", "Палембанг,Индонезия",
                "Абакан,Россия", "Афины,Греция", "Болонья,Италия", "Барселона,Испания", "Лондон,Великобритания"
            };
                

            string[] names = {
                    "Ровенский Б.Ю.","Спекторенко И.Д.","Спекторенко А.Д.","Ерхов Г.П",
                "Нестерцов В.И","Кулиш Д.А.","Кузьмин В.И.","Шевцова А.К","Чепикова У.Ю.",
                "Павлова П.П.","Шеремет Е.А.","Надворный А.Д.","Чернобровкина А.В.",
                "Золотарева Е.К.","Макушкин Д.К.","Шишков А.Г.","Краснова Ю.В."

            };
        
           
            return new Application
            {
                Number =Utils.Random.Next(1,100),
                Destination = destinations[Utils.GetRandom(0, destinations.Length - 1)],
                FlightNumber = $"{((char)Utils.GetRandom('A', 'Z'))}{((char)Utils.GetRandom('A', 'Z'))}{(Utils.GetRandom(1000, 5001))}",
                Name = names[Utils.GetRandom(0,names.Length-1)],
                                            //год                        //месяц            //день
                FlightDate = new DateTime(Utils.GetRandom(2021,2022),Utils.GetRandom(1,12),Utils.GetRandom(1,28))
               


            };
        }

    }
}
