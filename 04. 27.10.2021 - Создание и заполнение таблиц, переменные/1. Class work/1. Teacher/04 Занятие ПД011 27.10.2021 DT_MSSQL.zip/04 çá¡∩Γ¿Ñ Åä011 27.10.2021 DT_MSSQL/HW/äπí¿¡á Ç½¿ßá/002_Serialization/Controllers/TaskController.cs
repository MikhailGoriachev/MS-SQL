﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Serialization.Helpers;
using Serialization.Models;

using System.Runtime.Serialization.Formatters.Binary;

using System.IO;
using System.Collections;
using System.Xml.Serialization;

namespace Serialization.Controllers
{
    class TaskController {
        // имя бинарного файла
        private string _fileName;

        // имя бинарного файла
        private string _XMLfileName;
        public string FileName { get => _fileName; }
        public string XMLFileName { get => _XMLfileName; }

        // контейнер данных
        private List<Request> _requests;

        public int Count => _requests.Count;
        public List<Request> Requests => _requests;

        public TaskController() : this(new List<Request>(), "requests.dat", "requests.xml") {
            Initialize();
        } // TaskController

        public TaskController(List<Request> requests, string fileName, string XMLfileName) {
            _requests = requests;
            _fileName = fileName;
            _XMLfileName = XMLfileName;
        } // TaskController

        // Заполнение коллекции заявок
        public void Initialize(int n = 10) {
            _requests.Clear();

            for (int i = 0; i < n; i++)
                _requests.Add(Request.Generate(i + 1));

        } // Initialize


        // бинарная сериализация
        public void Serialize() {
            BinaryFormatter bf = new BinaryFormatter();

            // собственно сериализация
            using (FileStream fs = new FileStream(@"..\..\" + _fileName, FileMode.Create)) {
                bf.Serialize(fs, _requests);
            } // using
        } // Serialize

        // бинарная десериализация
        public void Deserialize() {
            BinaryFormatter bf = new BinaryFormatter();

            using (FileStream fs = new FileStream(@"..\..\" + _fileName, FileMode.Open)) {
                _requests = bf.Deserialize(fs) as List<Request>;
            } // using

        } // Deserialize

        // сериализация в формате XML
        public void XMLSerialize() {
            XmlSerializer xf = new XmlSerializer(typeof(List<Request>));

            using (FileStream fs = new FileStream(@"..\..\" + _XMLfileName, FileMode.Create)) {
                xf.Serialize(fs, _requests);
            } // using
        } // XMLSerialize

        // десериализация в формате XML
        public void XMLDeserialize() {
            XmlSerializer xf = new XmlSerializer(typeof(List<Request>));

            using (FileStream fs = new FileStream(@"..\..\" + _XMLfileName, FileMode.Open)) {
                _requests = xf.Deserialize(fs) as List<Request>;
            } // using

        } // XMLDeserialize

        // Добавление заявки в список
        public void AddRequest(Request request) {
            _requests.Add(request);
            Serialize();
        } // AddRequest

        // Удаление заявки из списка
        public void RemoveRequest(int num) {
            int index = _requests.FindIndex(x => x.Number == num);
            if (index < 0) throw new Exception("Заявка для удаления не найдена!");
            _requests.RemoveAt(index);
            Serialize();
        } // AddRequest

        // Удаление всех заявок из списка
        public void RemoveAllRequests() {
            _requests.Clear();
            Serialize();
        } // RemoveAllRequests


        // Именованный итератор, возвращает только записи с заданным номером рейса и дате вылета 
        public IEnumerable GetByFlightNumAndDate(string flightNum, DateTime date) {
            foreach (var item in _requests)
                if (item.FlightNum == flightNum && item.DepartureDate == date)
                    yield return item;
        } // GetByZodiacSign


        public string Show(string caption, int indent) =>
            Show(caption, indent, _requests);

        // Вывести данные коллекции в консоль - для вывода 
        public static string Show(string caption, int indent, List<Request> requests) {
            // вывод заголовка таблицы данных 
            string space = " ".PadRight(indent);
            StringBuilder sb = new StringBuilder($"\n\n{space}{caption}\n{Request.Header(indent)}");

            // вывод всех элементов массива объектов данных
            foreach(var el in requests)
                sb.Append($"{space}{el.ToTableRow()}\n");

            // вывод подвала таблицы
            return sb.Append($"{space}{Request.Footer}\n").ToString();
        } // Show

        // Упорядочить заявки по номеру рейса
        public void OrderByFlightNum() {
            _requests.Sort((x, y) => x.FlightNum.CompareTo(y.FlightNum));
            Serialize();
        } // OrderByFlightNum

        // Упорядочить заявки по желаемой дате рейса
        public void OrderByDate() {
            _requests.Sort((x, y) => x.DepartureDate.CompareTo(y.DepartureDate));
            Serialize();
        } // OrderByDate
    } // TaskController
}
