﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Serialization.Helpers;
using Serialization.Models;
using Serialization.Controllers;

namespace Serialization.Application
{
    /* 
    * Методы для решения задачи
    */
    internal partial class App {
        // Бинарная сериализация коллекции заявок
        public void DemoBinarySerialize() {
            Utils.ShowNavBarTask("   Бинарная сериализация коллекции заявок");
            _task.Initialize();
            Console.WriteLine(_task.Show("Данные сформированы:", 12));

            _task.Serialize();
            Console.WriteLine($"\n{" ".PadLeft(12)}Данные записаны в файл \"{_task.FileName}\"!");
        } // DemoBinarySerialize


        // Бинарная десериализация заявок
        public void DemoBinaryDeserialize() {
            Utils.ShowNavBarTask("   Бинарная десериализация заявок");

            _task.Deserialize();
            Console.WriteLine(_task.Show($"Данные прочитаны из файла \"{_task.FileName}\":", 12));
        } // DemoBinaryDeserialize


        // Вывод всех заявок из коллекции в консоль
        public void ShowRequests() {
            Utils.ShowNavBarTask("   Вывод всех заявок из коллекции в консоль");
            Console.WriteLine(_task.Show("Коллекция заявок:", 12));
        } // ShowRequests


        // Выборка заявок по заданному номеру рейса и дате вылета
        public void SelectByFlightNumAndDate() {
            Utils.ShowNavBarTask("   Выборка заявок по заданному номеру рейса и дате вылета");
            int index = Utils.GetRand(0, _task.Count - 1);
            string flightNum = _task.Requests[index].FlightNum;
            DateTime date = _task.Requests[index].DepartureDate;

            Console.WriteLine($"\n\t    Заданный номер рейса: {flightNum}\n\t    Заданная дата вылета: {date:dd/MM/yyyy}");

            List<Request> selected = new List<Request>();

            foreach (Request item in _task.GetByFlightNumAndDate(flightNum, date))
                selected.Add(item);

            Console.WriteLine(TaskController.Show("Найденные заявки:", 12, selected));

        } // SelectByFlightNumAndDate


        // Добавление заявки в список
        public void AddRequest() {
            Utils.ShowNavBarTask("   Добавление заявки в список");
            
            _task.AddRequest(Request.Generate(_task.Requests[_task.Count - 1].Number + 1));
            Console.WriteLine(_task.Show("Заявка добавлена в конец коллекции:", 12));
        } // RemoveAllRequests


        // Удаление заявки из списка
        public void RemoveRequest() {
            Utils.ShowNavBarTask("   Удаление заявки из списка");

            Console.WriteLine(_task.Show("Данные для удаления.", 12));
            Console.Write("\n\n\t    Введите номер заявки для удаления: ");
            string str = Console.ReadLine();

            if (!int.TryParse(str, out int num)) throw new Exception("Некорректный ввод!");

            _task.RemoveRequest(num);

            Console.Clear();
            Utils.ShowNavBarTask("   Удаление заявки из списка");
            Console.WriteLine(_task.Show("Коллекция после удаления заявки:", 12));

        } // RemoveRequest


        // Удаление всех заявок из списка
        public void RemoveAllRequests() {
            Utils.ShowNavBarTask("   Удаление всех заявок из списка");

            _task.RemoveAllRequests();
            Console.WriteLine($"\n\n{" ".PadLeft(12)}Данные успешно удалены!");
        } // RemoveAllRequests


        // Упорядочить заявки по номеру рейса
        public void DemoOrderByFlightNum() {
            Utils.ShowNavBarTask("   Упорядочить заявки по номеру рейса");

            _task.OrderByFlightNum();

            Console.WriteLine(_task.Show("Коллекция упорядочена по номеру рейса:", 12));

        } // DemoOrderByFlightNum


        // Упорядочить заявки по желаемой дате рейса
        public void DemoOrderByDate()  {
            Utils.ShowNavBarTask("   Упорядочить заявки по желаемой дате рейса");

            _task.OrderByDate();

            Console.WriteLine(_task.Show("Коллекция упорядочена по желаемой дате рейса:", 12));
        } // DemoOrderBy

        // Сериализация коллекции в формате XML
        public void DemoXMLSerialize() {
            Utils.ShowNavBarTask("   Сериализация коллекции в формате XML");
            _task.XMLSerialize();
            Console.WriteLine($"\n{" ".PadLeft(12)}Данные записаны в файл \"{_task.XMLFileName}\"!");
        } // DemoXMLSerialize

        // Десериализация коллекции из формата XML
        public void DemoXMLDeserialize() {
            Utils.ShowNavBarTask("   Десериализация коллекции из формата XML");

            _task.XMLDeserialize();
            Console.WriteLine(_task.Show($"Данные прочитаны из файла \"{_task.XMLFileName}\":", 12));
        } // DemoXMLDeserialize

    } // App
}
