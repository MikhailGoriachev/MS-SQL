﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Serialization.Helpers;

using System.IO;

namespace Serialization.Models
{
    // Заявка на авиабилет содержит:
    //                  номер заявки,
    //                  пункт назначения,
    //                  номер рейса,
    //                  фамилию и инициалы пассажира,
    //                  желаемую дату вылета
    [Serializable]
    public class Request {
        // номер заявки
        private int _number;
        public int Number {
            get  => _number; 
            set { if (value < 0) throw new Exception("Request. Некорректное значение номера заявки!"); _number = value; }
        } // Number

        
        // название пункта назначения
        private string _destination;
        public string Destination {
            get => _destination;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Request. Некорректное значение пункта назначения!"); _destination = value; }
        } // Destination
        
        
        // номер рейса
        private string _flightNum;
        public string FlightNum {
            get => _flightNum;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Request. Некорректное значение номера рейса!"); _flightNum = value; }
        } // FlightNum
        

        // фамилию и инициалы пассажира
        private string _passenger;
        public string Passenger {
            get => _passenger;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Request. Некорректное значение фамилии и инициалов пассажира!"); _passenger = value; }
        } // Passenger


        // желаемая дата вылета
        private DateTime _departureDate;
        public DateTime DepartureDate {
            get => _departureDate;
            set { if (value < DateTime.Now) throw new Exception("Request. Некорректное значение желаемой даты вылета!"); _departureDate = value; }
        } // DepartureDate

        public Request() : this(1, "Нью-Йорк", "NYF125", "Иванов И.И.", new DateTime(2022, 8, 10)) { }

        public Request(int number, string destination, string flightNum, string passenger, DateTime departureDate) {
            Number = number;
            Destination = destination;
            FlightNum = flightNum;
            Passenger = passenger;
            DepartureDate = departureDate;
        } // Request

        // вывод данных о заявке на авиабилет в формате строки таблицы
        public string ToTableRow() =>
            $"│ {_number, 3} │ {_destination,-16} │ {_flightNum, 11} │ {_passenger,-22} │ {_departureDate, 15:dd/MM/yyyy}      │";


        // статическое свойство для вывода шапки таблицы
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌─────┬──────────────────┬─────────────┬────────────────────────┬──────────────────────┐\n" +
                $"{spaces}│  №  │ Пункт назначения │ Номер рейса │ Фамилия И.О. пассажира │ Желаемая дата вылета │\n" +
                $"{spaces}├─────┼──────────────────┼─────────────┼────────────────────────┼──────────────────────┤\n";
            return str;
        } // Header


        public static string Footer =>
            "└─────┴──────────────────┴─────────────┴────────────────────────┴──────────────────────┘";


        // Фабричный метод для создания пользователя из случайных данных
        public static Request Generate(int num) {
            // массив фамилий 
            string[] surnames = new[] { "Семенов ",  "Дунаев ",  "Харламова ", "Олегова ", "Янковский ", "Абалкин ",
                                     "Романова ", "Воликов ", "Жукова ",    "Соколов ", "Лебедев " };

            // массив инициалов 
            string[] initials = new[] { "A.", "Б.", "В.", "Г.", "Д.", "Е.", "Ж.", "З.", "И.", "К.", "Л.", "М.", "Н.", "О.", "П.", "Р.", "С.", "Т.",
                                        "У.", "Ф.", "Х.", "Ц.", "Ч.", "Ш.", "Э.", "Ю.", "Я."};

            var flights = new (string destination, string flightNum, DateTime date)[] {
                ("Тель-Авив", "TDF130", new DateTime(2022, 1, 1)),
                ("Нью-Йорк",  "NYF125", new DateTime(2022, 8, 10)),
                ("Гамбург",   "KTH758", new DateTime(2021, 12, 27)),
                ("Франкфурт", "HYF351", new DateTime(2021, 12, 14)),
                ("Лиссабон",  "JTF354", new DateTime(2022, 8, 9)),
                ("Сидней",    "KVR780", new DateTime(2021, 12, 27)),
                ("Будапешт",  "PDR957", new DateTime(2021, 12, 27)),
                ("Бангкок",   "GYL347", new DateTime(2022, 2, 7)),
                ("Барселона", "FSH589", new DateTime(2021, 11, 3)),
                ("Кейптаун",  "MVT175", new DateTime(2022, 11, 4)),
            };

            int index = Utils.Random.Next(flights.Length);
            return new Request {
                Number = num,
                Destination = flights[index].destination,
                FlightNum = flights[index].flightNum,
                Passenger = surnames[Utils.Random.Next(surnames.Length)] + initials[Utils.Random.Next(initials.Length)] + initials[Utils.Random.Next(initials.Length)],
                DepartureDate = flights[index].date
            };
        } // Generate
    } // Request
}
