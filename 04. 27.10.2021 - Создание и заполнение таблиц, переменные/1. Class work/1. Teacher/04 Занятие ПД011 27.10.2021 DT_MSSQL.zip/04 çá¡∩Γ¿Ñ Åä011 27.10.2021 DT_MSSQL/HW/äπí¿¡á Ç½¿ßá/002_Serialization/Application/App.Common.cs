﻿using System;
using Serialization.Controllers;

namespace Serialization.Application
{

    // Класс приложения - обработка по заданию
    // Данные для обработки и конструкторы
    internal partial class App {
        TaskController _task;  // объект для решения задачи

        // конструктор по умолчанию
        public App() : this(new TaskController()) { }

        // конструктор с внедрением зависимостей
        public App(TaskController task) {
            _task = task;
        } // App

    } // class App
}