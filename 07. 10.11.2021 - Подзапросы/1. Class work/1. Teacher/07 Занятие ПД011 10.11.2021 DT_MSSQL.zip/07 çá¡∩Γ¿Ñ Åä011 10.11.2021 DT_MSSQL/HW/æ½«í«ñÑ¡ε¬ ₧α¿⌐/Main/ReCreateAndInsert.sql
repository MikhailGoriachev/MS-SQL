﻿drop table if exists Deliveries;
drop table if exists Editions;
drop table if exists EditionTypes;
drop table if exists Subscribers;
drop table if exists Addresses;

drop view if exists EditionsWithTypes;
drop view if exists DeliveriesWithAllKeys;
drop view if exists SubscribersWithAddresses;
go


begin -- EditionTypes


CREATE TABLE [dbo].[EditionTypes]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Type] NVARCHAR(30) NOT NULL
)


insert into EditionTypes
values
    (N'Газета'),
    (N'Каталог'),
    (N'Журнал')


end
go


begin -- Editions


CREATE TABLE [dbo].[Editions]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Index] NVARCHAR(20) NOT NULL, 
    [Title] NVARCHAR(80) NOT NULL, 
    [Price] MONEY NOT NULL, 
    [EditionTypeId] INT NOT NULL, 
    CONSTRAINT [FK_Editions_EditionTypes] FOREIGN KEY ([EditionTypeId]) REFERENCES [EditionTypes]([Id]), 
    CONSTRAINT [CK_Editions_Price] CHECK ([Price] >= 0)
)


insert into Editions
values
  ('22368','sit amet,',1764,2),
  ('6968','urna',42,2),
  ('66868','Cras dictum ultricies ligula.',288,1),
  ('456859','pede sagittis augue,',1652,2),
  ('568437','mi',1404,3),
  ('673527','lobortis risus.',1319,2),
  ('00385','hendrerit neque. In',1715,2),
  ('W5H 2EQ','auctor. Mauris vel',1191,1),
  ('61-740','sit amet',1972,2),
  ('18293','sed dictum eleifend,',1672,2),
  ('ZY85 4KB','fermentum risus, at',1683,3),
  ('IU27 1EG','felis purus ac tellus.',90,1),
  ('50213','nascetur ridiculus',1833,3),
  ('56652','nunc. Quisque ornare',1646,2),
  ('6344','ornare lectus justo eu',1029,2),
  ('M76 7LO','Nulla interdum.',1832,1),
  ('92784','Quisque imperdiet,',1503,3),
  ('887783','eu, placerat eget, venenatis',1986,2),
  ('08151','vel,',915,3),
  ('516244','sed orci',594,2),
  ('175062','ultrices, mauris ipsum porta',88,2),
  ('251214','et',1185,2),
  ('50064','quam a felis ullamcorper',1889,3),
  ('172133','massa. Suspendisse eleifend.',931,3),
  ('145135','odio tristique pharetra.',1143,2),
  ('O6R 3B8','in',895,1),
  ('83685','Fusce fermentum fermentum',1315,2),
  ('977854','erat, eget',1052,1),
  ('2751','Donec consectetuer',551,1),
  ('53569','orci lacus vestibulum lorem,',1031,2),
  ('364719','Integer in magna.',883,2),
  ('303863','pellentesque',385,2),
  ('15565-531','Nulla',330,3),
  ('51652','In condimentum. Donec',1657,1),
  ('7186','ac ipsum.',370,1),
  ('22576','bibendum',1525,2),
  ('815985','metus vitae velit',353,2),
  ('18641','at sem',22,2),
  ('41511','semper et, lacinia',1011,3),
  ('13842','hendrerit a,',941,2),
  ('26281','iaculis enim, sit',657,3),
  ('814665','nibh. Donec est',548,3),
  ('52954-902','conubia nostra, per inceptos',1165,2),
  ('19598','Nulla',978,2),
  ('18163','vehicula. Pellentesque tincidunt tempus',853,1),
  ('3203','non magna. Nam',638,1),
  ('777498','natoque penatibus et magnis',539,1),
  ('6595','fringilla cursus purus. Nullam',941,2),
  ('37175','Sed molestie.',1563,2),
  ('267258','ac libero',1410,2), 
  ('27754','vitae',1554,2),
  ('81251-83747','ut quam vel',990,1),
  ('58788','tellus. Phasellus elit',472,1),
  ('61572','iaculis enim, sit',758,2),
  ('15686','Praesent interdum ligula',598,1),
  ('63345','sed pede. Cum sociis',944,1),
  ('45847','enim non',1954,2),
  ('W1R 0A3','enim, gravida sit',1566,2),
  ('2260 YB','nec urna',1451,2),
  ('77558-38464','eros non enim commodo',750,2),
  ('28253','non, sollicitudin',404,3),
  ('344533','nisi. Cum',1761,2),
  ('434631','tempor, est ac',1231,2),
  ('30405','faucibus',1868,3),
  ('4724','metus. Aenean sed',404,2),
  ('05587','erat semper',111,3),
  ('8633','molestie',1600,1),
  ('58427','in, tempus eu, ligula.',1726,2),
  ('64661','et',1182,1),
  ('29408','porttitor eros nec',1038,1),
  ('91863','posuere at, velit.',360,1),
  ('BL2T 7OG','pede. Cras vulputate',1423,3),
  ('87541-57229','ipsum. Donec sollicitudin adipiscing',521,2),
  ('95343-447','nascetur',1931,1),
  ('706225','ultrices a,',268,1),
  ('9848','risus. In mi',1593,2),
  ('86661','sit amet massa.',1414,3),
  ('42885','dolor',330,3),
  ('17358','ante ipsum primis',617,3),
  ('878456','et ultrices',1561,2),
  ('59160','molestie tortor nibh sit',1069,3),
  ('64X 1A8','urna. Ut',1044,2),
  ('97660','adipiscing,',1949,2),
  ('7376','a, auctor non,',514,1),
  ('84854','sagittis placerat. Cras dictum',536,1),
  ('98924','a felis',183,2),
  ('5882','orci. Donec nibh.',199,2),
  ('06272-54721','hendrerit consectetuer,',1442,2),
  ('398712','vitae, posuere at, velit.',1069,3),
  ('73268','et',1166,2),
  ('37673','rutrum. Fusce',1591,1),
  ('8627','lobortis',1707,3),
  ('853034','quam vel sapien',1017,2),
  ('11869','quis massa.',615,1),
  ('2787','orci. Donec',1787,2),
  ('8991','dis',985,2),
  ('67100','et',1970,1),
  ('84305','diam dictum sapien. Aenean',1141,3),
  ('14204','adipiscing non,',1899,3),
  ('302387','vulputate velit',1110,2)


end
go


begin -- Addresses


CREATE TABLE [dbo].[Addresses]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Street] NVARCHAR(30) NOT NULL, 
    [House] NVARCHAR(10) NOT NULL, 
    [Apartment] NVARCHAR(10) NOT NULL
)


insert into Addresses
values
  ('risus.',20,72),
  ('mus.',121,44),
  ('nec',17,22),
  ('enim.',6,60),
  ('accumsan',142,19),
  ('turpis.',55,29),
  ('nunc.',51,48),
  ('Quisque',119,33),
  ('pharetra',70,41),
  ('urna',86,56),
  ('luctus',19,38),
  ('tortor,',177,56),
  ('pharetra.',71,17),
  ('feugiat.',183,70),
  ('mauris,',58,56),
  ('eu',154,38),
  ('sapien',37,35),
  ('consequat,',129,4),
  ('Praesent',20,51),
  ('metus',28,56),
  ('Quisque',108,79),
  ('nonummy',143,47),
  ('Nullam',5,44),
  ('commodo',143,76),
  ('nulla',186,68),
  ('sem',155,48),
  ('dis',154,66),
  ('tellus.',160,63),
  ('Maecenas',134,42),
  ('libero.',165,18),
  ('pede',121,69),
  ('dictum',16,2),
  ('pharetra,',102,16),
  ('Nulla',189,17),
  ('luctus',117,55),
  ('amet',28,14),
  ('vitae',5,41),
  ('Cras',80,79),
  ('enim',106,46),
  ('convallis',58,13),
  ('massa',3,21),
  ('Curabitur',188,29),
  ('lectus.',107,21),
  ('Class',193,4),
  ('quam',27,4),
  ('tristique',59,7),
  ('quis',166,44),
  ('Nam',35,20),
  ('vitae,',28,6),
  ('Nulla',16,45),
  ('neque',59,64),
  ('Sed',184,62),
  ('eu',97,19),
  ('habitant',81,32),
  ('Morbi',72,77),
  ('ante.',74,19),
  ('In',120,60),
  ('elit',110,35),
  ('dolor.',59,53),
  ('Aliquam',41,2),
  ('Proin',16,53),
  ('in',61,29),
  ('ac',69,76),
  ('felis',193,33),
  ('eget,',63,72),
  ('mollis',11,43),
  ('nulla.',112,36),
  ('leo,',155,52),
  ('in,',97,38),
  ('Praesent',173,75),
  ('sit',49,67),
  ('cursus,',33,75),
  ('libero',148,30),
  ('nonummy',95,62),
  ('consectetuer',199,50),
  ('eget',43,58),
  ('nunc',2,46),
  ('sem',168,57),
  ('nisi.',104,51),
  ('ridiculus',61,18),
  ('eget',148,72),
  ('Donec',95,28),
  ('sem',109,51),
  ('leo.',31,54),
  ('auctor,',125,18),
  ('nec',23,18),
  ('id',64,72),
  ('malesuada',23,24),
  ('at,',85,45),
  ('urna.',49,74),
  ('Aenean',143,54),
  ('neque',46,13),
  ('non,',60,75),
  ('non',183,18),
  ('cursus,',188,7),
  ('nunc',80,6),
  ('purus',89,32),
  ('eros.',96,4),
  ('sapien',85,69),
  ('libero.',4,72)


end
go


begin -- Subscribers


CREATE TABLE [dbo].[Subscribers]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Name] NVARCHAR(80) NOT NULL, 
    [Surname] NVARCHAR(80) NOT NULL, 
    [Patronymic] NVARCHAR(80) NOT NULL, 
    [PassportNumber] NVARCHAR(40) NOT NULL,
    [AddressId] INT NOT NULL,
    CONSTRAINT [FK_Subscribers_Addresses] FOREIGN KEY ([AddressId]) REFERENCES [Addresses]([Id]),
)


insert into Subscribers
values
  ('Brady','Barrera','V','450863 282238 5891',38),
  ('Daniel','Garrett','U','367879812233259',50),
  ('Emerson','Finch','Q','3643 815338 26910',9),
  ('Nero','Osborn','U','676781 21 4636 5334 583',82),
  ('Yardley','Day','X','527483 459225 4347',20),
  ('Beck','Dudley','I','3033 248283 86574',59),
  ('Emerson','Hickman','E','6709112873644766',57),
  ('Katelyn','Conley','Y','491375 2877947558',49),
  ('Camilla','Flowers','X','501867 6665775836',86),
  ('Lyle','Roach','Q','490 54232 43772 845',84),
  ('Brian','Moore','B','4929 9329 7734 8475',96),
  ('Daryl','Webb','E','2014 327417 24565',72),
  ('Serina','Morse','J','559 75291 13575 820',73),
  ('Kylee','Wilkinson','R','491157 75 3716 3853 510',12),
  ('Kieran','Gates','J','630473 834491 8626',33),
  ('Carter','Alexander','T','6706661372595336',21),
  ('Marah','Gordon','X','585484 671235 3351',79),
  ('Orlando','Justice','A','364827352814569',16),
  ('Fredericka','House','B','4485 7536 5475 5717',72),
  ('Addison','Hays','B','522564 427581 9245',29),
  ('Vincent','Cain','C','304414757668321',98),
  ('Ocean','Pratt','D','3745 671261 83697',30),
  ('Silas','Sanders','N','3045 493222 15775',73),
  ('Jaquelyn','Scott','Z','471673 386644 7429',26),
  ('Beau','Marshall','A','3738 983675 43781',79),
  ('Rylee','Lester','Z','4917 5354 6783 3858',25),
  ('Nayda','Osborn','B','601134 778464 5527',73),
  ('Madeson','Velez','P','490588 8291486847',42),
  ('Brenda','Salazar','Z','3038 157822 35772',39),
  ('Deacon','Mitchell','R','563934818681',59),
  ('Shad','Austin','I','490542 5836673678',81),
  ('Akeem','Welch','Y','6304 7763 4191 6961',37),
  ('Jolene','England','F','3455 722444 43821',9),
  ('Rudyard','Duke','O','633423 926221 3631',78),
  ('Barry','Kelly','W','304734621455765',28),
  ('Troy','Jones','S','589342626951746637',42),
  ('Tiger','Carter','E','67638524987457474',84),
  ('Stephanie','Baird','A','564182 1834487245',91),
  ('Rose','Clemons','K','4024007155491373',58),
  ('Charity','Curtis','X','214956158686839',31),
  ('Aaron','Kent','P','484 44487 76326 846',85),
  ('Veda','Sexton','W','4556336424552',46),
  ('Caleb','Anderson','G','3725 123561 19831',12),
  ('Amber','Freeman','H','503819275321651',16),
  ('Dorothy','Dennis','S','201452366579755',88),
  ('Abra','Hart','H','5641824365572658',78),
  ('Olga','Burns','R','374657466251715',59),
  ('Allegra','Aguilar','S','367245236364270',21),
  ('Joseph','Hull','M','369743385575421',91),
  ('Nigel','Zamora','H','201436645789525',53),
  ('Whitney','Ball','R','6334475246249468487',67),
  ('Pandora','Wiggins','S','587516867888271752',4),
  ('Aspen','Frank','W','345693759428211',29),
  ('Tatiana','Gomez','C','564 18223 47856 322',65),
  ('Regina','Weeks','T','3683 816681 52310',56),
  ('Sarah','Rodriguez','E','4913 3287 6526 7670',92),
  ('Tasha','Compton','U','535 52386 42472 325',28),
  ('Leah','Dixon','F','656646 372335 5463',19),
  ('Colt','Ashley','H','6709 8755 8652 7623',45),
  ('Daniel','Rich','Q','3711 725771 56558',10),
  ('Cailin','Duffy','X','6462331362629313',42),
  ('Zeph','Wooten','A','6759747619659583',77),
  ('Quinn','Bradley','Q','2014 776772 93861',85),
  ('Alika','Robertson','V','543435 888332 9771',8),
  ('Zelda','Myers','M','5018366655597',59),
  ('Brent','Cortez','T','670923 483527 7533',26),
  ('Fleur','Duran','S','633456 32 7775 2946 984',75),
  ('Lucian','Whitney','V','490 37494 54593 542',24),
  ('Porter','O''connor','Q','3745 666831 22346',33),
  ('Xantha','Sawyer','B','302336663988976',50),
  ('Odette','Alford','G','3476 776557 28871',52),
  ('Keegan','Holden','M','3674 876681 74880',81),
  ('Cullen','Carter','X','651 24792 59588 686',23),
  ('Tyler','Spears','C','4539584838688839',37),
  ('Colby','Cooke','L','4024 007 13 1592',12),
  ('Jana','Gates','N','3732 152783 65776',55),
  ('Christian','Conrad','Y','453 25262 13374 730',41),
  ('Malik','Hayden','U','303867581235669',93),
  ('Walker','Owen','V','363455756418588',58),
  ('Mallory','Ramirez','G','4556652257123',86),
  ('Zoe','Fowler','L','3464 663561 28750',23),
  ('Julie','Espinoza','G','3688 265362 61859',43),
  ('Cyrus','Goff','S','368566683566847',81),
  ('Camden','Blackburn','C','6304 466 75 3668',65),
  ('Cedric','Sears','D','4916 6595 4542 2277',6),
  ('MacKenzie','Shaffer','G','2014 868577 22557',79),
  ('Colette','Erickson','U','491 13793 47434 645',57),
  ('Griffith','Hoffman','V','5374 2432 8316 4220',1),
  ('Ishmael','Massey','W','201448618911432',92),
  ('Reagan','Stout','B','6468667495592579',84),
  ('Justin','Estes','U','3663 299713 35546',8),
  ('Zephania','Davenport','N','676761 2642684562',2),
  ('Aurelia','Cummings','A','647523 253449 6398',85),
  ('Wang','Harding','D','347265383668278',48),
  ('Lionel','Burris','L','2149 327866 12653',22),
  ('Jamal','Terrell','M','676272642831262449',37),
  ('George','Horton','D','3026 374232 33557',70),
  ('Slade','Steele','T','3758 336273 89871',56),
  ('Louis','Mcclure','C','535 48873 28848 363',85),
  ('Odessa','Davis','V','3776 224751 76441',88)


end
go


begin -- Deliveries


CREATE TABLE [dbo].[Deliveries]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY,
	[SubscriberId] INT NOT NULL, 
    [EditionId] INT NOT NULL, 
    [StartSubscribe] DATE NOT NULL, 
    [Term] SMALLINT NOT NULL, 
    CONSTRAINT [CK_Deliveries_Term] CHECK ([Term] >= 1), 
	CONSTRAINT [FK_Deliveries_Subscribers] FOREIGN KEY ([SubscriberId]) REFERENCES [Subscribers]([Id]),
	CONSTRAINT [FK_Deliveries_Editions] FOREIGN KEY ([EditionId]) REFERENCES [Editions]([Id]), 
)


insert into Deliveries
values
  (59,29,'Jun 29, 2021',8),
  (67,4,'Jun 5, 2021',5),
  (80,56,'Feb 3, 2021',3),
  (93,25,'Aug 9, 2022',11),
  (18,37,'Aug 21, 2022',5),
  (97,75,'Jun 9, 2021',3),
  (23,26,'Aug 9, 2022',2),
  (82,99,'Mar 18, 2022',8),
  (43,33,'Feb 11, 2021',4),
  (81,66,'Aug 5, 2022',10),
  (10,11,'Mar 6, 2022',1),
  (81,38,'May 27, 2021',7),
  (19,14,'Jul 5, 2022',9),
  (15,32,'Sep 18, 2021',6),
  (5,31,'Nov 8, 2022',1),
  (94,88,'Jun 11, 2022',8),
  (48,37,'Oct 25, 2022',5),
  (2,52,'Jun 29, 2021',12),
  (72,22,'Jun 28, 2022',8),
  (68,20,'Oct 4, 2021',11),
  (67,55,'Jun 28, 2021',9),
  (31,34,'Oct 6, 2022',5),
  (41,60,'Mar 10, 2022',8),
  (74,25,'Apr 11, 2021',2),
  (40,92,'Jun 11, 2022',5),
  (86,3,'May 4, 2021',9),
  (17,78,'May 16, 2021',8),
  (75,56,'Nov 28, 2020',3),
  (79,13,'Dec 7, 2020',4),
  (74,25,'Aug 17, 2021',9),
  (78,42,'Dec 5, 2020',3),
  (78,22,'Dec 21, 2020',10),
  (20,82,'Sep 27, 2022',12),
  (70,29,'Dec 29, 2021',11),
  (78,14,'Oct 30, 2022',3),
  (83,52,'Jul 30, 2022',2),
  (92,38,'Feb 23, 2022',9),
  (59,23,'May 2, 2021',8),
  (28,4,'Feb 23, 2021',3),
  (40,70,'Dec 3, 2020',3),
  (17,62,'Dec 2, 2021',9),
  (88,56,'Feb 18, 2022',8),
  (50,8,'May 5, 2021',4),
  (13,52,'Dec 7, 2020',5),
  (86,41,'Aug 19, 2022',7),
  (98,11,'Apr 17, 2022',7),
  (76,54,'Sep 19, 2022',5),
  (56,60,'Aug 23, 2021',10),
  (66,21,'Apr 13, 2021',6),
  (37,34,'Aug 28, 2022',6),
  (94,16,'Sep 23, 2022',10),
  (19,9,'May 11, 2022',11),
  (23,36,'Jun 15, 2021',11),
  (75,4,'Jul 22, 2022',7),
  (59,84,'May 31, 2021',4),
  (26,59,'Aug 10, 2021',11),
  (15,32,'Apr 5, 2021',4),
  (7,25,'Aug 29, 2022',10),
  (8,57,'Apr 27, 2021',2),
  (7,84,'Nov 17, 2021',5),
  (5,49,'Sep 6, 2021',10),
  (33,61,'Feb 13, 2022',12),
  (16,73,'Nov 12, 2020',8),
  (49,4,'Aug 19, 2022',2),
  (51,1,'Dec 23, 2020',2),
  (4,29,'Jan 3, 2021',9),
  (44,58,'Feb 6, 2022',4),
  (65,69,'Apr 21, 2022',8),
  (19,64,'Nov 6, 2022',7),
  (91,44,'Jan 19, 2022',7),
  (79,71,'May 3, 2021',4),
  (80,97,'Sep 30, 2022',3),
  (54,52,'Dec 19, 2020',2),
  (58,49,'Jun 26, 2022',6),
  (82,21,'Jun 21, 2022',9),
  (64,43,'Oct 22, 2022',3),
  (64,31,'Dec 31, 2020',3),
  (14,52,'May 11, 2022',11),
  (71,67,'Jan 21, 2021',7),
  (40,41,'Jan 26, 2022',4),
  (66,13,'Aug 24, 2022',3),
  (70,63,'Apr 3, 2022',11),
  (42,91,'Nov 6, 2021',8),
  (60,30,'Feb 11, 2022',2),
  (78,38,'Sep 24, 2022',11),
  (76,4,'Oct 1, 2021',1),
  (37,8,'Sep 15, 2022',4),
  (68,48,'Jun 22, 2022',12),
  (89,57,'Apr 21, 2022',9),
  (46,64,'Sep 18, 2021',12),
  (18,64,'Jun 6, 2022',6),
  (70,68,'Nov 4, 2021',4),
  (89,71,'Feb 20, 2022',8),
  (49,74,'Mar 13, 2021',9),
  (23,81,'Aug 31, 2021',9),
  (47,21,'Dec 26, 2020',9),
  (20,22,'Mar 23, 2022',4),
  (96,79,'Apr 29, 2021',4),
  (5,70,'Sep 17, 2021',7),
  (54,97,'Mar 29, 2022',1)


end
go


CREATE VIEW [dbo].[SubscribersWithAddresses]
	AS 
	select 
        s.Id,
        s.Name,
        s.Surname,
        s.Patronymic,
        s.PassportNumber,
        a.Street,
        a.House,
        a.Apartment
	from Subscribers s
	join Addresses a on s.AddressId = a.Id
go


CREATE VIEW [dbo].[EditionsWithTypes]
	AS 
	select 
        e.Id,
		e.[Index],
		e.Price,
		e.Title,
		t.Type
	from Editions e
	join EditionTypes t on e.EditionTypeId = t.Id
go


CREATE VIEW [dbo].[DeliveriesWithAllKeys]
	AS 
	SELECT 
        d.Id,
        d.StartSubscribe,
        d.Term,
        e.[Index],
        e.Price,
        e.Title,
        e.[Type],
        s.[Name],
        s.Surname,
        s.Patronymic,
        s.PassportNumber,
        s.Street,
        s.House,
        s.Apartment
    FROM Deliveries d
	join EditionsWithTypes e on d.EditionId = e.Id
	join SubscribersWithAddresses s on d.SubscriberId = s.Id
go