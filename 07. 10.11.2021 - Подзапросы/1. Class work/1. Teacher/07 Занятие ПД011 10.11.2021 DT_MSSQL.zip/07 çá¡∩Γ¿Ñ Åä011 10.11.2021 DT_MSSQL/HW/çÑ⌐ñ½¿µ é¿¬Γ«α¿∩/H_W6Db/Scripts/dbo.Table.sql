﻿
-- таблица - название улиц
CREATE TABLE [dbo].[Streets]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [NameStreet] NVARCHAR(80) NOT NULL 
);
go

-- таблица - подписчики
CREATE TABLE [dbo].[Subscribers]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Surname] NVARCHAR(50) NOT NULL, 
    [NameSubscriber] NVARCHAR(40) NOT NULL, 
    [Patronymic] NVARCHAR(60) NOT NULL, 
    [PassportNum] NVARCHAR(10) NOT NULL, 
    [IdStreet] INT NOT NULL, 
    [HouseNum] NVARCHAR(12) NOT NULL, 
    [ApartmentNum] NVARCHAR(12) NOT NULL,
	CONSTRAINT [FK_Subscribers_Streets] FOREIGN KEY ([IdStreet]) REFERENCES [dbo].[Streets] ([Id])
);
go

-- таблица - виды издания
CREATE TABLE [dbo].[TypesOfEdition]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [TypePublication] NVARCHAR(30) NOT NULL
);
go

-- таблица - издания
CREATE TABLE [dbo].[Publications]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [IndexPublication] NVARCHAR(10) NOT NULL, 
    [IdTypePublication] INT NOT NULL, 
    [TitlePublication] NVARCHAR(70) NOT NULL, 
    [PricePublication] FLOAT NOT NULL,
    CONSTRAINT [CK_Publications_PricePublication] CHECK ([PricePublication]>(0)),
	CONSTRAINT [FK_Publications_TypesOfEdotion] FOREIGN KEY ([IdTypePublication]) REFERENCES [dbo].[TypesOfEdotion] ([Id])
);
go

-- таблица - доставка
CREATE TABLE [dbo].[Delivery]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [IdSubscriber] INT NOT NULL, 
    [IdPublication] INT NOT NULL, 
    [DateSubscription] DATE NOT NULL, 
    [TerminSubscription] INT NOT NULL, 
    CONSTRAINT [CK_Delivery_TerminSubscription] CHECK ([TerminSubscription] <= 12),
	CONSTRAINT [FK_Delivery_Subscribers] FOREIGN KEY ([IdSubscriber]) REFERENCES [dbo].[Subscribers] ([Id]),
	CONSTRAINT [FK_Delivery_Publications] FOREIGN KEY ([IdPublication]) REFERENCES [dbo].[Publications] ([Id])
);
go