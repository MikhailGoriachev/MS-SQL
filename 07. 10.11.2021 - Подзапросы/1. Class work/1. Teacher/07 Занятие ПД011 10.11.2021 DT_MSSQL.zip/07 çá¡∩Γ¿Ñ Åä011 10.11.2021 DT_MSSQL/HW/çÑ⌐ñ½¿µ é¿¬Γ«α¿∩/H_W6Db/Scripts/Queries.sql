﻿-- 1. Запрос с параметром
-- Выбирает из таблицы ИЗДАНИЯ информацию о доступных
-- для подписки изданиях заданного типа,
-- стоимость 1 экземпляра для которых меньше заданной.
declare @price float = 1000;
select
    Publications.Id
    , Publications.IndexPublication
    , TypesOfEdotion.TypePublication
    , Publications.TitlePublication
    , Publications.PricePublication
from
    Publications join TypesOfEdotion on Publications.IdTypePublication = TypesOfEdotion.Id
where
    Publications.PricePublication < @price;
go

-- 2. Запрос с параметром
-- Выбирает из таблиц информацию о подписчиках,
-- проживающих на заданной параметром улице и номере дома,
-- которые оформили подписку на издание с заданным параметром наименованием
declare @namestreet nvarchar(30) = N'Артёма', @numHouse nvarchar(10) = N'6', @namePubl nvarchar(50) = N'В гостях у сказки';
select
    Subscribers.Id
    , Subscribers.Surname
    , Subscribers.NameSubscriber
    , Subscribers.Patronymic
    , Subscribers.PassportNum
    , Streets.NameStreet
    , Subscribers.HouseNum
    , Subscribers.ApartmentNum
    , Publications.TitlePublication
from
   Delivery join (Publications join TypesOfEdotion on Publications.IdTypePublication = TypesOfEdotion.Id) 
                      on Delivery.IdPublication = Publications.Id
            join (Subscribers join Streets on Subscribers.IdStreet = Streets.Id)
                      on Delivery.IdSubscriber = Subscribers.Id
where
   Streets.NameStreet = @namestreet and Subscribers.HouseNum = @numHouse and Publications.TitlePublication = @namePubl;
go

-- 3. Запрос с параметром
-- Выбирает из таблицы ИЗДАНИЯ информацию об изданиях,
-- для которых значение в поле Цена 1 экземпляра находится в заданном диапазоне значений
declare @loPrice float = 1000, @hiPrice float = 25000;
select
    Publications.Id
    , Publications.IndexPublication
    , TypesOfEdotion.TypePublication
    , Publications.TitlePublication
    , Publications.PricePublication
from
    Publications join TypesOfEdotion on Publications.IdTypePublication = TypesOfEdotion.Id
where
    Publications.PricePublication between @loPrice and @hiPrice;
go

-- 4. Запрос с параметром
-- Выбирает из таблиц информацию о подписчиках,
-- подписавшихся на заданный параметром тип издания
declare @typeEdition nvarchar(15) = N'газета';
select
    --Subscribers.Id
     Subscribers.Surname
    , Subscribers.NameSubscriber
    , Subscribers.Patronymic
    , Subscribers.PassportNum
    , Streets.NameStreet
    , Subscribers.HouseNum
    , Subscribers.ApartmentNum
    , TypesOfEdotion.TypePublication
from
   Delivery join (Publications join TypesOfEdotion on Publications.IdTypePublication = TypesOfEdotion.Id) 
                      on Delivery.IdPublication = Publications.Id
            join (Subscribers join Streets on Subscribers.IdStreet = Streets.Id)
                      on Delivery.IdSubscriber = Subscribers.Id
where 
   TypesOfEdotion.TypePublication = @typeEdition;
   

-- 5. Запрос с параметром 
-- Выбирает из таблиц ИЗДАНИЯ и ПОДПИСКА информацию обо всех оформленных подписках,
-- для которых срок подписки есть значение из некоторого диапазона.
-- Нижняя и верхняя границы диапазона задаются при выполнении запроса
declare @loTermin int = 2, @hiTermin int = 5;
select
   Publications.IndexPublication
   , Publications.TitlePublication
   , TypesOfEdotion.TypePublication
   , Delivery.TerminSubscription
from
   Delivery join (Publications join TypesOfEdotion on Publications.IdTypePublication = TypesOfEdotion.Id) 
                      on Delivery.IdPublication = Publications.Id
where
   Delivery.TerminSubscription between @loTermin and @hiTermin;
go

-- 6. Запрос с вычисляемыми полями
-- Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС.
-- Включает поля Индекс издания, Наименование издания,
-- Цена 1 экземпляра, Дата начала подписки,
-- Срок подписки, Стоимость подписки без НДС.
-- Сортировка по полю Индекс издания
select
   Publications.IndexPublication
   , Publications.TitlePublication
   , Publications.PricePublication
   , Delivery.DateSubscription
   , Delivery.TerminSubscription
   -- Стоимость подписки может быть вычислена как Цена 1 экземпляра * Срок подписки
   , (Publications.PricePublication * Delivery.TerminSubscription) as PriceSubscription
from
   Delivery join (Publications join TypesOfEdotion on Publications.IdTypePublication = TypesOfEdotion.Id) 
                   on Delivery.IdPublication = Publications.Id
order by
   Publications.IndexPublication
go

-- 7. Итоговый запрос
-- Выполняет группировку по полю Вид издания.
-- Для каждого вида вычисляет максимальную и минимальную цену 1 экземпляра
select
    TypesOfEdotion.TypePublication
    , COUNT(Publications.PricePublication) as AmountPublication
    , MIN(Publications.PricePublication) as MinPrice
    , MAX(Publications.PricePublication) as MaxPrice
from
    Delivery join (Publications join TypesOfEdotion on Publications.IdTypePublication = TypesOfEdotion.Id) 
                 on Delivery.IdPublication = Publications.Id
group by 
   TypesOfEdotion.TypePublication
go


-- 8. Итоговый запрос с левым соединением
-- Выполняет группировку по полю Улица.
-- Для всех улиц вычисляет количество подписчиков,
-- проживающих на данной улице (итоги по полю Код получателя)
select
   Streets.NameStreet
   , COUNT(Subscribers.Id) as AmountSubscribers
from
    (Subscribers join Streets on Subscribers.IdStreet = Streets.Id)
        left join Delivery on Delivery.IdSubscriber = Subscribers.Id
group by
   Streets.NameStreet
go


-- 9. Итоговый запрос с левым соединением
-- Для всех изданий выводит количество оформленных подписок
select
   Delivery.TerminSubscription
   --, Publications.TitlePublication
   , COUNT(Publications.TitlePublication) as AmountSubscriptions
from
   (Publications join TypesOfEdotion on Publications.IdTypePublication = TypesOfEdotion.Id)
             left join Delivery on Delivery.IdPublication = Publications.Id
group by
   Delivery.TerminSubscription
go

-- 10. Запрос на создание базовой таблицы
-- Создает таблицу ПОДПИСЧИКИ_ЖУРНАЛЫ, содержащую информацию о
-- подписчиках изданий, имеющих вид «журнал»
select
    Subscribers.Surname
    , Subscribers.NameSubscriber
    , Subscribers.Patronymic
    , Subscribers.PassportNum
    , Streets.NameStreet
    , Subscribers.HouseNum
    , Subscribers.ApartmentNum
    ,TypesOfEdotion.TypePublication
into
  Subscribers_Magazines
from
   Delivery join (Publications join TypesOfEdotion on Publications.IdTypePublication = TypesOfEdotion.Id) 
                      on Delivery.IdPublication = Publications.Id
            join (Subscribers join Streets on Subscribers.IdStreet = Streets.Id)
                      on Delivery.IdSubscriber = Subscribers.Id
where
   TypesOfEdotion.TypePublication = N'журнал';

-- 11. Запрос на создание базовой таблицы
-- Создает копию таблицы ПОДПИСЧИКИ с именем КОПИЯ_ПОДПИСЧИКИ
select
    *
into
   Copy_Subscribers
from 
   Subscribers;

-- 12. Запрос на удаление
-- Удаляет из таблицы КОПИЯ_ПОДПИСЧИКИ записи,
-- в которых значение в поле Улица равно «Садовая»
delete from
   Copy_Subscribers
from 
   Copy_Subscribers join Streets on Copy_Subscribers.IdStreet = Streets.Id
where
   Streets.NameStreet = N'Садовая';

-- 13. Запрос на обновление
-- Увеличивает значение в поле Цена 1 экземпляра таблицы ИЗДАНИЯ
-- на заданное параметром количество процентов для изданий,
-- заданного параметром вида
declare @percent int = 20;
declare @typePublic nvarchar(15) = N'журнал';
update
    Publications
set
    PricePublication *= 1.2
from
    Publications join TypesOfEdotion on Publications.IdTypePublication = TypesOfEdotion.Id
where
    TypesOfEdotion.TypePublication = @typePublic;
go
   
-- 14. Запрос на обновление
-- В таблице ДОСТАВКА увеличить срок подписки на
-- заданное параметром количество месяцев
declare @numMonths int = 3;
update
   Delivery
set
   TerminSubscription += 3
where
   TerminSubscription < 12;
go
