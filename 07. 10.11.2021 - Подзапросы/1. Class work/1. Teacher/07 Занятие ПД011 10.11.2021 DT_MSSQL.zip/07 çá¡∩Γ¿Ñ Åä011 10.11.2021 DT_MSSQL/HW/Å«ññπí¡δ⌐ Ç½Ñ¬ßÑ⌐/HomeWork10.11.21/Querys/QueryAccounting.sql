﻿-- запросы по заданию

-- 1	Запрос с параметром	
--		Выбирает из таблицы ИЗДАНИЯ информацию о доступных для подписки изданиях заданного типа,
--		стоимость 1 экземпляра для которых меньше заданной.
declare @TypeOfPublications int = 1, 
        @price int = 80;
select
    Publications.Id
    , Publications.[Index]
    , PrintEdition.TypeOfPrintEdition  
    , Publications.NameOfPublications
    , Publications.Price
from
    Publications join PrintEdition on Publications.IdTypeOfPublications = PrintEdition.Id
where
    Publications.Price < @price and Publications.IdTypeOfPublications = @TypeOfPublications
go


--2	    Запрос с параметром	
--      Выбирает из таблиц информацию о подписчиках, проживающих на заданной параметром улице и номере дома, 
--      которые оформили подписку на издание с заданным параметром наименованием
declare @NameOfPublications nvarchar(50) = N'Ведомости', 
        @NameOfStreet nvarchar(60) = N'Артёма',
        @HouseNumber nvarchar(10) = N'5а';
select
    Subscribers.Id
    , Person.Surname
    , Person.[Name]
    , Person.Patronymic
    , StreetType.TypeOfStreet
    , StreetName.NameOfStreet
    , Person.HouseNumber
    , Person.ApartmentNumber
    , PrintEdition.TypeOfPrintEdition
    , Publications.NameOfPublications
from
    Subscribers join (Person join StreetType on Person.IdStreetType = StreetType.id
                             join StreetName on Person.IdStreetName = StreetName.id)
                on Subscribers.IdPerson = Person.Id
                join (Publications join PrintEdition on Publications.IdTypeOfPublications =  PrintEdition.Id)
                on Subscribers.IdPublication = Publications.Id               
where
    Publications.NameOfPublications = @NameOfPublications
    and StreetName.NameOfStreet = @NameOfStreet
    and Person.HouseNumber = @HouseNumber
go


--3	   Запрос с параметром	
--     Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, для которых значение в поле 
--     Цена 1 экземпляра находится в заданном диапазоне значений
declare @lo int = 50, 
        @hi int = 80;
select
    Publications.Id
    , Publications.[Index]
    , PrintEdition.TypeOfPrintEdition  
    , Publications.NameOfPublications
    , Publications.Price
from
    Publications join PrintEdition on Publications.IdTypeOfPublications = PrintEdition.Id
where
    Publications.Price between @lo and @hi
go


--4	    Запрос с параметром	
--      Выбирает из таблиц информацию о подписчиках, подписавшихся на заданный параметром тип издания
declare @TypeOfPublications nvarchar(50) = N'газета';        
select
    Subscribers.Id
    , Person.Surname
    , Person.[Name]
    , Person.Patronymic
    , Person.PassportID
    , StreetType.TypeOfStreet
    , StreetName.NameOfStreet
    , Person.HouseNumber
    , Person.ApartmentNumber
    , PrintEdition.TypeOfPrintEdition
    , Publications.NameOfPublications
from
    Subscribers join (Person join StreetType on Person.IdStreetType = StreetType.id
                             join StreetName on Person.IdStreetName = StreetName.id)
                on Subscribers.IdPerson = Person.Id
                join (Publications join PrintEdition on Publications.IdTypeOfPublications =  PrintEdition.Id)
                on Subscribers.IdPublication = Publications.Id   
where
    PrintEdition.TypeOfPrintEdition = @TypeOfPublications    
go

-- 5	    Запрос с параметром	
--          Выбирает из таблиц ИЗДАНИЯ и ПОДПИСКА информацию обо всех оформленных подписках, 
--          для которых срок подписки есть значение из некоторого диапазона. 
--          Нижняя и верхняя границы диапазона задаются при выполнении запроса
declare @lo int = 6, 
        @hi int = 9;
select
    Subscribers.Id
    , Person.Surname
    , Person.[Name]
    , Person.Patronymic    
    , PrintEdition.TypeOfPrintEdition
    , Publications.NameOfPublications
    , Subscribers.DateStartSubsribe
    , Subscribers.SubscriptionTerm
from
    Subscribers join (Person join StreetType on Person.IdStreetType = StreetType.id
                             join StreetName on Person.IdStreetName = StreetName.id)
                on Subscribers.IdPerson = Person.Id
                join (Publications join PrintEdition on Publications.IdTypeOfPublications =  PrintEdition.Id)
                on Subscribers.IdPublication = Publications.Id               
where
    Subscribers.SubscriptionTerm between @lo and @hi    
go


--6	    Запрос с вычисляемыми полями	
--      Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС. 
--      Включает поля Индекс издания, Наименование издания, Цена 1 экземпляра, Дата начала подписки, 
--      Срок подписки, Стоимость подписки без НДС. Сортировка по полю Индекс издания
select
    Subscribers.Id
    , Person.Surname
    , Person.[Name]
    , Person.Patronymic 
    , Publications.[Index]
    , PrintEdition.TypeOfPrintEdition
    , Publications.NameOfPublications
    , Publications.Price
    , Subscribers.DateStartSubsribe
    , Subscribers.SubscriptionTerm
    , (Publications.Price * Subscribers.SubscriptionTerm)*1.01 as Cost
from
    Subscribers join (Person join StreetType on Person.IdStreetType = StreetType.id
                             join StreetName on Person.IdStreetName = StreetName.id)
                on Subscribers.IdPerson = Person.Id
                join (Publications join PrintEdition on Publications.IdTypeOfPublications =  PrintEdition.Id)
                on Subscribers.IdPublication = Publications.Id    
 order by
    Publications.[Index]    
go


--7	    Итоговый запрос	
--      Выполняет группировку по полю Вид издания. 
--      Для каждого вида вычисляет максимальную и минимальную цену 1 экземпляра
select
    PrintEdition.TypeOfPrintEdition
    , COUNT(Publications.Price) as Amount
    , MIN(Publications.Price) as MinPrice    
    , MAX(Publications.Price) as MaxPrice
from
    Publications join PrintEdition on Publications.IdTypeOfPublications =  PrintEdition.Id
group by
    PrintEdition.TypeOfPrintEdition;
go

--8	    Итоговый запрос с левым соединением	
--      Выполняет группировку по полю Улица. 
--      Для всех улиц вычисляет количество подписчиков, проживающих на данной улице (итоги по полю Код получателя)
select
   StreetName.NameOfStreet
   , COUNT(Subscribers.Id)  as Amount 
   
from   
   (Person join StreetType on Person.IdStreetType = StreetType.id
           join StreetName on Person.IdStreetName = StreetName.id) left join Subscribers on Subscribers.IdPerson = Person.Id     
group by
    StreetName.NameOfStreet;
go


--9	    Итоговый запрос с левым соединением
--      Для всех изданий выводит количество оформленных подписок
select
    PrintEdition.TypeOfPrintEdition
    , COUNT(Subscribers.Id) as Amount
   
from   
    (PrintEdition left join Publications on Publications.IdTypeOfPublications =  PrintEdition.Id) 
     left join Subscribers on Subscribers.IdPublication = Publications.Id     
group by
    PrintEdition.TypeOfPrintEdition;
go


-- 10	Запрос на создание базовой таблицы	
--      Создает таблицу ПОДПИСЧИКИ_ЖУРНАЛЫ, содержащую информацию о подписчиках изданий, имеющих вид «журнал»
select
    Subscribers.IdPerson
    , Subscribers.IdPublication
    , Subscribers.DateStartSubsribe
    , Subscribers.SubscriptionTerm    
    into Subscribers_Magazine
from
     Subscribers join (Publications join PrintEdition on Publications.IdTypeOfPublications =  PrintEdition.Id)
                on Subscribers.IdPublication = Publications.Id   
where
    PrintEdition.TypeOfPrintEdition = N'журнал';
select * from Subscribers_Magazine;
go
-- удаление таблицы ПОДПИСЧИКИ_ЖУРНАЛЫ
drop table Subscribers_Magazine;
go


-- 11	Запрос на создание базовой таблицы	
--      Создает копию таблицы ПОДПИСЧИКИ с именем КОПИЯ_ПОДПИСЧИКИ
select
    *
    into Subscribers_Copy
from
     Subscribers    
select 
    Subscribers_Copy.Id
    , Person.Surname
    , Person.[Name]
    , Person.Patronymic
    , Person.PassportID
    , StreetType.TypeOfStreet
    , StreetName.NameOfStreet
    , Person.HouseNumber
    , Person.ApartmentNumber
    , PrintEdition.TypeOfPrintEdition
    , Publications.NameOfPublications
from 
    Subscribers_Copy join (Person join StreetType on Person.IdStreetType = StreetType.id
                             join StreetName on Person.IdStreetName = StreetName.id)
                on Subscribers_Copy.IdPerson = Person.Id
                join (Publications join PrintEdition on Publications.IdTypeOfPublications =  PrintEdition.Id)
                on Subscribers_Copy.IdPublication = Publications.Id;
go
-- удаление таблицы КОПИЯ_ПОДПИСЧИКИ
drop table Subscribers_Copy;
go


-- 12	Запрос на удаление	
--      Удаляет из таблицы КОПИЯ_ПОДПИСЧИКИ записи, в которых значение в поле Улица равно «Садовая»
select 
    Subscribers_Copy.Id
    , Person.Surname
    , Person.[Name]
    , Person.Patronymic
    , Person.PassportID
    , StreetType.TypeOfStreet
    , StreetName.NameOfStreet
    , Person.HouseNumber
    , Person.ApartmentNumber
    , PrintEdition.TypeOfPrintEdition
    , Publications.NameOfPublications
from  Subscribers_Copy join (Person join StreetType on Person.IdStreetType = StreetType.id
                             join StreetName on Person.IdStreetName = StreetName.id)
                on Subscribers_Copy.IdPerson = Person.Id
                join (Publications join PrintEdition on Publications.IdTypeOfPublications =  PrintEdition.Id)
                on Subscribers_Copy.IdPublication = Publications.Id;
go
delete from 
    Subscribers_Copy
from
     Subscribers_Copy join (Person join StreetType on Person.IdStreetType = StreetType.id
                             join StreetName on Person.IdStreetName = StreetName.id)
                on Subscribers_Copy.IdPerson = Person.Id                
where
    StreetName.NameOfStreet = N'Садовая';
go

select 
    Subscribers_Copy.Id
    , Person.Surname
    , Person.[Name]
    , Person.Patronymic
    , Person.PassportID
    , StreetType.TypeOfStreet
    , StreetName.NameOfStreet
    , Person.HouseNumber
    , Person.ApartmentNumber
    , PrintEdition.TypeOfPrintEdition
    , Publications.NameOfPublications
from 
        Subscribers_Copy join (Person join StreetType on Person.IdStreetType = StreetType.id
                             join StreetName on Person.IdStreetName = StreetName.id)
                on Subscribers_Copy.IdPerson = Person.Id
                join (Publications join PrintEdition on Publications.IdTypeOfPublications =  PrintEdition.Id)
                on Subscribers_Copy.IdPublication = Publications.Id;
go


-- 13	Запрос на обновление	
-- Увеличивает значение в поле Цена 1 экземпляра таблицы ИЗДАНИЯ 
-- на заданное параметром количество процентов для изданий, заданного параметром вида
select
    Publications.Id
    , Publications.[Index]
    , PrintEdition.TypeOfPrintEdition  
    , Publications.NameOfPublications
    , Publications.Price
from
    Publications join PrintEdition on Publications.IdTypeOfPublications = PrintEdition.Id
go

declare @percent float = 6, 
        @TypeOfPublications nvarchar(50) = N'газета';
update
    Publications
set
    Publications.Price *= (1 + @percent/100)
    
from
     Publications join PrintEdition on Publications.IdTypeOfPublications =  PrintEdition.Id
where
    PrintEdition.TypeOfPrintEdition = @TypeOfPublications;

select
    Publications.Id
    , Publications.[Index]
    , PrintEdition.TypeOfPrintEdition  
    , Publications.NameOfPublications
    , Publications.Price
from
    Publications join PrintEdition on Publications.IdTypeOfPublications = PrintEdition.Id
go


-- 14	    Запрос на обновление	
--          В таблице ДОСТАВКА увеличить срок подписки на заданное параметром количество месяцев
declare @addmounts int = 3;
update
    Subscribers
set
    Subscribers.SubscriptionTerm +=@addmounts
    
from
     Delivery join  Subscribers on Delivery.IdPerson = Subscribers.Id
go