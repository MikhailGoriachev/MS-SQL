﻿-- Создание всех таблиц проекта

-- удаление существующих таблиц, работает в MS SQL Server 2016+
drop table if exists Delivery;
drop table if exists Person;
drop table if exists PrintEdition;
drop table if exists Publications;
drop table if exists StreetType;
drop table if exists StreetName;
drop table if exists Subscribers;
go

-- таблица списка изданий
CREATE TABLE [dbo].[PrintEdition]
(
	[Id] INT NOT NULL PRIMARY KEY Identity (1, 1), 
    [TypeOfPrintEdition] NVARCHAR(50) NOT NULL
)

-- таблица для типов улиц
CREATE TABLE [dbo].[StreetType]
(
	[Id] INT NOT NULL PRIMARY KEY Identity (1, 1), 
    [TypeOfStreet] NVARCHAR(50) NOT NULL
)

-- таблица для наименования улиц
CREATE TABLE [dbo].[StreetName]
(
	[Id] INT NOT NULL PRIMARY KEY Identity (1,1), 
    [NameOfStreet] NVARCHAR(60) NOT NULL,
)


-- таблица персон
CREATE TABLE [dbo].[Person]
(
	[Id] INT NOT NULL PRIMARY KEY Identity (1, 1), 
    [Surname] NVARCHAR(50) NOT NULL, 
    [Name] NVARCHAR(50) NOT NULL, 
    [Patronymic] NVARCHAR(50) NOT NULL, 
    [PassportID] NVARCHAR(15) NOT NULL, 
    [IdStreetType] INT NOT NULL,
    [IdStreetName] INT NOT NULL,
	[HouseNumber] NVARCHAR(10) NOT NULL, 
    [ApartmentNumber] NVARCHAR(10) NULL, 
    CONSTRAINT [FK_Person_StreetType] FOREIGN KEY ([IdStreetType]) REFERENCES [StreetType]([Id]), 
    CONSTRAINT [FK_Person_StreetName] FOREIGN KEY ([IdStreetName]) REFERENCES [StreetName]([Id]),
)

-- таблица изданий
CREATE TABLE [dbo].[Publications] (
    [Id]              INT           IDENTITY (1, 1) NOT NULL,
    [Index] NVARCHAR(20) NOT NULL, 
    [IdTypeOfPublications] INT NOT NULL, 
    [NameOfPublications] NVARCHAR(50) NOT NULL, 
    [Price] INT NOT NULL, 
    PRIMARY KEY CLUSTERED ([Id] ASC), 
    CONSTRAINT [FK_Publications_PrintEdition] FOREIGN KEY ([IdTypeOfPublications]) REFERENCES [PrintEdition]([Id])
);

-- таблица подписчиков
CREATE TABLE [dbo].[Subscribers] (
    [Id]              INT           IDENTITY (1, 1) NOT NULL,
    [IdPerson] INT NOT NULL, 
    [IdPublication] INT NOT NULL, 
    [DateStartSubsribe] DATE NOT NULL, 
    [SubscriptionTerm] INT NOT NULL, 
    PRIMARY KEY CLUSTERED ([Id] ASC), 
    CONSTRAINT [CK_Subscribers_SubscriptionTerm] CHECK (SubscriptionTerm in (3,6,9,12)), 
    CONSTRAINT [FK_Subscribers_Person] FOREIGN KEY ([IdPerson]) REFERENCES [Person]([Id]), 
    CONSTRAINT [FK_Subscribers_Publication] FOREIGN KEY ([IdPublication]) REFERENCES [Publications]([Id])
);


CREATE TABLE [dbo].[Delivery] (
    [Id]              INT           IDENTITY (1, 1) NOT NULL,
	[IdPerson] INT NOT NULL, 
    [IdPublication] INT NOT NULL, 
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Delivery_Person] FOREIGN KEY (IdPerson) REFERENCES [Person]([Id]), 
    CONSTRAINT [FK_Delivery_Publication] FOREIGN KEY (IdPublication) REFERENCES [Publications]([Id])
);

