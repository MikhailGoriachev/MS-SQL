﻿-- запросы к таблицам базы данных

-- Таблица Streets
select 
    *
from
    Streets;


-- Таблица PublicationTypes
select
    *
from
    PublicationTypes;


-- Таблица Subscribers с расшифровкой поля IdStreet
select
    Subscribers.Id
    , Subscribers.Surname      as SubscriberSurname
    , Subscribers.[Name]       as SubscriberName
    , Subscribers.Patronymic   as SubscriberPatronymic
    , Subscribers.PassportID 
    , Streets.StreetName 
    , Subscribers.HouseNum 
    , Subscribers.ApartmentNum  
from
    Subscribers join Streets on Subscribers.IdStreet = Streets.Id;


-- Таблица Publications с расшифровкой поля IdType
select
    Publications.Id
    , Publications.[Index]
    , Publications.Title
    , PublicationTypes.PubType
    , Publications.Price  
from
    Publications join PublicationTypes on Publications.IdType = PublicationTypes.Id;


-- таблица Deliveries с расшифровкой полей IdPatient, IdDoctor
select
    Deliveries.Id
    -- данные о подписчике
    -- Фамилия И. О. подписчика
    , Subscribers.Surname + N' ' 
    + Substring(Subscribers.[Name], 1, 1) + N'. '
    + Substring(Subscribers.Patronymic, 1, 1) +  N'. ' as Subscriber
    , Streets.StreetName 
    , Subscribers.HouseNum 
    , Subscribers.ApartmentNum 
    -- данные об издании
    , Publications.Title  as Publication
    , PublicationTypes.PubType
    , Publications.Price 
    -- данные о доставке
    , Deliveries.StartDate
    , Deliveries.Duration
from
    Deliveries 
        join (Subscribers join Streets on Subscribers.IdStreet = Streets.Id) 
             on Deliveries.IdSubscriber = Subscribers.Id
        join (Publications join PublicationTypes on Publications.IdType = PublicationTypes.Id)
             on Deliveries.IdPublication = Publications.Id;
go

-- ------------------------------------------------------------------------

--1. Запрос с параметром	
--   Выбирает из таблицы ИЗДАНИЯ информацию о доступных
--   для подписки изданиях заданного типа, стоимость 1 
--   экземпляра для которых меньше заданной.
declare @price int = 100;
select
    Publications.Id
    , Publications.[Index]
    , Publications.Title
    , PublicationTypes.PubType
    , Publications.Price  
from
    Publications join PublicationTypes on Publications.IdType = PublicationTypes.Id
where 
    Publications.Price < @price;
go


--2. Запрос с параметром	
--   Выбирает из таблиц информацию о подписчиках, 
--   проживающих на заданной параметром улице и номере дома, 
--   которые оформили подписку на издание с заданным параметром наименованием
declare @street nvarchar(50) = N'ул. Зайцева',
        @house nvarchar(10) = N'134А', 
        @title nvarchar(150) = N'Вечерняя Макеевка';
select
    Deliveries.Id
    -- данные о подписчике
    , Subscribers.Surname      as SubscriberSurname
    , Subscribers.[Name]       as SubscriberName
    , Subscribers.Patronymic   as SubscriberPatronymic
    , Subscribers.PassportID 
    , Streets.StreetName 
    , Subscribers.HouseNum 
    , Subscribers.ApartmentNum  
    -- данные об издании
    , Publications.Title  as Publication
from
    Deliveries 
        join (Subscribers join Streets on Subscribers.IdStreet = Streets.Id) 
             on Deliveries.IdSubscriber = Subscribers.Id
        join Publications on Deliveries.IdPublication = Publications.Id
where
    Streets.StreetName = @street and
    Subscribers.HouseNum = @house and
    Publications.Title = @title;
go

--3. Запрос с параметром	
--   Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, 
--   для которых значение в поле Цена 1 экземпляра находится
--   в заданном диапазоне значений
declare @lo int = 100, @hi int = 200;
select
    Publications.Id
    , Publications.[Index]
    , Publications.Title
    , PublicationTypes.PubType
    , Publications.Price  
from
    Publications join PublicationTypes on Publications.IdType = PublicationTypes.Id
where 
    Publications.Price between @lo and @hi;
go


--4. Запрос с параметром	
--   Выбирает из таблиц информацию о подписчиках, 
--   подписавшихся на заданный параметром тип издания
declare @type nvarchar(50) = N'газета';
select
    Deliveries.Id
    -- данные о подписчике
    , Subscribers.Surname      as SubscriberSurname
    , Subscribers.[Name]       as SubscriberName
    , Subscribers.Patronymic   as SubscriberPatronymic
    , Subscribers.PassportID 
    , Streets.StreetName 
    , Subscribers.HouseNum 
    , Subscribers.ApartmentNum  
    -- данные об издании
    , Publications.Title  as Publication
    , PublicationTypes.PubType
from
    Deliveries 
        join (Subscribers join Streets on Subscribers.IdStreet = Streets.Id) 
             on Deliveries.IdSubscriber = Subscribers.Id
        join (Publications join PublicationTypes on Publications.IdType = PublicationTypes.Id)
             on Deliveries.IdPublication = Publications.Id
where
    PublicationTypes.PubType = @type;
go


--5. Запрос с параметром	
--   Выбирает из таблиц ИЗДАНИЯ и ПОДПИСКА информацию 
--   обо всех оформленных подписках, для которых срок
--   подписки есть значение из некоторого диапазона. 
--   Нижняя и верхняя границы диапазона задаются при выполнении запроса
select
    Deliveries.Id
    -- данные о подписчике
    -- Фамилия И. О. подписчика
    , Subscribers.Surname + N' ' 
    + Substring(Subscribers.[Name], 1, 1) + N'. '
    + Substring(Subscribers.Patronymic, 1, 1) +  N'. ' as Subscriber
    , Streets.StreetName 
    , Subscribers.HouseNum 
    , Subscribers.ApartmentNum 
    -- данные об издании
    , Publications.Title  as Publication
    , PublicationTypes.PubType
    , Publications.Price 
    -- данные о доставке
    , Deliveries.StartDate
    , Deliveries.Duration
from
    Deliveries 
        join (Subscribers join Streets on Subscribers.IdStreet = Streets.Id) 
             on Deliveries.IdSubscriber = Subscribers.Id
        join (Publications join PublicationTypes on Publications.IdType = PublicationTypes.Id)
             on Deliveries.IdPublication = Publications.Id 
where
    Duration between 9 and 12;


--6. Запрос с вычисляемыми полями	
--   Вычисляет для каждой оформленной подписки ее стоимость 
--   с доставкой и без НДС. Включает поля Индекс издания, 
--   Наименование издания, Цена 1 экземпляра, Дата начала подписки,
--   Срок подписки, Стоимость подписки без НДС. Сортировка по полю Индекс издания
select
    Deliveries.Id
    -- данные об издании
    , Publications.[Index]
    , Publications.Title
    , Publications.Price 
    -- данные о доставке
    , Deliveries.StartDate
    , Deliveries.Duration
    -- Стоимость подписки = Цена 1 экземпляра * Срок подписки
    -- Клиент платит почтовому отделению 1% от стоимости подписки за доставку
    , Publications.Price * Deliveries.Duration * 1.01 as SubscriptionCost
from
    Deliveries join Publications on Deliveries.IdPublication = Publications.Id
order by
    Publications.[Index];


--7. Итоговый запрос	
--   Выполняет группировку по полю Вид издания.
--   Для каждого вида вычисляет максимальную и 
--   минимальную цену 1 экземпляра
-- Таблица Publications с расшифровкой поля IdType
select
    PublicationTypes.PubType
    , MIN(Publications.Price) as MinPrice  
    , MAX(Publications.Price) as MaxPrice  
from
    PublicationTypes left join Publications on Publications.IdType = PublicationTypes.Id
group by
    PublicationTypes.PubType;


--8. Итоговый запрос с левым соединением	
--   Выполняет группировку по полю Улица.
--   Для всех улиц вычисляет количество подписчиков, 
--   проживающих на данной улице (итоги по полю Код получателя)
select
    Streets.StreetName 
    , COUNT(Subscribers.Id) as Amount  
from
    Streets left join Subscribers on Subscribers.IdStreet = Streets.Id
group by
    Streets.StreetName


--9. Итоговый запрос с левым соединением	
--   Для всех изданий выводит количество оформленных подписок
select
    Publications.Title  as Publication
    , COUNT(Deliveries.Id) as Amount
from
    Publications left join Deliveries on Deliveries.IdPublication = Publications.Id 
group by
    Publications.Title


--10. Запрос на создание базовой таблицы	
--    Создает таблицу ПОДПИСЧИКИ_ЖУРНАЛЫ,
--    содержащую информацию о подписчиках изданий,
--    имеющих вид «журнал»
select
    Subscribers.Surname
    , Subscribers.[Name]
    , Subscribers.Patronymic
    , Streets.StreetName 
    , Subscribers.HouseNum 
    , Subscribers.ApartmentNum 
	into Subscribers_Magazine
from
    Deliveries 
        join (Subscribers join Streets on Subscribers.IdStreet = Streets.Id) 
             on Deliveries.IdSubscriber = Subscribers.Id
        join (Publications join PublicationTypes on Publications.IdType = PublicationTypes.Id)
             on Deliveries.IdPublication = Publications.Id
where
    PublicationTypes.PubType = N'журнал';

-- демонстрация созданной таблицы
select * from Subscribers_Magazine;
    


--11. Запрос на создание базовой таблицы	
--    Создает копию таблицы ПОДПИСЧИКИ с именем КОПИЯ_ПОДПИСЧИКИ
select
    Subscribers.Id
    , Subscribers.Surname
    , Subscribers.[Name]
    , Subscribers.Patronymic
    , Subscribers.PassportID 
    , Streets.StreetName 
    , Subscribers.HouseNum 
    , Subscribers.ApartmentNum  
	into Copy_Subscribers
from
    Subscribers join Streets on Subscribers.IdStreet = Streets.Id;

-- демонстрация созданной таблицы
select * from Copy_Subscribers;


--12. Запрос на удаление	
--    Удаляет из таблицы КОПИЯ_ПОДПИСЧИКИ записи, 
--    в которых значение в поле Улица равно «Садовая»
delete from
    Copy_Subscribers 
where 
    StreetName = N'Садовая';


--13. Запрос на обновление	
--    Увеличивает значение в поле Цена 1 экземпляра таблицы ИЗДАНИЯ
--    на заданное параметром количество процентов для изданий,
--    заданного параметром вида

declare @percent float = 1.2, @typeId int = 2;
-- таблица до обновления
select
    Publications.Id
    , Publications.[Index]
    , Publications.Title
    , PublicationTypes.PubType
    , Publications.Price  
from
    Publications join PublicationTypes on Publications.IdType = PublicationTypes.Id
where 
    Publications.IdType = @typeId; 

-- запрос на обновление 
update
    Publications 
set
    Price *= @percent
where
    Publications.IdType = @typeId; 

-- таблица после обновления
select
    Publications.Id
    , Publications.[Index]
    , Publications.Title
    , PublicationTypes.PubType
    , Publications.Price  
from
    Publications join PublicationTypes on Publications.IdType = PublicationTypes.Id
where 
    Publications.IdType = @typeId; 
go


--14. Запрос на обновление	
--    В таблице ДОСТАВКА увеличить срок подписки 
--    на заданное параметром количество месяцев
declare @month int = 3;

update
    Deliveries
set
    Duration += @month; 

