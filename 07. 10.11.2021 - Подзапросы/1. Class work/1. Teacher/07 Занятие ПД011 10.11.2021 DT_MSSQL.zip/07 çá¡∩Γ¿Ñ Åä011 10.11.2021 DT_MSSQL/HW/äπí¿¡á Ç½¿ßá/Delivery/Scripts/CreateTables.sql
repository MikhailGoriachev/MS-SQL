﻿-- Создание таблиц базы данных


-- удаление существующих таблиц
drop table if exists Deliveries;
drop table if exists Publications;
drop table if exists Subscribers;
drop table if exists PublicationTypes;
drop table if exists Streets;
go


-- Таблица - названия улиц
CREATE TABLE [dbo].[Streets] (
    [Id]         INT           NOT NULL PRIMARY KEY IDENTITY (1, 1),
    [StreetName] NVARCHAR (60) NOT NULL, -- название улицы
);
go


-- Таблица - виды издания 
CREATE TABLE [dbo].[PublicationTypes] (
    [Id]      INT           NOT NULL PRIMARY KEY IDENTITY (1, 1),
    [PubType] NVARCHAR (20) NOT NULL -- вид издания
);
go


-- Таблица сведений о подписчиках ПОДПИСЧИКИ --> Subscribers
CREATE TABLE [dbo].[Subscribers] (
    [Id]           INT           NOT NULL PRIMARY KEY IDENTITY (1, 1),
    [Surname]      NVARCHAR (70) NOT NULL,  -- Фамилия подписчика
    [Name]         NVARCHAR (70) NOT NULL,  -- Имя подписчика
    [Patronymic]   NVARCHAR (70) NOT NULL,  -- Отчество подписчика
    [PassportID]   INT           NOT NULL,  -- Номер паспорта подписчика
    [IdStreet]     INT           NOT NULL,  -- Улица
    [HouseNum]     NVARCHAR (8)  NOT NULL,  -- Номер дома
    [ApartmentNum] INT           NOT NULL,  -- Номер квартиры
    CONSTRAINT [FK_Subscribers_Streets] FOREIGN KEY ([IdStreet]) REFERENCES [dbo].[Streets] ([Id]),
    CONSTRAINT [CK_Subscribers_ApartmentNum] CHECK ([ApartmentNum]>(0))
);
go


-- Таблица сведений об изданиях ИЗДАНИЯ --> Publications
CREATE TABLE [dbo].[Publications] (
    [Id]     INT            NOT NULL PRIMARY KEY IDENTITY (1, 1),
    [Index]  INT            NOT NULL,   -- Индекс издания по каталогу
    [Title]  NVARCHAR (150) NOT NULL,   -- Наименование издания
    [IdType] INT            NOT NULL,   -- Вид издания 
    [Price]  FLOAT          NOT NULL,   -- Цена 1 экземпляра
    CONSTRAINT [FK_Publications_PublicationTypes] FOREIGN KEY ([IdType]) REFERENCES [dbo].[PublicationTypes] ([Id]),
    CONSTRAINT [CK_Publications_Pricce] CHECK ([Price]>(0)),
    CONSTRAINT [CK_Publications_Index] CHECK ([Index]>=(0))
);
go


-- Таблица сведений о доставках ДОСТАВКА --> Deliveries
CREATE TABLE [dbo].Deliveries (
	[Id]            INT  NOT NULL PRIMARY KEY IDENTITY, 
    [IdSubscriber]  INT  NOT NULL, -- данные о подписчике
    [IdPublication] INT  NOT NULL, -- данные об издании
	[StartDate]     DATE NOT NULL, -- дата начала подписки 
    [Duration]      INT  NOT NULL, -- Срок подписки (количество месяцев)
    CONSTRAINT [CK_Deliveries_Duration] CHECK (Duration > 0), 
    CONSTRAINT [FK_Deliveries_Subscribers] FOREIGN KEY (IdSubscriber) REFERENCES Subscribers(Id), 
    CONSTRAINT [FK_Deliveries_Publications] FOREIGN KEY (IdPublication) REFERENCES Publications(Id)
)
go