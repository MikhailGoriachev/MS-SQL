﻿CREATE TABLE [dbo].[Streets] (
    [Id]      INT  PRIMARY KEY IDENTITY(1,1),
    [Streets] NVARCHAR(60) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

