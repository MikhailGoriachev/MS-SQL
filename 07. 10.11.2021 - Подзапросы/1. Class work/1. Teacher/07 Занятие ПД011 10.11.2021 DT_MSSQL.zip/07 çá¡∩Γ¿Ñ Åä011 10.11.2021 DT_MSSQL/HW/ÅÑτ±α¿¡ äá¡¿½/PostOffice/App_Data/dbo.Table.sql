﻿CREATE TABLE [dbo].[Subscribers]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Surname] NVARCHAR(60) NOT NULL, 
    [Name] NVARCHAR(60) NOT NULL, 
    [Patronymic] NVARCHAR(60) NOT NULL, 
    [Street_Id] INT NOT NULL
)
