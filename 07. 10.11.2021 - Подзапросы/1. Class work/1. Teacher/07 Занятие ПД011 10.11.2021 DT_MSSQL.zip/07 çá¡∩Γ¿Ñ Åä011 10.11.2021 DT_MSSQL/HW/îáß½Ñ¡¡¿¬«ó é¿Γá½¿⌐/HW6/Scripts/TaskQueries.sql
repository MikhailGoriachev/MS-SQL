﻿


--1	Запрос с параметром	
--Выбирает из таблицы ИЗДАНИЯ информацию о доступных для подписки изданиях заданного типа,
--стоимость 1 экземпляра для которых меньше заданной.
declare @price int = 600;

select 
	Publications.Id,
	PubTypes.PubType		as PublicationType,
	Publications.Title		as PublicationTitle,
	Publications.PubIndex	as PublicationIndex,
	Publications.Price		as PublicationPrice
from dbo.Publications join PubTypes on Publications.IdPubType = PubTypes.Id
where Publications.Price < @price;


--2	Запрос с параметром
--Выбирает из таблиц информацию о подписчиках, проживающих на заданной параметром улице и номере дома,
--которые оформили подписку на издание с заданным параметром наименованием
declare @street nvarchar(60) = N'ул. Судовая';
declare @building int    = 112;
declare @publication nvarchar(120) = N'Известия';

select 
		Subscribers.Id,
		Subscribers.Surname,
		Subscribers.Name,
		Subscribers.Patronymic,
		Subscribers.Passport,
		Streets.StreetName,
		Subscribers.BuildingNum,
		Subscribers.AppartNum
from Deliveries join (Subscribers join Streets on Subscribers.IdStreetName = Streets.Id)
					on Deliveries.IdSubscriber = Subscribers.Id
				join Publications on Deliveries.IdPublication = Publications.Id
where Streets.StreetName = @street and Subscribers.BuildingNum = @building and Publications.Title = @publication;
go


--3	Запрос с параметром	
--из таблицы ИЗДАНИЯ информацию об изданиях, для которых значение в поле Цена 1 экземпляра
--находится в заданном диапазоне значений
declare @lo int = 300, @hi int = 700;

select 
	Publications.Id,
	PubTypes.PubType,
	Publications.Title,
	Publications.PubIndex,
	Publications.Price
from Publications join PubTypes on Publications.IdPubType = PubTypes.Id
where Publications.Price between @lo and @hi;
go

--4	Запрос с параметром
--Выбирает из таблиц информацию о подписчиках, подписавшихся на заданный параметром тип издания
declare @pubType nvarchar(40) = N'Газета';

select
		Subscribers.Id,
		Subscribers.Surname,
		Subscribers.Name,
		Subscribers.Patronymic,
		Subscribers.Passport,
		Streets.StreetName,
		Subscribers.BuildingNum,
		Subscribers.AppartNum
from	Deliveries join (Subscribers join Streets on Subscribers.IdStreetName = Streets.Id)
					on Deliveries.IdSubscriber = Subscribers.Id
				   join (Publications join PubTypes on Publications.IdPubType = PubTypes.Id)
					on Deliveries.IdPublication = Publications.Id
where   PubTypes.PubType = @pubType;
go


--5	Запрос с параметром
--Выбирает из таблиц ИЗДАНИЯ и ПОДПИСКА информацию обо всех оформленных подписках,
--для которых срок подписки есть значение из некоторого диапазона.
--Нижняя и верхняя границы диапазона задаются при выполнении запроса
declare @lo int = 4, @hi int = 8;

select 
	Deliveries.Id,
	Subscribers.Surname,
	Subscribers.Name,
	Subscribers.Patronymic,
	Subscribers.Passport,
	Streets.StreetName,
	Subscribers.BuildingNum,
	Subscribers.AppartNum,
	Deliveries.StartDate,
	Deliveries.Duration,
	PubTypes.PubType,
	Publications.Title,
	Publications.PubIndex
from Deliveries join (Subscribers join Streets on Subscribers.IdStreetName = Streets.Id)
					on Deliveries.IdSubscriber = Subscribers.Id
				   join (Publications join PubTypes on Publications.IdPubType = PubTypes.Id)
					on Deliveries.IdPublication = Publications.Id
where Deliveries.Duration between @lo and @hi;
go


--6	Запрос с вычисляемыми полями
--Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС.
--Включает поля Индекс издания, Наименование издания, Цена 1 экземпляра, Дата начала подписки,
--Срок подписки, Стоимость подписки без НДС.
--Сортировка по полю Индекс издания 
select
	Publications.PubIndex as PublicationIndex, 
	Publications.Title	  as PublicationTitle,
	Publications.Price	  as PublicationPrice,
	Deliveries.StartDate  as SubscribeStartDate,
	Deliveries.Duration   as SubcsribeDuration,
	(Publications.Price * Deliveries.Duration) as CostWithoutVAT,  -- общая цена подписки без НДС
	(Publications.Price * Deliveries.Duration + (Deliveries.Duration * (Publications.Price * 0.01))) 
												as CostWithDelivieryWithoutVAT -- общая цена подписки без с доставкой НДС
from Deliveries join (Subscribers join Streets on Subscribers.IdStreetName = Streets.Id)
					on Deliveries.IdSubscriber = Subscribers.Id
				   join (Publications join PubTypes on Publications.IdPubType = PubTypes.Id)
					on Deliveries.IdPublication = Publications.Id
order by PublicationIndex
go


--7	Итоговый запрос
--Выполняет группировку по полю Вид издания. Для каждого вида вычисляет максимальную и минимальную цену 1 экземпляра

select
	PubTypes.PubType as PublicatioType,
	COUNT(Publications.Price) as Amount,
	MIN(Publications.Price) as MinPrice,
	MAX(Publications.Price) as MaxPrice

from Publications join PubTypes on Publications.IdPubType = PubTypes.Id
group by PubTypes.PubType;

--8	Итоговый запрос с левым соединением	
--Выполняет группировку по полю Улица. Для всех улиц вычисляет количество подписчиков,
--проживающих на данной улице (итоги по полю Код получателя)

select
    Streets.StreetName as Street,
    COUNT(Streets.StreetName) as Amount
from
    Subscribers left join Streets on Subscribers.IdStreetName = Streets.Id
group by
    Streets.StreetName;

--9	Итоговый запрос с левым соединением
--Для всех изданий выводит количество оформленных подписок	
select 
	PubTypes.PubType as PubType,
	COUNT(PubTypes.PubType) as Amount
from Deliveries left join (Publications join PubTypes on Publications.IdPubType = PubTypes.Id)
				on Deliveries.IdPublication = Publications.Id
group by PubTypes.PubType;
go

--group by PubTypes.PubType;
--10	Запрос на создание базовой таблицы
--Создает таблицу ПОДПИСЧИКИ_ЖУРНАЛЫ, содержащую информацию о подписчиках изданий, имеющих вид «журнал»
declare @type nvarchar(40) = N'Журнал';
select 
		Subscribers.Id,
		Subscribers.Surname,
		Subscribers.Name,
		Subscribers.Patronymic,
		Subscribers.Passport,
		Streets.StreetName,
		Subscribers.BuildingNum,
		Subscribers.AppartNum
into Subscribers_Journal

from Deliveries join (Subscribers join Streets on Subscribers.IdStreetName = Streets.Id)
					on Deliveries.IdSubscriber = Subscribers.Id
				join (Publications join PubTypes on Publications.IdPubType = PubTypes.Id)
					on Deliveries.IdPublication = Publications.Id

where PubTypes.PubType = @type;
go


--11	Запрос на создание базовой таблицы
--Создает копию таблицы ПОДПИСЧИКИ с именем КОПИЯ_ПОДПИСЧИКИ	
select *
into Subscribers_copy
from Subscribers;
go


--12	Запрос на удаление
--Удаляет из таблицы КОПИЯ_ПОДПИСЧИКИ записи, в которых значение в поле Улица равно «Садовая»
declare @street nvarchar(60) = N'пр. Ленинский';

delete from Subscribers_copy
from Subscribers_copy
	join Streets
	on Subscribers_copy.IdStreetName = Streets.Id
where  Streets.StreetName = @street;
go


--14	Запрос на обновление
--В таблице ДОСТАВКА увеличить срок подписки на заданное параметром количество месяцев

declare @monthsAdd int = 3;

update Deliveries
set Duration += @monthsAdd;
