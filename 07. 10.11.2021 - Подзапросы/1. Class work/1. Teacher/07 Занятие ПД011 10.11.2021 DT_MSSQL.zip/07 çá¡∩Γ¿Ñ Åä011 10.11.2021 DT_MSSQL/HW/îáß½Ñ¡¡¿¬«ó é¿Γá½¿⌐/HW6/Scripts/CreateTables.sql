﻿


--drop table if exists PubTypes
--drop table if exists Streets
--drop table if exists Subscribers
--drop table if exists Publications
--drop table if exists Deliveries



-- Таблица типов изданий
create table dbo.PubTypes (
	Id          int          not null primary key identity (1, 1),
	PubType  nvarchar(40) not null    -- название типа издания
);
go

-- Таблица названий улиц
create table dbo.Streets (
	Id          int          not null primary key identity (1, 1),
	StreetName  nvarchar(60) not null    -- название улицы
);
go

-- Таблица подписчиков
create table dbo.Subscribers (
	Id            int          not null primary key identity (1, 1),
	Surname       nvarchar(60) not null,    -- Фамилия 
	[Name]        nvarchar(50) not null,    -- Имя 
	Patronymic    nvarchar(60) not null,    -- Отчество 
	Passport	  nvarchar(10) not null,    -- Номер паспорта
	IdStreetName  int		   not null,   -- Внешний ключ, связь со справочником названий улиц
	BuildingNum   nvarchar(10) not null,   -- Номер дома
	AppartNum	  nvarchar(10) not null    -- Номер квартиры

	-- внешний ключ к таблице улиц
	constraint FK_Subscribers_Streets foreign key (IdStreetName) references dbo.Streets(Id)
);
go

-- Таблица изданий
create table dbo.Publications (
	Id          int          not null primary key identity (1, 1),
	IdPubType	int          not null,	 -- Внешний ключ, связь со справочником типов изданий
	Title		nvarchar(120) not null,  -- Наименование издания
	PubIndex    nvarchar(5)  not null,   -- Индекс издания по каталогу
    Price		int not null,			 -- Цена за месяц подписки

	constraint [CK_Publications_Price] check (Price > 0), 
	constraint [FK_Publications_PubTypes] foreign key (IdPubType) references dbo.PubTypes(Id)
);
go

-- Таблица доставок
create table dbo.Deliveries(
	Id            int  not null primary key identity (1, 1),
	IdSubscriber  int  not null,	-- Внешний ключ, связь с таблицей подписчиков
	IdPublication int  not null,    -- Внешний ключ, связь с таблицей изданий
	StartDate     Date not null,    -- Дата начала подписки
	Duration      int  not null,	-- Срок подписки (количество месяцев)

	constraint [CK_Deliveries_Duration] check (Duration > 0), 
	constraint [FK_Deliveries_Subscribers] foreign key (IdSubscriber) references dbo.Subscribers(Id),
	constraint [FK_Deliveries_Publications] foreign key (IdPublication) references dbo.Publications(Id)
);
go