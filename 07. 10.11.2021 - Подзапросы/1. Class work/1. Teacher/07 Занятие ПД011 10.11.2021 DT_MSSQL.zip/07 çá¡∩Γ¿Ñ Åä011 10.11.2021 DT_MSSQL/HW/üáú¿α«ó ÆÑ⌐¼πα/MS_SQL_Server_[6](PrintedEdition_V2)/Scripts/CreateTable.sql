﻿ -- ==================>  Создание таблиц  <==================

-- удаление существующих таблиц, работает в MS SQL Server 2016+
drop table if exists Delivery;
drop table if exists Subscribers;
drop table if exists Editions;
drop table if exists Streets;
drop table if exists HouseNumbers;
drop table if exists GoodsEditions;
drop table if exists TypeEditions;
go


 -- ================== Создание таблицы "Подписчики" и всех прилежащих таблиц ==================

-- Таблица хранящая название улицы
create table dbo.Streets(
	Id		    int              not null primary key identity(1,1),
	Street      nvarchar(70)     not null -- название улицы
);
go

-- Таблица хранящая номер дома (возможно не стоило выносить в отдельную таблицу) 
create table dbo.HouseNumbers(
	Id		    int              not null primary key identity(1,1),
	HouseNumber nvarchar(30)     not null  -- номер дома
);
go

 -- Основная таблица "Подписчики"
create table dbo.Subscribers(
	Id               int            not null  primary key identity(1,1),
	Surname          nvarchar (60)  not null, -- Фамилия
	[Name]           nvarchar (50)  not null, -- Имя
	Patronymic       nvarchar (60)  not null, -- Отчество
	Passport         int			not null, -- Номер паспорта (6 цифр)
	IdStreet         int		    not null, -- Внешний ключ. Связь с таблицей улиц (Streets)
	IdHouseNumber    int			not null, -- Внешний ключ. Связь с таблицей номеров домов(HouseNumbers)
	ApartmentNumber  nvarchar(15)   not null, -- Номер квартиры
															       
	-- Проверка паспорта на кол-во цифр (Подписчиками только граждани Рос. федерации)
	-- не проживающие на автономной территории
	constraint CK_Subscribers_Passport check(Passport between 100000 and 999999),


	-- внешний ключ - связь М:1 к таблице Streets(улица)
	constraint FK_Subscribers_Streets foreign key (IdStreet) references dbo.Streets (Id),
	constraint FK_Subscribers_HouseNumbers foreign key (IdHouseNumber) references dbo.HouseNumbers(Id),
);
go



-- ================== Создание таблицы "Издания" и всех прилежащих таблиц ==================
 
 -- Таблица вида издания 
create table dbo.TypeEditions(
	Id		     int          not null primary key identity(1,1),
	TypeEdition  nvarchar(40) not null  -- Вид издания (газета, журнал, альманах...)
);
go

-- Таблица товара (издания)
create table dbo.GoodsEditions(
	Id		       int           not null primary key identity(1,1),
	[Name]         nvarchar(100) not null,   -- Наименование товара
	IdTypeEdition  int           not null,	 -- Вид товара(издания)
	Price          float		 not null    -- Цена 1 экземпляра

	-- Проверка стоимоти товара за 1 экземпляр
	constraint CK_GoodsEditions_Price check (Price > 0),

	-- внешний ключ - связь М:1 к таблице TypeEditions(Вид издания)
	constraint FK_GoodsEditions_TypeEditions foreign key (IdTypeEdition) references dbo.TypeEditions(Id)
);
go
  

-- Основная таблица "Издания" (каталог изданий) 
create table dbo.Editions(
	Id			    int          not null primary key identity(1,1),
	IndexEditions   nvarchar(10) not null,	-- id издания
	IdGoodsEditions int			 not null   -- Внешний ключ. Связь с таблицей товаров(изданий)(GoodsEditions)

	-- внешний ключ - связь 1:1 к таблице GoodsEditions(товар (издания))
	constraint FK_Editions_GoodsEditions foreign key (IdGoodsEditions) references dbo.GoodsEditions(Id)
);
go
 
-- ================== Создание таблицы "Доставка" ==================

-- Основная таблица "Доставка" (или подписка)  
create table dbo.Delivery(
	Id               int  not null primary key identity (1,1),
	IdSubscriber     int  not null,  -- Внешний ключ. Связь с таблицей подписчиков (Subscribers)
	IdEdition        int  not null,	 -- Внешний ключ. Связь с таблицей издания (каталог изданий) (Editions)
	SubscriptionDate Date not null,	 -- Дата начала подписки
	SubDuration      int  not null	 -- Длительность подписки (в месяцах)

	-- Ограничения на ввод данных 
	constraint CK_Delivery_SubDuration      check (SubDuration between 1 and 12),

	-- внешний ключ - связь М:1 к таблице Subscribers(подписчик) (e.g.: 1 подписчик может иметь много доставок(подписок))
	constraint FK_Delivery_Subscribers foreign key (IdSubscriber) references dbo.Subscribers(Id),
	-- внешний ключ - связь М:1 к таблице Editions(издания (каталог изданий) )
	constraint FK_Delivery_Editions foreign key (IdEdition) references dbo.Editions(Id)
);
go

 
