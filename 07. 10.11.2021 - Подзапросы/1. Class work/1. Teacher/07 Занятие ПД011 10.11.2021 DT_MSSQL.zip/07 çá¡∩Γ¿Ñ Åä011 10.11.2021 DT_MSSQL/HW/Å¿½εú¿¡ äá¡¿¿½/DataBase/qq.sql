﻿
--ЗАПРОСЫ

--1.Выбирает из таблицы ИЗДАНИЯ информацию о доступных для подписки 
--изданиях заданного типа, стоимость 1 экземпляра для которых меньше заданной.
select 
	Pubs.Id
	,EditionName
	,EditionType
	,Pubs.Cost
from Pubs join EditionNames on Pubs.idEditionName = EditionNames.Id
		  join EditionTypes on Pubs.idEditionType = EditionTypes.Id
where EditionType = N'Журнал' and Pubs.Cost < 400
--2.Выбирает из таблиц информацию о подписчиках, проживающих на заданной 
--параметром улице и номере дома, которые оформили подписку на издание с 
--заданным параметром наименованием
select
	Subs.Id
	,PName
	,PSurname
	,PPatronymic
	,Street
	,NumHouse
	,EditionName
from Delivs join (Subs join PNames on Subs.idName = PNames.Id
					   join PSurnames on Subs.idSurname = PSurnames.Id
					   join PPatronymics on Subs.idPatronymic = PPatronymics.Id
					   join Streets on Subs.idStreet = Streets.Id)
					on Delivs.idSub = Subs.Id
			join (Pubs join EditionNames on Pubs.idEditionName = EditionNames.Id)
					on Delivs.idPub = Pubs.Id
where Street = N'Свободы' and NumHouse = N'23B' and EditionName = N'Утренний Донецк'


--3.Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, для которых значение 
--в поле Цена 1 экземпляра находится в заданном диапазоне значений
select 
	EditionName
	,EditionType
	,Cost
from Pubs join EditionNames on Pubs.idEditionName = EditionNames.Id
			join EditionTypes on Pubs.idEditionType = EditionTypes.Id
where Cost between 300 and 400
--4.Выбирает из таблиц информацию о подписчиках, подписавшихся на заданный 
--параметром тип издания
declare @editName nvarchar = N'Утренний Донецк'
select
	Subs.Id
	,PName
	,PSurname
	,PPatronymic
	,Street
	,NumHouse
	,EditionName
from Delivs join (Subs join PNames on Subs.idName = PNames.Id
					   join PSurnames on Subs.idSurname = PSurnames.Id
					   join PPatronymics on Subs.idPatronymic = PPatronymics.Id
					   join Streets on Subs.idStreet = Streets.Id)
					on Delivs.idSub = Subs.Id
			join (Pubs join EditionNames on Pubs.idEditionName = EditionNames.Id)
					on Delivs.idPub = Pubs.Id
--where EditionName like @editName;
where EditionName like N'Утренний Донецк';
--5.Выбирает из таблиц ИЗДАНИЯ и ПОДПИСКА информацию обо всех оформленных 
--подписках, для которых срок подписки есть значение из некоторого диапазона. 
--Нижняя и верхняя границы диапазона задаются при выполнении запроса
select
	PName
	,PSurname
	,PPatronymic
	,EditionName
	,EditionType
	,DateOfSub
from Delivs join (Subs join PNames on Subs.idName = PNames.Id
					   join PSurnames on Subs.idSurname = PSurnames.Id
					   join PPatronymics on Subs.idPatronymic = PPatronymics.Id
					   join Streets on Subs.idStreet = Streets.Id)
					on Delivs.idSub = Subs.Id
			join (Pubs join EditionNames on Pubs.idEditionName = EditionNames.Id
					   join EditionTypes on Pubs.idEditionType = EditionTypes.Id)
					on Delivs.idPub = Pubs.Id
where DateOfSub between '2021-11-01' and '2021-11-04';
--6.Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС. 
--Включает поля Индекс издания, Наименование издания, Цена 1 экземпляра, Дата начала 
--подписки, Срок подписки, Стоимость подписки без НДС. Сортировка по полю Индекс издания
select
	Pubs.Id					as [Индекс издания]
	,EditionName			as [Наименование издания]
	,Cost					as [Цена 1 экземпляра]
	,DateOfSub				as [Дата начала подписки]
	,Term					as [Срок подписки]
	,(Cost * Term) * 1.01	as [Стоимость подписки без НДС]
from 
	Delivs join (Pubs join EditionNames on Pubs.idEditionName = EditionNames.Id
					   join EditionTypes on Pubs.idEditionType = EditionTypes.Id)
					on Delivs.idPub = Pubs.Id
--7.Выполняет группировку по полю Вид издания. Для каждого вида вычисляет максимальную 
--и минимальную цену 1 экземпляра
select 
	EditionType
	,Max(Cost)	as Max
	,Min(Cost)	as Min
from
	Delivs join (Pubs join EditionTypes on Pubs.idEditionType = EditionTypes.Id)
					on Delivs.idPub = Pubs.Id
group by EditionType
--8.Выполняет группировку по полю Улица. Для всех улиц вычисляет количество подписчиков, 
--проживающих на данной улице (итоги по полю Код получателя)
--9.Для всех изданий выводит количество оформленных подписок
--10.Создает таблицу ПОДПИСЧИКИ_ЖУРНАЛЫ, содержащую информацию о подписчиках изданий, 
--имеющих вид «журнал»
--11.Создает копию таблицы ПОДПИСЧИКИ с именем КОПИЯ_ПОДПИСЧИКИ
--12.Удаляет из таблицы КОПИЯ_ПОДПИСЧИКИ записи, в которых значение в поле Улица равно 
--«Садовая»
--13.Увеличивает значение в поле Цена 1 экземпляра таблицы ИЗДАНИЯ на заданное параметром 
--количество процентов для изданий, заданного параметром вида
--14.В таблице ДОСТАВКА увеличить срок подписки на заданное параметром количество месяцев
update Delivs
set Term += 2
select 
	Delivs.Term
from Delivs
	
	
