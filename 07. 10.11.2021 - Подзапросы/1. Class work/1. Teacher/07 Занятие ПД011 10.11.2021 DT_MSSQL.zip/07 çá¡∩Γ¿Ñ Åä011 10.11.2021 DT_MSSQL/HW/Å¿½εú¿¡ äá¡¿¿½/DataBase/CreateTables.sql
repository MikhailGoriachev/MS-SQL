﻿
--СКРИПТ СОЗДАНИЯ ТАБЛИЦ

--создание таблицы видов издания
CREATE TABLE [dbo].[EditionTypes]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [EditionType] NVARCHAR(20) NOT NULL
)

go

--создание таблицы Наименований (название) изданий
CREATE TABLE [dbo].[EditionNames]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    EditionName NVARCHAR(60) NOT NULL
)

go

--создание таблицы имен
CREATE TABLE [dbo].PNames
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    PName NVARCHAR(40) NOT NULL
)

go

--создание таблицы фамилий
CREATE TABLE [dbo].PSurnames
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    PSurname NVARCHAR(40) NOT NULL
)

go

--создание таблицы отчеств
CREATE TABLE [dbo].PPatronymics
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    PPatronymic NVARCHAR(40) NOT NULL
)

go

--создание таблицы улиц
CREATE TABLE [dbo].Streets
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    Street NVARCHAR(60) NOT NULL
)

go


--создание таблицы изданий
CREATE TABLE [dbo].[Pubs] (
    [Id]               INT        IDENTITY (1, 1) NOT NULL,
    [idEditionName]    INT        NOT NULL,
    [idEditionType]    INT        NOT NULL,
    [Cost]             INT        NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Pubs_EditNames] FOREIGN KEY ([idEditionName]) REFERENCES [dbo].[EditionNames] ([Id]),
    CONSTRAINT [FK_Pubs_EditTypes] FOREIGN KEY ([idEditionType]) REFERENCES [dbo].[EditionTypes] ([Id]),
                   
    CONSTRAINT [CK_Pubs_idEditionName] CHECK ([idEditionName]>(0)),
    CONSTRAINT [CK_Pubs_idEditionType] CHECK ([idEditionType]>(0)),
    CONSTRAINT [CK_Pubs_Cost] CHECK (Cost>(0))
);

go

--создание таблицы подписчиков
CREATE TABLE [dbo].[Subs] (
    [Id]               INT        IDENTITY (1, 1) NOT NULL,
    [idName]           INT        NOT NULL,
    [idSurname]        INT        NOT NULL,
    [idPatronymic]     INT        NOT NULL,
    [NumberOfPassport] INT        NOT NULL,
    [idStreet]         INT        NOT NULL,
    [NumHouse]         NCHAR (10) NOT NULL,
    [NumApartment]     NCHAR (10) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Subs_Names] FOREIGN KEY ([idName]) REFERENCES [dbo].[PNames] ([Id]),
    CONSTRAINT [FK_Subs_Surnames] FOREIGN KEY ([idSurname]) REFERENCES [dbo].[PSurnames] ([Id]),
    CONSTRAINT [FK_Subs_Patronymics] FOREIGN KEY ([idPatronymic]) REFERENCES [dbo].[PPatronymics] ([Id]),
    CONSTRAINT [FK_Subs_Streets] FOREIGN KEY ([idStreet]) REFERENCES [dbo].[Streets] ([Id]),

    CONSTRAINT [CK_Subs_idName] CHECK ([idName]>(0)),
    CONSTRAINT [CK_Subs_idSurname] CHECK ([idSurname]>(0)),
    CONSTRAINT [CK_Subs_idPatronymic] CHECK ([idPatronymic]>(0)),
    CONSTRAINT [CK_Subs_idStreet] CHECK ([idStreet]>(0))
);

go

--создание таблицы доставки
CREATE TABLE [dbo].[Delivs] (
    [Id]               INT        IDENTITY (1, 1) NOT NULL,
    [idSub]            INT        NOT NULL,
    [idPub]            INT        NOT NULL,
    [DateOfSub]        DATE       NOT NULL,
    [Term]             INT        NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Delivs_Sub] FOREIGN KEY ([idSub]) REFERENCES [dbo].[Subs] ([Id]),
    CONSTRAINT [FK_Delivs_Pud] FOREIGN KEY ([idPub]) REFERENCES [dbo].[Pubs] ([Id]),
                   
    CONSTRAINT [CK_Delivs_Sub] CHECK ([idSub]>(0)),
    CONSTRAINT [CK_Delivs_Pub] CHECK ([idPub]>(0)),
    CONSTRAINT [CK_Delivs_Term] CHECK ([Term]>(0))
);


--drop table Delivs
--drop table Subs
--drop table Pubs
--drop table EditionTypes
--drop table EditionNames
--drop table PNames
--drop table PSurnames
--drop table PPatronymics
--drop table Streets
