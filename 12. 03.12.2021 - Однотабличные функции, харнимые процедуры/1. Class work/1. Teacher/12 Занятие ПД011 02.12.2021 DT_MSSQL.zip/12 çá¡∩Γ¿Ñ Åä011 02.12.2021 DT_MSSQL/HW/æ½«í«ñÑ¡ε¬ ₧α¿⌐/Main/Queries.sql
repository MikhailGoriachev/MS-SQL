﻿-- 1
-- Вывести все фильмы, вышедшие на экран в текущем и прошлом году.
declare @currentYear int = Year(GetDate())
declare @previousYear int = @currentYear - 1

select * from Movies
where Year(Movies.ReleaseDate) between @previousYear and @currentYear

go


-- 2
-- Вывести информацию об актерах, снимавшихся в заданном фильме.
declare @filmTitle nvarchar(max) = 'a tortor. Nunc commodo'

select Persons.* 
from MoviesActors
join Persons on MoviesActors.ActorId = Persons.Id
where MoviesActors.MovieId = (select Id from Movies where Title = @filmTitle)

go


-- 3
-- Вывести информацию об актерах, снимавшихся как минимум в N фильмах.
declare @min int = 2

select 
	Persons.*,
	FilmsCount
from Persons
join (select 
		MoviesActors.ActorId,
		Count(MoviesActors.ActorId) as FilmsCount
	  from MoviesActors
	  group by MoviesActors.ActorId) as Actors 
on Actors.ActorId = Persons.Id
where Actors.FilmsCount >= @min

go


-- 4
-- Вывести информацию об актерах, которые были режиссерами хотя бы одного из фильмов.
select 
	Persons.*
from Movies
join Persons on Movies.ProducerId = Persons.Id
where Movies.ProducerId in (select MoviesActors.ActorId from MoviesActors)

go


-- 5
-- Вывести все фильмы, дата выхода которых была более заданного числа лет назад.
declare @years int = 0,
		@currentYear int = Year(GetDate())

select * from Movies
where (@currentYear - Year(Movies.ReleaseDate)) > @years

go


-- 6
-- Вывести всех актеров и количество фильмов, в которых они участвовали.
select 
	Persons.*,
	Actors.FilmsCount
from Persons
left join (select 
				MoviesActors.ActorId,
				Count(MoviesActors.MovieId) as FilmsCount
		   from MoviesActors
           group by MoviesActors.ActorId) as Actors
on Persons.Id = Actors.ActorId

go


-- 7
-- Скалярная функция. Вывести количество актеров в заданном по названию фильме.
declare @title nvarchar(max) = 'a tortor. Nunc commodo'

select 
	@title as Title,
	dbo.CountActorsInMovie(@title) as ActorsCount

go


-- 8
-- Скалярная функция. Вывести суммарный бюджет фильмов заданного режиссера.
declare @producerId int = 83

select 
	@producerId as ProducerId,
	dbo.GetProducerTotalBudget(@producerId) as TotalBudget