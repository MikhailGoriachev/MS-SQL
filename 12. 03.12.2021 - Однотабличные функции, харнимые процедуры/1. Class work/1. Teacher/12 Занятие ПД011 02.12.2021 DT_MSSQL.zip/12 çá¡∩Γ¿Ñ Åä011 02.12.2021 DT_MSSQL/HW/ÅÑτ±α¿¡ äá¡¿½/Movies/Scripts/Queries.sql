﻿select 
* 
from 
     Actors join Persons on Actors.IdPersons = Persons.Id

--•	Вывести все фильмы, вышедшие на экран в текущем и прошлом году.
declare @that date = '2020-01-01',  @this date = '2021-12-01'
select 
   Id
   ,Title
   ,ReleaseDate
 from 
      Movies
where 
      ReleaseDate between @that and @this 

--Представления для актеров и режиссеров


--•	Вывести информацию об актерах, снимавшихся в заданном фильме.
declare @movie nvarchar(40) = N'Дюна'
declare @movieid int = (select 
  Id 
from 
      Movies
where 
     Title = @movie)

select 
    Id
   ,[Name]
   ,Surname
   ,Patronymic
   ,BirthDate
from 
    MoviesActors join ActorsView on ActorsView.Id = MoviesActors.IdActor
 where
     MoviesActors.IdMovie = @movieid 

--•	Вывести информацию об актерах, снимавшихся как минимум в N фильмах.
declare @number int = 2
select 
   Id
  ,[Name]
  , Surname
  , Patronymic
  , ActorCount
  
 from
      Persons join (select IdActor, Count(IdActor) as ActorCount from MoviesActors group by IdActor) as ActorTable on IdActor = Persons.Id
 where 
      ActorCount >= @number

-- •	Вывести информацию об актерах, которые были режиссерами хотя бы одного из фильмов.
    select 
       Movies.IdDirector
       , [Name]
       , Surname
       , Patronymic
       , BirthDate
    from 
        Movies join DirectorsView on Movies.IdDirector = DirectorsView.Id
    where 
         DirectorsView.PersonId in 
         (select IdActor from MoviesActors 
            join ActorsView on MoviesActors.IdActor = ActorsView.Id)