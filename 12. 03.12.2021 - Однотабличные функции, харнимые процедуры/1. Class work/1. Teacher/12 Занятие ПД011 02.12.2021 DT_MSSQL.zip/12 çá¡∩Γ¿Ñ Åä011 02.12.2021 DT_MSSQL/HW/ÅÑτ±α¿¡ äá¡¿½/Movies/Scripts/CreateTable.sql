﻿--БД домашняя видеотека 

drop table if exists dbo.MoviesActors
drop table if exists dbo.Movies
drop table if exists dbo.Actors
drop table if exists dbo.Directors
drop table if exists dbo.Countries
drop table if exists dbo.Persons
drop table if exists dbo.Genres

-- Таблица данных о персонах 
create table dbo.Persons 
(
     Id int not null Primary key Identity(1,1), 
     [Name] nvarchar(60) not null, 
     Surname nvarchar(60) not null,
     Patronymic nvarchar(60) not null, 
     BirthDate date not null, 
); 
go 

-- Таблица с режиссерами 
create table dbo.Directors 
(
      Id int not null Primary key Identity(1,1),
      IdPersons int not null,

      constraint FK_Directors_Persons foreign key (IdPersons) references dbo.Persons(Id),

);
go 

--Таблица с актерами 
create table dbo.Actors 
(
      Id int not null Primary key Identity(1,1), 
      IdPersons int not null, 

      constraint FK_Actors_Persons foreign key (IdPersons) references dbo.Persons(Id),
);
go 

-- Таблица жанров фильмов 
create table dbo.Genres 
( 
    Id int not null Primary key Identity(1,1), 
    Genre nvarchar(20) not null, 
); 
go

--Таблица стран-производителей фильмов

create table dbo.Countries 
(
     Id int not null Primary key Identity(1,1), 
     Country nvarchar (20) not null, 
);
go

--Таблица фильмов 
create table dbo.Movies
(
   Id int not null Primary key Identity(1,1), 
   Title nvarchar(40) not null, 
   IdDirector int not null, 
   ReleaseDate date not null, 
   IdGenre int not null, 
   Budget int not null, 
   IdCountry int not null, 

   --внешние ключи 
   constraint FK_Movies_Directors foreign key (IdDirector) references dbo.Directors(Id), 
   constraint FK_Movies_Genres foreign key (IdGenre) references dbo.Genres(Id),
   constraint FK_Movies_Country foreign key (IdCountry) references dbo.Countries(Id),
);
go

--Таблица-посредник для связи "многие ко многим" между фильмами и актерами
create table MoviesActors 
(
     IdMovie int not null, 
     IdActor int not null, 

     primary key (IdMovie, IdActor),

     -- внешние ключи
     constraint FK_MovieActors_Actors foreign key (IdMovie) references dbo.Movies(Id), 
     constraint FK_MovieActors_Movie foreign key(IdActor) references dbo.Actors(Id), 

); 
go