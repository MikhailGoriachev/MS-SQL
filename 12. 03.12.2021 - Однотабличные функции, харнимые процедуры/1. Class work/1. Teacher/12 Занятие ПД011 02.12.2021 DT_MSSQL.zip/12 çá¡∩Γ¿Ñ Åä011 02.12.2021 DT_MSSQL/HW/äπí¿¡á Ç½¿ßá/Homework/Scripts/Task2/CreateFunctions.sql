﻿---------------------------- Создание функций для задачи 2 ----------------------------

-- Скалярная функция, возвращающая количество актеров в
-- заданном по названию фильме
drop function if exists NumActors;
go

-- Получить количество актеров в заданном по названию фильме
create function NumActors(@film nvarchar(120)) returns int
as
begin
	return ( select count(*) from ViewActors where title = @film);
end
go

-- Скалярная функция, возвращающая суммарный бюджет фильмов заданного режиссера
drop function if exists SumBudget;
go

create function SumBudget(@surname nvarchar(60), @name nvarchar(60), @patronymic nvarchar(60))
    returns float
	as
	begin
		return (select 
					Sum(ViewFilms.Budget) 
				from 
					ViewFilms 
				where 
					ProducerName = @name and 
					ProducerSurname = @surname and 
					ProducerPatronymic = @patronymic); 
	end;
go
