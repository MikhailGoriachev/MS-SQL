﻿-------------------------------------- Задача 2 --------------------------------------

-- Вывести все фильмы, вышедшие на экран в текущем и прошлом году.
select
	Title
	, Genre
	, Country
	, ReleaseDate
from
	ViewFilms
where
	year(ReleaseDate) in (year(GETDATE()), year(GETDATE())-1);
go


-- Вывести информацию об актерах, снимавшихся в заданном фильме.
declare @film nvarchar(120) = N'Невидимый гость';
select
	ActorName
	, ActorSurname
	, ActorPatronymic
	, ActorDOB
from 
	ViewActors
where
	Title = @film;
go


-- Вывести информацию об актерах, снимавшихся как минимум в N фильмах.
declare @n int = 3;
select
	ActorName
	, ActorSurname
	, ActorPatronymic
	, ActorDOB
	, COUNT(*) as AmountFilms
from 
	ViewActors
group by
	ActorName
	, ActorSurname
	, ActorPatronymic
	, ActorDOB
having 
	COUNT(*) >= @n;
go


-- Вывести информацию об актерах, которые были режиссерами хотя бы одного из фильмов.
select
	ActorName
	, ActorSurname
	, ActorPatronymic
	, ActorDOB
from 
	ViewActors
where
	ViewActors.IdActor in (select IdProducer from ViewFilms);
go


-- Вывести все фильмы, дата выхода которых была более заданного числа лет назад.
declare @n int = 10;
select
	Title
	, Genre
	, Country
	, ReleaseDate
from
	ViewFilms
where
	year(GETDATE()) - year(ReleaseDate) > @n;
go


-- Вывести всех актеров и количество фильмов, в которых они участвовали.
select
	ActorName
	, ActorSurname
	, ActorPatronymic
	, ActorDOB
	, COUNT(*) as AmountFilms
from 
	ViewActors
group by
	ActorName
	, ActorSurname
	, ActorPatronymic
	, ActorDOB
go


-- Скалярная функция. Вывести количество актеров в заданном по названию фильме.
-- применение функции
select dbo.NumActors(N'Невидимый гость') as AmountActors;
go


-- Скалярная функция. Вывести суммарный бюджет фильмов заданного режиссера
-- применение функции
select dbo.SumBudget(N'Князьков', N'Степан', N'Сидорович') as SumBudget;
go