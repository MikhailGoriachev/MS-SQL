﻿---------------------------- Создание функций для задачи 1 ----------------------------

-- Proc17. Описать функцию RootsCount(A, B, C) целого типа, определяющую
--         количество корней квадратного уравнения A·x2 + B·x + C = 0 
--         (A, B, C — вещественные параметры). 
--         Количество корней определять по значению дискриминанта:
--         D = B^2 − 4·A·C.
drop function if exists dbo.RootsCount;
go

create function RootsCount(@a float, @b float, @c float)
    returns int
	as
	begin
		-- расчет дискриминанта
	    declare @d float = @b * @b - 4 * @a * @c;
		declare @roots int = case 
								when  @d > 0 then 2
								when  @d = 0 then 1
								else  0
							 end;
		return @roots;
	end
go


-- Proc18. Описать функцию CircleS(R) вещественного типа, 
--         находящую площадь круга радиуса R (R — вещественное).
--         Площадь круга радиуса R вычисляется по формуле S = π·R^2.
drop function if exists dbo.CircleS;
go

create function CircleS(@r float)
    returns float
	as
	begin
		return @r * @r * Pi();
	end
go


-- Proc19. Описать функцию RingS(R1, R2) вещественного типа, находящую 
--         площадь кольца, заключенного между двумя окружностями с общим 
--         центром и радиусами R1, R2 (R1 и R2 — вещественные, R1 > R2, 
--         при нарушении этого условия возвращайте -1). 
--         Воспользоваться формулой площади круга радиуса R: 
--         S = π·R2.
drop function if exists dbo.RingS;
go

create function RingS(@r1 float, @r2 float)
    returns float
	as
	begin
		declare @res float;

		if @r1 < @r2 
			set @res = -1;
		else 
			-- C использование функции CircleS
			set @res = dbo.CircleS(@r1) - dbo.CircleS(@r2);
			-- Без использования функции CircleS
			-- set @res = @r1 * @r1 * Pi() - @r2 * @r2 * Pi();

		return @res;
	end
go


-- Proc28. Описать функцию IsPrime(N) логического типа, возвращающую TRUE,
--         если целый параметр N (> 1, при нарушении условия возвращать FALSE)
--         является простым числом, и FALSE в противном случае 
--         (число, большее 1, называется простым, если оно не имеет положительных 
--         делителей, кроме 1 и самого себя). 
drop function if exists dbo.IsPrime;
go

create function IsPrime(@n int)
    returns bit
	as
	begin
		if @n < 1 return 0;

		declare @i int = 2;

		while @i < SQRT(@n) begin
			if @n % @i = 0 return 0;
			set @i += 1;
		end;

		return 1;
	end
go


-- Proc36. Описать функцию Fib(N) целого типа, вычисляющую N-й элемент 
--         последовательности чисел Фибоначчи FK, которая описывается
--         следующими формулами:
--                F1 = 1, F2 = 1, FK = FK−2 + FK−1, K = 3, 4, ... 
drop function if exists dbo.Fib;
go

create function Fib(@n int)
    returns int
	as
	begin
		if @n < 1 return 0;

		declare @i int = 0
				, @f1 int = 0
				, @f2 int = 1
				, @res int = 1;

		while @i < @n - 1 begin
			set @res = @f1 + @f2;
			set @f1 = @f2;
			set @f2 = @res;
			set @i += 1;
		end;

		return @res;
	end
go