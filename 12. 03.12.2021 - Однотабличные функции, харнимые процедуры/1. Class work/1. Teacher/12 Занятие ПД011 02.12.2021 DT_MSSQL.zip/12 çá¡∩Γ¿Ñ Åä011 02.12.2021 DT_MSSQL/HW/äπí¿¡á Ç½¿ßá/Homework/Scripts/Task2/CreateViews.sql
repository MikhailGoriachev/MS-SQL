﻿drop view if exists ViewFilms;
drop view if exists ViewActors;
go
-- создание представления для фильмов
create view ViewFilms as
    select
        Films.Title
        , Films.Id 
        , Films.IdProducer
        , Films.ReleaseDate
        , Films.Budget
        , Countries.Country
        , Genres.Genre
        , Persons.[Name]  as ProducerName
        , Persons.Surname as ProducerSurname
        , Persons.Patronymic as ProducerPatronymic
        , Persons.DateOfBirth as ProducerDOB
    from
        Films join Persons on Films.IdProducer = Persons.Id
              join Countries on Films.IdCountry = Countries.Id
              join Genres on Films.IdGenre = Genres.Id;
go

-- создание представления для актеров
create view ViewActors as
    select
        Actors.IdActor
        , Persons.[Name]  as       ActorName
        , Persons.Surname as     ActorSurname
        , Persons.Patronymic as  ActorPatronymic
        , Persons.DateOfBirth as ActorDOB
        , ViewFilms.Title
        , ViewFilms.ReleaseDate
        , ViewFilms.Budget
        , ViewFilms.Country
        , ViewFilms.Genre
        , ViewFilms.ProducerName
        , ViewFilms.ProducerSurname
        , ViewFilms.ProducerPatronymic
        , ViewFilms.ProducerDOB
    from
        Actors join Persons on Actors.IdActor = Persons.Id
               join ViewFilms on Actors.IdFilm = ViewFilms.Id;
go