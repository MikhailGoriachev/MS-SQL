﻿drop table if exists dbo.Casts;
drop table if exists dbo.Movies;
drop table if exists dbo.Actors;
drop table if exists dbo.Directors;
drop table if exists dbo.Persons;
drop table if exists dbo.Genres;
drop table if exists dbo.Countries;

-- таблица стран-производителей
create table dbo.Countries (
	Id          int          not null primary key identity (1, 1),
	Country		nvarchar(30) not null
);
go

-- таблица жанров
create table dbo.Genres (
	Id          int          not null primary key identity (1, 1),
	Genre		nvarchar(20) not null
);
go

-- общие данные актёров и режиссеров
create table dbo.Persons (
	Id          int          not null primary key identity (1, 1),
	[Name]      nvarchar(60) not null,    -- Имя персоны
	Surname     nvarchar(60) not null,    -- Фамилия персоны
	Patronymic  nvarchar(60) not null,    -- Отчество персоны
	BirthDate   date		 not null	  -- Дата рождения
);
go

-- таблица актёров
create table dbo.Actors (
	Id          int          not null primary key identity (1, 1),
	IdPerson	int			 not null,        -- ФИО актёра, внеший ключ к таблице персон

	-- внешний ключ - связь 1:1 к таблице Persons
	constraint FK_Actors_Persons foreign key (IdPerson) references dbo.Persons(Id),
);
go

-- таблица режиссеров
create table dbo.Directors (
	Id          int          not null primary key identity (1, 1),
	IdPerson	int			 not null,        -- ФИО режиссёра, внеший ключ к таблице персон

	-- внешний ключ - связь 1:1 к таблице Persons
	constraint FK_Directors_Persons foreign key (IdPerson) references dbo.Persons(Id),
);
go

-- таблица данных о фильмах
create table dbo.Movies (
	Id          int          not null primary key identity (1, 1),
	Title		nvarchar(100)not null, -- название фильма
	IdDirector	int			 not null, -- режиссер
	ReleaseDate date		 not null, -- дата выхода
	IdGenre		int			 not null, -- жанр
	Budget		int			 not null, -- бюджет
	IdCountry	int			 not null, -- страна-производитель

	-- внешние ключи - к таблицам режиссёров, жанров, стран-производителей
	constraint FK_Movies_Directors foreign key (IdDirector) references dbo.Directors(Id),
	constraint FK_Movies_Genres foreign key (IdGenre) references dbo.Genres(Id),
	constraint FK_Movies_Countries foreign key (IdCountry) references dbo.Countries(Id)

);
go

-- таблица составов актёров в фильмах
create table dbo.Casts (
	Id          int          not null primary key identity (1, 1),
	IdMovie		int			 not null, -- внешний ключ к таблице фильмов
	IdActor		int          not null, -- внешний ключ к таблице актёров

	constraint FK_Casts_Actors foreign key (IdActor) references dbo.Actors(Id),
	constraint FK_Casts_Movies foreign key (IdMovie) references dbo.Movies(Id)
);
go

