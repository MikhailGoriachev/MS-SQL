﻿
drop view if exists ViewMovies;
go

-- представление таблицы фильмов
create view ViewMovies as 
	select
	Movies.Id
	, Movies.Title
	, PDirectors.Name       as DirectorName
	, PDirectors.Surname	as DirectorSurname
	, PDirectors.Patronymic	as DirectorPatronymic	
	, Movies.ReleaseDate
	, Genres.Genre
	, Movies.Budget
	, Countries.Country
	from
		Movies join Genres on Genres.Id = Movies.IdGenre
			   join (Directors join Persons as PDirectors on PDirectors.Id = Directors.IdPerson) on Directors.Id = Movies.IdDirector
			   join Countries on Countries.Id = Movies.IdCountry;
go

drop view if exists ViewCasts;
go

-- представление таблицы состава актёров
create view ViewCasts as
	select
	   Movies.Title
	   , Persons.Name      
	   , Persons.Surname	
	   , Persons.Patronymic
	from 
		Casts join Movies on Movies.Id = Casts.IdMovie
			  join (Actors join Persons on Persons.Id = Actors.IdPerson) on Actors.Id = Casts.IdActor;
go

