﻿
-- •	1 Вывести все фильмы, вышедшие на экран в текущем и прошлом году.
declare @year1 int = 2021, @year2 int = 2020;

select
	Title
	, ReleaseDate
from ViewMovies
where year(ReleaseDate) = @year1 or year(ReleaseDate) = @year2;
go


-- •	2 Вывести информацию об актерах, снимавшихся в заданном фильме.
declare @title nvarchar(100) = N'Сестры'
select
	Name
	, Surname
	, Patronymic
from ViewCasts
where Title = @title;
go

-- •	3 Вывести информацию об актерах, снимавшихся как минимум в N фильмах.
declare @n int = 2;

select
	Name
	, Surname
	, Patronymic
	, count(Title) as Roles
from 
	ViewCasts
group by
	Name, Surname, Patronymic
having count(Title) >= @n;
go


-- •	4 Вывести информацию об актерах, которые были режиссерами хотя бы одного из фильмов.
select
	Persons.Name
	, Persons.Surname
	, Persons.Patronymic	
from
	Actors join Persons on Persons.Id = Actors.IdPerson			  
where Actors.IdPerson in (select IdPerson from Directors);
go


-- •	5 Вывести все фильмы, дата выхода которых была более заданного числа лет назад.
declare @yearsAgo int = 16;

select
	Title
	, ReleaseDate
from ViewMovies
where DATEDIFF(yy, ReleaseDate, GETDATE()) > @yearsAgo;
go


-- •	6 Вывести всех актеров и количество фильмов, в которых они участвовали.
select
	Name
	, Surname
	, Patronymic
	, Count(Title) as TotalMovies
from ViewCasts
group by Name, Surname, Patronymic;
go


-- •	7 Скалярная функция. Вывести количество актеров в заданном по названию фильме.
drop function if exists CountMovieActors;
go

create function CountMovieActors(@movie nvarchar(100)) returns int
as
begin
		return (select count(Title)
				from ViewCasts
				where Title = @movie)
end;
go


declare @movie nvarchar(100) = N'Дюна';

select @movie as Movie, dbo.CountMovieActors(@movie) as Actors;
go

-- •	8 Скалярная функция. Вывести суммарный бюджет фильмов заданного режиссера.

drop function if exists CountDirectorsBudget;
go

create function CountDirectorsBudget(@surname nvarchar(60)) returns int
as
begin
	return (select sum(Budget)
			from ViewMovies
			where DirectorSurname = @surname)
end;
go

declare @director nvarchar(60) = N'Ричи';

select @director as Director, dbo.CountDirectorsBudget(@director) as TotalBudget;
go