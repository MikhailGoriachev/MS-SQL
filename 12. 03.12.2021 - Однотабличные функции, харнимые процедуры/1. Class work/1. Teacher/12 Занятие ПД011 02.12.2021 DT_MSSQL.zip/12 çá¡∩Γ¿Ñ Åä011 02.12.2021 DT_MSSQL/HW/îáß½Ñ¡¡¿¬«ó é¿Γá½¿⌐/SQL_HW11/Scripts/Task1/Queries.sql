﻿--Задача 1. Разработайте, пожалуйста, скрипт T-SQL для решения следующих задач, исходные данные формируйте при помощи 
--генератора случайных чисел, задачу Case12 реализуйте в цикле, где код элемента меняется от 1 до 4, не используйте 
--скалярную функцию при решении Case12: 

--•	Case12. Элементы окружности пронумерованы следующим образом: 
--  1 – радиус R, 2 – диаметр D = 2·R, 3 – длина L = 2·π·R, 4 – площадь круга S = π·R2.
--  Дан номер одного их этих элементов и его значение.
--  Вывести значения остальных элементов данной окружности (в том же порядке). 

declare @i int = 1, @value float;
		
while @i <= 4
begin
	set @value = 1 + 10*rand ();
	declare @result nvarchar(100);
	set @result = case @i
		when 1 then N'R = ' + ltrim(@value) + N', D = ' + ltrim(2 * @value) + N', L = ' + ltrim(2 * Pi() * @value) + N', S = ' + ltrim(Pi() * @value * @value)
		when 2 then N'R = ' + ltrim(@value/2) + N', D = ' + ltrim(@value) + N', L = ' + ltrim(2 * Pi() * @value/2) + N', S = ' + ltrim(Pi() * power(@value/2, 2))
		when 3 then N'R = ' + ltrim(@value/2*Pi()) + N', D = ' + ltrim(2*(@value/2*Pi())) + N', L = ' + ltrim(@value) + N', S = ' + ltrim(Pi() * power(@value/2*Pi(), 2))
		when 4 then N'R = ' + ltrim(sqrt(@value/Pi())) + N', D = ' + ltrim(2*sqrt(@value/Pi())) + N', L = ' + ltrim(2*Pi()*sqrt(@value/Pi())) + N', S = ' + ltrim(@value)
	end;
	print @result;
	set @i += 1;
end;
go


--•	Proc17. Описать функцию RootsCount(A, B, C) целого типа, определяющую количество корней
--  квадратного уравнения A·x2 + B·x + C = 0 (A, B, C — вещественные параметры).
--  С ее помощью найти количество корней для каждого из пяти квадратных уравнений с данными коэффициентами.
--  Количество корней определять по значению дискриминанта: D = B2 − 4·A·C.

-- создание ф-ции
create function RootsCount(@a float, @b float, @c float) returns int
as
begin
	declare @d float =  @b * @b - 4 * @a * @c;
	return case 
					when @D < 0 then 0
					when @D = 0 then 1
					when @D > 0 then 2
		   end;
end;
go

-- объявление переменных 
declare @A float, @B float, @C float, @D float,
		@i int = 1;

-- цикл вычислений и вывода
while @i <= 5
begin
	set @A = 1.0 + 100.0*rand();
	set @B = 1.0 + 100.0*rand();
	set @C = 1.0 + 100.0*rand();

	print char(10) + char(9) + ltrim(str(@A,5,2)) + N'*x^2 + ' + ltrim(str(@B,5,2)) + N'*x + ' + ltrim(str(@C,5,2)) + N' = 0' +
		  char(10) + char(9) + N'Корней: ' + str(dbo.RootsCount(@A,@B,@C)) + char(10);

	set @i += 1;
end;
go


--•	Proc18. Описать функцию CircleS(R) вещественного типа, находящую площадь круга радиуса R (R — вещественное).
--  С помощью этой функции найти площади пяти кругов с данными радиусами.
--  Площадь круга радиуса R вычисляется по формуле S = π·R2. 

-- создание ф-ции
create function CircleS(@R float) returns float
as begin
	return Pi()*@R*@R;
end;
go


declare @R float, @i int = 1;

while @i <= 5
begin
	set @R = 1.0 + 10.0 * rand();
	print char(10) + char(9) + N'Радиус круга R = ' + ltrim(str(@R,5,2)) + N', площадь круга S = ' + ltrim(str(dbo.CircleS(@R),5,2));
	set @i += 1;
end;
go


--•	Proc19. Описать функцию RingS(R1, R2) вещественного типа, находящую площадь кольца,
--  заключенного между двумя окружностями с общим центром и радиусами R1, R2 
--  (R1 и R2 — вещественные, R1 > R2, при нарушении этого условия возвращайте -1).
--  С ее помощью найти площади пяти колец, для которых даны внешние и внутренние радиусы.
--  Воспользоваться формулой площади круга радиуса R: S = π·R2.

-- создание ф-ции
create function RingS(@R1 float, @R2 float) returns float
as
begin
	return iif(@R1 - @R2 > 1e-6, pi()*(@R1*@R1 - @R2*@R2), -1);
end;
go

declare @R1 float, @R2 float, @i int = 1;

while @i <= 5
begin
	set @R1 = 1.0 + 10.0 * rand();
	set @R2 = 1.0 + 10.0 * rand();
	declare @S float = dbo.RingS(@R1, @R2);
	
	print char(10) + char(9) + N'Радиус круга R1 = ' + ltrim(str(@R1,5,2)) + N', радиус круга R2 = ' + ltrim(str(@R2,5,2))+ 
		  char(10) + char(9) + iif(@S = -1, N'Недопустимые входные данные',N'Площадь кольца, заключенного между двумя окружностями S = ' + ltrim(str(@S,5,2)));
	
	set @i += 1;
end;
go

--•	Proc28. Описать функцию IsPrime(N) логического типа, возвращающую TRUE, 
--  если целый параметр N (> 1, при нарушении условия возвращать FALSE) является простым числом,
--  и FALSE в противном случае (число, большее 1, называется простым, если оно не имеет положительных делителей,
--  кроме 1 и самого себя). Дан набор из 10 целых случайных чисел, больших 1.
--  С помощью функции IsPrime найти количество простых чисел в данном наборе.

-- создание ф-ции
create function IsPrime(@N int) returns bit
as begin
	declare @i int = 1, @isPrime bit = 1;
	while @i < @N/2	begin
		set @i += 1;
		if @N % @i = 0 begin
			set @i = @N;
			set @isPrime = 0;
		end;
	end;
	return @isPrime;
end;
go

declare @i int = 1, @x int, @count int = 0;

while @i <= 10
begin
	set @x = 2 + 50 * rand();

	--declare @isPrime bit = dbo.IsPrime(@x);
	
	if(dbo.IsPrime(@x) = 1)
		set @count += 1;
	set @i += 1;
	print ltrim(str(@x));
end;

print char(10) + N'Количество простых чисел - ' + ltrim(str(@count));
go


--•	Proc36. Описать функцию Fib(N) целого типа, вычисляющую N-й элемент последовательности чисел Фибоначчи FK, 
--  которая описывается следующими формулами:
--    F1 = 1, F2 = 1, FK = FK−2 + FK−1, K = 3, 4, ... 
--  Используя функцию Fib, найти пять чисел Фибоначчи с данными номерами N1, N2, . . ., N5.

-- создание ф-ции
create function Fib(@N int) returns int
as begin
	declare @i int = 3,
			@fk1 int = 1,
			@fk2 int = 1,
			@fk int;

	while @i <= @N begin
		set @fk = @fk1 + @fk2;
		set @fk2 = @fk1;
		set @fk1 = @fk;
		set @i += 1;
	end;
	return @fk;
end;
go

declare @i int = 1, @n int;

while @i <= 5 begin
	set @n = 2 + 20*rand();
	print N'Число Фибоначчи №' + ltrim(str(@n)) + N' = ' + ltrim(str(dbo.Fib(@n)));
	set @i += 1;
end;
go