﻿-- Proc17. 
--    Описать функцию RootsCount(A, B, C) целого типа, определяющую
--    количество корней квадратного уравнения A·x2 + B·x + C = 0 
--    (A, B, C — вещественные параметры). 
--    С ее помощью найти количество корней
--    для каждого из пяти квадратных уравнений с данными коэффициентами.
--    Количество корней определять по значению дискриминанта:
--    D = B^2 − 4·A·C.

declare      @a int, 
			 @b int ,
			 @c int ,
			 @iters int = 1,
			 @Euquation nvarchar(20) = N' A·x^2 + B·x + C = 0 '

while @iters <= 5 begin 

set  @a = 100*rand() 
set  @b = 100*rand()
set @c = 100*rand()
set @iters += 1

select

 @Euquation as Equation
,@a as A
,@b as B
,@c as C
,dbo.RootsCount(@a,@b,@c) as amount

end
go
--  Proc18. 
--  Описать функцию CircleS(R) вещественного типа, находящую площадь круга радиуса R (R — вещественное). 
--  С помощью этой функции найти площади пяти кругов с данными радиусами. 
--  Площадь круга радиуса R вычисляется по формуле S = π•R2. 

declare @R float,
		@iters int = 1

while @iters <= 5 begin 

set  @R = 100*rand()
set @iters += 1

select

 round(@R,1) as Radisus
,round(dbo.Circles(@R),2) as [Square]

end
go
-- Proc19. 
-- Описать функцию RingS(R1, R2) вещественного типа, находящую площадь кольца, 
-- заключенного между двумя окружностями с общим центром и радиусами R1, R2 (R1 и R2 — вещественные, R1 > R2, при нарушении этого условия возвращайте -1). 
-- С ее помощью найти площади пяти колец, для которых даны внешние и внутренние радиусы. 
-- Воспользоваться формулой площади круга радиуса R: 
-- S = π•R2.

declare @R1 float,
		@R2 float,
		@iters int = 1

while @iters <= 5 begin 

set  @R1 = 100*rand()
set  @R2 = 100*rand()
set @iters += 1

select

 round(@R1,1) as Radisus_1
,round(@R2,1) as Radisus_2
,round(dbo.Rings(@R1,@R2),2) as SquareOfRing

end