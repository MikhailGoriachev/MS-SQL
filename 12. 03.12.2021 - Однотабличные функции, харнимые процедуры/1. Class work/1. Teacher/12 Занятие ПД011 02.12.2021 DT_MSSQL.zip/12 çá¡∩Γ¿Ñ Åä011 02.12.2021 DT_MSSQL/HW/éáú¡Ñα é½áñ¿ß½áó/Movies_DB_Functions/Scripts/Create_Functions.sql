﻿-- Proc17. 
--    Описать функцию RootsCount(A, B, C) целого типа, определяющую
--    количество корней квадратного уравнения A·x2 + B·x + C = 0 
--    (A, B, C — вещественные параметры). 
--    D = B^2 − 4·A·C.

drop function if exists dbo.RootsCount
drop function if exists Circles
drop function if exists Rings
drop function if exists IsPrime
drop function if exists Fib
go

create function RootsCount(@A float, @B float, @C float)
returns float 
as 
begin
	declare 
	@D float  =  @B*@B - 4*(@A*@C),
	@Amount float

	set	@Amount = case 
		when @D > 0 then 2
		when @D = 0 then 1 
		when @D < 0 then 0
		end;

	RETURN @Amount

end
go

--  Proc18. 
--  Описать функцию CircleS(R) вещественного типа, находящую площадь круга радиуса R (R — вещественное). 
--  С помощью этой функции найти площади пяти кругов с данными радиусами. 
--  Площадь круга радиуса R вычисляется по формуле S = π•R2. 


create function Circles(@R float ) 
returns float
as
begin 
	declare @S float = Pi()*(@R*@R)
	RETURN @S
end
go

-- Proc19. 
-- Описать функцию RingS(R1, R2) вещественного типа, находящую площадь кольца, 
-- заключенного между двумя окружностями с общим центром и радиусами R1, R2 (R1 и R2 — вещественные, R1 > R2, при нарушении этого условия возвращайте -1). 
-- С ее помощью найти площади пяти колец, для которых даны внешние и внутренние радиусы. 
-- Воспользоваться формулой площади круга радиуса R: 
-- S = π•R2.

create function Rings(@R1 float ,@R2 float ) 
returns float
as
begin 

	if @R1 > @R2
		return -1
	
	declare @S float  = Pi()*(@R2*@R2-@R1*@R1)
	
	return @S
end
go
-- Proc28. 
-- Описать функцию IsPrime(N) логического типа, возвращающую TRUE, если целый параметр N (> 1, при нарушении условия возвращать FALSE) является простым числом, 
-- и FALSE в противном случае (число, большее 1, называется простым, если оно не имеет положительных делителей, кроме 1 и самого себя). 
-- Дан набор из 10 целых случайных чисел, больших 1. 
-- С помощью функции IsPrime найти количество простых чисел в данном наборе.

create function IsPrime(@N int)
returns bit
as
begin 
-- Переменная цыкла
	declare @i int = 2

	if @N < 1
		return 0

	while @i < sqrt(@N)
	begin 

	if @N%@i = 0
		return 0

	set @i += 1

	end;
--Если цыкл пройден, тогда, возращаем TRUE
return 1

end

go
-- Proc36. 
-- Описать функцию Fib(N) целого типа, вычисляющую N-й элемент последовательности чисел Фибоначчи FK, 
--  которая описывается следующими формулами:
-- F1 = 1, F2 = 1, FK = FK−2 + FK−1, K = 3, 4, ... 
-- Используя функцию Fib, найти пять чисел Фибоначчи с данными номерами N1, N2, . . ., N5.
create function Fib(@N int)
returns int
as
begin 

	if @N = 1 or @N = 2
		return 1

	declare @A int = 1, @B int = 1, @C int, @i int = 3

	--Цыкл вычисления
	while @i <= @N
	begin
	  
	  set @C = @A+@B
	  set @A = @B
	  set @B = @C
	  
      set @i+=1
	end;

	return @C
end

-- Case12. 
-- Элементы окружности пронумерованы следующим образом: 
-- 1 – радиус R, 2 – диаметр D = 2•R, 3 – длина L = 2•π•R, 4 – площадь круга S = π•R2. 
-- Дан номер одного их этих элементов и его значение. 
-- Вывести значения остальных элементов данной окружности (в том же порядке). 