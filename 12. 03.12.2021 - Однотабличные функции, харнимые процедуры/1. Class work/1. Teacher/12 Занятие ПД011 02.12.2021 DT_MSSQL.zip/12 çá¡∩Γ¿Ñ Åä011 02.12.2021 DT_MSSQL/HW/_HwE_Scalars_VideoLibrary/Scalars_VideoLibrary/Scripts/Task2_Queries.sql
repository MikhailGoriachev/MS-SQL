﻿/* Задача 2. Домашняя видеотека */

-- Видеотека. В БД хранится информация о домашней видеотеке: фильмы, актеры, 
-- режиссеры

-- режиссеры
select
   *
from
   ViewProducers;
go

-- актеры
select
    *
from
    ViewActors;

-- запросы по заданию

-- 1. Вывести все фильмы, вышедшие на экран в текущем и прошлом году.
declare @currentYear int = Year(GetDate());
declare @prevYear int = @currentYear - 1;
select
    *
from
    ViewFilms
where
    DATEPART(year, ViewFilms.ReleaseDate) in (@currentYear, @prevYear);
go

-- 2. Вывести информацию об актерах, снимавшихся в заданном фильме.
declare @title nvarchar(80) = N'Вечерний звон в Тамани';
select
    Persons.Surname as ActorSurname
    , Persons.[Name] as ActorName
    , Persons.Patronymic as ActorPatronymic
    , Films.Title
from
    ActorsFilms join Persons on ActorsFilms.IdActor = Persons.Id
                join Films   on ActorsFilms.IdFilm = Films.Id 
where
    Films.Title = @title;
go

-- 3. Вывести информацию об актерах, снимавшихся как минимум в N фильмах.
select
    Persons.Surname as ActorSurname
    , Persons.[Name] as ActorName
    , Persons.Patronymic as ActorPatronymic
    , count(ActorsFilms.IdFilm)
from
    ActorsFilms join Persons on ActorsFilms.IdActor = Persons.Id
group by
    Persons.Surname, Persons.[Name], Persons.Patronymic
having
    count(ActorsFilms.IdFilm) >= 2;

-- 4. Вывести информацию об актерах, которые были режиссерами хотя бы одного из фильмов.
select distinct
    ActorsFilms.IdActor
    , Persons.Surname as ActorSurname
    , Persons.[Name] as ActorName
    , Persons.Patronymic as ActorPatronymic
from
    ActorsFilms join Persons on ActorsFilms.IdActor = Persons.Id
where
    ActorsFilms.IdActor in (select distinct IdProducer from Films);

-- 5. Вывести все фильмы, дата выхода которых была более заданного числа лет назад.
declare @interval int = 1;

select
   *
from
    ViewFilms
where
     Year(GetDate()) - Year(ViewFilms.ReleaseDate) > @interval;
go

-- 6. Вывести всех актеров и количество фильмов, в которых они участвовали.
select
    ActorsFilms.IdActor
    , Persons.Surname
    , Persons.[Name]
    , Persons.Patronymic
    , count(ActorsFilms.IdFilm)
from
    ActorsFilms join Persons on ActorsFilms.IdActor = Persons.Id
group by
    ActorsFilms.IdActor, Persons.Surname, Persons.[Name], Persons.Patronymic;
go


-- 7. Скалярная функция. Вывести количество актеров в заданном по названию фильме.
drop function if exists dbo.Query07;
go

create function dbo.Query07(@title nvarchar(80)) returns int
as
begin
   declare @total int;
   select 
       @total = count(IdActor) 
   from 
       ActorsFilms join Films on ActorsFilms.IdFilm = Films.Id
   where
       Films.Title = @title;

   return @total
end;
go

select dbo.Query07(N'Вечерний звон в Тамани') as Actors
select dbo.Query07(N'Чужой в Питсбурге') as Actors
select dbo.Query07(N'День радио на море') as Actors
go

-- 8. Скалярная функция. Вывести суммарный бюджет фильмов заданного режиссера.
drop function if exists dbo.Query08;
go

create function dbo.Query08(@producerSurname nvarchar(60), @producerName nvarchar(50), @producerPatronymic nvarchar(60))
returns int
as
begin
    declare @sum int;
    select
        @sum = sum(Films.Budget)
    from
        Films join Persons on Films.IdProducer = Persons.Id
    where
        Persons.Surname = @producerSurname and Persons.[Name] = @producerName and
        Persons.Patronymic = @producerPatronymic;
    return @sum;
end;
go

select dbo.Query08(N'Юрковский',   N'Марк',   N'Максимилианович') as SumBudget;
select dbo.Query08(N'Лапотникова', N'Тамара', N'Оскаровна') as SumBudget;
select dbo.Query08(N'Михайлович',  N'Анна',   N'Валентиновна') as SumBudget;
go