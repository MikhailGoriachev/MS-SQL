﻿
drop table if exists Deals;
drop table if exists Owners;
drop table if exists Realtors;
drop table if exists Apartments;
drop table if exists Persons;
drop table if exists Streets;
drop table if exists Houses;
go

--Номер улицы и дома
create table dbo.Streets(
	Id			      INT			NOT NULL	PRIMARY KEY IDENTITY(1,1),
	StreetName		  NVARCHAR(40)  NOT NULL, -- название улицы
);
go

create table dbo.Houses(
	Id			      INT			NOT NULL	PRIMARY KEY IDENTITY(1,1),
	HouseNum	      NVARCHAR(40)  NOT NULL  -- номер дома
);
go
--таблица персон
create table dbo.Persons
(
	Id			    INT			 NOT NULL	PRIMARY KEY IDENTITY(1,1),
	SurName         NVARCHAR(30) NOT NULL,--Фамилия
	[Name]	        NVARCHAR(30) NOT NULL,--Имя
	Patronymic	    NVARCHAR(30) NOT NULL --Отчество
);
go
--таблица квартир
create table dbo.Apartments(
	Id			      INT			NOT NULL	PRIMARY KEY IDENTITY(1,1),
	IdStreetNum       INT			NOT NULL, --Внешний ключ связанный с таблицей улиц
	IdHouseNum        INT		    NOT NULL, --Внешний ключ связанный с таблицей домов
	ApartmentNum	  NVARCHAR(30)	NOT NULL, --Номер квартиры
	Area			  INT			NOT NULL, --Площадь квартиры
	AmountRooms		  INT			NOT NULL, --количество комнат в квартире 
	Price			  INT			NOT NULL  --Цена квартиры

	--проверки на стоимость и площадь квартиры
	constraint CK_Apartments_Price check (Price > 0),
	constraint CK_Apartments_Area  check (Area > 0),
	--внешние ключи к таблицам Streets и Houses
	constraint FK_Subscribers_Streets foreign key (IdStreetNum) references dbo.[Streets](Id),
	constraint FK_Subscribers_Houses foreign key (IdHouseNum) references dbo.[Houses](Id)
);
go
--таблица риэлторов
create table dbo.Realtors(
	Id				INT			NOT NULL	PRIMARY KEY IDENTITY(1,1),
	IdPerson		INT			NOT NULL, --Внешний ключ связанный с таблицей персон
	[Percent]		INT			NOT NULL  --Процент вознаграждения выплачиваемый риэлтору 
	--проверка на нулевую зарплату
	constraint CK_Realtors_Area  check ([Percent] > 0),
	--связь c персоной
	constraint FK_Realtors_Persons foreign key (IdPerson) references dbo.[Persons](Id)
);
go
--таблица владельцев
create table dbo.Owners(
	Id			    INT			NOT NULL	PRIMARY KEY IDENTITY(1,1),
	IdPerson		INT			NOT NULL, --Внешний ключ связанный с таблицей персон
	PassportNum		NVARCHAR(40)NOT NULL  --Cерия и номер паспорта владельца
	constraint FK_Owners_Persons foreign key (IdPerson) references dbo.[Persons](Id)
);
go

--таблица сделок
create table dbo.Deals(
    Id			    INT			NOT NULL	PRIMARY KEY IDENTITY(1,1),
	IdOwner			INT			NOT NULL, --Внешний ключ связанный с таблицей владельцев
	IdApartment		INT			NOT NULL, --Внешний ключ связанный с таблицей квартир
	IdRealtors		INT			NOT NULL, --Внешний ключ связанный с таблицей риэлторов
	DateOfDeal		Date        NOT NULL  --Дата сделки

	--внешние ключи к таблицам Owners, Apartment и Realtors
	constraint FK_Deals_Owners foreign key (IdOwner) references dbo.[Owners](Id),
	constraint FK_Deals_Apartments foreign key (IdApartment) references dbo.[Apartments](Id),
	constraint FK_Deals_Realtors foreign key (IdRealtors) references dbo.[Realtors](Id)
);
go