﻿--запрос 1
--Выбирает из таблицы КВАРТИРЫ информацию о 3-комнатных квартирах, 
--расположенных на улице «Садовая». Значения задавать параметрами запроса.
declare @Street NVARCHAR(40) = N'ул. Садовая';
declare @RoomAmount INT = 3;
select
	Streets.StreetName,
	Houses.HouseNum,
	Apartments.ApartmentNum,
	Apartments.AmountRooms,
	Apartments.Area,
	Apartments.Price
from
	Apartments join Streets on Apartments.IdStreetNum = Streets.Id
			   join Houses  on Apartments.IdHouseNum = Houses.Id
where
	StreetName = @Street
	and
	AmountRooms = @RoomAmount;
go

--запрос 2
--Выбирает из таблицы РИЭЛТОРЫ информацию о риэлторах, 
--фамилия которых начинается с буквы «И» и процент вознаграждения больше 10%. 
--Значения задавать параметрами запроса.
declare @SurName NVARCHAR(10) = N'И%';
select
	Persons.SurName,
	Persons.[Name],
	Persons.Patronymic,
	Realtors.[Percent]
from
	Realtors join Persons on Realtors.IdPerson = Persons.Id
where
	Persons.SurName like @SurName
	and
	[Percent] > 10;
go
--запрос 3
--Выбирает из таблицы КВАРТИРЫ информацию об 1-комнатных квартирах,
--цена на которые находится в диапазоне от 900 000 руб. до 1000 000 руб. 
--Значения задавать параметрами запроса.
declare @Room INT = 1;
select
	Houses.HouseNum,
	Streets.StreetName,
	Apartments.AmountRooms,
	Apartments.Price,
	Apartments.Area,
	Apartments.ApartmentNum
from
	Apartments join Streets on Apartments.IdStreetNum = Streets.Id
			   join Houses  on Apartments.IdHouseNum = Houses.Id
where
	AmountRooms = @Room
	and
	Price between 900000 and 1000000;
go
--запрос 4
--Выбирает из таблицы КВАРТИРЫ информацию о квартирах с заданным числом комнат. 
--Значения задавать параметрами запроса.
select
	Houses.HouseNum,
	Streets.StreetName,
	Apartments.AmountRooms,
	Apartments.Price,
	Apartments.Area,
	Apartments.ApartmentNum
from
	Apartments join Streets on Apartments.IdStreetNum = Streets.Id
			   join Houses  on Apartments.IdHouseNum = Houses.Id
where
	AmountRooms = 2;
go
--запрос 5
--Выбирает из таблицы КВАРТИРЫ информацию обо всех 2-комнатных квартирах, 
--площадь которых есть значение из некоторого диапазона. 
--Значения задавать параметрами запроса.
select
	Houses.HouseNum,
	Streets.StreetName,
	Apartments.AmountRooms,
	Apartments.Price,
	Apartments.Area,
	Apartments.ApartmentNum
from
	Apartments join Streets on Apartments.IdStreetNum = Streets.Id
			   join Houses  on Apartments.IdHouseNum = Houses.Id
where
	AmountRooms = 2 
	and
	Area between 30 and 50;
go
--запрос 6
--Вычисляет для каждой оформленной сделки размер комиссионного вознаграждения риэлтора.
--Включает поля Фамилия риэлтора, Имя риэлтора, Отчество риэлтора, 
--сделки, Цена квартиры, Комиссионные. Сортировка по полю Дата сделки.
select
	Persons.SurName,
	Persons.[Name],
	Persons.Patronymic,
	Deals.DateOfDeal,
	Apartments.Price,
	Realtors.[Percent],
	Apartments.Price * Realtors.[Percent] / 100 as Reward
from
	Deals join Apartments on Deals.IdApartment = Apartments.Id
		  join ( Realtors join Persons on Realtors.IdPerson = Persons.Id)
				on Deals.IdRealtors = Realtors.Id
order by
	Deals.DateOfDeal;
go
