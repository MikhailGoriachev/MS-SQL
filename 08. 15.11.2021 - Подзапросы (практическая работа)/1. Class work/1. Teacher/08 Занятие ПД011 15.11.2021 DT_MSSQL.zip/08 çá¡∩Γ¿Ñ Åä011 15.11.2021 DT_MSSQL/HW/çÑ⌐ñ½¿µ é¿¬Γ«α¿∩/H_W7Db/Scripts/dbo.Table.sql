﻿-- таблица - название улиц
CREATE TABLE [dbo].[Streets]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [NameStreet] NVARCHAR(80) NOT NULL 
);
go


-- таблица - персоны ФИО
CREATE TABLE [dbo].[Persons]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Surname] NVARCHAR(50) NOT NULL, 
    [Name] NVARCHAR(40) NOT NULL, 
    [Patronymic] NVARCHAR(60) NOT NULL
);
go


-- таблица - квартиры
CREATE TABLE [dbo].[Apartments]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [IdNameStreet] INT NOT NULL, 
    [HouseNum] NVARCHAR(12) NOT NULL, 
    [Flat] INT NOT NULL, 
    [AreaApartment] FLOAT NOT NULL, 
    [NumberOfRooms] INT NOT NULL, 
    [PriceApartment] INT NOT NULL, 
    CONSTRAINT [CK_Apartments_Flat] CHECK ([Flat] >= 0), 
    CONSTRAINT [CK_Apartments_AreaApartment] CHECK ([AreaApartment] > 0), 
    CONSTRAINT [CK_Apartments_NumberOfRooms] CHECK ([NumberOfRooms] >= 0), 
    CONSTRAINT [CK_Apartments_PriceApartment] CHECK ([PriceApartment] > 0), 
    CONSTRAINT [FK_Apartments_Streets] FOREIGN KEY ([IdNameStreet]) REFERENCES [Streets]([Id])
);
go

-- таблица - владельцы квартир
CREATE TABLE [dbo].[Owners]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [IdPerson] INT NOT NULL, 
    [PassportNum] NVARCHAR(15) NOT NULL, 
    [IdApartment] INT NOT NULL, 
    CONSTRAINT [FK_Owners_Persons] FOREIGN KEY ([IdPerson]) REFERENCES [Persons]([Id]), 
    CONSTRAINT [FK_Owners_Apartments] FOREIGN KEY ([IdApartment]) REFERENCES [Apartments]([Id])
);
go

-- таблица - риелторы
CREATE TABLE [dbo].[Realtors]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [IdPerson] INT NOT NULL, 
    [PercentRemuneration] INT NOT NULL, 
    CONSTRAINT [CK_Realtors_PercentRemuneration] CHECK ([PercentRemuneration] > 0), 
    CONSTRAINT [FK_Realtors_Persons] FOREIGN KEY ([IdPerson]) REFERENCES [Persons]([Id])
);
go

-- таблица - сделки
CREATE TABLE [dbo].[Dealings]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [IdApartment] INT NOT NULL, 
    [IdRealtor] INT NOT NULL, 
    [DateDeal] DATE NOT NULL, 
    CONSTRAINT [FK_Dealings_Apartments] FOREIGN KEY ([IdApartment]) REFERENCES [Apartments]([Id]), 
    CONSTRAINT [FK_Dealings_Realtors] FOREIGN KEY ([IdRealtor]) REFERENCES [Realtors]([Id])
);
go