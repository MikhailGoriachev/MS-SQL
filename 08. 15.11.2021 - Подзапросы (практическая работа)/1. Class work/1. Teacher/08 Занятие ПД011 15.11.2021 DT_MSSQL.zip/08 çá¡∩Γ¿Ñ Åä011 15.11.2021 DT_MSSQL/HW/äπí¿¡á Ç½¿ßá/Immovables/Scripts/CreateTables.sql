﻿-- Создание таблиц базы данных


-- удаление существующих таблиц
drop table if exists Dealings;
drop table if exists Realtors;
drop table if exists Apartments;
drop table if exists Persons;
drop table if exists Streets;
go


-- Таблица - названия улиц
CREATE TABLE [dbo].[Streets] (
    [Id]         int           not null primary key identity (1, 1),
    [Street] nvarchar (60) not null, -- название улицы
);
go


-- Таблица персональных данных, одинаковых для владельцев квартиры
-- и риэлторов - Persons
create table dbo.Persons (
	Id          int          not null primary key identity (1, 1),
	Surname     nvarchar(60) not null,    -- Фамилия персоны
	[Name]      nvarchar(50) not null,    -- Имя персоны
	Patronymic  nvarchar(60) not null,    -- Отчество персоны
    Passport    nvarchar(15) not null     -- Серия-номер паспорта персоны
);
go


-- Таблица сведений о квартирах КВАРТИРЫ --> Apartments
CREATE TABLE [dbo].Apartments (
    [Id]           int          not null primary key identity (1, 1),
    IdStreet       int          not null, -- Название улицы
    Building       nvarchar(10) not null, -- номер дома
	Flat           int          not null, -- номер квартиры, 0 для частного сектора
    Area           float        not null, -- Площадь квартиры
    Rooms          int          not null, -- Количество комнат
    Price          int          not null, -- Зафиксированная цена продажи квартиры
    IdOwner        int          not null, -- Владелец квартиры

    constraint [FK_Apartments_Streets] foreign key ([IdStreet]) references [dbo].[Streets] ([Id]),
    constraint [FK_Apartments_Persons] foreign key ([IdOwner])  references [dbo].[Persons] ([Id]),
    constraint [CK_Apartments_Flat]  check (Flat > (0)),
    constraint [CK_Apartments_Area]  check (Area > (0)),
    constraint [CK_Apartments_Rooms] check (Rooms > (0)),
    constraint [CK_Apartments_Price] check (Price > (0))
);
go


-- Таблица сведений о риэлторах РИЭЛТОРЫ --> Realtors
CREATE TABLE [dbo].Realtors (
    [Id]      int            not null primary key identity (1, 1),
    IdRealtor int            not null, -- Риэлтор
    [Percent] float          not null, -- Процент вознаграждения

    constraint [FK_Realtors_Persons] foreign key (IdRealtor)  references [dbo].Persons ([Id]),
    constraint [CK_Realtors_Percent] check ([Percent]>(0))
);
go


-- Таблица сведений о сделках СДЕЛКИ --> Dealings
CREATE TABLE [dbo].Dealings (
	[Id]            int  not null primary key identity (1, 1), 
    [IdRealtor]     int  not null, -- риэлтор, оформивший сделку купли-продажи
    [IdApartment]   int  not null, -- данные о квартире
	[Date]          date not null, -- дата оформления сделки купли-продажи
    CONSTRAINT [FK_Deliveries_Realtors] FOREIGN KEY ([IdRealtor]) REFERENCES [dbo].Realtors(Id), 
    CONSTRAINT [FK_Deliveries_Apartments] FOREIGN KEY ([IdApartment]) REFERENCES [dbo].Apartments(Id)
)
go