﻿-- База данных «Учет сделок с недвижимостью»

-- вывод всех таблиц с рашифровкой полей связанных таблиц
select
   *
from
   Streets;
go


select
    *
from
    Persons;
go


-- риэлторы с расшифровкой
select
    Realtors.Id
    , Persons.Surname
    , Persons.[Name]
    , Persons.Patronymic
    , Realtors.[Percent]
from
    Realtors join Persons on Realtors.IdRealtor = Persons.Id;
go


-- квартиры с расшифровкой
select
    Apartments.Id
    , Persons.Surname + ' ' + SUBSTRING(Persons.[Name], 1, 1) + '. ' + SUBSTRING(Persons.Patronymic, 1, 1) + '. ' as [Owner]
    , Streets.Street + N',  д. ' + Apartments.Building + N', кв. ' + LTrim(Str(Apartments.Flat, 5)) as [Address] 
    , Apartments.Area
    , Apartments.Rooms
    , Apartments.Price
from 
    Apartments join Persons on Apartments.IdOwner = Persons.Id
               join Streets on Apartments.IdStreet = Streets.Id;
go


-- сделки с расшифровкой
select
    Dealings.Id
    , P.Surname + ' ' + SUBSTRING(P.[Name], 1, 1) + '. ' + SUBSTRING(P.Patronymic, 1, 1) + '. ' as Realtor
    , Realtors.[Percent]
    , Persons.Surname + ' ' + SUBSTRING(Persons.[Name], 1, 1) + '. ' + SUBSTRING(Persons.Patronymic, 1, 1) + '. ' as [Owner]
    , Streets.Street + N',  д. ' + Apartments.Building + N', кв. ' + LTrim(Str(Apartments.Flat, 5)) as [Address] 
    , Apartments.Area
    , Apartments.Rooms
    , Apartments.Price
    , [Date]
from
    Dealings join (Apartments join Persons on Apartments.IdOwner = Persons.Id join Streets on Apartments.IdStreet = Streets.Id) 
                    on Dealings.IdApartment = Apartments.Id
             join (Realtors join Persons P on Realtors.IdRealtor = P.Id) 
                    on Dealings.IdRealtor = Realtors.Id;
go


-----------------------------------------------------------------------------------------------------

-- 1. Запрос с параметрами	
--    Выбирает из таблицы КВАРТИРЫ информацию о 3-комнатных квартирах, 
--    расположенных на улице «Садовая». Значения задавать параметрами запроса
-- вариант 1
declare @street nvarchar(25) = N'ул. Садовая', @rooms int = 3;
select
    Apartments.Id
    , Persons.Surname + ' ' + SUBSTRING(Persons.[Name], 1, 1) + '. ' + SUBSTRING(Persons.Patronymic, 1, 1) + '. ' as [Owner]
    , Streets.Street + N',  д. ' + Apartments.Building + N', кв. ' + LTrim(Str(Apartments.Flat, 5)) as [Address] 
    , Apartments.Area
    , Apartments.Rooms
    , Apartments.Price
from 
    Apartments join Persons on Apartments.IdOwner = Persons.Id
               join Streets on Apartments.IdStreet = Streets.Id
where 
    Streets.Street = @street and Apartments.Rooms = @rooms;
go


-- 2. Запрос с параметрами	
--    Выбирает из таблицы РИЭЛТОРЫ информацию о риэлторах, 
--    фамилия которых начинается с буквы «И» и процент 
--    вознаграждения больше 10%. Значения задавать параметрами запроса
declare @letter nvarchar(25) = N'И', @percent float = 10;
select
    Realtors.Id
    , Persons.Surname
    , Persons.[Name]
    , Persons.Patronymic
    , Realtors.[Percent]
from
    Realtors join Persons on Realtors.IdRealtor = Persons.Id
where 
    Persons.Surname like (@letter + '%') and Realtors.[Percent] > @percent
go


-- 3. Запрос с параметрами	
--    Выбирает из таблицы КВАРТИРЫ информацию об 1-комнатных квартирах, 
--    цена на которые находится в диапазоне от 900 000 руб. до 1000 000 руб.
--    Значения задавать параметрами запроса
declare @rooms int = 1, @loPrice int = 900000, @hiPrice int = 1000000
select
    Apartments.Id
    , Persons.Surname + ' ' + SUBSTRING(Persons.[Name], 1, 1) + '. ' + SUBSTRING(Persons.Patronymic, 1, 1) + '. ' as [Owner]
    , Streets.Street + N',  д. ' + Apartments.Building + N', кв. ' + LTrim(Str(Apartments.Flat, 5)) as [Address] 
    , Apartments.Area
    , Apartments.Rooms
    , Apartments.Price
from 
    Apartments join Persons on Apartments.IdOwner = Persons.Id
               join Streets on Apartments.IdStreet = Streets.Id
where 
    Apartments.Price between @loPrice and @hiPrice and Apartments.Rooms = @rooms;
go


-- 4. Запрос с параметрами	
--    Выбирает из таблицы КВАРТИРЫ информацию о квартирах с заданным числом комнат. 
--    Значения задавать параметрами запроса
declare @rooms int = 3
select
    Apartments.Id
    , Persons.Surname + ' ' + SUBSTRING(Persons.[Name], 1, 1) + '. ' + SUBSTRING(Persons.Patronymic, 1, 1) + '. ' as [Owner]
    , Streets.Street + N',  д. ' + Apartments.Building + N', кв. ' + LTrim(Str(Apartments.Flat, 5)) as [Address] 
    , Apartments.Area
    , Apartments.Rooms
    , Apartments.Price
from 
    Apartments join Persons on Apartments.IdOwner = Persons.Id
               join Streets on Apartments.IdStreet = Streets.Id
where 
    Apartments.Rooms = @rooms;
go


-- 5. Запрос с параметрами	
--    Выбирает из таблицы КВАРТИРЫ информацию обо всех 2-комнатных квартирах,
--    площадь которых есть значение из некоторого диапазона. 
--    Значения задавать параметрами запроса
declare @loArea float = 30, @hiArea float = 60, @rooms int = 2
select
    Apartments.Id
    , Persons.Surname + ' ' + SUBSTRING(Persons.[Name], 1, 1) + '. ' + SUBSTRING(Persons.Patronymic, 1, 1) + '. ' as [Owner]
    , Streets.Street + N',  д. ' + Apartments.Building + N', кв. ' + LTrim(Str(Apartments.Flat, 5)) as [Address] 
    , Apartments.Area
    , Apartments.Rooms
    , Apartments.Price
from 
    Apartments join Persons on Apartments.IdOwner = Persons.Id
               join Streets on Apartments.IdStreet = Streets.Id
where 
    Apartments.Area between @loArea and @hiArea and Apartments.Rooms = @rooms;
go


-- 6. Запрос с вычисляемыми полями	
--    Вычисляет для каждой оформленной сделки размер комиссионного вознаграждения риэлтора. 
--    Включает поля Фамилия риэлтора, Имя риэлтора, Отчество риэлтора, Дата сделки,
--    Цена квартиры, Комиссионные. Сортировка по полю Дата сделки
select
    Dealings.Id
    , Persons.Surname
    , Persons.[Name]
    , Persons.Patronymic
    , [Date]
    , Apartments.Price
    , Realtors.[Percent]
    , Apartments.Price * Realtors.[Percent] / 100. as Commission
from
    Dealings join Apartments on Dealings.IdApartment = Apartments.Id
             join (Realtors join Persons on Realtors.IdRealtor = Persons.Id) 
                    on Dealings.IdRealtor = Realtors.Id
order by 
    [Date];
go

-- 7. Запрос на левое соединение	
--    Выбрать всех риэлторов, количество клиентов, оформивших с ним сделки и сумму сделок риэлтора.
--    Упорядочить выборку по убыванию суммы сделок.
select
    Realtors.Id
    , Persons.Surname
    , Persons.[Name]
    , Persons.Patronymic
    , Count(Dealings.IdApartment) as ClientsAmount
    , SUM(Apartments.Price) as SumPrice
from
    Realtors join Persons on Realtors.IdRealtor = Persons.Id
             left join (Dealings join Apartments on Dealings.IdApartment = Apartments.Id) 
             on Dealings.IdRealtor = Realtors.Id
group by 
   Persons.Surname, Persons.[Name], Persons.Patronymic, Realtors.Id
order by  
    SumPrice desc;
go


-- 8. Запрос на левое соединение	
--    Для всех улиц вывести сумму сделок, упорядочить выборку по убыванию суммы сделки
select
   Streets.Street 
    , COUNT(Apartments.Id) as Amount
    , SUM(Apartments.Price) as SumPrice
from
    Streets left join (Dealings join Apartments on Dealings.IdApartment = Apartments.Id) 
                    on Apartments.IdStreet = Streets.Id
group by 
   Streets.Street 
order by  
    SumPrice desc;
go


-- 9. Запрос на левое соединение	
--    Для всех улиц вывести сумму сделок за заданный период,
--    упорядочить выборку по убыванию суммы сделки. 
--    Диапазон задавать параметрами запроса
declare @loDate date = '2020-10-01', @hiDate date = '2021-01-01'
select
   Streets.Street 
    , COUNT(Dealings.Id) as Amount
    , SUM(Apartments.Price) as SumPrice
from
    Streets left join (Apartments left join Dealings on Dealings.IdApartment = Apartments.Id)
                        on Apartments.IdStreet = Streets.Id
where
    Dealings.[Date] between @loDate and @hiDate
group by 
   Streets.Street 
order by  
    SumPrice desc;
go

-- 10. Итоговый запрос	
--     Выполняет группировку по полю Количество комнат. 
--     Для каждой группы вычисляет среднее значение по полю Цена квартиры
select
    Rooms
    , Count(Id) as Amount
    , MIN(Price) as MinPrice
    , MAX(Price) as MaxPrice
    , AVG(Price) as AvgPrice
from 
    Apartments 
group by 
    Rooms;
go


-- 11. Итоговый запрос	
--     Выполняет группировку по полю Площадь квартиры.
--     Для каждой группы вычисляет наибольшее и наименьшее значение по полю Цена квартиры
select
    Area
    , Count(Id) as Amount
    , MIN(Price) as MinPrice
    , MAX(Price) as MaxPrice
from 
    Apartments 
group by 
    Area;
go


-- 12. Запрос на создание базовой таблицы	
--     Создает таблицу КВАРТИРЫ_3_КОМН, содержащую информацию о 3-комнатных квартирах
drop table if exists Apartments_3_Rooms;
select
    Apartments.Id
    , Persons.Surname + ' ' + SUBSTRING(Persons.[Name], 1, 1) + '. ' + SUBSTRING(Persons.Patronymic, 1, 1) + '. ' as [Owner]
    , Streets.Street + N',  д. ' + Apartments.Building + N', кв. ' + LTrim(Str(Apartments.Flat, 5)) as [Address] 
    , Apartments.Area
    , Apartments.Rooms
    , Apartments.Price
    into Apartments_3_Rooms
from
    Apartments join Persons on Apartments.IdOwner = Persons.Id
               join Streets on Apartments.IdStreet = Streets.Id
where 
    Rooms = 3;
     
-- показать выбранные в таблицу Apartments_3_Rooms данные 
select * from Apartments_3_Rooms;
go


-- 13. Запрос на создание базовой таблицы	
--     Создает копию таблицы КВАРТИРЫ с именем КОПИЯ_КВАРТИРЫ
drop table if exists Copy_Apartments;
select
    *
    into Copy_Apartments
from
    Apartments;

-- показать выбранные в таблицу Copy_Apartments данные 
select * from Copy_Apartments;
go

-- 14. Запрос на удаление	
--     Удаляет из таблицы КОПИЯ_КВАРТИРЫ записи, 
--     в которых значение в поле Цена квартиры больше 3 000 000 руб.
declare @Price int = 3000000

-- показать таблицу Copy_Apartments до удалания записей
select * from Copy_Apartments;

-- удаление по заданию
delete from 
    Copy_Apartments
where
    Copy_Apartments.Price > @Price;

-- показать таблицу Copy_Apartments после удалания записей
select * from Copy_Apartments;
go

-- 15. Запрос на обновление	
--     Увеличивает значение в поле Цена квартиры таблицы КОПИЯ_КВАРТИРЫ 
--     на 10 процентов для 1-комнатных квартир
declare @percent float = 10, @rooms int = 1

-- показать таблицу Copy_Apartments до изменения
select * from Copy_Apartments;

-- выполнить модификацию цены
update 
    Copy_Apartments
set
    Price *= ((100 + @percent)/100)
where
    Copy_Apartments.Rooms = @rooms;

-- показать таблицу Copy_Apartments после изменения
select * from Copy_Apartments;