﻿--    Удаление существующий таблиц, созданных в ходе выполнения запросов
drop table if exists ApartmentsThreeRooms;
drop table if exists Apartments_COPY;


--			-> Запрос №1 [ Запрос с параметром ] <-
-- Выбирает из таблицы КВАРТИРЫ информацию о 3-комнатных квартирах, 
-- расположенных на улице «Садовая». Значения задавать параметрами запроса.
declare @street   nvarchar(15) = N'ул. Садовая';
declare @numRooms int          = 3;
select
	Apartments.Id,
	Streets.Street,
	HouseNumbers.HouseNumber,
	Apartments.ApartmentNumber,
	Apartments.Area,
	Apartments.NumberRooms,
	Apartments.Price
from
	Apartments join Streets      on Apartments.IdStreet = Streets.Id
			   join HouseNumbers on Apartments.IdHouseNumber = HouseNumbers.Id
where 
	Apartments.NumberRooms = @numRooms and Streets.Street = @street;
go
			
		
--			-> Запрос №2 [ Запрос с параметром ] <-
-- Выбирает из таблицы РИЭЛТОРЫ информацию о риэлторах, 
-- фамилия которых начинается с буквы «И» и процент вознаграждения больше 10%. 
-- Значения задавать параметрами запроса
declare @letter				    nvarchar(1) = N'И';
declare @percentageRemuneration float       = 10;
select
	Realtors.Id,
	Persons.Surname,
	Persons.[Name],
	Persons.Patronymic,
	Realtors.PercentageRemuneration
from
	Realtors join Persons on Realtors.IdPerson = Persons.Id
where
	Persons.Surname like (@letter + N'%') and Realtors.PercentageRemuneration > @percentageRemuneration;
go


--			-> Запрос №3 [ Запрос с параметром ] <-
-- Выбирает из таблицы КВАРТИРЫ информацию об 1-комнатных квартирах, 
-- цена на которые находится в диапазоне от 900 000 руб. до 1000 000 руб. 
-- Значения задавать параметрами запроса
declare @numRooms int = 1;
declare @loPrice  int = 900000;
declare @hiPrice  int = 1000000;
select
	Apartments.Id,
	Streets.Street,
	HouseNumbers.HouseNumber,
	Apartments.ApartmentNumber,
	Apartments.Area,
	Apartments.NumberRooms,
	Apartments.Price
from
	Apartments join Streets      on Apartments.IdStreet = Streets.Id
			   join HouseNumbers on Apartments.IdHouseNumber = HouseNumbers.Id
where 
	Apartments.NumberRooms = @numRooms and Apartments.Price between @loPrice and @hiPrice;
go


--			-> Запрос №4 [ Запрос с параметром ] <-
-- Выбирает из таблицы КВАРТИРЫ информацию о квартирах с заданным числом комнат. 
-- Значения задавать параметрами запроса
--		Формула "псевдо" генерации случайного числа взята отсюда: https://oracleplsql.ru/function-sql-server-rand.html
declare @numRooms int = FLOOR(RAND()*(5-1)+1);
select
	Apartments.Id,
	Streets.Street,
	HouseNumbers.HouseNumber,
	Apartments.ApartmentNumber,
	Apartments.Area,
	Apartments.NumberRooms,
	Apartments.Price
from
	Apartments join Streets      on Apartments.IdStreet = Streets.Id
			   join HouseNumbers on Apartments.IdHouseNumber = HouseNumbers.Id
where 
	Apartments.NumberRooms = @numRooms;
go


--			-> Запрос №5 [ Запрос с параметром ] <-
-- Выбирает из таблицы КВАРТИРЫ информацию обо всех 2-комнатных квартирах, 
-- площадь которых есть значение из некоторого диапазона. 
-- Значения задавать параметрами запроса
declare @numRooms int = 2;
declare @loArea float = RAND()*(55-22)+22;
declare @hiArea float = RAND()*(79-55)+55;
select
	Apartments.Id,
	Streets.Street,
	HouseNumbers.HouseNumber,
	Apartments.ApartmentNumber,
	Apartments.Area,
	Apartments.NumberRooms,
	Apartments.Price,
	round(@loArea,2) as LowArea,
	round(@hiArea,2) as HighArea
from
	Apartments join Streets      on Apartments.IdStreet = Streets.Id
			   join HouseNumbers on Apartments.IdHouseNumber = HouseNumbers.Id
where 
	Apartments.NumberRooms = @numRooms and Apartments.Area between @loArea and @hiArea;
go

--			-> Запрос №6 [ Запрос с вычисляемыми полями ] <-
-- Вычисляет для каждой оформленной сделки размер комиссионного вознаграждения риэлтора. 
-- Включает поля Фамилия риэлтора, Имя риэлтора, Отчество риэлтора, Дата сделки, 
-- Цена квартиры, Комиссионные. Сортировка по полю Дата сделки
select
	Transactions.Id,
	Persons.Surname as SurnameRealtor,				  
	Persons.[Name] as NameRealtor,					 
	Persons.Patronymic as PatronymicRealtor,		 
	Transactions.DateExecution,
	Apartments.Price,
	Realtors.PercentageRemuneration,
	Apartments.Price * Realtors.PercentageRemuneration / 100 as PercentageRemuneration 
from
	Transactions join (Realtors join Persons on Realtors.IdPerson = Persons.Id)
						on	Transactions.IdRealtor = Realtors.Id
				 join (Owners join Apartments on Owners.IdApartment = Apartments.Id)
						on  Transactions.IdOwner = Owners.Id
order by 
	Transactions.DateExecution;
go


--			-> Запрос №7 [ Запрос на левое соединение ] <-
-- Выбрать всех риэлторов, количество клиентов, 
-- оформивших с ним сделки и сумму сделок риэлтора. 
-- Упорядочить выборку по убыванию суммы сделок.
			
			-- Вывод всех риэлторов со стоимостью сделок
select
	Transactions.Id,
	Persons.Surname,
	Persons.[Name],
	Persons.Patronymic,
	Apartments.Price
from
	Transactions join (Owners join Apartments on Owners.IdApartment = Apartments.Id)
						on Transactions.IdOwner = Owners.Id
				 join (Realtors join Persons on Realtors.IdPerson = Persons.Id)
						on Transactions.IdRealtor = Realtors.Id																
go

			-- Вывод риэлторов с сумированной стоимостью сделок
select
	Persons.Surname,
	Persons.[Name],
	Persons.Patronymic,
	COUNT(Transactions.IdOwner) as AmountTransactions,
	SUM(Apartments.Price)       as SumTransactions
from
	(Realtors join Persons on Realtors.IdPerson = Persons.Id) left  join (Transactions join (Owners join Apartments
																						on Owners.IdApartment = Apartments.Id)
																	on Transactions.IdOwner = Owners.Id)
																on Transactions.IdRealtor = Realtors.Id
group by 
	Persons.Surname,Persons.[Name],Persons.Patronymic
order by
	SUM(Apartments.Price);
go
	

--			-> Запрос №8 [ Запрос на левое соединение ] <-
-- Для всех улиц вывести сумму сделок, 
-- упорядочить выборку по убыванию суммы сделки

--   Костыль т.к. из-за ошибки в проектировании или пострении запроса,
--   даже если квартира с определенной улицы не учавствует ни в одной сделки
--   она все равно имеет цену продажи.
select
	Streets.Street,
	COUNT(Transactions.IdOwner) as AmountTransactions,
	SUM(Apartments.Price)       as SumTransactions
from
	(Owners join (Apartments join Streets on Apartments.IdStreet = Streets.id)
			on Owners.IdApartment = Apartments.Id) left join Transactions
											on Transactions.IdOwner = Owners.Id
group by 
	Streets.Street
order by 
	  SUM(Apartments.Price) desc;
go


--			-> Запрос №9 [ Запрос на левое соединение ] <-
-- Для всех улиц вывести сумму сделок за заданный период,
-- упорядочить выборку по убыванию суммы сделки. 
-- Диапазон задавать параметрами запроса 
declare @loDate Date = '03.22.1978';
declare @hiDate Date = '07.17.2001';
select
	Streets.Street,
	Transactions.DateExecution,
	COUNT(Transactions.IdOwner) as AmountTransactions,
	SUM(Apartments.Price)       as SumTransactions
from
	(Owners join (Apartments join Streets on Apartments.IdStreet = Streets.id)
			on Owners.IdApartment = Apartments.Id) left join Transactions
											on Transactions.IdOwner = Owners.Id
where
	Transactions.DateExecution between @loDate and @hiDate
group by 
	Streets.Street, Transactions.DateExecution
order by 
	  SUM(Apartments.Price) desc;
go


--			-> Запрос №10 [ Итоговый запрос ] <-
-- Выполняет группировку по полю Количество комнат. 
-- Для каждой группы вычисляет среднее значение по полю Цена квартиры
select 
	Apartments.NumberRooms
	,COUNT(Apartments.ApartmentNumber) as CountRoom
	,AVG(Apartments.Price)			   as AvgPrice
from
	Apartments
group by
	Apartments.NumberRooms;
go


--			-> Запрос №11 [ Итоговый запрос ] <-
-- Выполняет группировку по полю Площадь квартиры.
-- Для каждой группы вычисляет наибольшее и наименьшее значение по полю Цена квартиры
select 
	Apartments.Area
	,COUNT(Apartments.Area)  as [Count]
	,MIN(Apartments.Price)   as MinPrice
	,MAX(Apartments.Price)   as MaxPrice
from
	Apartments
group by
	Apartments.Area;
go


--			-> Запрос №12 [ Запрос на создание базовой таблицы ] <-
-- Создает таблицу КВАРТИРЫ_3_КОМН, содержащую информацию о 3-комнатных квартирах
-- Если таблица уже создана
drop table if exists Subscribers_COPY;

select
	*
	into ApartmentsThreeRooms
from
	Apartments
where 
	Apartments.NumberRooms =3;
go
-- Показать данные созданной таблицы
select * from ApartmentsThreeRooms; 
go

--			-> Запрос №13 [ Запрос на создание базовой таблицы ] <-
-- Создает копию таблицы КВАРТИРЫ с именем КОПИЯ_КВАРТИРЫ
 
drop table if exists Apartments_COPY;

select
	*
	into Apartments_COPY
from
	Apartments 
go
-- Показать данные созданной таблицы
select * from Apartments_COPY; 
go

--			-> Запрос №14 [ Запрос на удаление ] <-
-- Удаляет из таблицы КОПИЯ_КВАРТИРЫ записи, 
-- в которых значение в поле Цена квартиры больше 3 000 000 руб.

--				[ Вывод таблицы перед удалением ]
select
	Apartments_COPY.Id,
	Streets.Street,
	HouseNumbers.HouseNumber,
	Apartments_COPY.ApartmentNumber,
	Apartments_COPY.Area,
	Apartments_COPY.NumberRooms,
	Apartments_COPY.Price
from
	Apartments_COPY join Streets      on Apartments_COPY.IdStreet = Streets.Id
			   join HouseNumbers on Apartments_COPY.IdHouseNumber = HouseNumbers.Id;
go

--				[ Само удалением ]
declare @loPriceDelete int = 3000000;
delete from
	Apartments_COPY
where 
	Apartments_COPY.Price>@loPriceDelete;
go

--				[ Вывод таблицы после удаления ]
select
	Apartments_COPY.Id,
	Streets.Street,
	HouseNumbers.HouseNumber,
	Apartments_COPY.ApartmentNumber,
	Apartments_COPY.Area,
	Apartments_COPY.NumberRooms,
	Apartments_COPY.Price
from
	Apartments_COPY join Streets      on Apartments_COPY.IdStreet = Streets.Id
			   join HouseNumbers on Apartments_COPY.IdHouseNumber = HouseNumbers.Id;
go


--			-> Запрос №15 [ Запрос на обновление ] <-
-- Увеличивает значение в поле Цена квартиры таблицы КОПИЯ_КВАРТИРЫ
-- на 10 процентов для 1-комнатных квартир

--				[ Вывод таблицы перед изменением ]
select
	Apartments_COPY.Id,
	Streets.Street,
	HouseNumbers.HouseNumber,
	Apartments_COPY.ApartmentNumber,
	Apartments_COPY.Area,
	Apartments_COPY.NumberRooms,
	Apartments_COPY.Price
from
	Apartments_COPY join Streets      on Apartments_COPY.IdStreet = Streets.Id
			   join HouseNumbers on Apartments_COPY.IdHouseNumber = HouseNumbers.Id;
go

--				[ Само изменение ]

declare @numRooms int = 1;
update
	Apartments_COPY
set
	Apartments_COPY.Price += Apartments_COPY.Price * 10 / 100
where
	Apartments_COPY.NumberRooms = @numRooms;
go


--				[ Вывод таблицы после изменения ]
select
	Apartments_COPY.Id,
	Streets.Street,
	HouseNumbers.HouseNumber,
	Apartments_COPY.ApartmentNumber,
	Apartments_COPY.Area,
	Apartments_COPY.NumberRooms,
	Apartments_COPY.Price
from
	Apartments_COPY join Streets      on Apartments_COPY.IdStreet = Streets.Id
			   join HouseNumbers on Apartments_COPY.IdHouseNumber = HouseNumbers.Id;
go