﻿
--ЗАПРОСЫ


--1.Выбирает из таблицы КВАРТИРЫ информацию о 3-комнатных квартирах, 
--расположенных на улице «Садовая». Значения задавать параметрами запроса
select
	Street
	,Apartments.NumHouse
	,Apartments.NumApartment
	,Apartments.[Square]
	,Apartments.Rooms
	,Apartments.Cost
from 
	Apartments join Streets on Apartments.idStreet = Streets.Id
where
	Street in (select Street from Streets where Street like N'Садовая')
	and Apartments.Rooms in (select Rooms from Apartments where Rooms = 3);

--2.Выбирает из таблицы РИЭЛТОРЫ информацию о риэлторах, фамилия которых 
--начинается с буквы «И» и процент вознаграждения больше 10%. Значения 
--задавать параметрами запроса
select
	PSurname
	,PName
	,PPatronymic
	,Realtors.Percnt
from Realtors join PSurnames on Realtors.idSurname = PSurnames.Id
				join PNames on Realtors.idName = PNames.Id
				join PPatronymics on Realtors.idPatronymic = PPatronymics.Id
where
	PSurname in (select PSurname from PSurnames where PSurname like N'И%')
	and Realtors.Percnt in (select Percnt from Realtors where Percnt > 10);
--3.Выбирает из таблицы КВАРТИРЫ информацию об 1-комнатных квартирах, цена
--на которые находится в диапазоне от 900 000 руб. до 1000 000 руб. Значения 
--задавать параметрами запроса
select
	Street
	,Apartments.NumHouse
	,Apartments.NumApartment
	,Apartments.Rooms
	,Apartments.[Square]
	,Apartments.Cost
from 
	Apartments join Streets on Apartments.idStreet = Streets.Id
where
	Rooms in (select Rooms from Apartments where Rooms = 1)
	and Cost in (select Cost from Apartments where Cost between 12000 and 13400)

--4.Выбирает из таблицы КВАРТИРЫ информацию о квартирах с заданным числом 
--комнат. Значения задавать параметрами запроса
declare @rms int = 3;
select
	Street
	,Apartments.NumHouse
	,Apartments.NumApartment
	,Apartments.Rooms
	,Apartments.[Square]
	,Apartments.Cost
from 
	Apartments join Streets on Apartments.idStreet = Streets.Id
where
	Rooms in (select Rooms from Apartments where Rooms = @rms)
--5.Выбирает из таблицы КВАРТИРЫ информацию обо всех 2-комнатных квартирах, 
--площадь которых есть значение из некоторого диапазона. Значения задавать 
--параметрами запроса
select
	Street
	,Apartments.NumHouse
	,Apartments.NumApartment
	,Apartments.Rooms
	,Apartments.[Square]
	,Apartments.Cost
from 
	Apartments join Streets on Apartments.idStreet = Streets.Id
where
	Rooms in (select Rooms from Apartments where Rooms = 2)
	and Apartments.[Square] in 
			(select Apartments.[Square] from Apartments where Apartments.[Square] between 35 and 45)
--6.Вычисляет для каждой оформленной сделки размер комиссионного вознаграждения 
--риэлтора. Включает поля Фамилия риэлтора, Имя риэлтора, Отчество риэлтора, 
--Дата сделки, Цена квартиры, Комиссионные. Сортировка по полю Дата сделки
select 
	PSurname
	,PName
	,PPatronymic
	,Buyers.DateOfDeal
	,Apartments.Cost
	,[Cost] * Realtors.Percnt as Комиссионные
from 
	Deals join (Realtors join  PSurnames on Realtors.idSurname = PSurnames.Id
				join PNames on Realtors.idName = PNames.Id
				join PPatronymics on Realtors.idPatronymic = PPatronymics.Id)
					on Deals.idRealtor = Realtors.Id
		  join Buyers on Deals.idBuyer = Buyers.Id
		  join (Apartments join Streets on Apartments.idStreet = Streets.Id)
					on Deals.idApartment = Apartments.Id
order by DateOfDeal


--7.Выбрать всех риэлторов, количество клиентов, оформивших с ним сделки и 
--сумму сделок риэлтора. Упорядочить выборку по убыванию суммы сделок.
select 
	PSurname
	,COUNT(Deals.idBuyer) as [Клиенты]
	,SUM(Apartments.Cost) as [Сумма сделок]
from
	PSurnames left join (Realtors join Deals on Realtors.Id = Deals.idRealtor)
			on PSurnames.Id = Realtors.idSurname
group by PSurname
--8.Для всех улиц вывести сумму сделок, упорядочить выборку по убыванию суммы сделки
select
	Streets.Street
	,SUM(Apartments.Cost) as [Сумма сделки]
from
	Streets left join Apartments on Streets.Id = Apartments.idStreet
group by Street
--9.Для всех улиц вывести сумму сделок за заданный период, упорядочить 
--  выборку по убыванию суммы сделки. Диапазон задавать параметрами запроса
select
	Streets.Street
	,SUM(Apartments.Cost) as [Сумма сделки]
from 
	Streets left join Apartments on Streets.Id = Apartments.idStreet
where Buyers.DateOfDeal in 
			(select DateOfDeal where DateOfDeal between '2021-11-01' and '2021-11-03')
group by Street
--10.Выполняет группировку по полю Количество комнат. Для каждой группы 
--   вычисляет среднее значение по полю Цена квартиры
select 
	Apartments.Rooms
	,AVG(Cost)
from Apartments
group by Rooms
--11.Выполняет группировку по полю Площадь квартиры. Для каждой группы 
--   вычисляет наибольшее и наименьшее значение по полю Цена квартиры
select
	Apartments.[Square]
	,MIN(Apartments.Cost) as [Min]
	,MAX(Apartments.Cost) as [Max]
from Apartments
group by [Square]
--12.Создает таблицу КВАРТИРЫ_3_КОМН, содержащую информацию о 3-комнатных квартирах
drop table if exists Apart_3_Rooms; 
select
    *
    into Apart_3_Rooms
from
    Apartments
where Apartments.Id in (select Apartments.Id from Apartments where Apartments.Rooms = 3)
select * from Apart_3_Rooms;
go
--13.Создает копию таблицы КВАРТИРЫ с именем КОПИЯ_КВАРТИРЫ
drop table if exists Apart_Copy; 
select
    *
    into Apart_Copy
from
    Apartments
select * from Apart_3_Rooms;
go
--14.Удаляет из таблицы КОПИЯ_КВАРТИРЫ записи, в которых значение в поле 
--   Цена квартиры больше 3 000 000 руб.
delete from Apart_Copy
where Apart_Copy.Id in (select Apart_Copy.Id where Apart_Copy.Cost > 40000)
--15.Увеличивает значение в поле Цена квартиры таблицы КОПИЯ_КВАРТИРЫ на 
--   10 процентов для 1-комнатных квартир
update Apart_Copy
set Cost *=1.10
where Rooms in (select Rooms where Rooms = 1)



