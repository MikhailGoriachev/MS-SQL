﻿--Выбирает из таблицы КВАРТИРЫ информацию о 3-комнатных квартирах, расположенных на улице «Садовая». 
--Значения задавать параметрами запроса

select 
   *
from 
   -- Flats join Streets on Flats.IdStreets = Streets.Street
   -- Flats join Streets on Flats.IdStreets = Streets.Id
   Flats
where 
   -- Room# =3 and IdStreets = N'Садовая'
   -- Room# =3 and Street = N'Садовая'
   Room# = 3 and IdStreets = (select Id from Streets where Street = N'ул.Садовая')