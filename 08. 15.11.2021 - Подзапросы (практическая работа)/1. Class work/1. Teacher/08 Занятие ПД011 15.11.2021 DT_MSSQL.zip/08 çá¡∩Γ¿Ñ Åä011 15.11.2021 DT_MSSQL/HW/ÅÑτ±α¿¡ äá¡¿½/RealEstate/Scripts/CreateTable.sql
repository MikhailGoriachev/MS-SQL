﻿--База данных «Учет сделок с недвижимостью»
/*
База данных должна включать как минимум таблицы КВАРТИРЫ, РИЭЛТОРЫ, СДЕЛКИ (возможны и другие таблицы), 
содержащие следующую информацию:
-Название улицы
-Номер дома
-Номер квартиры
-Площадь квартиры
-Количество комнат
-Зафиксированная цена продажи квартиры
-Фамилия владельца квартиры
-Имя владельца квартиры
-Отчество владельца квартиры
-Серия-номер паспорта владельца квартиры
-Дата оформления сделки купли-продажи
-Фамилия риэлтора, оформившего сделку купли-продажи
-Имя риэлтора, оформившего сделку купли-продажи
-Отчество риэлтора, оформившего сделку купли-продажи

*/

-- при повторном создании таблицы, проверяем есть ли она уже. 
drop table if exists Deals;
drop table if exists EstateAgents;
drop table if exists Owners;
drop table if exists Flats;
drop table if exists Persons;
drop table if exists Streets;

--таблица с персонами
CREATE TABLE [dbo].[Persons]
(
	[Id] INT NOT NULL PRIMARY KEY Identity(1,1), 
    [Surname] NVARCHAR(60) NOT NULL,    -- фамилия персоны
    [Name] NVARCHAR(60) NOT NULL,       -- имя персоны
    [Patronymic] NVARCHAR(60) NOT NULL  -- очество персоны
);
go
-- таблица с названиями улиц
CREATE TABLE [dbo].[Streets]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Street] NVARCHAR(50) NOT NULL -- название улицы
);
go

-- данные о квартире 
CREATE TABLE [dbo].[Flats]
(
	[Id] INT NOT NULL PRIMARY KEY Identity, 
    [IdStreets] INT NOT NULL,        -- название улицы
    [House#] NVARCHAR(10) NOT NULL,  -- номер дома
    [Flat#] NVARCHAR(10) NOT NULL,   --номер квартиры
    [FlatArea] FLOAT NOT NULL,       -- площадь квартиры
    [Room#] INT NOT NULL,            -- количество комнат
    [FixPrice] INT NOT NULL,         -- зафиксированная цена продажи 

    -- внешний ключ связь к таблице Streets
    CONSTRAINT FK_Flats_Streets FOREIGN KEY(IdStreets) references dbo.Streets(Id), 
    -- ограничение на номер квартиры
    CONSTRAINT [CK_Flats_Flat#] CHECK (Flat# >0), 
    -- ограничения на площадь квартиры
    CONSTRAINT [CK_Flats_FlatArea] CHECK (FlatArea >0), 
    -- ограничения на цену квартиры
    CONSTRAINT [CK_Flats_FixPrice] CHECK (FixPrice >0)
);
go

-- данные о владельцах квартиры
CREATE TABLE [dbo].[Owners]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY (1,1), 
    [IdPerson] INT NOT NULL,    -- внешний ключ
    [OwnersPassport] NVARCHAR(15) NOT NULL  -- номер паспорта владельца

    --внешний ключ для связи с таблицей Persons
	CONSTRAINT FK_OWNERS_PERSONS FOREIGN KEY (IdPerson) references dbo.Persons(id)
);
go



--данные о риелторах
CREATE TABLE [dbo].[EstateAgents]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [IdPerson] INT NOT NULL, 
    [AgentsFee] FLOAT NOT NULL

    constraint CK_EstateAgents_AgentsFee check(AgentsFee > 0),

	CONSTRAINT FK_ESTATEAGENTS_PERSONS FOREIGN KEY (IdPerson) references dbo.Persons(Id)

);
go

--данные о сделках
CREATE TABLE [dbo].[Deals]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [IdOwner] INT NOT NULL, 
    [IdEstateAgent] INT NOT NULL, 
    [Date] DATE NOT NULL, 

	CONSTRAINT FK_OWNER_DEALS FOREIGN KEY (IdOwner) references dbo.Owners(id),
	CONSTRAINT FK_ESTATE_DELAS FOREIGN KEY (IdEstateAgent) references dbo.EstateAgents(id)

);
go