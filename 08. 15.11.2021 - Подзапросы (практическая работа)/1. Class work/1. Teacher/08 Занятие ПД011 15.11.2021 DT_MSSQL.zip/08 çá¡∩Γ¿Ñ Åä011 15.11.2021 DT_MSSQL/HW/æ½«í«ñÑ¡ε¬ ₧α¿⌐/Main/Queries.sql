﻿-- 1
-- Выбирает из таблицы КВАРТИРЫ информацию о 3-комнатных квартирах, 
-- расположенных на улице «Садовая». Значения задавать параметрами запроса
declare @street nvarchar(max) = 'vel',
		@rooms int = 5;

select * from ApartmentsView
where Rooms = @rooms and Street = @street 

go


-- 2
-- Выбирает из таблицы РИЭЛТОРЫ информацию о риэлторах, фамилия которых 
-- начинается с буквы «И» и процент вознаграждения больше 10%. Значения задавать параметрами запроса
declare @surname nvarchar(max) = 'B%',
		@percent float = 5

select * from AgentsView
where 
	Surname like @surname and
	DealPercent > @percent
	
go


-- 3
-- Выбирает из таблицы КВАРТИРЫ информацию об 1-комнатных квартирах, цена 
-- на которые находится в диапазоне от 900 000 руб. до 1000 000 руб. Значения задавать параметрами запроса
declare @min money = 4000000,
		@max money = 8000000

select * from ApartmentsView
where Price between @min and @max

go


-- 4
-- Выбирает из таблицы КВАРТИРЫ информацию о квартирах с заданным числом комнат. Значения задавать параметрами запроса
declare @rooms int = 3

select * from ApartmentsView
where Rooms = @rooms

go


-- 5
-- Выбирает из таблицы КВАРТИРЫ информацию обо всех 2-комнатных квартирах, 
-- площадь которых есть значение из некоторого диапазона. Значения задавать параметрами запроса
declare @rooms int = 2,
		@areaMin float = 40,
		@areaMax float = 70

select * from Apartments
where 
	Rooms = @rooms and
	Area between @areaMin and @areaMax

go


-- 6
-- Вычисляет для каждой оформленной сделки размер комиссионного вознаграждения риэлтора. 
-- Включает поля Фамилия риэлтора, Имя риэлтора, Отчество риэлтора, 
-- Дата сделки, Цена квартиры, Комиссионные. Сортировка по полю Дата сделки
select 
	AgentSurname,
	AgentFirstname,
	AgentPatronymic,
	RegistrationDate,
	Price,
	DealPercent,
	dbo.CalculateAgentAward(Price, DealPercent) as AgentAward
from DealsView
order by RegistrationDate

go


-- 7
-- Выбрать всех риэлторов, количество клиентов, 
-- оформивших с ним сделки и сумму сделок риэлтора. Упорядочить выборку по убыванию суммы сделок.
select 
	a.AgentsId as AgentId,
	Count(ClientsId) as DealsCount,
	Sum(d.Price) as DealsTotal
from AgentsView a
left join DealsView d on a.AgentsId = d.AgentsId
group by a.AgentsId

go


-- 8
-- Для всех улиц вывести сумму сделок, упорядочить выборку по убыванию суммы сделки
select
	a.Street,
	Sum(a.Price) as Total
from Apartments a
left join Deals d on d.ApartmentId = a.ApartmentsId
group by a.Street
order by Total desc

go


-- 9
-- Для всех улиц вывести сумму сделок за заданный период, упорядочить 
-- выборку по убыванию суммы сделки. Диапазон задавать параметрами запроса
declare @firstDate date = '12/01/2021',
		@secondDate date = '2/26/2022'

select
	a.Street,
	Sum(a.Price) as Total
from Apartments a
left join Deals d on a.ApartmentsId = d.ApartmentId
where d.RegistrationDate between @firstDate and @secondDate
group by a.Street
order by Total desc

go


-- 10
-- Выполняет группировку по полю Количество комнат. 
-- Для каждой группы вычисляет среднее значение по полю Цена квартиры
select 
	a.Rooms,
	avg(a.Price) as AveragePrice
from Apartments a
group by a.Rooms

go


-- 11
-- Выполняет группировку по полю Площадь квартиры. Для каждой 
-- группы вычисляет наибольшее и наименьшее значение по полю Цена квартиры
select
	a.Area,
	max(a.Price) as MaxPrice,
	min(a.Price) as MinPrice
from Apartments a
group by a.Area

go


-- 12
-- Создает таблицу КВАРТИРЫ_3_КОМН, содержащую информацию о 3-комнатных квартирах
drop table if exists ApartmentsWith3Rooms

select * into ApartmentsWith3Rooms
from Apartments a
where a.Rooms = 3

go


-- 13
-- Создает копию таблицы КВАРТИРЫ с именем КОПИЯ_КВАРТИРЫ
drop table if exists ApartmentsCopy

select * into ApartmentsCopy
from Apartments

go


-- 14
-- Удаляет из таблицы КОПИЯ_КВАРТИРЫ записи, в которых значение в поле Цена квартиры больше 3 000 000 руб.
delete from ApartmentsCopy
where Price > 3000000

go


-- 15
-- Увеличивает значение в поле Цена квартиры таблицы КОПИЯ_КВАРТИРЫ на 10 процентов для 1-комнатных квартир
update ApartmentsCopy
set Price += (Price / 100) * 10
where Rooms = 1

go