﻿-- Создание всех таблиц проекта

-- удаление существующих таблиц, работает в MS SQL Server 2016+
drop table if exists Deals;
drop table if exists Seller;
drop table if exists Realtor;
drop table if exists [Apartment];
drop table if exists Person;
drop table if exists [Address];
drop table if exists StreetName;
drop table if exists StreetType;
go

-- таблица для типов улиц
CREATE TABLE [dbo].[StreetType]
(
	[Id] INT NOT NULL PRIMARY KEY Identity (1, 1), 
    [TypeOfStreet] NVARCHAR(50) NOT NULL
)

-- таблица для наименования улиц
CREATE TABLE [dbo].[StreetName]
(
	[Id] INT NOT NULL PRIMARY KEY Identity (1,1), 
    [NameOfStreet] NVARCHAR(60) NOT NULL,
)


-- таблица персон
CREATE TABLE [dbo].[Person] (
    [Id]         INT           IDENTITY (1, 1) NOT NULL,
    [Surname]    NVARCHAR (50) NOT NULL,
    [Name]       NVARCHAR (50) NOT NULL,
    [Patronymic] NVARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

-- таблица адресов
CREATE TABLE [dbo].[Address] (
    [Id]              INT           IDENTITY (1, 1) NOT NULL,
    [IdStreetType]    INT           NOT NULL,
    [IdStreetName]    INT           NOT NULL,
    [HouseNumber]     NVARCHAR (10) NOT NULL,
    [ApartmentNumber] NVARCHAR (10) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Address_ToTable] FOREIGN KEY ([IdStreetName]) REFERENCES [dbo].[StreetName] ([Id]),
    CONSTRAINT [FK_Address_TypeStreet] FOREIGN KEY ([IdStreetType]) REFERENCES [dbo].[StreetType] ([Id])
);

-- таблица риелторов
CREATE TABLE [dbo].[Realtor] (
    [Id]       INT IDENTITY (1, 1) NOT NULL,
    [IdPerson] INT NOT NULL,
    [Percent]  INT NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Realtor_Person] FOREIGN KEY ([IdPerson]) REFERENCES [dbo].[Person] ([Id])
);

-- таблица квартир
CREATE TABLE [dbo].[Apartment] (
    [Id]         INT IDENTITY (1, 1) NOT NULL,
    [IdAddress]  INT NOT NULL,
    [Area]       INT NOT NULL,
    [CountRooms] INT NOT NULL,
    [Price]      FLOAT NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Apartment_Address] FOREIGN KEY ([IdAddress]) REFERENCES [dbo].[Address] ([Id])    
);

-- таблица владельцев квартир
CREATE TABLE [dbo].[Seller]
(
	[Id] INT NOT NULL PRIMARY KEY Identity (1,1), 
    [IdApartment] INT NOT NULL, 
    [IdPerson] INT NOT NULL,
	[PassportID]  NVARCHAR (15) NOT NULL, 
    CONSTRAINT [FK_Seller_Apartment] FOREIGN KEY ([IdApartment]) REFERENCES [Apartment]([Id]), 
    CONSTRAINT [FK_Seller_Person] FOREIGN KEY ([IdPerson]) REFERENCES [Person]([Id])

);

-- таблица сделок
CREATE TABLE [dbo].[Deals]
(
	[Id] INT NOT NULL PRIMARY KEY Identity (1,1), 
    [IdRealtor] INT NOT NULL, 
    [IdSeller] INT NOT NULL, 
    [Date] DATE NOT NULL, 
    CONSTRAINT [FK_Deals_Realtor] FOREIGN KEY ([IdRealtor]) REFERENCES [Realtor]([Id]), 
    CONSTRAINT [FK_Deals_Seller] FOREIGN KEY ([IdSeller]) REFERENCES [Seller]([Id])
);