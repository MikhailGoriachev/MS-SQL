﻿-- запросы
-- 1	Запрос с параметрами	
-- Выбирает из таблицы КВАРТИРЫ информацию о 3-комнатных квартирах, 
-- расположенных на улице «Садовая». Значения задавать параметрами запроса
declare @CountRooms int = 3, 
        @NameOfStreet nvarchar(60) = N'Садовая';
select
    Apartment.Id
    , StreetType.TypeOfStreet
    , StreetName.NameOfStreet
    , [Address].HouseNumber
    , [Address].ApartmentNumber
    , Apartment.Area
    , Apartment.CountRooms
    , Apartment.Price
    
from
    Apartment join ( [Address] join  StreetType on [Address].IdStreetType = StreetType.id
                               join  StreetName on [Address].IdStreetName = StreetName.id)
                    on Apartment.IdAddress = [Address].Id
where
    StreetName.NameOfStreet = @NameOfStreet and Apartment.CountRooms = @CountRooms
go
-- с использовнием подзапроса
declare @CountRooms int = 3, 
        @NameOfStreet nvarchar(60) = N'Садовая';
select
    Apartment.Id
    , StreetType.TypeOfStreet
    , StreetName.NameOfStreet
    , [Address].HouseNumber
    , [Address].ApartmentNumber
    , Apartment.Area
    , Apartment.CountRooms
    , Apartment.Price
    
from
    Apartment join ( [Address] join  StreetType on [Address].IdStreetType = StreetType.id
                               join  StreetName on [Address].IdStreetName = StreetName.id)
                    on Apartment.IdAddress = [Address].Id
where
    Apartment.CountRooms in (select Apartment.CountRooms from Apartment where Apartment.CountRooms = @CountRooms)     
    and  StreetName.NameOfStreet in (select StreetName.NameOfStreet from StreetName where StreetName.NameOfStreet like @NameOfStreet)     
go










-- 2	Запрос с параметрами	
-- Выбирает из таблицы РИЭЛТОРЫ информацию о риэлторах, фамилия которых начинается 
-- с буквы «И» и процент вознаграждения больше 10%. Значения задавать параметрами запроса
declare @SurNameStart nvarchar(1) = N'И', 
        @Persent int = 10;
select
    Realtor.Id
    , Person.Surname
    , Person.[Name]
    , Person.Patronymic
    , Realtor.[Percent]
    
from
    Realtor join Person on Realtor.IdPerson = Person.Id
where
    Person.Surname like @SurNameStart+N'%' and Realtor.[Percent]>@Persent
go
-- с использовнием подзапроса
declare @SurNameStart nvarchar(1) = N'И', 
        @Persent int = 10;
select
    Realtor.Id
    , Person.Surname
    , Person.[Name]
    , Person.Patronymic
    , Realtor.[Percent]
    
from
    Realtor join Person on Realtor.IdPerson = Person.Id
where
     Person.Surname in (select Person.Surname from Person where Person.Surname like @SurNameStart+N'%')
     and Realtor.[Percent] in (select Realtor.[Percent] from Realtor where Realtor.[Percent] > @Persent)
go





-- 3	Запрос с параметрами	
-- Выбирает из таблицы КВАРТИРЫ информацию об 1-комнатных квартирах, 
-- цена на которые находится в диапазоне от 900 000 руб. до 1000 000 руб. 
-- Значения задавать параметрами запроса
declare @CountRooms int = 1, 
        @loprice int = 900000,
        @hiprice int = 1000000;
select
    Apartment.Id
    , StreetType.TypeOfStreet
    , StreetName.NameOfStreet
    , [Address].HouseNumber
    , [Address].ApartmentNumber
    , Apartment.Area
    , Apartment.CountRooms
    , Apartment.Price
    
from
    Apartment join ( [Address] join  StreetType on [Address].IdStreetType = StreetType.id
                               join  StreetName on [Address].IdStreetName = StreetName.id)
                    on Apartment.IdAddress = [Address].Id
where
    Apartment.CountRooms = @CountRooms and (Apartment.Price between  @loprice and @hiprice)
go
-- с использовнием подзапроса
declare @CountRooms int = 1, 
        @loprice int = 900000,
        @hiprice int = 1000000;
select
    Apartment.Id
    , StreetType.TypeOfStreet
    , StreetName.NameOfStreet
    , [Address].HouseNumber
    , [Address].ApartmentNumber
    , Apartment.Area
    , Apartment.CountRooms
    , Apartment.Price
    
from
    Apartment join ( [Address] join  StreetType on [Address].IdStreetType = StreetType.id
                               join  StreetName on [Address].IdStreetName = StreetName.id)
                    on Apartment.IdAddress = [Address].Id
where
    Apartment.CountRooms in (select Apartment.CountRooms from Apartment where Apartment.CountRooms = @CountRooms)
    and Apartment.Price in (select Apartment.Price from Apartment where Apartment.Price between @loprice and @hiprice)
go



-- 4	Запрос с параметрами	
-- Выбирает из таблицы КВАРТИРЫ информацию о квартирах с заданным числом комнат.
-- Значения задавать параметрами запроса
declare @CountRooms int = 3;
select
    Apartment.Id
    , StreetType.TypeOfStreet
    , StreetName.NameOfStreet
    , [Address].HouseNumber
    , [Address].ApartmentNumber
    , Apartment.Area
    , Apartment.CountRooms
    , Apartment.Price
    
from
    Apartment join ( [Address] join  StreetType on [Address].IdStreetType = StreetType.id
                               join  StreetName on [Address].IdStreetName = StreetName.id)
                    on Apartment.IdAddress = [Address].Id
where
    Apartment.CountRooms = @CountRooms
go
-- с использовнием подзапроса
declare @CountRooms int = 3;
select
    Apartment.Id
    , StreetType.TypeOfStreet
    , StreetName.NameOfStreet
    , [Address].HouseNumber
    , [Address].ApartmentNumber
    , Apartment.Area
    , Apartment.CountRooms
    , Apartment.Price
    
from
    Apartment join ( [Address] join  StreetType on [Address].IdStreetType = StreetType.id
                               join  StreetName on [Address].IdStreetName = StreetName.id)
                    on Apartment.IdAddress = [Address].Id
where
    Apartment.CountRooms in (select Apartment.CountRooms from Apartment where Apartment.CountRooms = @CountRooms)
go

-- 5	Запрос с параметрами	
-- Выбирает из таблицы КВАРТИРЫ информацию обо всех 2-комнатных квартирах, 
-- площадь которых есть значение из некоторого диапазона. 
-- Значения задавать параметрами запроса
declare @CountRooms int = 2, 
        @loArea int = 51,
        @hiArea int = 60;
select
    Apartment.Id
    , StreetType.TypeOfStreet
    , StreetName.NameOfStreet
    , [Address].HouseNumber
    , [Address].ApartmentNumber
    , Apartment.Area
    , Apartment.CountRooms
    , Apartment.Price
    
from
    Apartment join ( [Address] join  StreetType on [Address].IdStreetType = StreetType.id
                               join  StreetName on [Address].IdStreetName = StreetName.id)
                    on Apartment.IdAddress = [Address].Id
where
    Apartment.CountRooms in (select Apartment.CountRooms from Apartment where Apartment.CountRooms = @CountRooms)
    and Apartment.Area in (select Apartment.Area from Apartment where Apartment.Area between @loArea and @hiArea)
go


-- 6	Запрос с вычисляемыми полями	
-- Вычисляет для каждой оформленной сделки размер комиссионного вознаграждения риэлтора. 
-- Включает поля Фамилия риэлтора, Имя риэлтора, Отчество риэлтора, Дата сделки, Цена квартиры, Комиссионные. 
-- Сортировка по полю Дата сделки
select
    Deals.Id
    , Person.Surname
    , Person.[Name]
    , Person.Patronymic
    , Deals.[Date]
    , Apartment.Price
    , Apartment.Price*Realtor.[Percent]/100 as Commission
    
    
from
    Deals join ( Realtor join Person on Realtor.IdPerson = Person.Id)
           on Deals.IdRealtor = Realtor.Id
          join ( Seller join ( Apartment join ( [Address] join  StreetType on [Address].IdStreetType = StreetType.id
                                                          join  StreetName on [Address].IdStreetName = StreetName.id)
                                         on Apartment.IdAddress = [Address].Id)
                        on Seller.IdApartment = Apartment.Id)
                        
           on Deals.IdSeller=Seller.Id  
order by
    Deals.[Date]
go

-- 7	Запрос на левое соединение	
-- Выбрать всех риэлторов, количество клиентов, оформивших с ним сделки и сумму сделок риэлтора. 
-- Упорядочить выборку по убыванию суммы сделок.
select
    Person.Surname     
    , COUNT (Deals.Id) as AmountClients
    , SUM (Apartment.Price) as TransactionAmount
    
from
    Deals left join ( Realtor join Person on Realtor.IdPerson = Person.Id)
           on Deals.IdRealtor = Realtor.Id
          join ( Seller join ( Apartment join ( [Address] join  StreetType on [Address].IdStreetType = StreetType.id
                                                          join  StreetName on [Address].IdStreetName = StreetName.id)
                                         on Apartment.IdAddress = [Address].Id)
                        on Seller.IdApartment = Apartment.Id)
                        
           on Deals.IdSeller=Seller.Id  
group by
    Person.Surname
order by  
    SUM (Apartment.Price) desc   
go

-- 8	Запрос на левое соединение	
-- Для всех улиц вывести сумму сделок, 
-- упорядочить выборку по убыванию суммы сделки
select
    StreetName.NameOfStreet         
    , SUM (Apartment.Price) as TransactionAmount
    
from
    Deals left join ( Realtor join Person on Realtor.IdPerson = Person.Id)
           on Deals.IdRealtor = Realtor.Id
          join ( Seller join ( Apartment join ( [Address] join  StreetType on [Address].IdStreetType = StreetType.id
                                                          join  StreetName on [Address].IdStreetName = StreetName.id)
                                         on Apartment.IdAddress = [Address].Id)
                        on Seller.IdApartment = Apartment.Id)
                        
           on Deals.IdSeller=Seller.Id  
group by
    StreetName.NameOfStreet
order by  
    SUM (Apartment.Price) desc   
go


-- 9	Запрос на левое соединение	
-- Для всех улиц вывести сумму сделок за заданный период, 
-- упорядочить выборку по убыванию суммы сделки. 
-- Диапазон задавать параметрами запроса
declare @DateStart date = '8-01-21', 
        @DateEnd date = '8-30-21';
select
    StreetName.NameOfStreet         
    , SUM (Apartment.Price) as TransactionAmount
    
from
    Deals left join ( Realtor join Person on Realtor.IdPerson = Person.Id)
           on Deals.IdRealtor = Realtor.Id
          join ( Seller join ( Apartment join ( [Address] join  StreetType on [Address].IdStreetType = StreetType.id
                                                          join  StreetName on [Address].IdStreetName = StreetName.id)
                                         on Apartment.IdAddress = [Address].Id)
                        on Seller.IdApartment = Apartment.Id)
                        
           on Deals.IdSeller=Seller.Id  
where 
    Deals.[Date] in (select Deals.[Date] from Deals where Deals.[Date] between @DateStart and @DateEnd)
group by
    StreetName.NameOfStreet
order by  
    SUM (Apartment.Price) desc   
go

-- 10	Итоговый запрос	
-- Выполняет группировку по полю Количество комнат. 
-- Для каждой группы вычисляет среднее значение по полю Цена квартиры
select
    Apartment.CountRooms
    , AVG(Apartment.Price) as AVGPrice
    
from
    Apartment join ( [Address] join  StreetType on [Address].IdStreetType = StreetType.id
                               join  StreetName on [Address].IdStreetName = StreetName.id)
                    on Apartment.IdAddress = [Address].Id
group by
    Apartment.CountRooms
go

-- 11	Итоговый запрос	
-- Выполняет группировку по полю Площадь квартиры. 
-- Для каждой группы вычисляет наибольшее и наименьшее значение по полю Цена квартиры
select
    Apartment.Area
    , MIN(Apartment.Price) as MinPrice
    , MAX(Apartment.Price) as MaxPrice
    
from
    Apartment join ( [Address] join  StreetType on [Address].IdStreetType = StreetType.id
                               join  StreetName on [Address].IdStreetName = StreetName.id)
                    on Apartment.IdAddress = [Address].Id
group by
    Apartment.Area
go


-- 12	Запрос на создание базовой таблицы	
-- Создает таблицу КВАРТИРЫ_3_КОМН, 
-- содержащую информацию о 3-комнатных квартирах
declare @CountRoom int = 3;
select
    *
    into ApartmentThreerooms
from
    Apartment
where
    Apartment.CountRooms in (select Apartment.CountRooms from Apartment where Apartment.CountRooms = @CountRoom )

-- удалить таблицу ApartmentThreerooms
-- drop table if exists ApartmentThreerooms;

-- 13	Запрос на создание базовой таблицы	
-- Создает копию таблицы КВАРТИРЫ с именем КОПИЯ_КВАРТИРЫ
select
    *
    into Copy_Apartment
from
    Apartment;

-- удалить таблицу Copy_Apartment
-- drop table if exists Copy_Apartment;



-- 14	Запрос на удаление	
-- Удаляет из таблицы КОПИЯ_КВАРТИРЫ записи, в которых значение в поле 
-- Цена квартиры больше 3 000 000 руб.
-- удаление по заданию с использованием подзапроса
declare @price int = 3000000;
delete from 
    Copy_Apartment
where                              
    Copy_Apartment.Price = any (select Copy_Apartment.Price from Copy_Apartment where Copy_Apartment.Price > @price);  


-- 15	Запрос на обновление	
-- Увеличивает значение в поле Цена квартиры таблицы 
-- КОПИЯ_КВАРТИРЫ на 10 процентов для 1-комнатных квартир
declare @Percent int=10,
        @CountRooms float = 1;

update 
    Copy_Apartment
set
    Copy_Apartment.Price *= 1+(@CountRooms/100)
where    
    Copy_Apartment.CountRooms = all (select Copy_Apartment.CountRooms from  Copy_Apartment where Copy_Apartment.CountRooms = @CountRooms);