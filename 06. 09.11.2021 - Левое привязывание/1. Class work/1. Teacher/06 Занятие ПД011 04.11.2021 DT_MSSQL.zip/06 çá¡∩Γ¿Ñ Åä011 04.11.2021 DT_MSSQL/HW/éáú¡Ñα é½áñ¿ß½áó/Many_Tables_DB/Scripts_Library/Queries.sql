﻿-- Вывести полную информацию обо всех книгах
select
    Books.Id
    , Authors.FullName
    , Categories.Category
    , Books.Title
    , Books.Published
    , Books.Price
    , Books.Amount
from
    
    Books inner join Authors on Books.IdAuthor = Authors.Id inner join Categories on Books.IdCategory = Categories.Id;

-- Вывести полную информацию по книгам заданного автора, изданным в заданный период. 
  -- Например, автор Абрамян М.Э., период с 2002 по 2019
  select
      Books.Id
    , Authors.FullName
    , Categories.Category
    , Books.Title
    , Books.Published
    , Books.Price
    , Books.Amount
  from
    Books inner join Authors on Books.IdAuthor = Authors.Id 
          inner join Categories on Books.IdCategory = Categories.Id
    where 
        Authors.author = N'Абрамян %' and Books.Pusblished between 2002 and 2019;

--Вывести название, год издания и количество (поле books.amount) книг заданной категории, имеющих заданную строку в названии. 
 --Например, категория «задачник», строка в названии «LINQ». 
 select
      Books.Title
    , Books.Published
    , Books.Amount
  from
    Books inner join Authors on Books.IdAuthor = Authors.Id 
          inner join Categories on Books.IdCategory = Categories.Id
  where 
    Categories.Category =  N'% LINQ[ .-–]%'
    
-- Таже самая выборка, но через gorup by
  select
      Categories.Category
     , sum(Books.Amount) as LINQ_Books
     , AVG (Books.Price) as AveragePrice
  from
    Books inner join Authors on Books.IdAuthor = Authors.Id 
          inner join Categories on Books.IdCategory = Categories.Id
  group by
    Categories.Category
  having
    Categories.Category = N'LINQ[ .-–]%'
     

-- Вывести автора, название, категорию и стоимость для каждой книги, количество которых от 4 до 6 
select
     Authors.FullName
    , Books.Title
    , Categories.Category
    , Books.Amount
  from
    Books inner join Authors on Books.IdAuthor = Authors.Id 
          inner join Categories on Books.IdCategory = Categories.Id
  where 
    Books.Price between 4 and 6;
-- Вывести фамилии и инициалы авторов, количество (сумма полей books.amount) книг этих авторов
select
     Authors.FullName
     , sum(Books.Amount) as Amount
  from
    Books inner join Authors on Books.IdAuthor = Authors.Id 
          inner join Categories on Books.IdCategory = Categories.Id
  group by 
     Authors.FullName
-- Для категорий книг вывести количество, минимальную стоимость книги, среднюю стоимость книги, максимальную стоимость книги
select
Categories.Category
, COUNT(Books.id) as Books_amount
,  MIN(Price) as Min_Book_Price
, AVG (Price) as Average_Price
, MAX (Price) as Max_Book_Price
    
  from
    Books inner join Authors on Books.IdAuthor = Authors.Id 
          inner join Categories on Books.IdCategory = Categories.Id
  group by 
    Categories.Category;

-- Вывести общее количество книг по C++
select
Categories.Category
, COUNT(Books.id) as Books_amount
,  MIN(Price) as Min_Book_Price
, AVG (Price) as Average_Price
, MAX (Price) as Max_Book_Price
    
  from
    Books inner join Authors on Books.IdAuthor = Authors.Id 
          inner join Categories on Books.IdCategory = Categories.Id
  where 
  -- Интервальные символы задаю специально для лучшего понимания
    Books.Title = N'%[-–. ]C++ %'