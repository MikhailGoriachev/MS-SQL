﻿-- Создание всех таблиц БД library 

create table dbo.Books (

 Id int not null primary key identity (1,1),
 Title nvarchar(110) not null,
 Pusblished date not null,
 Price float not null,
 Amount int not null,

 -- ограничения для сохранения корректности данных
  constraint CK_Books_Price check (Price >= 0),   -- Цена не отрицательна
  constraint CK_Books_Amount check (Amount >= 0), -- Вероятно кол-во книг также не может быть отрицательным
  --constraint FK_ID_books_Id_authors

);
go

-- Создание таблицы авторов 
create table dbo.Authors 
(
 Id int not null primary key identity (1,1),
 FullName nvarchar(150) not null
);
go

-- Создание таблицы категорий 
create table dbo.Categories
(
	Id int not null primary key identity (1,1),
	Category nvarchar(50) not null
);
go

