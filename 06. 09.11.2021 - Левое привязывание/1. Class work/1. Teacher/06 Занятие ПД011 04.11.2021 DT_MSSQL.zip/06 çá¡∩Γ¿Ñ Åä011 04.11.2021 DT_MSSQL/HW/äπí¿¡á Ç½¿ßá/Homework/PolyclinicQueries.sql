﻿-- 1. Запрос с параметром	
--    Выбирает из таблицы ПАЦИЕНТЫ информацию о пациентах, 
--    фамилия которых начинается с заданной буквы (например, «И»)
select
	*
from
	Patients
where 
	[Name] like N'И%';


-- 2. Запрос на выборку	
--    Выбирает из таблицы ВРАЧИ информацию о врачах,
--    имеющих заданную специальность. Например, «хирург»
select
	*
from
	Doctors
where 
	Speciality = N'хирург';


-- 3. Запрос на выборку	
--    Выбирает из таблиц ВРАЧИ, ПАЦИЕНТЫ и ПРИЕМЫ
--    информацию о приемах: фамилия и инициалы пациента,
--    дата приема, дата рождения пациента, специальность врача,
--    стоимость прима
select
    -- фамилия и инициалы пациента
    Patients.Surname + N' '
    + Substring(Patients.[Name], 0, 2) + N'. '
    + Substring(Patients.Patronymic, 0, 2) + N'.' as Patient

    , Patients.DateOfBirth
    , [Date]
    , Doctors.Speciality
    , Doctors.Price
from
    Receptions inner join Doctors on Receptions.Doctor = Doctors.Id 
               inner join Patients on Receptions.Patient = Patients.Id;


-- 4. Запрос с параметром	
--    Выбирает из таблицы ВРАЧИ информацию о врачах 
--    с заданным значением в поле Стоимость приема. 
--    Конкретное значение стоимости приема вводится 
--    при выполнении запроса
declare @price float = 1000.00
select 
    *
from
    Doctors
where 
    Price = @price;
go


-- 5. Запрос с параметром	
--    Выбирает из таблицы ВРАЧИ информацию о врачах, 
--    Процент отчисления на зарплату которых находится
--    в некотором заданном диапазоне. Нижняя и верхняя 
--    границы диапазона задаются при выполнении запроса
declare @lo float = 6.0, @hi float = 8.3;
select 
    *
from
    Doctors
where 
    SalaryPercentage between @lo and @hi;
go


-- 6. Запрос с вычисляемыми полями	
--    Вычисляет размер заработной платы врача за каждый прием.
--    Включает поля Фамилия врача, Имя врача, Отчество врача, 
--    Специальность врача, Стоимость приема, Зарплата. 
--    Сортировка по полю Фамилия врача
select 
    Surname
    , [DocName]
    , Patronymic
    , Speciality
    , Price
    -- Заработная плата =
    -- Стоимость приема * Процент отчисления от стоимости приема на зарплату врача
    -- Из этой суммы вычитается подоходный налог, составляющий 13% от суммы.
    , Price * SalaryPercentage / 100 * 0.87 as Salary
from
    Doctors
order by
    Surname


-- 7. Итоговый запрос	
--    Выполняет группировку по полю Дата приема. 
--    Для каждой даты вычисляет минимальную стоимость приема
select
    [Date]
    , Min(Doctors.Price) as MinPrice
from
    Receptions inner join Doctors on Receptions.Doctor = Doctors.Id 
               inner join Patients on Receptions.Patient = Patients.Id
group by
    [Date];


-- 8. Итоговый запрос	
--    Выполняет группировку по полю Специальность. 
--    Для каждой специальности вычисляет максимальный 
--    Процент отчисления на зарплату от стоимости приема
select 
    Speciality
    , MAX(SalaryPercentage) as MaxPercentage
from
    Doctors
group by
    Speciality
