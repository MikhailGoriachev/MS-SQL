﻿--drop table Doctors
--drop table Patients
--drop table Reception

--delete from Doctors
--delete from Patients
--delete from Reception


-- Таблица сведений о докторах --> Doctors
CREATE TABLE [dbo].[Doctors] (
    [Id]         INT           IDENTITY (1, 1) NOT NULL,
    [Surname]    NVARCHAR (60) NOT NULL,        -- Фамилия доктора
    [Name]       NVARCHAR (60) NOT NULL,        -- Имя доктора
    [Patronymic] NVARCHAR (60) NOT NULL,        -- Отчество доктора
    [Speciality] NVARCHAR (60) NOT NULL,        -- Специальность доктора
    [Price]      int   NOT NULL,                -- Стоимость приема врача
    [Percent]    FLOAT (53)    NOT NULL,        -- Процент отчисления от стоимости приема на зарплату доктора
    CONSTRAINT [CK_Doctors_Price] CHECK (Price > 0), 
    CONSTRAINT [CK_Doctors_Percent] CHECK ([Percent] > 0),
    PRIMARY KEY CLUSTERED ([Id] ASC)
);
go

--Таблица свелений о пациентах --> Patients
CREATE TABLE [dbo].[Patients] (
    [Id]         INT           IDENTITY (1, 1) NOT NULL,
    [Surname]    NVARCHAR (60) NOT NULL,        -- Фамилия пациента
    [Name]       NVARCHAR (60) NOT NULL,        -- Имя пациента
    [Patronymic] NVARCHAR (60) NOT NULL,        -- Отчество пациента
    [DateOfBorn] DATE          NOT NULL,        -- Дата рождения пациента
    [Adress]     NVARCHAR (60) NOT NULL,        -- Адрес пациента
    CONSTRAINT [PK_Patients] PRIMARY KEY CLUSTERED ([Id] ASC)
);
go

--Таблица сведений о приемах --> Reception
CREATE TABLE [dbo].[Reception] (
    [Id]              INT           IDENTITY (1, 1) NOT NULL,
    [DateOfReception] NVARCHAR (50) NOT NULL,       -- Дата приема
    [Price]           INT           NOT NULL,       -- Стоимость приема
    [DoctorId]        INT           NOT NULL,       -- Id врача
    [PatientId]       INT           NOT NULL,       -- Id пациента
    CONSTRAINT [PK_Reception] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Reception_Patients] FOREIGN KEY ([PatientId]) REFERENCES [dbo].[Patients] ([Id]),
    CONSTRAINT [FK_Reception_Doctors] FOREIGN KEY ([DoctorId]) REFERENCES [dbo].[Doctors] ([Id])
);
go


-- Запись данных в таблицы --

-- запись в таблицы докторов
insert Doctors
    ([Surname], [Name], [Patronymic], [Speciality], [Price], [Percent])
values
    (N'Молчанов',    N'Артём',      N'Макарович',   N'Гематолог',  6046, 11.03),
    (N'Ильин',       N'Богдан',     N'Даниилович',  N'Венеролог',  9683, 12.53),
    (N'Сорокина',    N'Вероника',   N'Ильинична',   N'Психиатор',  8555, 5.30 ),
    (N'Марков',      N'Максим',     N'Билалович',   N'Терапевт',   5101, 12.29),
    (N'Куликова',    N'Елизавета',  N'Романовна',   N'Травматолог',8958, 4.63 ),
    (N'Широков',     N'Иван',       N'Дмитриевич',  N'Токсиколог', 3858, 1.35 ),
    (N'Зайцева',     N'Алёна',      N'Львовна',     N'Уролог',     3509, 10.99),
    (N'Фролов',      N'Георгий',    N'Михайлович',  N'Фармацевт',  7840, 5.95 ),
    (N'Скворцов',    N'Лука',       N'Ярославович', N'Хирург',     3672, 5.13 ),
    (N'Иванов',      N'Иван',       N'Иванович',    N'Фармацевт',  9036, 6.13 );
go

-- запись в таблицы пациентов
insert Patients
    ([Surname],[Name], [Patronymic],[DateOfBorn], [Adress])
values
    (N'Соколова',   N'Мария',       N'Елисеевна',     N'09-26-91',  N'пр. Домодедовская 74'),
    (N'Панов',      N'Никита',      N'Алексеевич',    N'12-20-18',  N'ул. 1905 года 85'    ),
    (N'Покровская', N'Антонина',    N'Ильинична',     N'08-30-94',  N'пер. 1905 года 27'   ),
    (N'Леонова',    N'Виктория',    N'Артёмовна',     N'11-04-13',  N'сп. Ломоносова 35'   ),
    (N'Яковлева',   N'Дарья',       N'Мироновна',     N'10-17-84',  N'пл. Ленина 93'       ),
    (N'Корнилова',  N'Марьям',      N'Георгиевна',    N'09-02-85',  N'сп. Балканская 33'   ),
    (N'Степанов',   N'Дмитрий',     N'Александрович', N'01-27-15',  N'пр. Гагарина 57'     ),
    (N'Агафонов',   N'Артём',       N'Иванович',      N'03-24-12',  N'ш. Сталина 39'       ),
    (N'Демидова',   N'Софья',       N'Фёдоровна',     N'12-24-12',  N'б. Ломоносова 90'    ),
    (N'Карасева',   N'Виктория',    N'Александровна', N'01-21-12',  N'пл. Чехова 15'       );
go

-- запись в таблицы приемов
insert Reception
    ([DateOfReception], [Price], [DoctorId], [PatientId])
values
    (N'02-20-21', 9660,  1, 1),
    (N'09-18-21', 10938, 1, 4),
    (N'06-23-22', 14649, 4, 2),
    (N'08-26-22', 7113,  2, 6),
    (N'11-27-20', 5607,  3, 5),
    (N'05-23-21', 11420, 5, 7),
    (N'01-08-22', 15297, 8, 8),
    (N'06-10-21', 1960,  9, 9),
    (N'05-10-21', 13872, 6, 4),
    (N'01-11-21', 15000, 6, 4);
go