﻿-- запросы к таблицам базы данных Polyclinic
-- Таблица Specialities
select 
    *
from
    Specialities;

-- Таблица Persons
select
    *
from
    Persons;

-- Таблица Patients с расшифровкой поля IdPerson
select
    Patients.Id
    , Persons.Surname      as PatientSurname
    , Persons.[Name]       as PatientName
    , Persons.Patronymic   as PatientPatronymic
    , Patients.BornDate 
    , Patients.[Address]
from
    Patients join Persons on Patients.IdPerson = Persons.Id;

-- Таблица Doctors с расшифровкой полей IdPerson, IdSpeciality
select
    Doctors.Id
    , Persons.Surname          as DoctorSurname
    , Persons.[Name]           as DoctorName
    , Persons.Patronymic       as DoctorPatronymic
    , Specialities.Speciality 
    , Doctors.Price
    , Doctors.[Percent]
from
    Doctors join Persons on Doctors.IdPerson = Persons.Id
            join Specialities on Doctors.IdSpeciality = Specialities.Id;


-- таблица Appointments с расшифровкой полей IdPatient, IdDoctor
select
    Appointments.Id
    , Appointments.AppointmentDate
    , Persons.Surname as PatientSurname
    , Persons.[Name] as PatientName
    , Persons.Patronymic as PatientPatronymic
    , DateDiff(Year, Patients.BornDate, GetDate()) as Age
    , Patients.BornDate
    , Patients.[Address]
    , P.Surname as DoctorSurname
    , P.[Name] as DoctorName
    , P.Patronymic as DoctorPatronymic
    , Specialities.Speciality
    , Doctors.Price
    , Doctors.[Percent]
from
    Appointments 
        join (Patients join Persons on Patients.IdPerson = Persons.Id) 
             on Appointments.IdPatient = Patients.Id
        join (Doctors join Specialities on Doctors.IdSpeciality = Specialities.Id
                      join Persons P on Doctors.IdPerson = P.Id)
             on Appointments.IdDoctor = Doctors.Id;
go

-- ------------------------------------------------------------------------

-- запросы к таблицам базы данных Polyclinic по заданию

-- Запрос 1. Запрос с параметром	
-- Выбирает из таблицы ПАЦИЕНТЫ информацию о пациентах, фамилия которых
-- начинается с заданной буквы (например, «И»)
declare @firstLetter nvarchar = N'И';

select
    Patients.Id
    , Persons.Surname      as PatientSurname
    , Persons.[Name]       as PatientName
    , Persons.Patronymic   as PatientPatronymic
    , Patients.BornDate
    , Patients.[Address]
from
    Patients join Persons on Patients.IdPerson = Persons.Id
where
    Persons.Surname like @firstLetter + '%';
go

-- Запрос 2. Запрос на выборку	
-- Выбирает из таблицы ВРАЧИ информацию о врачах, имеющих заданную 
-- специальность. Например, «хирург»
declare @speciality nvarchar(40) = N'хирург';

select
    Doctors.Id
    , Persons.Surname
    , Persons.[Name]
    , Persons.Patronymic
    , Specialities.Speciality
    , Doctors.Price
    , Doctors.[Percent]
from
    Doctors join Persons on Doctors.IdPerson = Persons.Id
            join Specialities on Doctors.IdSpeciality = Specialities.Id
where
    Specialities.Speciality = @speciality;
go


-- Запрос 3. Запрос на выборку	
-- Выбирает из таблиц ВРАЧИ, ПАЦИЕНТЫ и ПРИЕМЫ информацию о приемах: 
-- фамилия и инициалы пациента, дата приема, дата рождения пациента, 
-- специальность врача, стоимость приема
select
    Persons.Surname + N' ' + SUBSTRING(Persons.[Name], 1, 1) + N'.' + SUBSTRING(Persons.Patronymic, 1, 1) + N'.' as Patient
    , Appointments.AppointmentDate
    , Patients.BornDate
    -- разность двух дат
    , DateDiff(Year, Patients.BornDate, GetDate()) as Age
    , Specialities.Speciality as Specialist
    , Doctors.Price
from
    Appointments join (Patients join Persons on Patients.IdPerson = Persons.Id) 
                      on Appointments.IdPatient = Patients.Id
                 join (Doctors join Specialities on Doctors.IdSpeciality = Specialities.Id)
                      on Appointments.IdDoctor = Doctors.Id;
go


-- Запрос 4. Запрос с параметром	
-- Выбирает из таблицы ВРАЧИ информацию о врачах с заданным значением 
-- в поле Стоимость приема. Конкретное значение стоимости приема вводится 
-- при выполнении запроса
declare @price int = 300;

select
    Doctors.Id
    , Persons.Surname
    , Persons.[Name]
    , Persons.Patronymic
    , Specialities.Speciality
    , Doctors.Price
    , Doctors.[Percent]
from
    Doctors join Persons on Doctors.IdPerson = Persons.Id
            join Specialities on Doctors.IdSpeciality = Specialities.Id
where
    Doctors.Price = @price;
go


-- Запрос 5. Запрос с параметром	
-- Выбирает из таблицы ВРАЧИ информацию о врачах, Процент отчисления на 
-- зарплату которых находится в некотором заданном диапазоне. Нижняя и 
-- верхняя границы диапазона задаются при выполнении запроса
declare @loPerscent float = 2, @hiPercent float = 3.5;

select
    Doctors.Id
    , Persons.Surname
    , Persons.[Name]
    , Persons.Patronymic
    , Specialities.Speciality
    , Doctors.Price
    , Doctors.[Percent]
from
    Doctors join Persons on Doctors.IdPerson = Persons.Id
            join Specialities on Doctors.IdSpeciality = Specialities.Id
where
    Doctors.[Percent] between @loPerscent and @hiPercent
order by
    Doctors.[Percent]
go


-- Запрос 6. Запрос с вычисляемыми полями	
-- Вычисляет размер заработной платы врача за каждый прием. Включает поля 
-- Фамилия врача, Имя врача, Отчество врача, Специальность врача, Стоимость 
-- приема, Зарплата. Сортировка по полю Фамилия врача
select
    Doctors.Id
    , Persons.Surname
    , Persons.[Name]
    , Persons.Patronymic
    , Specialities.Speciality
    , Doctors.Price
    , Doctors.[Percent]

    -- вычисляемое поле, зарплата за прием - 87% от начисления, 13% - подоходный налог
    , 0.87 * (Doctors.Price * Doctors.[Percent] / 100) as Salary
from
    Doctors join Persons on Doctors.IdPerson = Persons.Id
            join Specialities on Doctors.IdSpeciality = Specialities.Id
order by
    Persons.Surname
go
 	 	
        
-- Запрос 7. Итоговый запрос	
-- Выполняет группировку по полю Дата приема. Для каждой даты вычисляет 
-- минимальную стоимость приема
select
    Appointments.AppointmentDate
    , COUNT(Doctors.Price) as Amount
    , MIN(Doctors.Price) as MinPrice
    , AVG(Doctors.Price) as AvgPrice
    , MAX(Doctors.Price) as MaxPrice
from
    Appointments join Doctors on Appointments.IdDoctor = Doctors.Id
group by
    Appointments.AppointmentDate;
go


-- Запрос 8. Итоговый запрос	
-- Выполняет группировку по полю Специальность. Для каждой специальности 
-- (по данным докторов)  вычисляет максимальный Процент отчисления на зарплату 
-- от стоимости приема
select
    Specialities.Speciality
    , COUNT(*)                as Amount
    , MIN(Doctors.[Percent])  as MinPercent
from
    Doctors join Specialities on Doctors.IdSpeciality = Specialities.Id
group by
    Specialities.Speciality;
go


-- !!! Левое соединение !!!
-- Выполняет группировку по полю Специальность. Для каждой специальности 
-- вычисляет максимальный Процент отчисления на зарплату от стоимости приема
select
    Specialities.Speciality
    , COUNT(*)                as Amount
    , MIN(Doctors.[Percent])  as MinPercent
from
    Specialities left join Doctors on Doctors.IdSpeciality = Specialities.Id
group by
    Specialities.Speciality;
go

-- Выполняет группировку по полю Специальность. Для каждой специальности 
-- вычисляет максимальный Процент отчисления на зарплату от стоимости приема
select
    Specialities.Speciality
    , MAX(Doctors.[Percent])
from
    Specialities left join Doctors on Doctors.IdSpeciality = Specialities.Id
group by
    Specialities.Speciality;

-- Вывести всех пациентов и количестов приемов этих пациентов
select
    Patients.Id
    , COUNT(Appointments.IdPatient) as AppointmentsAmount
from
    Patients left join Appointments on Appointments.IdPatient = Patients.Id
group by
    Patients.Id; 
go

select * from Patients join Persons on Patients.IdPerson = Persons.Id;

select
    Patients.Id
    , Persons.Surname
    , Persons.[Name]
    , Persons.Patronymic
    , COUNT(Appointments.IdPatient) as AppointmentsAmount
from
    (Patients join Persons on Patients.IdPerson = Persons.Id) left join Appointments on Appointments.IdPatient = Patients.Id
group by
    Patients.Id, Persons.Surname, Persons.[Name], Persons.Patronymic; 

-- все пациенты и даты их премов
select
    Patients.Id
    , Persons.Surname
    , Persons.[Name]
    , Persons.Patronymic
    , Appointments.AppointmentDate
    , ISNULL(Appointments.AppointmentDate, '01-01-1900')
from
    (Patients join Persons on Patients.IdPerson = Persons.Id) left join Appointments on Appointments.IdPatient = Patients.Id
