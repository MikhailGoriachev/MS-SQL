﻿-- Удаление таблиц, если существуют
DROP TABLE IF EXISTS dbo.Appointments;
DROP TABLE IF EXISTS dbo.Doctors;
DROP TABLE IF EXISTS dbo.Patients;


-- Создание таблицы докторов
CREATE TABLE [dbo].[Doctors]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY(1, 1), -- Идентификатор БД
    [Surname] NVARCHAR(30) NOT NULL, 			  -- Фамилия
    [FirstName] NVARCHAR(30) NOT NULL, 			  -- Имя
    [Patronymic] NVARCHAR(30) NOT NULL, 		  -- Отчество
    [Speciality] NVARCHAR(60) NOT NULL, 		  -- Специализация
    [Price] INT NOT NULL, 						  -- Стоимость приёма
    [Deductions] REAL NOT NULL, 				  -- Отчисление процента врачу
    CONSTRAINT [CK_Doctors_Price] CHECK (Price > 0), 
    CONSTRAINT [CK_Doctors_Deductions] CHECK (Deductions > 0)
)

-- Заполнение таблицы докторов
INSERT INTO Doctors
	(Surname, Firstname, Patronymic, Speciality, Price, Deductions)
VALUES
	(N'Никитина', N'Стефания', N'Мироновна', N'Терапевт', 200, 25),
	(N'Самсонова', N'Софья', N'Ярославовна', N'Хирург',500, 45),
	(N'Харитонова', N'Евдокия', N'Артёмовна', N'Неонатолог', 300, 20),
	(N'Павловский', N'Иван', N'Русланович', N'Нейрохирург', 900, 50),
	(N'Александрова', N'Арина', N'Платоновна', N'Венеролог', 400, 30),
	(N'Сазонов', N'Дамир', N'Ярославович', N'Гастроэнтеролог', 350, 25),
	(N'Яковлев', N'Кирилл', N'Иванович', N'Дерматолог', 300, 33),
	(N'Медведев', N'Роман', N'Романович', N'Педиатр', 400, 28),
	(N'Антонов', N'Олег', N'Романович', N'Хирург', 700, 58),
	(N'Газманов', N'Юрий', N'Олегович', N'Хирург', 1500, 48),
	(N'Селиванов', N'Лев', N'Евгеньевич', N'Кардиолог', 330, 38),
	(N'Федотова', N'Полина', N'Демидовна', N'Ортопед', 200, 20),
	(N'Кисигач', N'Яна', N'Юрьевна', N'Терапевт', 100, 20),
	(N'Бергман', N'Вадим', N'Дмитриевич', N'Хирург', 600, 3),
	(N'Фролова', N'Алина', N'Андреевна', N'Терапевт', 400, 10)
	;


-- Создание таблицы пациентов
CREATE TABLE [dbo].[Patients]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY(1, 1),  -- Идентификатор БД
    [SurName] NVARCHAR(30) NOT NULL, 			   -- Фамилия
    [Firstname] NVARCHAR(30) NOT NULL, 			   -- Имя
    [Patronymic] NVARCHAR(30) NOT NULL, 		   -- Отчество
    [BirthDate] DATE NOT NULL,					   -- Дата Рождения
    [LivingAddress] NVARCHAR(100) NOT NULL		   -- Адрес проживания
)

-- Заполнение таблицы пациентов
INSERT INTO Patients
	(Surname, Firstname, Patronymic, BirthDate, LivingAddress)
VALUES
    (N'Петрова', N'Алиса', N'Мирославовна', '1963-03-18', N'ул. Торфяная 3-я, дом 32, квартира 70'),
    (N'Сидоров', N'Михаил', N'Юрьевич'     ,'2017-06-09', N'ул. Судовая, дом 160, квартира 98'),
    (N'Ершов', N'Степан', N'Германович'    ,'1957-12-22', N'ул. Волконский 1-й пер, дом 139, квартира 92'),
    (N'Филатова', N'Вероника', N'Давидовна','2007-11-27', N'ул. Новосибирская, дом 25, квартира 77'),
    (N'Лукин', N'Артём', N'Дмитриевич'     ,'1980-03-24', N'ул. Садовая, дом 105, квартира 55'),
    (N'Евсеев', N'Ярослав', N'Андреевич'   ,'1980-03-24', N'ул. Фрезер проезд, дом 31, квартира 37'),
    (N'Кулешова', N'Анна', N'Михайловна'   ,'1991-05-18', N'ул. Мира 2-й пер, дом 116, квартира 379'),
    (N'Измайлова', N'Олеся', N'Тимофеевна' ,'2021-02-22', N'ул. Зверинецкая, дом 7, квартира 967'),
    (N'Туманов', N'Артём', N'Денисович'    ,'1967-06-18', N'ул. Чкалова, дом 9, квартира 22'),
    (N'Белов', N'Богдан', N'Серафимович'   ,'1957-04-03', N'ул. Содовая, дом 152, квартира 119')

;

-- Создание таблицы приёма пациентов
DROP TABLE IF EXISTS dbo.Appointments;
CREATE TABLE [dbo].[Appointments]
(
	[Id]          INT           IDENTITY (1, 1) NOT NULL, -- Идентификатор БД
    [IdPatient]	  INT			NOT NULL, 				  -- Пациент
    [IdDoctor]    INT			NOT NULL, 				  -- Доктор
    [Price]       INT			NOT NULL, 				  -- Стоимость приёма
    [SessionDate] DATE			NOT NULL, 				  -- Дата посещения
    CONSTRAINT [FK_Appointments_Patients] FOREIGN KEY ([IdPatient]) REFERENCES [Patients]([Id]),
    CONSTRAINT [FK_Appointments_Doctors] FOREIGN KEY ([IdDoctor]) REFERENCES [Doctors]([Id])
)



-- Заполнение таблицы приёма пациентов
INSERT INTO Appointments
	(IdPatient, IdDoctor, Price, SessionDate)
VALUES
	(2, 5, 400, '20210703'),
	(3, 15, 400, '20210105'),
	(6, 6, 350, '20210307'),
	(4, 7, 300, '20210906'),
	(1, 6, 350, '20210102'),
	(3, 2, 500, '20210201'),
	(4, 3, 300, '20210402'),
	(7, 8, 900, '20210809'),
	(3, 4, 900, '20210205'),
	(1, 7, 300, '20210304')
	;