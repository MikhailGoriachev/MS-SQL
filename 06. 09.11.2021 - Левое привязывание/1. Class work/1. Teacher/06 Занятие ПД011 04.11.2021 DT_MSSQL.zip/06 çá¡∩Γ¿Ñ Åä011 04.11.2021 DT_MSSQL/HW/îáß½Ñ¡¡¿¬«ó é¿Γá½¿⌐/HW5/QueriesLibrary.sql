﻿--•	Запрос 1. Вывести полную информацию обо всех книгах
SELECT
    Books.Id
    , Authors.FullName
    , Categories.Category
    , Books.Title
    , Books.PubYear
    , Books.Price
    , Books.Amount
FROM
    Books inner join Authors on Books.IdAuthor = Authors.Id 
          inner join Categories on Books.IdCategory = Categories.Id;

--•	Запрос 2. Запрос с параметрами.
--Вывести полную информацию по книгам заданного автора, изданным в заданный период.
--Например, автор Абрамян М.Э., период с 2002 по 2019
SELECT
    Books.Id
    , Authors.FullName
    , Categories.Category
    , Books.Title
    , Books.PubYear
    , Books.Price
    , Books.Amount
FROM
    Books inner join Authors on Books.IdAuthor = Authors.Id 
          inner join Categories on Books.IdCategory = Categories.Id
WHERE Authors.FullName = N'Абрамян М.Э.' and Books.PubYear between 2002 and 2019;

--•	Запрос 3. Запрос с параметрами.
--Вывести название, год издания и количество (поле books.amount) книг заданной категории, 
--имеющих заданную строку в названии. Например, категория «задачник», строка в названии «LINQ». 
SELECT
    Books.Id
    , Books.Title
    , Books.PubYear
    , Books.Amount
FROM
    Books inner join Categories on Books.IdCategory = Categories.Id
WHERE Category = N'задачник' and
      Books.Title like N'% LINQ %';


--•	Запрос 4. Запрос с параметрами.
--Вывести автора, название, категорию и стоимость для каждой книги, количество которых от 4 до 6 
SELECT
    Books.Id
    , Authors.FullName
    , Books.Title
    , Categories.Category
    , Books.Price
    , Books.Amount
FROM 
    Books inner join Authors on Books.IdAuthor = Authors.Id 
          inner join Categories on Books.IdCategory = Categories.Id
WHERE Books.Amount between 4 and 6;

--•	Запрос 5. Итоговый запрос.
--Вывести фамилии и инициалы авторов, количество (сумма полей books.amount) книг этих авторов
SELECT
    Authors.FullName as Author,
    SUM(Books.Amount) as Amount
FROM 
    Books inner join Authors on Books.IdAuthor = Authors.Id
GROUP BY Authors.FullName;

--•	Запрос 6. Итоговый запрос.
--Для категорий книг вывести количество, минимальную стоимость книги,
--среднюю стоимость книги, максимальную стоимость книги
SELECT
    Categories.Category as Category,
    COUNT(Books.IdCategory) as Amount,
    MIN(Books.Price) as MinPrice,
    MAX(Books.Price) as MaxPrice
FROM 
    Books inner join Categories on Books.IdCategory = Categories.Id
GROUP BY 
    Categories.Category

--•	Запрос 7. Итоговый запрос.
--Вывести общее количество книг по C++ (сумма полей books.amount)

SELECT
    COUNT(Books.Amount) as Amount
FROM 
    Books
WHERE
    Books.Title like N'%C++%';