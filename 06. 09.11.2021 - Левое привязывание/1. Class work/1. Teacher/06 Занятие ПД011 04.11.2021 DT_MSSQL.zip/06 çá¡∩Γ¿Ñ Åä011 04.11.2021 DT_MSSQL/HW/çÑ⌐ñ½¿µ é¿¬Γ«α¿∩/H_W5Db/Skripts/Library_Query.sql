﻿-- Запрос 1. Вывести полную информацию обо всех книгах
select
    Books.Id
    , Authors.FullName
    , Categories.Category
    , Books.Title
    , Books.PubYear
    , Books.Price
    , Books.Amount
from
    Books join Authors on Books.IdAuthor = Authors.Id 
          join Categories on Books.IdCategory = Categories.Id;

-- Запрос 2. Запрос с параметрами.
-- Вывести полную информацию по книгам заданного автора,
-- изданным в заданный период.
-- Например, автор Абрамян М.Э., период с 2002 по 2019
select
    Books.Id
    , Authors.FullName
    , Categories.Category
    , Books.Title
    , Books.PubYear
    , Books.Price
    , Books.Amount
from
    Books inner join Authors on Books.IdAuthor = Authors.Id 
          inner join Categories on Books.IdCategory = Categories.Id
where
    Authors.Fullname = N'Дейтел П.' and 
    Books.PubYear between 2011 and 2016;

-- Запрос 3. Запрос с параметрами.
-- Вывести название, год издания и количество (поле books.amount) книг заданной категории,
-- имеющих заданную строку в названии.
-- Например, категория «задачник», строка в названии «LINQ». 
select
    Books.Id
    , Books.Title
    , Books.PubYear
    , Books.Amount
from
    Books inner join Authors on Books.IdAuthor = Authors.Id 
          inner join Categories on Books.IdCategory = Categories.Id
where
    Categories.Category = N'учебник' and
    Books.Title like N'Android %' or Books.Title like N'% Android' or Books.Title like N'% Android %';

-- Запрос 4. Запрос с параметрами.
-- Вывести автора, название, категорию и стоимость для каждой книги,
-- количество которых от 4 до 6 
select
    Books.Id
    , Authors.FullName
    , Categories.Category
    , Books.Title
    , Books.Price
    , Books.Amount
from
    Books inner join Authors on Books.IdAuthor = Authors.Id 
          inner join Categories on Books.IdCategory = Categories.Id
where
    Books.Amount between 4 and 6;

-- Запрос 5. Итоговый запрос.
-- Вывести фамилии и инициалы авторов,
-- количество (сумма полей books.amount) книг этих авторов
select
    Authors.FullName
    , Sum(Books.Amount) as SumTotal
from
    Books join Authors on Books.IdAuthor = Authors.Id 
group by
    Authors.FullName;

-- Запрос 6. Итоговый запрос.
-- Для категорий книг вывести количество,
-- минимальную стоимость книги,
-- среднюю стоимость книги,
-- максимальную стоимость книги
select
    Categories.Category
    , Count(Categories.Category) as CntCategory
    , Min(Books.Price) as MinPrice
    , AVG(Books.Price) as AvgPrice
    , Max(Books.Price) as Maxprice
from 
    Books inner join Categories on Books.IdCategory = Categories.Id
group by
    Categories.Category;

-- Запрос 7. Итоговый запрос.
-- Вывести общее количество книг по C++ (сумма полей books.amount)
select
    Books.Title
    , Sum(Books.Amount) as SumTotal
from
    Books
where
   Books.Title like N'С++ %' or Books.Title like N'% С++' or Books.Title like N'% С++ %'
group by
   Books.Title;
