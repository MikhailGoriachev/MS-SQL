﻿-- 1. Запрос с параметром
-- Выбирает из таблицы ПАЦИЕНТЫ информацию о пациентах,
-- фамилия которых начинается с заданной буквы (например, «И»)
select
   *
from
   Patients
where
    SurnamePatient like N'К%';

-- 2. Запрос на выборку
-- Выбирает из таблицы ВРАЧИ информацию о врачах,
-- имеющих заданную специальность. Например, «хирург»
select
    Doctors.Id
    , SurnameDoc
    , NameDoc
    , PatronymicDoc
    , Specialties.Speciality
    , CostOfAdmission
    , PercentOfDeduction
from
    Doctors join Specialties on Doctors.IdSpeciality = Specialties.Id 
where
    Speciality = N'хирург';

-- 3. Запрос на выборку
-- Выбирает из таблиц ВРАЧИ, ПАЦИЕНТЫ и ПРИЕМЫ информацию о приемах:
-- фамилия и инициалы пациента, дата приема, дата рождения пациента,
-- специальность врача, стоимость приёма
select
    --Receptions.Id
     Patients.SurnamePatient
    , Receptions.DateOfReceipt
    , Patients.DateOfBirth
    , Specialties.Speciality
    , Doctors.SurnameDoc
    , Doctors.CostOfAdmission
from
    Receptions join Patients on Receptions.IdPatient = Patients.Id
               join Doctors on Receptions.IdDoctor = Doctors.Id 
               join Specialties on Doctors.IdSpeciality = Specialties.Id; 

-- 4. Запрос с параметром
-- Выбирает из таблицы ВРАЧИ информацию о врачах с
-- заданным значением в поле Стоимость приема.
-- Конкретное значение стоимости приема вводится при выполнении запроса
declare @cost int = 500;
select
   *
from
   Doctors
where
    CostOfAdmission = @cost;
go

-- 5. Запрос с параметром
-- Выбирает из таблицы ВРАЧИ информацию о врачах,
-- Процент отчисления на зарплату которых находится в
-- некотором заданном диапазоне.
-- Нижняя и верхняя границы диапазона задаются при выполнении запроса
declare @lo int = 3, @hi int = 5;
select
   *
from
   Doctors
where
    PercentOfDeduction between @lo and @hi
order by
    PercentOfDeduction;
go

-- 6. Запрос с вычисляемыми полями
-- Вычисляет размер заработной платы врача за каждый прием.
-- Размер начисляемой врачу заработной платы за каждый прием
-- вычисляется по формуле:
-- Стоимость приема * Процент отчисления от стоимости приема на зарплату врача. 
-- Включает поля Фамилия врача, Имя врача, Отчество врача,
-- Специальность врача, Стоимость приема, Зарплата.
-- Сортировка по полю Фамилия врача
declare @salaryDoc int = (CostOfAdmission * PercentOfDeduction);
-- add Salary
select
   Doctors.Id
   , SurnameDoc
   , NameDoc
   , PatronymicDoc
   , Specialties.Speciality
   , CostOfAdmission
from
   Doctors join Specialties on Doctors.IdSpeciality = Specialties.Id 
order by
    Doctors.SurnameDoc;
go

-- 7. Итоговый запрос
-- Выполняет группировку по полю Дата приема.
-- Для каждой даты вычисляет минимальную стоимость приема
select
   DateOfReceipt
   , Min(CostOfAdmission) as MinCost
from
   Receptions, Doctors
group by
   DateOfReceipt;


-- 8. Итоговый запрос
-- Выполняет группировку по полю Специальность.
-- Для каждой специальности вычисляет максимальный
-- Процент отчисления на зарплату от стоимости приема
select
    Speciality
    , Max(PercentOfDeduction) as MaxPercent
from
    Doctors join Specialties on Doctors.IdSpeciality = Specialties.Id
group by
    Speciality;   

   