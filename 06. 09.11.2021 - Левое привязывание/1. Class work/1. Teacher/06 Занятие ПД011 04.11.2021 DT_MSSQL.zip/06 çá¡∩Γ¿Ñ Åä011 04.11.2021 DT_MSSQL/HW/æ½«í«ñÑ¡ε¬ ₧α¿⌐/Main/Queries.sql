﻿-- 1
-- Выбирает из таблицы ПАЦИЕНТЫ информацию о пациентах, 
-- фамилия которых начинается с заданной буквы (например, «И»)
declare @symbol varchar = 'H%'

select * from Patients p
where p.Surname like @symbol
go


-- 2
-- Выбирает из таблицы ВРАЧИ информацию о врачах, имеющих заданную 
-- специальность. Например, «хирург»
select 
	Surname, Firstname, Patronymic, Category, Cost, InterestDeduction
from Doctors d
join Categories c on d.CategoryId = c.Id
where Category = N'хирург'
go


-- 3
-- Выбирает из таблиц ВРАЧИ, ПАЦИЕНТЫ и ПРИЕМЫ информацию о приемах: 
-- фамилия и инициалы пациента, дата приема, дата рождения 
-- пациента, специальность врача, стоимость прима
select 
	p.Surname as PatientSurname,
	formatmessage('%s.%s', SUBSTRING(p.Firstname, 0, 2), 
		SUBSTRING(p.Patronymic, 0, 2)) as PatientInitials,
	convert(nvarchar, r.Date, 103) as ReceptionDate,
	p.BirthDate as PatientBirthDate,
	c.Category as DoctorsCategory,
	r.Cost as ReceptionCost
from Reception r
join Patients p on r.PatientId = p.Id
join Doctors d on r.DoctorId = d.Id
join Categories c on d.CategoryId = c.Id
go


-- 4
-- Выбирает из таблицы ВРАЧИ информацию о врачах с заданным значением в поле 
-- Стоимость приема. Конкретное значение стоимости приема вводится при выполнении запроса
declare @cost money = 1303.0000;

select * from Doctors d
where d.Cost = @cost;
go


-- 5
-- Выбирает из таблицы ВРАЧИ информацию о врачах, Процент отчисления на зарплату 
-- которых находится в некотором заданном диапазоне. Нижняя и верхняя границы диапазона 
-- задаются при выполнении запроса
declare @min float = 3,
		@max float = 7;

select * from Doctors d
where d.InterestDeduction between @min and @max
go


-- 6
-- Вычисляет размер заработной платы врача за каждый прием. 
-- Включает поля Фамилия врача, Имя врача, Отчество врача, Специальность врача, 
-- Стоимость приема, Зарплата. Сортировка по полю Фамилия врача
select 
	d.Id,
	r.Id,
	d.Surname,
	d.Firstname,
	d.Patronymic,
	c.Category,
	r.Cost as ReceptionCost,
	dbo.CalculateDoctorsSalary(r.Cost, d.InterestDeduction) as PaymentPerReception
from Doctors d
join Reception r on d.Id = r.DoctorId
join Categories c on d.CategoryId = c.Id
order by d.Surname
go


-- 7
-- Выполняет группировку по полю Дата приема. 
-- Для каждой даты вычисляет минимальную стоимость приема
select 
	r.Date,
	Min(r.Cost) as MinCost
from Reception r
group by r.Date
go


-- 8
-- Выполняет группировку по полю Специальность. 
-- Для каждой специальности вычисляет максимальный Процент отчисления 
-- на зарплату от стоимости приема
select 
	c.Category,
	Max(d.InterestDeduction) as MaxInterest
from Doctors d
join Categories c on d.CategoryId = c.Id
group by c.Category
go