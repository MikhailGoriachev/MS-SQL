﻿


-- создание представления для Фактов проката
create view ViewRentals as
    select
       Rentals.Id
       , Clients.Surname
       , Clients.[Name]
       , Clients.Patronymic
       , Clients.Passport
       , Brands.Brand
       , Colors.Color
       , Cars.Plate
       , Cars.YearManufac
       , Cars.InsurancePay
       , Cars.Rental
       , Rentals.DateStart
       , Rentals.Duration
    from
        Rentals join Clients on Rentals.IdClient = Clients.Id
			   Join (Cars join Brands on Cars.IdBrand = Brands.Id
						  join Colors on Cars.IdColor = Colors.Id)
									  on Rentals.IdCar = Cars.Id 
go


-- 1 запрос
-- Выбирает информацию обо всех фактах проката
-- автомобиля с заданным госномером

declare @plate nvarchar(10) = 'C 615 CO';

select
	 *
from
	ViewRentals
where
	Plate = @plate;
go
	 

-- 2 запрос
-- Выбирает информацию обо всех фактах проката
-- автомобиля с заданной моделью/брендом

declare @brand nvarchar(20) = 'Kia Carnival';

select
	 *
from
	ViewRentals
where
	Brand = @brand;
go


-- 3 запрос
-- Выбирает информацию об автомобиле с заданным госномером

declare @plate nvarchar(10) = 'H 817 HK';

select
	 Brand
	 , Color
	 , InsurancePay
	 , Plate
	 , Plate
	 , Rental
	 , YearManufac
from
	ViewRentals
where
	Plate = @plate;
go


-- 4 запрос
-- Выбирает информацию о клиентах по серии и номеру паспорта

declare @pass1 nvarchar(20) = '19 83 716251',
		@pass2 nvarchar(20) = '98 87 172615';		

select
	Id
	, Surname
	, [Name]
	, Patronymic
	, Brand
	, DateStart
	, Duration
	, Rental
from
	ViewRentals
where
	Passport = @pass1
	or Passport = @pass2;
go


-- 5 запрос
-- Выбирает информацию обо всех зафиксированных фактах
-- проката автомобилей в некоторый заданный интервал времени.

declare @dLo Date = '11-01-2021',
		@dHi Date = '11-11-2021';

select
	 *
from
	ViewRentals
where
	DateStart between @dLo and @dHi;
go


-- 6 запрос
-- Вычисляет для каждого факта проката стоимость проката.
-- Включает поля Дата проката, Госномер автомобиля,
-- Модель автомобиля, Стоимость проката.
-- Сортировка по полю Дата проката

select
	 DateStart
	 , Plate
	 , Brand
	 , Rental * Duration as CostRental
from
	ViewRentals
order by
	DateStart;
go


-- 7 запрос
-- Для всех клиентов прокатной фирмы вычисляет количество
-- фактов проката, суммарное количество дней проката,
-- упорядочивание по убыванию суммарного количества дней проката

select
	Clients.Surname
	, Clients.[Name]
	, Clients.Patronymic
	, Clients.Passport
	, Count(Rentals.IdCar) as AmountRental
	, Sum(Rentals.Duration) as Rental
from
	Clients left join Rentals on Clients.Id = Rentals.IdClient
group by
	Clients.Surname, Clients.[Name], Clients.Patronymic, Clients.Passport
order by
	Sum(Rentals.Duration) desc;
go


-- 8 запрос
-- Выполняет группировку по полю Модель автомобиля.
-- Для каждой модели вычисляет количество фактов проката, сумму за прокат

select
	 Brands.Brand
	 , Count(Brand) as AmountRental
	 , Sum(Cars.Rental * Rentals.Duration) as Rental
from
	(Brands join Cars on Brands.Id = Cars.IdBrand) join Rentals on Cars.Id = Rentals.IdCar
group by
	Brands.Brand;
go	


-- 9 запрос
-- Добавляет данные о новом клиенте.
-- Данные передавайте параметрами

declare @surname     nvarchar(60) = N'Астахова',
		@name	     nvarchar(60) = N'Аделина',
		@patronymic	 nvarchar(60) = N'Артуровна',
		@passport    nvarchar(20) = '17 16 892716';

insert into Clients
	(Surname, [Name], Patronymic, Passport)
values
	(@surname, @name, @patronymic, @passport);
go


-- 10 запрос
-- Изменяет данные клиента (все поля, кроме идентификатора).
-- Данные передавайте параметрами

declare @id int = 1,
		@surname    nvarchar(60) = N'Носов',
		@name       nvarchar(60) = N'Роман',
		@patronymic nvarchar(60) = N'Иванович',
		@passport   nvarchar(20) = '81 71 921822';

update 
	Clients
set
	Surname      = @surname
	, [Name]     = @name
	, Patronymic = @patronymic
	, Passport   = @passport
where
	Id = @id;
go


-- 11 запрос
-- Изменяет данные автомобиля (все поля, кроме идентификатора).
-- Данные передавайте параметрами

declare @id           int = 1,
		@idB          int = 2,
		@idC          int = 2,
		@plate        nvarchar(20) = 'O 111 OO',
		@yearM        int  = 2019,
		@insuranceP   int = 25000,
		@rental       int = 6200;

update 
	Cars
set
	IdBrand        = @idB
	, IdColor      = @idC
	, Plate        = @plate
	, YearManufac  = @yearM
	, InsurancePay = @insuranceP
	, Rental       = @rental
where
	Id = @id;
go


---------------------------------------------------------------------------------------------------
--										T-SQL

-- 12 запрос
-- Задача If13. Даны три числа.
-- Найти среднее из них (то есть число,
-- расположенное между наименьшими наибольшим).
-- Числа формируйте генератором случайных чисел

declare @a int = -100 + 200*rand(),
		@b int = -100 + 200*rand(),
		@c int = -100 + 200*rand();
declare @avg int;

if (@a < @c and @c < @b) or (@b < @c and @c < @a) begin
	set @avg = @c;
end else if (@b < @a and @a < @c) or (@c < @a and @a < @b) begin 
	set @avg = @a;
end else begin
	set @avg = @b;
end

print N'Результат:' + char(10) +   -- вывод в область сообщений
      char(9) + 'a   = ' + ltrim(str(@a)) + char(10) +
      char(9) + 'b   = ' + ltrim(str(@b)) + char(10) + 
      char(9) + 'c   = ' + ltrim(str(@c)) + char(10) + 
      char(9) + 'avg = ' + ltrim(str(@avg));
go


-- 13 запрос
-- Задача If14. Даны три числа.
-- Вывести вначале наименьшее,
-- а затем наибольшее из данных чисел.
-- Числа формируйте генератором случайных чисел

declare @a int = -100 + 200*rand(),
		@b int = -100 + 200*rand(),
		@c int = -100 + 200*rand(),
		@min int, @max int;

if @a < @b and @a < @c begin
   set @min = @a;
end else if @b < @a and @b < @c begin
   set @min = @b;
end else begin
	set @min = @c;
end;

if @a <> @min and @a > @b and @a > @c begin
	set @max = @a;
end else if @b <> @min and @b > @c and @b > @a begin
	set @max = @b;
end else begin
	set @max = @c;
end;

print N'Результат:' + char(10) +   -- вывод в область сообщений
      char(9) + 'a   = ' + ltrim(str(@a)) + char(10) +
      char(9) + 'b   = ' + ltrim(str(@b)) + char(10) + 
      char(9) + 'c   = ' + ltrim(str(@c)) + char(10) + 
      char(9) + 'min = ' + ltrim(str(@min)) + char(10) + 
      char(9) + 'max = ' + ltrim(str(@max));
go


-- 14 запрос
-- Задача If15. Даны три числа.
-- Найти сумму двух наибольших из них.
-- Числа формируйте генератором случайных чисел

declare @a    int = -100 + 200*rand(),
		@b    int = -100 + 200*rand(),
		@c    int = -100 + 200*rand(),
		@summ int;

if @a <= @b and @a <= @c begin
	set @summ = @b + @c
end else if @b <= @a and @b <= @c begin
	set @summ = @a +@c
end else if @c <= @a and @c <= @b begin
	set @summ = @a + @b
end;


print N'Результат:' + char(10) +   -- вывод в область сообщений
      char(9) + 'a    = ' + ltrim(str(@a)) + char(10) +
      char(9) + 'b    = ' + ltrim(str(@b)) + char(10) + 
      char(9) + 'c    = ' + ltrim(str(@c)) + char(10) + 
      char(9) + 'summ = ' + ltrim(str(@summ));
go


-- 15 запрос
-- Задача If17. Даны три числа.
-- Если их значения упорядочены по возрастанию или убыванию,
-- то удвоить их; в противном случае заменить значение каждой
-- переменной на противоположное.
-- Числа формируйте генератором случайных чисел или присваиванием

declare @a    int = -100 + 200*rand(),
		@b    int = -100 + 200*rand(),
		@c    int = -100 + 200*rand();

print N'До работы с ними:' + char(10) +   -- вывод в область сообщений
   char(9) + 'a    = ' + ltrim(str(@a)) + char(10) +
   char(9) + 'b    = ' + ltrim(str(@b)) + char(10) + 
   char(9) + 'c    = ' + ltrim(str(@c)); 


if (@a < @b and @b < @c) or (@a > @b and @b > @c) begin
	set @a *= 2;
	set @b *= 2;
	set @c *= 2;
end else begin
	set @a = -@a;
	set @b = -@b;
	set @c = -@c;
end

print char(10) + N'После работы с ними:' + char(10) +   -- вывод в область сообщений
      char(9) + 'a    = ' + ltrim(str(@a)) + char(10) +
      char(9) + 'b    = ' + ltrim(str(@b)) + char(10) + 
      char(9) + 'c    = ' + ltrim(str(@c)); 
go
