﻿-- Создание представлений в базе данных аренды автомобилей

-- информация об автомобилях
select 
   Cars.Id
   ,BrandModels.BrandModel
   , Colors.Color
   , Cars.Plate
   , Cars.YearManuf
   , Cars.InsurValue
   , Cars.Rental
from 
    Cars join BrandModels on Cars.IdBrand = BrandModels.Id
         join Colors on Cars.IdColor = Colors.Id
go

-- создание представления об автомобилях 
create view ViewCars as 

select 
   Cars.Id
   ,BrandModels.BrandModel
   , Colors.Color
   , Cars.Plate
   , Cars.YearManuf
   , Cars.InsurValue
   , Cars.Rental
from 
    Cars join BrandModels on Cars.IdBrand = BrandModels.Id
         join Colors on Cars.IdColor = Colors.Id
go

--информация о клиентах 
select 
* 
from 
    Clients
go

-- создание представления о клиентах
create view AllClients as 

select 
* 
from 
    Clients
go


-- создание представления о клиентах 



--факты проката
select 
   Hires.Id
   , Cars.Rental
   , Cars.Plate
   , Colors.Color
   , Clients.Surname + N' ' + Substring(Clients.[Name], 1,1) + N'.'+ Substring(Clients.Patronymic, 1,1) + N'.' as Client
   , Hires.DateStart
   , Hires.Duration
from
    Hires join (Cars join BrandModels on Cars.IdBrand = BrandModels.Id   
                     join Colors on Cars.IdColor = Colors.Id) on Hires.IdCar = Cars.Id
          join Clients on Hires.IdClient = Clients.Id
go 

--создание представления о фактах проката 
create view ViewHires as 
select 
   Hires.Id
   , Cars.Rental
   , Cars.Plate
   , BrandModels.BrandModel
   , Colors.Color
   , Clients.Surname + N' ' + Substring(Clients.[Name], 1,1) + N'.'+ Substring(Clients.Patronymic, 1,1) + N'.' as Client
   , Hires.DateStart
   , Hires.Duration
from
    Hires join (Cars join BrandModels on Cars.IdBrand = BrandModels.Id   
                     join Colors on Cars.IdColor = Colors.Id) on Hires.IdCar = Cars.Id
          join Clients on Hires.IdClient = Clients.Id
go 

-- использование представления о фактах проката 
select 
*
from ViewHires

go



-- 1. Запрос к представлению. Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
declare @plate nvarchar(12)  = N'С167РК'; 

select 
* 
from 
      ViewHires
where 
      Plate = @plate
go

--2. Запрос к представлению. Выбирает информацию обо всех фактах проката автомобиля с заданной моделью/брендом
declare @brand nvarchar(30) = N'Volkswagen Polo'; 

select 
* 
from 
    ViewHires
where 
     BrandModel = @brand
go 

-- 3. Запрос к представлению. Выбирает информацию об автомобиле с заданным госномером
declare @plate nvarchar(12)  = N'С167РК'; 

select 
*
from 
    ViewCars
where 
     Plate = @plate;
go

-- 4. Запрос к представлению. Выбирает информацию о клиентах по серии и номеру паспорта
declare @passport nvarchar(15) = N'11 21 098181';

select 
*
from 
    AllClients
where 
     Passport = @passport
go

-- 5 Запрос к представлению. Выбирает информацию обо всех зафиксированных фактах проката автомобилей в некоторый заданный интервал времени.
declare @from date = '2021-09-01', @to date = '2021-10-04'; 

select 
* 
from 
    ViewHires
where 
     DateStart between @from and @to
go 

-- 6. Запрос к представлению. Вычисляет для каждого факта проката стоимость проката. 
--Включает поля Дата проката, Госномер автомобиля, Модель автомобиля, Стоимость проката. Сортировка по полю Дата проката
select 
        Id
    , DateStart
    , Plate
    , BrandModel
    , Rental
    , Duration
    , Rental * Duration as Price
from 
    ViewHires
order by 
      DateStart
go
-- 7 Запрос с левым соединением. Для всех клиентов прокатной фирмы вычисляет количество фактов проката, 
--суммарное количество дней проката, упорядочивание по убыванию суммарного количества дней проката
select 
   Clients.Id
   , Clients.Surname + N' ' + SUBSTRING(Clients.[Name], 1,1) + N'.' + Substring(Clients.Patronymic, 1, 1) + N'.' as Clients
   , Count(Hires.IdCar) as Amount
   , Sum(Hires.Duration) as SumDuration 
from
     Clients left join Hires on Clients.Id = Hires.IdClient
group by
       Clients.Id, Clients.Surname, Clients.[Name], Clients.Patronymic
order by 
      SumDuration Desc
go

--8 Итоговый запрос. Выполняет группировку по полю Модель автомобиля. 
--Для каждой модели вычисляет количество фактов проката, сумму за прокат
select 
    BrandModel
    , Count(*) as AmountBrandModel
from 
    ViewHires
group by 
     BrandModel
go 

