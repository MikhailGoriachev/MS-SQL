﻿drop table if exists Orders;
drop table if exists Cars;
drop table if exists Brands;
drop table if exists Colors;
drop table if exists Clients;
drop view if exists CarsWithKeys;
drop view if exists OrdersWithKeys;
go


begin -- Clients


CREATE TABLE [dbo].[Clients]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Surname] NVARCHAR(50) NOT NULL, 
    [Firstname] NVARCHAR(50) NOT NULL, 
    [Patronymic] NVARCHAR(50) NOT NULL, 
    [Passport] NVARCHAR(40) NOT NULL
);


INSERT INTO Clients
VALUES
  ('Lowe','Xyla','F','LT724408574538385623'),
  ('Ray','Lara','U','AL80387957048638483742206749'),
  ('Collins','Stewart','D','GB32MMST98988476505234'),
  ('Mckay','Jael','J','LT220446822368805627'),
  ('Duffy','Quynn','H','BH81783523848646137394'),
  ('Pollard','Jescie','T','PK6189461214298473906177'),
  ('White','Lev','U','CY81880770748473437301111378'),
  ('Goodman','Mona','Z','AZ55184348354313861867506346'),
  ('Elliott','Acton','O','AD0345844487641731513680'),
  ('Pickett','Brett','F','BH25736525766254352348'),
  ('Barber','Aladdin','Z','LB50124364752307916434755586'),
  ('Rivers','Paul','N','AL46667813275158833673159884'),
  ('Hartman','Fritz','E','MT16HJMA40787407497873357848192'),
  ('Shields','Fuller','U','FO9510631513952736'),
  ('Barlow','Mohammad','I','MK93738705257362488'),
  ('Duran','Colin','W','SE2494138221502942834765'),
  ('Moore','Felix','U','AD0725334724126798136244'),
  ('Cash','James','F','ME75551187660624176025'),
  ('Gibson','Donna','K','PT04078291517123822573713'),
  ('Daugherty','Jesse','H','CH9126077766085362575'),
  ('Wolf','Rachel','L','NO9213866718550'),
  ('Garrett','Alfreda','L','CH0288398458353117422'),
  ('Larsen','Kenyon','M','GL3879263235346717'),
  ('Nguyen','Hayfa','M','AT752323319415913126'),
  ('Collins','Eliana','B','AL12278708208296174765357813'),
  ('Calhoun','Maggie','A','DE25651537465872471276'),
  ('Tyson','Abdul','I','RS70313814374154357034'),
  ('Deleon','Rachel','I','LB27462729469862582682555563'),
  ('Dalton','Quamar','M','RS10110257788014356964'),
  ('Craft','Reed','D','LI8138329928274885445'),
  ('Dixon','Zachary','K','IT575YXUAI21644183181533663'),
  ('Peck','Gail','H','DO95211813755331202486056128'),
  ('Bailey','Germaine','S','IL382264534252809112452'),
  ('Lynch','Quinlan','Y','HU89731512234485465846811544'),
  ('Stout','Hilel','L','SI32759884377724438'),
  ('Hahn','Camilla','E','CR3306142101103470541'),
  ('Pittman','Byron','P','SM8962210618184156952573092'),
  ('Parrish','Leroy','P','CZ4854381273562232461445'),
  ('Austin','Hammett','F','NO3255626085355'),
  ('Munoz','Lavinia','L','AE585804780498496097647'),
  ('Clark','Rachel','Q','FR6051553188921897726567286'),
  ('Dunn','Tarik','T','AT567604575438053631'),
  ('Mccormick','Gage','J','SK5510757256172933812741'),
  ('Raymond','Clinton','U','PS325087797671041065357867515'),
  ('Payne','Shannon','L','RO33YTMQ9094222871223229'),
  ('Pitts','Dominic','L','IE92VEPT45467215676432'),
  ('Meadows','Ezekiel','C','VG4136149843456468812579'),
  ('Russell','Kay','P','LU787133413090585232'),
  ('Parks','Ulla','D','HR1527764886797848094'),
  ('Knox','Quinlan','G','RS18224097474117578463'),
  ('Bray','Evan','M','DK1181172930685537'),
  ('Reeves','Latifah','W','PK3166810632214837658868'),
  ('Padilla','Zahir','D','AZ57133905361780373066155053'),
  ('Trujillo','Patience','F','DO92790553374776145356132586'),
  ('Burris','Kelly','K','BH59885775526731631713'),
  ('Coleman','Neville','X','CZ4681211631344035447591'),
  ('Holt','Bo','K','SK3540500243290569772105'),
  ('Coleman','Octavius','D','VG0414445843311400541511'),
  ('Knowles','Ishmael','V','GI27OCLH868428191129203'),
  ('Horn','Stewart','O','FR0585779042869499274234171'),
  ('Kent','Sara','Q','IS263348538545615141646263'),
  ('Buckley','Rhoda','C','SA6611502215228871545377'),
  ('Pittman','Lance','N','FR8175686730584816598751658'),
  ('Peters','Ronan','T','KW3511285658151392752446004321'),
  ('Mcfadden','Omar','P','IT611MGOMI89887951461256025'),
  ('Hardin','Channing','V','NL52MPOW4487448743'),
  ('Byers','Victoria','T','ME80247122677655546955'),
  ('Morales','Phelan','N','BG83QRDB68835925828733'),
  ('Moss','Barbara','W','IL407544456947052389334'),
  ('Armstrong','Alvin','B','SI94711822293796737'),
  ('Warren','Ruby','W','EE854380063887236731'),
  ('Witt','Kerry','O','SI82382458361253874'),
  ('Todd','Carissa','J','IS346573347329514599775405'),
  ('Farrell','Pearl','G','AZ29582784583245809346888389'),
  ('Moody','Tarik','L','MU7374327352679126496133176953'),
  ('Heath','Ramona','H','GE22404436361721177432'),
  ('Castro','Carla','O','SI68867450748253746'),
  ('Vaughn','Jelani','S','DO21233451324534171821824876'),
  ('Roman','Alyssa','L','GE44221877417858234248'),
  ('Key','Kyra','Y','MR5154420383147133353995789'),
  ('Marshall','Harlan','A','FI3364688404705131'),
  ('Blankenship','Chantale','F','CR2736126828875012578'),
  ('Fleming','MacKensie','N','AT418880257325326198'),
  ('Odom','Carlos','F','VG3874382281646622922657'),
  ('Hobbs','Wyoming','P','SM1944663192422565766167940'),
  ('Huffman','Carlos','Q','IS174708063268554081128871'),
  ('Torres','Megan','R','TN3012056776724453232075'),
  ('Delgado','Kamal','R','LI3546436906966872618'),
  ('Figueroa','Knox','U','GI85HMWK182063626144813'),
  ('Simon','Elizabeth','H','PT95198620487022054476521'),
  ('Juarez','Regina','Q','PT72178656333123556754539'),
  ('Hopkins','Alisa','I','KZ412317671615796271'),
  ('Scott','Echo','P','LB14716583843322548276125135'),
  ('Mccray','Marshall','G','TN7736385323157429713734'),
  ('Mcmahon','Quinn','L','SI10804577607681707'),
  ('Cobb','Hop','V','KZ169741366007573751'),
  ('Gill','Amy','K','AE296532839640396466858'),
  ('Rodriguez','Elton','H','ES7613735324134883200348'),
  ('Roberson','Kylee','I','TR432266431257388969182310'),
  ('Anthony','Rebecca','K','DK5604211534474843');


end
go


begin -- Colors


CREATE TABLE [dbo].[Colors]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Color] NVARCHAR(20) NOT NULL,
    CONSTRAINT [CK_Colors_Color] UNIQUE([Color])
);


INSERT INTO Colors
VALUES
  ('Red'),
  ('Magenta'),
  ('Yellow'),
  ('Aqua'),
  ('Purple'),
  ('Green'),
  ('Silver'),
  ('Black'),
  ('White'),
  ('Blue');


end
go


begin -- Brands


CREATE TABLE [dbo].[Brands]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Brand] NVARCHAR(50) NOT NULL,
    CONSTRAINT [CK_Brands_Brand] UNIQUE([Brand])
);


INSERT INTO Brands
VALUES
  ('Quam Incorporated'),
  ('Fringilla Est Incorporated'),
  ('Luctus Vulputate Industries'),
  ('Ac Metus Inc.'),
  ('Montes Nascetur Institute'),
  ('Duis At Institute'),
  ('Eget Dictum Placerat Company'),
  ('In Sodales Ltd'),
  ('Lobortis Ultrices Vivamus PC'),
  ('Lacus Aliquam Rutrum Corporation'),
  ('Praesent Interdum Ligula Inc.'),
  ('A Odio PC'),
  ('Semper Tellus Associates'),
  ('Dui Quis Accumsan Incorporated'),
  ('In At Corp.'),
  ('Et Netus Et Corp.'),
  ('Lorem Tristique Limited'),
  ('Feugiat Nec Diam Company'),
  ('Lectus Justo Eu Institute'),
  ('Eu Enim Foundation'),
  ('Fringilla Cursus PC'),
  ('Vulputate Incorporated'),
  ('Nullam Enim Corporation'),
  ('Donec Feugiat Corp.'),
  ('Pellentesque Tellus Sem Limited'),
  ('Rutrum Industries'),
  ('Ac Ltd'),
  ('Metus In Lorem Company'),
  ('Ornare Foundation'),
  ('Tincidunt Dui LLC'),
  ('Arcu Nunc LLC'),
  ('Consequat Industries'),
  ('Integer Vitae Nibh Company'),
  ('Aliquam PC'),
  ('Vitae Erat Associates'),
  ('Sed Corp.'),
  ('Malesuada Augue PC'),
  ('Consectetuer Adipiscing Elit Corporation'),
  ('Curae Phasellus Inc.'),
  ('Non Lobortis LLP'),
  ('Vitae Incorporated'),
  ('Consequat Lectus Sit Corp.'),
  ('Magnis Dis Inc.'),
  ('Integer Vitae PC'),
  ('Dolor Fusce Company'),
  ('Magna Institute'),
  ('Mauris Sapien LLC'),
  ('Donec Fringilla Donec Associates'),
  ('Suspendisse Sed Limited'),
  ('Nibh Ltd'),
  ('Et Netus Limited'),
  ('Cras Vulputate Velit PC'),
  ('Aliquam Nec LLP'),
  ('Rutrum Non Hendrerit Inc.'),
  ('Leo Vivamus Nibh PC'),
  ('Ipsum LLC'),
  ('Libero Integer In Corp.'),
  ('Leo Elementum Limited'),
  ('Convallis In Institute'),
  ('Nec Mollis Company'),
  ('Dolor Elit Limited'),
  ('Imperdiet Incorporated'),
  ('Ut Nulla PC'),
  ('In Hendrerit LLP'),
  ('Metus Aliquam Inc.'),
  ('Blandit Enim Consulting'),
  ('Libero Et PC'),
  ('Lobortis Quam A Corp.'),
  ('Sagittis Placerat LLP'),
  ('Lorem Ipsum Ltd'),
  ('Egestas Industries'),
  ('Ad Litora Torquent PC'),
  ('Quis Inc.'),
  ('Cras Eu Corp.'),
  ('Sit Amet Ultricies Inc.'),
  ('Nullam Incorporated'),
  ('Adipiscing Elit Etiam Associates'),
  ('Aliquet Ltd'),
  ('Cursus Et Magna Associates'),
  ('Arcu Aliquam Incorporated'),
  ('Tellus Corp.'),
  ('Eget Mollis Lectus PC'),
  ('Sed Neque Company'),
  ('Est Mauris Rhoncus Institute'),
  ('At Iaculis PC'),
  ('Sed Auctor Incorporated'),
  ('Duis Risus Company'),
  ('Massa Non Incorporated'),
  ('Donec LLP'),
  ('Libero Proin Mi Company'),
  ('Congue Elit Foundation'),
  ('Non Sapien Molestie Foundation'),
  ('Natoque Limited'),
  ('A Foundation'),
  ('Curabitur PC'),
  ('Malesuada Fames Limited'),
  ('Orci Ut Corp.'),
  ('Quis Accumsan Industries'),
  ('Vel Company'),
  ('Est Ac Ltd');


end
go


begin -- Cars


CREATE TABLE [dbo].[Cars]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Model] NVARCHAR(50) NOT NULL, 
    [BrandId] INT NOT NULL, 
    [ColorId] INT NOT NULL, 
    [LicenseNumber] NVARCHAR(20) NOT NULL, 
    [ProductionYear] SMALLINT NOT NULL, 
    [InsurancePayment] MONEY NOT NULL, 
    [PriceForDay] MONEY NOT NULL, 
    CONSTRAINT [CK_Cars_ProductionYear] CHECK ([ProductionYear] >= 1970), 
    CONSTRAINT [CK_Cars_InsurancePayment] CHECK ([InsurancePayment] >= 0), 
    CONSTRAINT [CK_Cars_PriceForDay] CHECK ([PriceForDay] >= 1), 
    CONSTRAINT [CK_Cars_LicenseNumber] UNIQUE([LicenseNumber]),
    CONSTRAINT [FK_Cars_Brands] FOREIGN KEY ([BrandId]) REFERENCES [Brands]([Id]), 
    CONSTRAINT [FK_Cars_Colors] FOREIGN KEY ([ColorId]) REFERENCES [Colors]([Id])
);


INSERT INTO Cars
VALUES
  ('Donec sollicitudin adipiscing',3,3,'Y604TC',2015,5427430,3599),
  ('a,',40,3,'I544GG',2008,9663835,4911),
  ('rutrum. Fusce',15,2,'V331WM',2002,8675009,4508),
  ('penatibus et',61,8,'U644AF',2013,9659594,4242),
  ('odio tristique',11,1,'K946US',2014,7180725,4964),
  ('pharetra, felis',80,9,'X442OD',2018,3571475,2922),
  ('eleifend nec,',27,3,'G615OR',2011,1021021,2503),
  ('vel,',56,3,'O723ZS',2012,6640690,3875),
  ('Cras',69,3,'N018HY',2011,3779186,3528),
  ('mollis.',96,8,'C822EC',2005,7183751,3782),
  ('non, egestas a,',70,7,'V184NX',2014,8218245,2093),
  ('leo. Vivamus nibh',83,1,'A026NG',2010,7709138,1291),
  ('malesuada vel,',59,5,'O378RA',2004,5671085,1888),
  ('molestie dapibus',42,9,'Z832HK',2014,4445509,2095),
  ('tempus, lorem fringilla',90,7,'K183KO',2009,1081124,3439),
  ('Donec',48,6,'Y215QH',2015,4439918,1929),
  ('sit amet orci.',83,6,'B074FG',2000,2890345,1423),
  ('ullamcorper magna.',66,7,'E686KD',2007,8922373,2893),
  ('Maecenas libero',17,7,'B332XN',2008,9617731,4487),
  ('Mauris',55,5,'Y421ET',2004,4794439,3204),
  ('ante lectus',65,1,'W534KD',2006,2685120,3429),
  ('nisi dictum',22,9,'X567NU',2015,2116286,2427),
  ('mollis lectus pede',42,4,'F205BL',2008,5302044,3060),
  ('in lobortis tellus',3,5,'G979DC',2013,9969471,2449),
  ('lobortis ultrices.',63,9,'Y761LV',2004,5504862,2244),
  ('Integer id magna',82,4,'C743MU',2013,8672924,1646),
  ('Aenean sed',36,2,'B448TN',2017,7794487,3102),
  ('pede et',13,8,'H171TP',2013,7577232,1353),
  ('Nunc laoreet',67,8,'Q053EO',2013,7069827,1139),
  ('et, rutrum eu,',31,8,'H894EC',2018,3792916,985),
  ('porta elit,',52,9,'B938JU',2006,9700967,2116),
  ('Nulla',42,7,'V143VC',2011,6695871,4609),
  ('felis.',95,1,'U482YR',2004,5274893,1059),
  ('ultricies ligula.',40,8,'R126WY',2006,6996248,3525),
  ('Quisque',21,9,'C335JK',2016,4218467,4752),
  ('In lorem.',24,7,'U048MY',2008,3077514,1616),
  ('metus. In',93,5,'T372GP',2005,2621627,1451),
  ('lobortis',6,7,'Y622DW',2013,5633422,1735),
  ('Curabitur massa.',98,9,'H277XW',2000,5092859,2613),
  ('non enim.',66,9,'A255VI',2006,9184651,2429),
  ('nunc id',47,6,'J488EW',2006,3347937,2435),
  ('dapibus',38,7,'W553RR',2008,5613406,4287),
  ('congue. In',97,6,'W942VW',2005,5917227,2381),
  ('nulla. In',16,6,'C763XD',2003,2184533,4663),
  ('lectus rutrum',75,2,'B431HV',2009,9347205,3229),
  ('in',98,10,'Y873GE',2004,9143648,4788),
  ('magna.',32,1,'F546VZ',2004,5644388,1152),
  ('ipsum.',59,9,'K536UZ',2005,1367906,3076),
  ('arcu. Vivamus sit',1,1,'C396DD',2009,4237033,4562),
  ('vel,',3,8,'R328FF',2016,9749801,2323),
  ('urna.',17,9,'C447UF',2004,6305991,2392),
  ('turpis. In condimentum.',60,10,'S962CT',2004,7340346,3782),
  ('suscipit, est',84,3,'K453VH',2010,7124150,995),
  ('Suspendisse eleifend.',25,7,'X137WW',2018,1758894,3610),
  ('ridiculus mus.',64,9,'W758OV',2002,7889032,1710),
  ('turpis. Aliquam',62,9,'P222AJ',2010,6347332,1638),
  ('facilisis lorem tristique',60,9,'B555TW',2015,4806669,2169),
  ('eu, euismod ac,',73,4,'W034UV',2013,2472719,3185),
  ('non, lacinia at,',58,6,'S972OX',2014,1635319,4329),
  ('commodo ipsum.',16,8,'H015RZ',2007,3202108,4427),
  ('Vestibulum ante',57,8,'B861ZC',2006,9898844,4994),
  ('purus ac tellus.',52,2,'H224BB',2011,8993100,3964),
  ('laoreet posuere,',38,5,'X657KC',2016,2909806,2090),
  ('a, facilisis non,',12,3,'X816ND',2006,8401853,2272),
  ('pretium et,',76,1,'C881CT',2005,7021528,3646),
  ('nec,',64,6,'M743QE',2008,7938623,4634),
  ('lorem',77,6,'R456CW',2004,7886854,685),
  ('Lorem ipsum',75,5,'H852JD',2012,8419851,1026),
  ('vel arcu.',45,4,'R363FU',2005,4108201,1510),
  ('cursus',60,8,'S171KR',2005,2018804,4370),
  ('Proin eget odio.',16,9,'H250JP',2018,8336077,1644),
  ('consectetuer ipsum nunc',9,5,'N838FP',2018,5546217,463),
  ('accumsan laoreet',52,9,'V743NF',2002,8723922,886),
  ('non',56,4,'P859YP',2018,8053110,2384),
  ('Curabitur egestas',24,4,'Q300WL',2012,9689761,2772),
  ('eu augue',83,10,'L757CK',2003,2839865,4117),
  ('erat. Etiam',25,4,'Y844GZ',2002,5155390,3864),
  ('Mauris quis turpis',83,4,'Q486IW',2002,1584391,3230),
  ('Donec egestas. Duis',56,1,'O625NE',2001,9020543,3194),
  ('ullamcorper. Duis cursus,',98,6,'M258EI',2011,6922046,2453),
  ('quis',81,5,'C382YW',2005,6093181,2699),
  ('lobortis',14,8,'Q587EO',2011,7647295,3016),
  ('nibh. Phasellus',13,9,'U404IX',2003,7349251,3160),
  ('odio',98,8,'S517GI',2014,8865126,1730),
  ('lacinia',4,9,'R971BX',2009,5272241,1074),
  ('Vestibulum',47,6,'S881YM',2003,9274637,1968),
  ('In condimentum. Donec',12,8,'M588UP',2011,5319251,3124),
  ('mauris. Suspendisse',61,3,'P566FN',2016,8307107,2832),
  ('auctor. Mauris vel',97,7,'D133WG',2013,6402799,1045),
  ('magna',53,2,'M721CK',2012,6888829,4897),
  ('magnis dis',67,5,'Y041DU',2008,3491676,1422),
  ('consequat purus.',63,4,'O010NC',2007,8056336,904),
  ('placerat eget,',40,3,'Q105RL',2015,2558620,3400),
  ('Aliquam',43,1,'K724BX',2018,4977607,1954),
  ('urna justo faucibus',85,3,'D475LE',2001,3001254,665),
  ('Duis sit',82,2,'J337RI',2015,4717677,2270),
  ('mauris',93,3,'Q806PC',2016,3589063,4089),
  ('Nulla eu neque',80,5,'P280PR',2006,1544756,1124),
  ('tristique',47,4,'P289KW',2001,3145009,1372),
  ('id enim. Curabitur',23,10,'W705LW',2005,8451412,3442);


end
go


begin -- Orders


CREATE TABLE [dbo].[Orders]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [CarId] INT NOT NULL, 
    [ClientId] INT NOT NULL, 
    [StartDate] DATE NOT NULL, 
    [Duration] SMALLINT NOT NULL, 
    CONSTRAINT [CK_Orders_Duration] CHECK ([Duration] >= 1), 
    CONSTRAINT [FK_Orders_Cars] FOREIGN KEY ([CarId]) REFERENCES [Cars]([Id]), 
    CONSTRAINT [FK_Orders_Clients] FOREIGN KEY ([ClientId]) REFERENCES [Clients]([Id])
);


INSERT INTO Orders
VALUES
  (3,91,'06.23.21',5),
  (7,59,'06.30.21',27),
  (35,86,'12.08.20',36),
  (8,84,'03.23.21',33),
  (33,12,'07.19.22',39),
  (99,80,'03.19.22',23),
  (57,94,'04.23.22',3),
  (2,7,'10.31.21',26),
  (64,6,'01.13.22',6),
  (71,96,'07.21.21',40),
  (73,26,'10.06.22',9),
  (91,14,'10.27.21',22),
  (57,61,'11.05.22',33),
  (6,93,'11.03.21',38),
  (77,10,'10.25.22',14),
  (28,17,'11.24.20',35),
  (59,56,'05.26.21',9),
  (59,22,'10.18.22',4),
  (88,32,'08.15.21',32),
  (90,61,'05.13.22',33),
  (47,38,'06.04.22',15),
  (87,9,'12.01.21',38),
  (62,50,'02.23.22',17),
  (66,22,'01.02.22',11),
  (15,4,'10.11.22',22),
  (69,42,'02.17.22',8),
  (34,48,'07.11.22',9),
  (33,86,'06.03.22',20),
  (34,63,'12.12.21',19),
  (83,10,'07.25.21',31),
  (18,70,'10.01.21',22),
  (96,59,'09.01.22',9),
  (32,58,'11.29.21',36),
  (89,95,'02.03.21',25),
  (14,80,'04.30.21',25),
  (50,84,'08.09.21',16),
  (99,63,'07.30.22',10),
  (20,46,'07.23.22',29),
  (54,55,'09.22.22',11),
  (13,62,'06.19.21',39),
  (63,67,'06.19.22',26),
  (73,6,'11.04.21',33),
  (12,59,'02.05.22',40),
  (61,48,'01.26.21',28),
  (27,32,'01.30.22',26),
  (41,41,'06.28.21',15),
  (60,65,'03.18.21',37),
  (78,37,'11.02.22',22),
  (43,86,'09.28.21',9),
  (57,4,'08.07.21',2),
  (31,74,'12.07.21',27),
  (83,89,'01.28.22',33),
  (66,4,'09.22.21',13),
  (46,65,'03.11.21',22),
  (10,59,'12.07.20',29),
  (98,6,'02.04.21',10),
  (45,43,'10.26.21',15),
  (68,9,'04.04.21',23),
  (33,50,'10.10.22',14),
  (38,50,'09.06.21',18),
  (99,11,'09.06.21',31),
  (76,71,'12.24.21',38),
  (49,13,'11.07.21',29),
  (19,7,'08.01.22',28),
  (35,74,'11.14.22',31),
  (40,79,'02.13.21',20),
  (56,84,'01.06.21',21),
  (47,96,'09.18.22',28),
  (53,49,'12.13.20',5),
  (38,94,'08.11.21',38),
  (83,32,'10.01.21',10),
  (30,67,'12.17.20',18),
  (80,23,'02.26.22',24),
  (6,18,'10.11.21',17),
  (24,86,'01.03.22',32),
  (86,5,'04.04.21',19),
  (40,8,'07.09.22',21),
  (27,86,'04.20.21',14),
  (58,65,'09.13.22',35),
  (71,71,'02.26.22',17),
  (14,96,'07.30.21',25),
  (92,6,'12.29.20',9),
  (64,58,'02.19.22',31),
  (78,74,'05.15.21',22),
  (47,71,'11.05.22',25),
  (17,27,'06.28.22',15),
  (22,96,'12.28.21',6),
  (10,12,'09.16.21',37),
  (89,83,'06.15.22',30),
  (85,79,'10.24.21',20),
  (68,97,'10.05.22',8),
  (92,87,'03.02.21',34),
  (90,49,'07.18.21',25),
  (29,67,'12.18.21',37),
  (12,95,'09.30.22',9),
  (79,43,'07.13.21',19),
  (98,38,'06.29.22',16),
  (64,34,'09.09.22',5),
  (44,97,'01.01.21',35),
  (55,19,'04.21.22',14);


end
go


CREATE VIEW CarsWithKeys AS
    select 
        Cars.Id,
        Cars.BrandId,
        Cars.ColorId,
        Cars.InsurancePayment,
        Cars.LicenseNumber,
        Cars.Model,
        Cars.PriceForDay,
        Cars.ProductionYear,
        Brands.Brand,
        Colors.Color
    from Cars
    join Brands on Cars.BrandId = Brands.Id
    join Colors on Cars.ColorId = Colors.Id;
go


CREATE VIEW OrdersWithKeys AS
    select 
        Orders.CarId,
        Orders.ClientId,
        Orders.Duration,
        Orders.Id,
        Orders.StartDate,
        Clients.Firstname,
        Clients.Surname,
        Clients.Patronymic,
        Clients.Passport,
        Cars.BrandId,
        Cars.ColorId,
        Cars.InsurancePayment,
        Cars.LicenseNumber,
        Cars.Model,
        Cars.PriceForDay,
        Cars.ProductionYear
    from Orders
    join Clients on Orders.ClientId = Clients.Id
    join Cars on Orders.CarId = Cars.Id;
go