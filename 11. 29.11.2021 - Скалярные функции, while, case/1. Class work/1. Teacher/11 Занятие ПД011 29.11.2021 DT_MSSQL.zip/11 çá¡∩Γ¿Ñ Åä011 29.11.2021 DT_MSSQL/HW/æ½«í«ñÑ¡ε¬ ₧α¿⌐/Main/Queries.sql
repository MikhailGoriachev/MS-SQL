﻿-- 1
-- Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
declare @licenseNumber nvarchar(max) = 'Y421ET'

select * from OrdersWithKeys
where OrdersWithKeys.LicenseNumber = @licenseNumber
go


-- 2
-- Выбирает информацию обо всех фактах проката автомобиля с заданной моделью/брендом
declare @brand int = 3;

select * from OrdersWithKeys
where OrdersWithKeys.BrandId = @brand
go


-- 3
-- Выбирает информацию об автомобиле с заданным госномером
declare @licenseNumber nvarchar(max) = 'Y421ET'

select * from CarsWithKeys
where CarsWithKeys.LicenseNumber = @licenseNumber
go


-- 4
-- Выбирает информацию о клиентах по серии и номеру паспорта
declare @passport nvarchar(max) = 'BH25736525766254352348'

select * from Clients
where Clients.Passport = @passport
go


-- 5
-- Выбирает информацию обо всех зафиксированных фактах проката 
-- автомобилей в некоторый заданный интервал времени.
declare @from date = '10.31.21',
        @to date = '10.31.22'

select * from OrdersWithKeys
where OrdersWithKeys.StartDate between @from and @to
go


-- 6
-- Вычисляет для каждого факта проката стоимость проката. Включает поля Дата проката, 
-- Госномер автомобиля, Модель автомобиля, Стоимость проката. Сортировка по полю Дата проката
select
	OrdersWithKeys.StartDate,
	OrdersWithKeys.LicenseNumber,
	OrdersWithKeys.Model,
	dbo.CalculateRentTotal(PriceForDay, Duration) as Total
from OrdersWithKeys
order by OrdersWithKeys.StartDate asc
go


-- 7
-- Для всех клиентов прокатной фирмы вычисляет количество фактов проката, суммарное 
-- количество дней проката, упорядочивание по убыванию суммарного количества дней проката
select 
	Clients.Surname,
	Clients.Firstname,
	Clients.Patronymic,
	Clients.Passport,
	Count(Orders.ClientId) as Count,
	Sum(Orders.Duration) as Days
from Clients
left join Orders on Orders.ClientId = Clients.Id
group by Clients.Surname, Clients.Firstname, Clients.Patronymic, Clients.Passport
order by Days desc
go


-- 8
-- Выполняет группировку по полю Модель автомобиля. Для каждой модели 
-- вычисляет количество фактов проката, сумму за прокат
select 
	OrdersWithKeys.Model,
	Count(OrdersWithKeys.Model) as Count,
	Sum(OrdersWithKeys.PriceForDay) as Sum
from OrdersWithKeys
group by OrdersWithKeys.Model
go


-- 9
-- Добавляет данные о новом клиенте. Данные передавайте параметрами
declare @surname nvarchar(max) = 'Lowe',
		@firstname nvarchar(max) = 'Xyla',
		@patronymic nvarchar(max) = 'F',
		@passport nvarchar(max) = 'LT724404174538385623'

insert into Clients
values
	(@surname, @firstname, @patronymic, @passport)
go


-- 10
-- Изменяет данные клиента (все поля, кроме идентификатора). Данные передавайте параметрами
declare @surname nvarchar(max) = 'Lowe',
		@firstname nvarchar(max) = 'Xyla',
		@patronymic nvarchar(max) = 'F',
		@passport nvarchar(max) = 'LT724404174538385623',
		@id int = 7

update Clients
set 
	Surname = @surname,
	Firstname = @firstname,
	Patronymic = @patronymic,
	Passport = @passport
where Clients.Id = @id
go


-- 11
-- Изменяет данные автомобиля (все поля, кроме идентификатора). Данные передавайте параметрами
declare @model nvarchar(max) = 'm',
		@brandId int = 40,
		@colorId int = 3,
		@LicenseNumber nvarchar(max) = 'I534GG',
		@ProductionYear int = 2008,
		@InsurancePayment money = 9663835,
		@PriceForDay money = 4911,
		@id int = 7

update Cars
set 
	Model = @model,
	BrandId = @brandId,
	ColorId = @colorId,
	LicenseNumber = @LicenseNumber,
	ProductionYear = @ProductionYear,
	InsurancePayment = @InsurancePayment,
	PriceForDay = @PriceForDay
where Cars.Id = @id
go