﻿-- Выборка всех авто 
Select
	Brands.Brand as Brand
   ,Colors.Color
   ,Cars.Plate as License_plate
   ,Cars.Prod_year as Produced
   ,Cars.Insurance_pay
   ,Cars.Daily_price
from 
	Cars join Brands on Cars.IdBrand = Brands.Id
		 join Colors on Cars.IdColor = Colors.Id
order by 
	Cars.Daily_price desc

-- Выборка всех клиентов 
Select 
	Persons.Surname + N'.' + SUBSTRING(Persons.Person_name,1,1) + N'.' + SUBSTRING(Persons.Patronymic,1,1) as Client 
	,Persons.Passport 
From 
	Clients join Persons on Clients.IdPerson = Persons.Id

-- Выборка фактов проката 

Select 
	Persons.Surname + N'.' + SUBSTRING(Persons.Person_name,1,1) + N'.' + SUBSTRING(Persons.Patronymic,1,1) as Client 
   ,Persons.Passport 
   ,Brands.Brand as Brand
   ,Colors.Color
   ,Cars.Plate as License_plate
   ,Cars.Daily_price
   ,Rentals.DateStart 
   ,Rentals.Duration 
   ,Rentals.Duration*Cars.Daily_price as GeneralSumm
from 
	Rentals join (Clients join Persons on Clients.IdPerson = Persons.Id) on Rentals.IdClient = Clients.Id
			join (Cars join Brands on Cars.IdBrand = Brands.Id
					   join Colors on Cars.IdColor = Colors.Id) on Rentals.IdCar = Cars.Id
order by 
	GeneralSumm Desc
go

-- Представление для фактов проката 
create /*create alter*/ view ViewRentals as 
	select 
	Rentals.Id
   ,Rentals.IdCar
   ,Rentals.IdClient
   ,Persons.Surname + N'.' + SUBSTRING(Persons.Person_name,1,1) + N'.' + SUBSTRING(Persons.Patronymic,1,1) as Client 
   ,Persons.Passport 
   ,Persons.Surname
   ,Persons.Person_name
   ,Persons.Patronymic
   ,Brands.Brand
   ,Colors.Color
   ,Cars.Plate
   ,Cars.Daily_price
   ,Cars.Insurance_pay 
   ,Cars.Prod_year as Produced
   ,Rentals.DateStart 
   ,Rentals.Duration 
   ,Rentals.Duration*Cars.Daily_price as GeneralSumm
	from 
	Rentals join (Clients join Persons on Clients.IdPerson = Persons.Id) on Rentals.IdClient = Clients.Id
			join (Cars join Brands on Cars.IdBrand = Brands.Id
					   join Colors on Cars.IdColor = Colors.Id) on Rentals.IdCar = Cars.Id

go

--Проверка представления 
Select 
	Client 
   ,Passport 
   ,Brand
   ,Color
   ,Plate
   ,Daily_price
   ,DateStart 
   ,Duration 
   ,GeneralSumm
from 
	ViewRentals
go
-- Представление для таблицы автомобилей 
create /*create alter*/ view ViewCars as
select
	Cars.Id
   ,Brands.Brand
   ,Colors.Color
   ,Cars.Plate
   ,Cars.Prod_year as Produced
   ,Cars.Insurance_pay
   ,Cars.Daily_price
from 
	Cars join Brands on Cars.IdBrand = Brands.Id
		 join Colors on Cars.IdColor = Colors.Id

go

--Проверка представления 
Select
	*
from 
	ViewCars
order by 
	Insurance_pay
go 

Select
   Brand
  ,Plate
  ,Produced
  ,Color
  ,Insurance_pay
  ,Daily_price
from 
	ViewCars
order by 
	Insurance_pay Desc
go


-- Представелние для таблицы клиентов
create /*create alter*/ view ViewClients as
Select 
	 Clients.Id
	,Persons.Surname + N'.' + SUBSTRING(Persons.Person_name,1,1) + N'.' + SUBSTRING(Persons.Patronymic,1,1) as Client
	,Persons.Passport 
	,Persons.Surname
	,Persons.Person_name
	,Persons.Patronymic
From 
	Clients join Persons on Clients.IdPerson = Persons.Id

go


-- 001 Выбирает информацию обо всех фактах проката 
--     автомобиля с заданным госномером
declare @plate nvarchar(12) = N'AH3983НВ'
Select
	Client 
   ,Passport 
   ,Brand
   ,Plate
   ,Daily_price
   ,DateStart 
   ,Duration 
   ,GeneralSumm
from 
	ViewRentals
where 
	Plate = @plate
go

-- 002 Выбирает информацию обо всех фактах проката
--     автомобиля с заданной моделью/брендом
declare @brand nvarchar(40) = N'Audi%'
Select
	Client 
   ,Passport 
   ,Brand
   ,Plate
   ,Daily_price
   ,DateStart 
   ,Duration 
   ,GeneralSumm
from 
	ViewRentals
where 
	Brand like @brand
go

-- 003 Выбирает информацию об автомобиле с заданным госномером
declare @plate nvarchar(12) = N'AH3353НВ'
Select
   Brand
  ,Plate
  ,Produced
  ,Color
  ,Insurance_pay
  ,Daily_price
from 
	ViewCars
where 
	Plate = @plate

-- 004 Выбирает информацию о клиентах по серии и номеру паспорта
declare @passport nvarchar(50) = N'ВС89532'
Select
	Client
	,Passport
from 
	ViewClients
where 
	Passport = @passport

-- 005 Выбирает информацию обо всех зафиксированных фактах проката автомобилей
--     в некоторый заданный интервал времени.
declare @StartDate Date = '2021/02/21', @EndtDate Date = '2021/09/02'
Select
	Client 
   ,Passport 
   ,Brand
   ,Plate
   ,Daily_price
   ,DateStart 
   ,Duration 
   ,GeneralSumm
from 
	ViewRentals
where 
	DateStart between @StartDate and @EndtDate
go

-- 006 Вычисляет для каждого факта проката стоимость проката. 
--     Включает поля Дата проката, Госномер автомобиля, 
--     Модель автомобиля, Стоимость проката. 
--     Сортировка по полю Дата проката

Select
	Client 
   ,Passport 
   ,Brand
   ,Plate
   ,Daily_price
   ,DateStart 
   ,Duration 
   ,GeneralSumm as RentalPrice
from 
	ViewRentals
order by 
	RentalPrice desc
go

-- 007 Запрос с левым соединением	
--     Для всех клиентов прокатной фирмы вычисляет количество фактов проката, 
--     суммарное количество дней проката, 
--     упорядочивание по убыванию суммарного количества дней проката
Select 
	ViewClients.Client
	,COUNT(ViewRentals.IdClient) as Rents
	,ISNULL(SUM(ViewRentals.Duration),0) as GeneralDuration
from 
	ViewClients left join ViewRentals on ViewRentals.IdClient = ViewClients.Id
group by 
	ViewClients.Client
order by 
	GeneralDuration  desc

-- 008 Выполняет группировку по полю Модель автомобиля. 
--     Для каждой модели вычисляет количество фактов проката, сумму за прокат
Select 
	Brand
   ,COUNT(ViewRentals.IdCar) as Rented
   ,SUM(ViewRentals.GeneralSumm) as GenSum
   ,AVG(ViewRentals.GeneralSumm) as AverageRentPrice
from 
	ViewRentals
group by 
	Brand --Группирову по полю рег.номера не делал, поскольку в парке может быть несколько одинаковых моделей авто с разными рег.номерами
order by 
	GenSum desc

-- 009 Добавляет данные о новом клиенте. 
--     Данные передавайте параметрами

-- Сначала удаляем уже добавленных персон с задаваемыми в следующем запросе денными
declare @Passport_1 nvarchar(30) = N'АK74423', @Passport_2 nvarchar(30) = N'ВО72512'
delete from 
 Persons
where 
	 Persons.Passport = @Passport_1 or Persons.Passport = @Passport_2;

-- Добавляем в персон новые данные
Insert Persons
	(Surname,Person_name,Patronymic,Passport )
values
	(N'Потемкинн',   N'Павел',   N'Юрьевич',  @Passport_1),
	(N'Матвеев',   N'Степан',    N'Романович',  @Passport_2);
go

-- Добавляем Persons в таблицу клиентов 
declare @Passport_1 nvarchar(30) = N'АK74423', @Passport_2 nvarchar(30) = N'ВО72512'

Insert Clients 
	(IdPerson)
values
	((Select Id from Persons where Persons.Passport = @Passport_1)),
	((Select Id from Persons where Persons.Passport = @Passport_2));
go

--2-й способ добавления. Когда при помощи 2-х подзапросов мы получаем порядковый номер Person, который на 1 > найбольшего idPeson записанного в FK_Clients
-- В случае, если выйдем за пределы таблицы Person - добавим 1-ю запись из Person
Insert Clients 
	(IdPerson)
values
	((Select Id from Persons where Id = (Select ISNULL(MAX(Clients.IdPerson)+1,1) from Clients)));
go

-- Демонстрация результата 
Select 
	Client
	,Passport
from 
	ViewClients
go

--Удаляем данные клиентов для последующей демонстрации
declare @Passport_1 nvarchar(30) = N'АK74423', @Passport_2 nvarchar(30) = N'ВО72512'
delete from 
 Clients
where 
	Clients.IdPerson = (Select distinct Id from Persons where Persons.Passport = @Passport_1) or
	Clients.IdPerson = (Select distinct Id from Persons where Persons.Passport = @Passport_2);
go

-- Удаляем клиента добавленного 2-м способом
delete from 
 Clients
where 
	Clients.IdPerson = (Select ISNULL(MAX(Clients.IdPerson),1) from Clients);
go



-- 010 Изменяет данные клиента (все поля, кроме идентификатора). 
--     Данные передавайте параметрами

--Выводим клиентов до изменения 
Select 
	Client
	,Passport
from 
	ViewClients
go

declare @ChosenId int = (Select distinct AVG(Clients.IdPerson) from Clients); --Редактируем персону, которая есть в таблице клиентов

update 
	Persons
set
    Person_name = N'Данила',
    Surname = N'Александров',
    Patronymic = N'Миронович',
    Passport = N'AC90467'
where
	Persons.Id = @ChosenId 

-- Выводим инфомрацию о том какой клиент был изменен
Select 
(Select distinct Id from Clients where Clients.IdPerson = @ChosenId) as ChangedClientId

--Выводим клиентов до изменения 
Select 
	Client
	,Passport
	,Surname
	,Person_name
	,Patronymic
from 
	ViewClients
go


-- 011 Изменяет данные автомобиля (все поля, кроме идентификатора). 
--     Данные передавайте параметрами
Select
   Brand
  ,Plate
  ,Produced
  ,Color
  ,Insurance_pay
  ,Daily_price
from 
	ViewCars

--Изменяем цвет записи, которая содержится в таблице автомобилей
declare @ChosenIdBrand int = (Select AVG(IdBrand) from Cars)
declare @ChosenIdColor int = (Select Cars.IdColor from Cars where Cars.IdBrand = @ChosenIdBrand)
update 
	Colors
set
    Colors.Color = N'Liquid Yellow'
where
	Colors.Id = @ChosenIdColor -- Изменяем тот цвет, который используется в выбранном автомобиле


--Изменяем бренд записи, которая содержится в таблице автомобилей
update 
	Brands
set
    Brands.Brand = N'BMW M3'
where
	Brands.Id = @ChosenIdBrand


-- Изменяем итоговую таблицу
--declare @ChosenIdBrand int = (Select AVG(IdBrand) from Cars)

update 
	ViewCars
set
    Insurance_pay = 55000
	,Daily_price = 200
	,Plate = N'AH2715НВ'
	,Produced = 2019
where	
	Brand = (Select Brands.Brand from Brands where Brands.Id = @ChosenIdBrand)

-- Вывод после изменения 
Select
   Brand
  ,Plate
  ,Produced
  ,Color
  ,Insurance_pay
  ,Daily_price
from 
	ViewCars


-- If конструкции

-- 0012 If13. Даны три числа. 
--      Найти среднее из них. Числа формируйте генератором случайных чисел

-- Числа от 2 до 100
declare @Num1 int = rand()*(100-2)+2,@Num2 int = rand()*(100-2)+2,@Num3 int = rand()*(100-2)+2, @Average int

--Вычисление 
if (@Num1 > @Num2 and @Num1 < @Num3) or (@Num1 < @Num2 and @Num1 > @Num3)
    set @Average = @Num1
else if (@Num2 > @Num1 and @Num2 < @Num3) or (@Num2 < @Num1 and @Num2 > @Num3)
    set @Average = @Num2
else if (@Num3 > @Num1 and @Num3 < @Num2) or (@Num3 < @Num1 and @Num3 > @Num2)
    set @Average = @Num3

-- Вывод 
--Select 
-- N'Число 1: ' + str(@Num1) as Number_1
--,N'Число 2: ' + str(@Num2) as Number_2
--,N'Число 3: ' + str(@Num3) as Number_3
--,N'Среднее: ' + str(@Average) as [AVG]  

 PRINT 
 N'Число 1: ' +		  ltrim(str(@Num1))        + char(10) +
 N'Число 2: ' +       ltrim(str(@Num2))        + char(10) +
 N'Число 3: ' +       ltrim(str(@Num3))        + char(10) +
 N'Среднее: ' +   ltrim(str(@Average))	   + char(10);

go



-- 0013 If14. Даны три числа. 
--      Вывести вначале наименьшее, а затем наибольшее их данных чисел. 
--      Числа формируйте генератором случайных чисел
declare @A int = rand()*(100-2)+2,@B int = rand()*(100-2)+2,@C int = rand()*(100-2)+2,@Min int,@Max int

-- Поиск Min/Max

if @A > @B and @A>@C
set @Max = @A
else if @B > @A and @B > @C
set @Max = @B
else if @C > @A and @C > @B
set @Max = @C

-- Определяем найменьшее 

if @A < @B and @A < @C
set @Min = @A
else if @B < @A and @B <@C
set @Min = @B
else if @C < @A and @C < @B
set @Min = @C

-- Вывод 1
--Select 
-- N'Число 1: ' + str(@A) as Number_A
--,N'Число 2: ' + str(@B) as Number_B
--,N'Число 3: ' + str(@C) as Number_C
--,N'Максимальное: ' + str(@Max) as [Max]
--,N'Минимальное: ' + str(@Min) as [Min]


-- Вывод 2

 PRINT N'Число 1: ' + ltrim(str(@A))        + char(10) +
 N'Число 2: ' +       ltrim(str(@B))        + char(10) +
 N'Число 3: ' +       ltrim(str(@C))        + char(10) +
 N'Максимальное: ' +  ltrim(str(@Max)) + char(10) +
 N'Минимальное: ' +   ltrim(str(@Min))  + char(10);
go

-- 014 If15. Даны три числа. 
--     Найти сумму двух наибольших из них. 
--     Числа формируйте генератором случайных чисел
declare @A int = rand()*(100-2)+2,@B int = rand()*(100-2)+2,@C int = rand()*(100-2)+2,@Max1 int,@Max2 int

-- Поиск Max_1

if @A > @B and @A>@C
set @Max1 = @A
else if @B > @A and @B > @C
set @Max1 = @B
else if @C > @A and @C > @B
set @Max1 = @C

-- Поиск Max_2

-- Если число меньше максимального, то больше остальных чисел, тогда оно 2-е максимальное
if @A < @Max1 and @A>@B
set @Max2 = @A
else if  @A < @Max1 and @A>@C
set @Max2 = @A
else if @B < @Max1 and @B > @A
set @Max2 = @B
else if  @A < @Max1 and @B > @C
set @Max2 = @B
else if @C < @Max1 and @C > @A
set @Max2 = @C
else if  @C < @Max1 and @C > @B
set @Max2 = @C

-- Вывод 2

 PRINT 
 N'Число 1: ' + ltrim(str(@A))        + char(10) +
 N'Число 2: ' +       ltrim(str(@B))        + char(10) +
 N'Число 3: ' +       ltrim(str(@C))        + char(10) +
 N'1-е максимальное: ' +       ltrim(str(@Max1))        + char(10) +
 N'2-е максимальное: ' +       ltrim(str(@Max2))        + char(10) +
 N'Сумма 2-х максимальных: ' +  ltrim(str(@Max1 + @Max2)) + char(10);
go

-- 015 if17 
--     Даны три числа. 
--     Если их значения упорядочены по возрастанию или убыванию, то удвоить их; 
--     в противном случае заменить значение каждой переменной на противоположное. 
--     Числа формируются генератором или присваиванием
declare @A int = rand()*(100-2)+2,@B int = rand()*(100-2)+2,@C int = rand()*(100-2)+2, @Desc int

PRINT 
 N'Числа до ветвления. '       + char(10) +
 N'Число 1: ' + ltrim(str(@A)) + char(10) +
 N'Число 2: ' + ltrim(str(@B)) + char(10) +
 N'Число 3: ' + ltrim(str(@C)) + char(10)

 -- 1 и 2-е число меньше 3-го и 1-е меньше второго
if @A < @B and @B < @C  begin 
    set @A *= 2;
    set @B *= 2;
    set @C *= 2;
    set @Desc = 0;
end  else  begin 
    set @A = -@A; 
    set @B = -@B; 
    set @C = -@C; 
    set @Desc = 1;
end -- if

-- Вывод после
if @Desc = 1
Begin
PRINT 
 N'Числа после ветвления. '       + char(10) +
 N'Число 1: ' + ltrim(str(@A)) + char(10) +
 N'Число 2: ' + ltrim(str(@B)) + char(10) +
 N'Число 3: ' + ltrim(str(@C)) + char(10)
end
else
begin 
PRINT 
 N'Числа после ветвления. '       + char(10) +
 N'Число 3: ' + ltrim(str(@C)) + char(10) +
 N'Число 2: ' + ltrim(str(@B)) + char(10) +
 N'Число 1: ' + ltrim(str(@A)) + char(10) 

end