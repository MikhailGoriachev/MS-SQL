﻿

-- Отображение всех данных таблциы-представления фактов аренды
select
	*
from 
	RentalFactsView;
go

-- Запросы по заданию

--1	Запрос к представлению
--	Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
declare @number nvarchar(6) = N'В467АР';

select
	RegNumber
	, BrandModel
	, Client
	, Passport
	, BeginDate
	, RentDays
from 
	RentalFactsView
where
	RegNumber = @number;
go


--2	Запрос к представлению
--	Выбирает информацию обо всех фактах проката автомобиля с заданной моделью/брендом
declare @model nvarchar(30) = N'Mercedes Vito';

select
	RegNumber
	, BrandModel
	, Client
	, Passport
	, BeginDate
	, RentDays
from 
	RentalFactsView
where
	BrandModel = @model;
go


--3	Запрос к представлению
--	Выбирает информацию об автомобиле с заданным госномером
declare @number nvarchar(6) = N'В467АР';

select
	Id
	, RegNumber
	, BrandModel
	, Color
	, YearMade
	, InsuranceCost
	, DayCost
from 
	CarsView
where
	RegNumber = @number;
go

--4	Запрос с параметром
--	Выбирает информацию о клиентах по серии и номеру паспорта
declare @passport nvarchar(15) = N'9317024758';

select
	Id
	, Surname
	, Name
	, Patronymic
	, Passport
from	
	Clients
where Passport = @passport;
go

--5	Запрос к представлению	
--	Выбирает информацию обо всех зафиксированных фактах проката автомобилей
--	в некоторый заданный интервал времени.
declare @from date = '2021-05-01', @to date = '2021-08-01'

select
	RegNumber
	, BrandModel
	, Client
	, Passport
	, BeginDate
	, RentDays
from 
	RentalFactsView
where 
	BeginDate between @from and @to;
go


--6	Запрос к представлению	
--	Вычисляет для каждого факта проката стоимость проката. Включает поля Дата проката,
--	Госномер автомобиля, Модель автомобиля, Стоимость проката. Сортировка по полю Дата проката

select
	BeginDate
	, RegNumber
	, BrandModel
	, RentPrice
from 
	RentalFactsView
order by
	BeginDate;
go


--7	Запрос с левым соединением	
--	Для всех клиентов прокатной фирмы вычисляет количество фактов проката,
--	суммарное количество дней проката, упорядочивание по убыванию суммарного
--	количества дней проката
select
	Clients.Surname
	, Clients.Name
	, Clients.Patronymic
	, Clients.Passport
	, Sum(RentDays) as TotalRentDays
	, Count(RentDays) as RentsCount
from  Clients left join RentalFactsView on Clients.Passport = RentalFactsView.Passport
group by
	Clients.Name
	, Clients.Surname
	, Clients.Patronymic
	, Clients.Passport
order by
	TotalRentDays;
go


--8	Итоговый запрос	
--	Выполняет группировку по полю Модель автомобиля.
--	Для каждой модели вычисляет количество фактов проката, сумму за прокат	
select
	BrandModel
	, Count(RentDays) as RentsCount
	, Sum(RentDays)	  as TotalRentDays
from	
	RentalFactsView
group by
	BrandModel;
go



--9	Запрос на добавление	
--	Добавляет данные о новом клиенте. Данные передавайте параметрами
declare @surname nvarchar(60) = N'Иванов', @name nvarchar(50) = N'Пётр', 
		@patronymic nvarchar(60) = N'Сергеевич', @passport nvarchar(15) = N'9321123456';

select * from Clients;

insert into RentalFactsView
	(Surname, Name, Patronymic, Passport)
values
	(@surname, @name, @patronymic, @passport);

select * from Clients;
go


--10	Запрос на обновление	
--	Изменяет данные клиента (все поля, кроме идентификатора). Данные передавайте параметрами
declare @passport nvarchar(15) = N'9320063452', @newPassport nvarchar(15) = N'9320999999',
		 @surname nvarchar(60) = N'Ливингстон', @name nvarchar(50) = N'Джонатан', 
		@patronymic nvarchar(60) = N'Чайкович';

select * from Clients;

update RentalFactsView
set
	Surname = @surname
	, Name = @name
	, Patronymic = @patronymic
	, Passport = @newPassport
where
	Passport = @passport;

select * from Clients;

go

--11	Запрос на обновление	
--	Изменяет данные автомобиля (все поля, кроме идентификатора). Данные передавайте параметрами
declare
@curRegNum nvarchar(6) = N'А550ЕР'

,@brandModel	nvarchar(30) = N'Toyota Corolla'
,@color		nvarchar(20) = N'Gray'	
,@yearMade	int			 = 2021	
,@regNumber	nvarchar(6)  = N'A123PO'	
,@insuranceCost	int		 = 100000
,@dayCost		int	     = 500;

select * from CarsView;

go

update Cars
set
	IdBrandModel = (select Id from BrandModels where BrandModel = @brandModel)
	, IdColor = (select Id from Colors where Color = @color)
	, YearMade = @yearMade
	, RegNumber = @regNumber
	, InsuranceCost = @insuranceCost
	, DayCost = @dayCost
where
	RegNumber = @curRegNum;

select * from CarsView;

----------------------------------------------------------------------------------------------

--12	Изучение T-SQL
--		Задача If13.
--	Даны три числа. Найти среднее из них (то есть число, расположенное между наименьшими наибольшим).
--	Числа формируйте генератором случайных чисел
declare @a int = -100 + 200*rand(),
		@b int = -100 + 200*rand(),
		@c int = -100 + 200*rand(),	
		@mid int;

declare @i int = 0; -- счетчик цикла

--  цикл для множественности результатов
while @i < 10
begin
	set @a = -100 + 200*rand()
	set @b = -100 + 200*rand()
	set @c = -100 + 200*rand()
	
	-- нахождение среднего числа
	if (@a >= @b and @a <= @c) or (@a < @b and @a >= @c)
		set @mid = @a
	else if (@b >= @a and @b <= @c) or (@b <= @a and @b >= @c)
		set @mid = @b
	else set @mid = @c

	-- вывод
	select @a as a, @b as b, @c as c, @mid as middle
	
	-- тестирование отображения сообщений в output
	print N'┌─────┬─────┬─────┬─────┐' + char(10) +
		  N'│  A  │  B  │  C  │ Mid │' + char(10) +
		  N'├─────┼─────┼─────┼─────┤' + char(10) +
		  N'│ ' + right(str(@a),3) + N' │ ' + right(str(@b),3) + N' │ ' + right(str(@c),3) + N' │ ' + right(str(@mid),3) + N' │' + char(10) +
		  N'└─────┴─────┴─────┴─────┘' + char(10) 

	set @i = @i + 1
end;

--						 Пробовал вариант с использованием временнной таблицы 
--declare @numbers table (number int)
--insert into @numbers values (@a), (@b), (@c)
--
--select
--	@a as a,
--	@b as b,
--	@c as c,
--	number as middle
--from @numbers
--where
--	number > (select min(number) from @numbers) and number < (select max(number) from @numbers);

go


--13	Изучение T-SQL
--		Задача If14.
--	Даны три числа. Вывести вначале наименьшее, а затем наибольшее их данных чисел.
--	Числа формируйте генератором случайных чисел
declare @a int= -100 + 200*rand(),
		@b int= -100 + 200*rand(),
		@c int= -100 + 200*rand(),	
		@min int, @max int;

-- нахождение наименьшего числа
if @a >= @b and @a >= @c
	set @max = @a
else if @b >= @c
	set @max = @b
else set @max = @c

-- нахождение наибольшего числа
if @a <= @b and @a <= @c
	set @min = @a
else if @b <= @c
	set @min = @b
else set @min = @c

-- вывод
select @a as a, @b as b, @c as c, @min as [min], @max as [max];

--declare @numbers table (number int)
--insert into @numbers values (@a), (@b), (@c)
--
--select
--	@a as a,
--	@b as b,
--	@c as c,
--	min(number) as [min],
--	max(number) as [max]
--from @numbers

go

--14	Изучение T-SQL
--		Задача If15.
--	Даны три числа. Найти сумму двух наибольших из них. Числа формируйте генератором случайных чисел
declare @a int= -100 + 200*rand(),
		@b int= -100 + 200*rand(),
		@c int= -100 + 200*rand(),	
		@max int, @mid int;

	
-- нахождение наибольшего числа
if @a >= @b and @a >= @c
	set @max = @a
else if @b >= @c
	set @max = @b
else set @max = @c

-- нахождение второго наибольшего числа
if (@a >= @b and @a <= @c) or (@a <= @b and @a >= @c)
	set @mid = @a
else if (@b >= @a and @b <= @c) or (@b < @a and @b >= @c)
	set @mid = @b
else set @mid = @c

----- Способ с использованием временной таблицы в качестве массива в цикле

--declare @numbers table (id int, number int)
--insert into @numbers values (1, @a), (2, @b), (3, @c)
--
--select @max = (select number from @numbers where id = 1)
--set @mid = (select number from @numbers where id = 2);
--
--declare @i int = 2;
--
--while @i <= 3
--begin
--	declare @tmp int = (select number from @numbers where id = @i)
--
--	if @tmp >= @max begin
--		set @mid = @max
--		select @max = @tmp
--	end
--	else if (@tmp > @mid)
--		set @mid = @tmp
--
--	set @i = @i + 1
--end

-- вывод
select @a as a, @b as b, @c as c, @max as [max], @mid as mid, @max + @mid as SumOfTwoHighest
go


--15	Изучение T-SQL
--		Задача If17.
--	Даны три числа. Если их значения упорядочены по возрастанию или убыванию, то удвоить их;
--	в противном случае заменить значение каждой переменной на противоположное.
--	Числа формируйте генератором случайных чисел или присваиванием

declare @a int= -100 + 200*rand(),
		@b int= -100 + 200*rand(),
		@c int= -100 + 200*rand(),	
		@max int, @mid int;


select @a as a, @b as b, @c as c

if @a <= @b and @b <= @c or @a >= @b and @b >= @c
begin
	set @a = 2 * @a
	set @b = 2 * @b
	set @c = 2 * @c
end else 
begin
	set @a = -@a
	set @b = -@b
	set @c = -@c
end

select @a as a, @b as b, @c as c;

go