﻿-- База данных «Прокат автомобилей»

-- вывод всех таблиц с рашифровкой полей связанных таблиц
select
    *
from
    Clients;
go


select
   *
from
   Colors;
go


select
    *
from
    Brands;
go

-- автомобили с расшифровкой
select
    Cars.Id
    , Brands.Brand
    , Colors.Color
    , Cars.Plate
    , Cars.YearManuf
    , Cars.InsurancePay
    , Cars.Rental
from
    Cars join Colors on Cars.IdColor = Colors.Id
         join Brands on Cars.IdBrand = Brands.Id;
go


-- прокаты с расшифровкой
select
    Rentals.Id
    , Clients.Surname  + ' ' + SUBSTRING(Clients.Name, 1, 1) + '. ' + SUBSTRING(Clients.Patronymic, 1, 1) + '. ' as Client
    , Brands.Brand
    , Colors.Color
    , Cars.Plate
    , Cars.YearManuf
    , Cars.InsurancePay
    , Cars.Rental
from 
    Rentals join (Cars join Colors on Cars.IdColor = Colors.Id join Brands on Cars.IdBrand = Brands.Id) on Rentals.IdCar = Cars.Id
            join Clients on Rentals.IdClient = Clients.Id
go

-----------------------------------------------------------------------------------------------------
--                               Запросы к таблицам базы данных

-- 1. Запрос к представлению	
--    Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
declare @plate nvarchar(9) = N'С167РК';
select
    Plate
    , YearManuf
    , Brand
    , Color
    , InsurancePay
    , Rental
from 
    ViewRentals
where 
    Plate = @plate;
go


-- 2. Запрос к представлению	
--    Выбирает информацию обо всех фактах проката автомобиля с заданной моделью/брендом
declare @brand nvarchar(20) = N'Skoda Roomster';
select
    Plate
    , YearManuf
    , Brand
    , Color
    , InsurancePay
    , Rental
from 
    ViewRentals
where 
    Brand = @brand;
go


-- 3. Запрос к представлению	
--    Выбирает информацию об автомобиле с заданным госномером
declare @plate nvarchar(9) = N'С167РК';
select
    Plate
    , YearManuf
    , Brand
    , Color
    , InsurancePay
    , Rental
from 
    ViewCars
where 
    Plate = @plate;
go


-- 4. Запрос с параметром	
--    Выбирает информацию о клиентах по серии и номеру паспорта
declare @passport nvarchar(15) = '12 21 345671'
select
    *
from
    Clients
where 
    Passport = @passport;
go


-- 5. Запрос к представлению	
--    Выбирает информацию обо всех зафиксированных фактах
--    проката автомобилей в некоторый заданный интервал времени.
declare @lo date = '2021-09-01', @hi date = '2021-09-30';
select
    Plate
    , Client
    , DateStart
    , Duration
from 
    ViewRentals
where 
    DateStart between @lo and @hi;
go


-- 6. Запрос к представлению	
--    Вычисляет для каждого факта проката стоимость проката. 
--    Включает поля Дата проката, Госномер автомобиля, Модель автомобиля, 
--    Стоимость проката. Сортировка по полю Дата проката
select
    DateStart
    , Plate
    , Brand
    -- Стоимость проката = Стоимость одного дня проката * Количество дней проката. 
    , Rental * Duration as RentalPrice
from 
    ViewRentals;
go


-- 7. Запрос с левым соединением	
--    Для всех клиентов прокатной фирмы вычисляет количество фактов проката, 
--    суммарное количество дней проката, упорядочивание по убыванию суммарного 
--    количества дней проката
select
    Clients.Surname  + ' ' + SUBSTRING(Clients.Name, 1, 1) + '. ' + SUBSTRING(Clients.Patronymic, 1, 1) + '. ' as Client
    , COUNT(Rentals.Id) as AmountRentals
    , Sum(Rentals.Duration) as SumDuration
from 
    Clients left join Rentals on Rentals.IdClient = Clients.Id
group by
    Clients.Surname  + ' ' + SUBSTRING(Clients.Name, 1, 1) + '. ' + SUBSTRING(Clients.Patronymic, 1, 1) + '. '
order by 
    SumDuration desc;
go

--8. Итоговый запрос	
--   Выполняет группировку по полю Модель автомобиля. 
--   Для каждой модели вычисляет количество фактов проката, сумму за прокат
select
    Brands.Brand
    , COUNT(Rentals.Id) as AmountRentals
    , Sum(Cars.Rental * Rentals.Duration) as RentalPrice
from 
    Rentals join (Cars join Colors on Cars.IdColor = Colors.Id join Brands on Cars.IdBrand = Brands.Id) 
                    on Rentals.IdCar = Cars.Id
group by 
    Brands.Brand
go


--9. Запрос на добавление	
--   Добавляет данные о новом клиенте. Данные передавайте параметрами
declare @surname    nvarchar(60) = N'Иванов',
	    @name       nvarchar(50) = N'Иван',
	    @patronymic nvarchar(60) = N'Иванович',
        @passport   nvarchar(15) = N'99 21 000001';

insert into 
	Clients (Surname, [Name], Patronymic, Passport)
values
    (@surname, @name, @patronymic, @passport);
go

--10. Запрос на обновление	
--    Изменяет данные клиента (все поля, кроме идентификатора). 
--    Данные передавайте параметрами
declare @id int = 1,
	    @surname    nvarchar(60) = N'Михайлович',
	    @name       nvarchar(50) = N'Сергей',
	    @patronymic nvarchar(60) = N'Федорович',
        @passport   nvarchar(15) = N'13 43 878232';

update
    Clients
set
    Surname = @surname
    , [Name] = @name
    , Patronymic = @patronymic
    , Passport = @passport
where
    Clients.Id = @id;
go


--11. Запрос на обновление	
--    Изменяет данные автомобиля (все поля, кроме идентификатора). 
--    Данные передавайте параметрами
declare @id int = 1, 
        @brand nvarchar(30) = N'Mercedes 210', 
        @color nvarchar(30) = N'серебристый',
        @plate nvarchar(12)=N'М345РК',
        @yearManuf int = 2020, 
        @insurValue int = 4500000,
        @rental int = 5100;

update
    Cars
set
    IdBrand = (select Id from Brands where Brand = @brand)
    , IdColor = (select Id from Colors where color = @color)
    , Plate = @plate
    , YearManuf = @yearManuf
    , InsurancePay = @insurValue
    , Rental = @rental
where
    Cars.Id = @id;
go


---------------------------------------------------------------------------------------------
--                           Запросы на изучение T-SQL

--12. Задача If13. 
--    Даны три числа. Найти среднее из них.
--    Числа формируйте генератором случайных чисел
declare @a int = -100 + 200*rand();
declare @b int = -100 + 200*rand();
declare @c int = -100 + 200*rand();
declare @mean int;

if @a < @b and @b < @c or @a > @b and @b > @c begin   -- логика решения
   set @mean = @b;
end else if @b < @a and @a < @c or  @b > @a and @a > @c begin
   set @mean = @a;
end else begin
    set @mean = @c;
end;
-- вывод результата
select @a as 'a', @b as 'b',  @c as 'c', @mean as 'mean';  -- вывод в область результатов
print N'результат:' + char(10) +                           -- вывод в область сообщений
      char(9) + 'a = ' + ltrim(str(@a)) + char(10) +
      char(9) + 'b = ' + ltrim(str(@b)) + char(10) + 
      char(9) + 'c = ' + ltrim(str(@b)) + char(10) + 
      char(9) + 'mean = ' + ltrim(str(@mean));
go


--13. Задача If14. 
--    Даны три числа. Вывести вначале наименьшее, а затем наибольшее их данных чисел.
--    Числа формируйте генератором случайных чисел
declare @a int = -100 + 200*rand();
declare @b int = -100 + 200*rand();
declare @c int = -100 + 200*rand();
declare @min int, @max int;

if @a < @b and @c < @b begin  
    set @max = @b;
    if @a < @c begin set @min = @a; end 
    else begin       set @min = @c; end 

end else if @c < @a begin
   set @max = @a;
   if @b < @c begin set @min = @b; end 
   else begin       set @min = @c; end 

end else begin
    set @max = @c;
    if @b < @a begin set @min = @b; end 
    else begin       set @min = @a; end 
end;

-- вывод результата
select @a as 'a', @b as 'b', @c as 'c', @min as 'min', @max as 'max'; -- вывод в область результатов
print N'результат:' + char(10) +                                      -- вывод в область сообщений
      char(9) + 'a = ' + ltrim(str(@a)) + char(10) +
      char(9) + 'b = ' + ltrim(str(@b)) + char(10) + 
      char(9) + 'c = ' + ltrim(str(@c)) + char(10) + 
      char(9) + 'min = ' + ltrim(str(@min)) + char(10) +
      char(9) + 'max = ' + ltrim(str(@max));
go

--14. Задача If15. 
--    Даны три числа. Найти сумму двух наибольших из них. 
--    Числа формируйте генератором случайных чисел
declare @a int = -100 + 200*rand();
declare @b int = -100 + 200*rand();
declare @c int = -100 + 200*rand();
declare @res int;

if @a < @b and @a < @c begin
    set @res = @b + @c;
end else if @c < @b begin
    set @res = @b + @a;
end else begin 
    set @res = @a + @c;
end;

-- вывод результата
select @a as 'a', @b as 'b', @c as 'c', @res as 'res'; -- вывод в область результатов
print N'результат:' + char(10) +                       -- вывод в область сообщений
      char(9) + 'a = ' + ltrim(str(@a)) + char(10) +
      char(9) + 'b = ' + ltrim(str(@b)) + char(10) + 
      char(9) + 'c = ' + ltrim(str(@c)) + char(10) + 
      char(9) + 'res = ' + ltrim(str(@res)) ;
go

--15. Задача If17.
--    Даны три числа. Если их значения упорядочены по возрастанию или убыванию,
--    то удвоить их; в противном случае заменить значение каждой переменной 
--    на противоположное. Числа формируйте генератором случайных чисел или присваиванием
declare @a int = -100 + 200*rand();
declare @b int = -100 + 200*rand();
declare @c int = -100 + 200*rand();
declare @res int;

select N'Данные до обработки:' as Title, @a as 'a', @b as 'b', @c as 'c'; -- вывод в область результатов

if @a < @b and @b < @c or @a > @b and @b > @c begin
    set @a *= 2;
    set @b *= 2;
    set @c *= 2;
end else  begin
    set @a = -@a;
    set @b = -@b;
    set @c = -@c;
end;

-- вывод результата
select N'Данные после обработки:' as Title, @a as 'a', @b as 'b', @c as 'c'; -- вывод в область результатов