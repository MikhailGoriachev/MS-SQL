﻿
drop view if exists ViewCars;
drop view if exists ViewRentals;
go
-- создание представления для автомобилей
create view ViewCars as
    select
        Cars.Id
        , Brands.Brand
        , Colors.Color
        , Cars.Plate
        , Cars.YearManuf
        , Cars.InsurancePay
        , Cars.Rental
    from
        Cars join Colors on Cars.IdColor = Colors.Id
             join Brands on Cars.IdBrand = Brands.Id;
go


-- создание представления для фактов проката
create view ViewRentals as
    select
        Rentals.Id
        , Clients.Surname  + ' ' + SUBSTRING(Clients.Name, 1, 1) + '. ' + SUBSTRING(Clients.Patronymic, 1, 1) + '. ' as Client
        , Clients.Surname 
        , Clients.[Name]
        , Clients.Patronymic
        , Clients.Passport
        , Brands.Brand
        , Colors.Color
        , Cars.Plate
        , Cars.YearManuf
        , Cars.InsurancePay
        , Cars.Rental
        , Rentals.DateStart
        , Rentals.Duration
    from     
        Rentals join (Cars join Colors on Cars.IdColor = Colors.Id join Brands on Cars.IdBrand = Brands.Id) on Rentals.IdCar = Cars.Id
                join Clients on Rentals.IdClient = Clients.Id
go
