﻿--создание представления об Clients
create view ClientsView as
	select
		Clients.Id
		,Clients.Surname
		,Clients.[Name]
		,Clients.Patronymic
		,Clients.PassportId
	from
		Clients
go


--создание представления об автопарке
create view CarParkView as
	select
		CarPark.Id
		,Cars.CarName
		,Colors.Color
		,CarPark.YearManuf
		,CarPark.Plate
		,CarPark.Rental
		,CarPark.InsurValue
	from
		CarPark join Cars on CarPark.IdCarName = Cars.Id
		        join Colors on CarPark.IdColor = Colors.Id
go


--cоздание представления о фактах проката
create view HiresView as
	select 
		Hires.Id
	   ,Clients.Surname
	   ,Clients.[Name]
	   ,Clients.Patronymic
	   ,Clients.Surname + N' ' + SUBSTRING(Clients.[Name],1,1) + N'.'+SUBSTRING(Clients.Patronymic,1,1)+N'.' as Client
	   ,Clients.PassportId
	   ,Cars.CarName
	   ,Colors.Color
	   ,CarPark.Plate
	   ,CarPark.YearManuf
	   ,CarPark.InsurValue
	   ,CarPark.Rental
	   ,Hires.DateStart 
	   ,Hires.Duration
	 from
		Hires join(CarPark join Cars on CarPark.IdCarName = Cars.Id join Colors on CarPark.IdColor = Colors.Id) on Hires.IdCar = CarPark.IdCarName	
			  join Clients on Hires.IdClient = Clients.Id
go			  
		

--Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
select
	HiresView.Client
	,HiresView.CarName
	,HiresView.Color
	,HiresView.Plate
	,HiresView.Rental
	,HiresView.DateStart
	,HiresView.Duration
from
	HiresView
where HiresView.Plate = N'А135АХ'
go


--Выбирает информацию обо всех фактах проката автомобиля с заданной моделью/брендом
select
	HiresView.Client
	,HiresView.CarName
	,HiresView.Color
	,HiresView.Plate
	,HiresView.Rental
	,HiresView.DateStart
	,HiresView.Duration
from
	HiresView
where HiresView.CarName like 'Ford%'
go



--Выбирает информацию об автомобиле с заданным госномером
select
	*
from
	CarParkView
where CarParkView.Plate = N'А135АХ'
go

--Выбирает информацию о клиентах по серии и номеру паспорта
select
	*
from
	ClientsView
where ClientsView.PassportId = N'09 19 002129'
go

--Выбирает информацию обо всех зафиксированных фактах проката автомобилей в некоторый заданный интервал времени.
select
	*
from
	HiresView
where HiresView.DateStart between '2021-09-05' and '2021-10-06'
go


--Вычисляет для каждого факта проката стоимость проката. Включает поля Дата проката, 
--Госномер автомобиля, Модель автомобиля, Стоимость проката. Сортировка по полю Дата проката
select
	 HiresView.Client
	,HiresView.DateStart
	,HiresView.CarName
	,HiresView.Plate
	,HiresView.Rental
	,HiresView.Duration
	,HiresView.Rental * HiresView.Duration as RentalSum
from
	HiresView
order by HiresView.DateStart
go

--Для всех клиентов прокатной фирмы вычисляет количество фактов проката, суммарное количество дней проката,
--упорядочивание по убыванию суммарного количества дней проката

select

	Clients.Surname + N' '+SUBSTRING(Clients.[Name],1,1)+N'.'+SUBSTRING(Clients.Patronymic,1,1)+N'.' as Client
	,sum(Hires.Duration) as DaysSum
	,count(Hires.Id) as RentAmount
from
	Clients left join  Hires on Clients.Id = Hires.IdClient
group by
	Clients.Surname,Clients.[Name],Clients.Patronymic
order by 
	DaysSum desc
go

--Выполняет группировку по полю Модель автомобиля. Для каждой модели вычисляет количество фактов проката, сумму за прокат
select
	Cars.CarName
	,count(Hires.Duration) as RentAmount
	,sum(CarPark.Rental * Hires.Duration) as RentIncome
from
	Cars join (Hires join CarPark on CarPark.Id = Hires.IdCar) on CarS.Id = Hires.IdCar
group by
	Cars.CarName
		 

--Добавляет данные о новом клиенте. Данные передавайте параметрами
declare @name nvarchar(10) = N'Алексей' ,@surname nvarchar(25) = N'Надворный',@patronymic nvarchar(25) =N'Дмитриевич',
		@passportId nvarchar(30) = N'10 19 001603'
insert into Clients
	values
		(@surname,@name,@patronymic,@passportId)

--Изменяет данные клиента (все поля, кроме идентификатора). Данные передавайте параметрами
declare @nameupd nvarchar(10) = N'Анатолий' ,@surnameupd nvarchar(25) = N'Бургунский',@patronymicupd nvarchar(25) =N'Дмитриевич',
		@passportIdupd nvarchar(30) = N'22 19 101603'
update Clients
	set
		[Name] = @nameupd,
		Surname = @surnameupd,
		Patronymic = @patronymicupd,
		PassportId =@passportIdupd
where
	Clients.Id = 1


--Изменяет данные автомобиля (все поля, кроме идентификатора). Данные передавайте параметрами
declare @carname nvarchar(15) = N'ВАЗ 21099'
update Cars
	set
		CarName = @carname
where
	Cars.Id = 1



--drop view CarParkView
--drop view ClientsView
--drop view HiresView