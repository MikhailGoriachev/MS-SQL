﻿--Задача If13. Даны три числа. Найти среднее из них (то есть число, расположенное между наименьшими наибольшим). 
--Числа формируйте генератором случайных чисел
go
declare @num1 int =(select FLOOR(RAND()*(10))+1),@num2 int = (select FLOOR(RAND()*(10))+1),
        @num3 int=(select FLOOR(RAND()*(10))+1),@result int

if @num1 > @num2 and @num1 < @num3
	set @result = @num1;
else if @num2 > @num1 and @num2 < @num3
	set @result = @num2;
else
	set @result = @num3;
	
print N'Среднее число из трех чисел '+ltrim(str(@num1))+N','+ ltrim(str(@num2))+','+ltrim(str(@num3))+N' = '+ ltrim(str(@result))


--Задача If14. Даны три числа. Вывести вначале наименьшее, а затем наибольшее их данных чисел. Числа формируйте генератором случайных чисел
go
declare @x1 int =100 + 200*rand();
declare @x2 int = -100 + 200*rand();
declare @x3 int=100 + 200*rand();
declare @min int,@max int;

if @x1 < @x2 and @x2 < @x3 begin
	set @max = @x3;
	set @min = @x1;
end;
else if @x1 > @x2 and @x2 > @x3 begin
	set @max = @x1;
	set @min = @x3;
end;
else if @x2 > @x1 and @x1 > @x3 begin
	set @max = @x2;
	set @min = @x3;
end
else if @x1 > @x3 and @x2 < @x3 begin
		set @max = @x1;
		set @min = @x2;
end else begin
	set @min = @x3;
	set @max =@x2;
end;

select @x1 as 'X1' , @x2 as 'X2' ,@x3 as 'X3',@min as 'MIN',@max as 'MAX';
go


--Задача If15. Даны три числа. 
--Найти сумму двух наибольших из них. Числа формируйте генератором случайных чисел
go
declare @x1 int =100 + 200*rand();
declare @x2 int = -100 + 200*rand();
declare @x3 int=100 + 200*rand();
declare @max int,@max2 int;

if @x1 > @x2 and @x2 > @x3 begin
	set @max = @x1;
	set @max2 = @x2;
end;
else if @x1 < @x2 and @x2 < @x3 begin
	set @max = @x3;
	set @max2 = @x2;
end;
else if @x1 > @x2 and @x2< @x3
	set @max = @x3;
	set @max2 = @x1;

select @x1 as 'X1' , @x2 as 'X2' ,@x3 as 'X3',@max as 'MAX',@max2 as 'MAX2';
go

--Задача If17. Даны три числа. Если их значения упорядочены по возрастанию или убыванию, то удвоить их; 
--в противном случае заменить значение каждой переменной на противоположное. 
--Числа формируйте генератором случайных чисел или присваиванием

go
declare @x1 int =10 + 200*rand();
declare @x2 int = -10 + 200*rand();
declare @x3 int=10 + 200*rand();

if @x1 > @x2 and @x2 > @x3 begin
	set @x1*=2;
	set @x2*=2;
	set @x3*=2;
end;
else if @x1 < @x2 and @x2 < @x3 begin
	set @x1*=2;
	set @x2*=2;
	set @x3*=2;
end else begin
	set @x1 = -@x1;
	set @x2 = -@x2;
	set @x3 = -@x3;
end;
select @x1 as 'X1' , @x2 as 'X2' ,@x3 as 'X3';
go
	