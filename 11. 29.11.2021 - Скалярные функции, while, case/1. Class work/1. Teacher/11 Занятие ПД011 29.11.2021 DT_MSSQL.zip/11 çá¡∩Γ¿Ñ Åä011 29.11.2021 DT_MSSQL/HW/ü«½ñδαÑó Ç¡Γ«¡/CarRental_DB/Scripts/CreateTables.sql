﻿
drop table if exists Cars;
drop table if exists Colors;
drop table if exists CarPark;
drop table if exists Clients;
drop table if exists Hires;



--создание таблицы машин
create table Cars
(
	Id		int				not null primary key identity (1,1),
	CarName	nvarchar(45)	not null
	
);
go

--создание таблицы цвета автомобилей
create table Colors
(
	Id		int				not null primary key identity (1,1),
	Color	nvarchar(25)	not null


);
go

--таблица автопарка
create table CarPark
(
	Id			int				not null primary key identity(1,1),
	IdCarName	int				not null, --внешний ключ ,ссылка на таблицу Cars
	IdColor		int				not null, --внешний ключ,ссылка на таблицу Colors	
	Plate		nvarchar(10)	not null, --гос номер
	YearManuf	int				not null, --год выпуска
	InsurValue	int				not null, --страховая стоимость
	Rental		int				not null, --стоимсть дня проката

	--проверочные ограничения
	constraint CK_CarPark_YearManuf		check(YearManuf > 2010),
	constraint CK_CarPark_InsurValue	check(InsurValue > 0),
	constraint CK_CarPark_Rental		check(Rental>0),
	
	--органичение уникальности значение столбцов
	constraint	CK_CarPark_Plate	unique(Plate),

	--внешние ключи
	constraint FK_CarPark_Cars   foreign key(IdCarName) references Cars(Id),
	constraint FK_CarPark_Colors foreign key(IdColor)   references Colors(Id)
	
);
go


--таблица клиентов
create table Clients(

	Id			int				not null primary key identity (1,1),
	Surname		nvarchar(60)	not null,--фамилия
	[Name]		nvarchar(50)	not null,--имя
	Patronymic	nvarchar(60)	not null,--Отчество
	PassportId	nvarchar(15)	not null,--Серия паспорта

	--орграничение уникальности
	constraint CK_Clients_Passport unique(PassportId)


);
go


--таблица регистрации фактов проката
create table Hires(

	Id			int		not null primary key identity (1,1),
	IdClient	int		not null, --внешний ключ,ссылка на таблицу клиентов
	IdCar		int		not null, --внешний ключ,ссылка на таблицу CarPark
	DateStart	date	not null, --дата начала проката
	Duration	int		not null, --длительность проката

	--проверочные ограничения
	constraint	CK_Hires_DateStart	check(DateStart	> '01.01.2021'),
	constraint  CK_Hires_Duration	check(Duration between 1 and 15),

	--внешние ключи 
	constraint FK_Hires_Clients		foreign key(IdClient) references Clients(Id),
	constraint FK_Hires_CarPark		foreign key(IdCar)	  references CarPark(Id)

);
go

