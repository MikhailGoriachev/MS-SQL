﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace Files.App_Data
{
    internal partial class App
    {
        public static void WriteText(string fileName)
        {
            string str;
            StringBuilder sb = new StringBuilder();

            using (StreamWriter sw = new StreamWriter(fileName, true, Encoding.UTF8))
            {
                while(true)
                {
                    Console.Write("Введите строку (exit -  выход)");
                    str = Console.ReadLine();
                    if (str == "exit") break;

                    // запись строки в файл
                    sw.WriteLine(str);
                    sb.Append(str).Append("\n");
                }// while
            }// using 
        }

        public static void ReadText(string fileName)
        {
            using (StreamReader sr = new StreamReader(File.OpenRead(fileName), Encoding.UTF8))
            {
                string str;
                while(!sr.EndOfStream)
                {
                    //пока не достигнут конец файла
                    str = sr.ReadLine(); // читать строку
                    Console.WriteLine(str);

                }// while
            }
        }
    }
}
