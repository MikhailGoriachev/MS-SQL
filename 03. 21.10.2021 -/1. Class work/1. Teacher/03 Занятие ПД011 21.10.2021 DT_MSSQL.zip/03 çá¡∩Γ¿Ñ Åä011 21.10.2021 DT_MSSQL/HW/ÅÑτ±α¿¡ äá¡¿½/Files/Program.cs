﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Files.App_Data;

namespace Files
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 21.09.2021 . Работа с файлами";

            MenuItem[] menu = new[] 
            { 
                new MenuItem{ HotKey = ConsoleKey.Q, Text = "Задача 1. Определить среднее число"},
                new MenuItem{ HotKey = ConsoleKey.W, Text = "Задача 2. Количество слов в тексте"}
            };

            App app = new App(); 

            while(true)
            {
                try
                {
                    //настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  ООП С# - Работа с файлами");
                    Utils.ShowMenu(12, 5, "Меню приложения для работы с файлами", menu);

                    // получения кода клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg = " Нажмите выделенныую цветом клавишу для выбора ".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch(key)
                    {
                        case ConsoleKey.Q:
                            app.Task1();
                            break;
                        case ConsoleKey.W:
                            app.Task2();
                            break;
                    }

                }
                catch(Exception ex)
                {
                    Console.WriteLine("\n");
                    Console.WriteLine(ex);
                    Console.ReadKey();

                }
            }
            
        }
    }
}
