﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Files.App_Data
{
    internal partial class App
    {
        public void Task1()
        {
            Utils.ShowNavBarTask("Задача 1. Определить среднее число");

            ReadText(@"..\..\data.txt"); 



            Console.ReadKey();
        }

        public void Task2()
        {
            Utils.ShowNavBarTask("Задача 2. Количество слов в тексте");


            Console.ReadKey(); 

        }
    }
}
