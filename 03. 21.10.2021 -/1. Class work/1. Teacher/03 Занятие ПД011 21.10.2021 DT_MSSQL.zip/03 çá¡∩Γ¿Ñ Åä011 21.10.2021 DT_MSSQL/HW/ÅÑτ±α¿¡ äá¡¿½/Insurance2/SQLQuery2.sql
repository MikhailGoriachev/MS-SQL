﻿SELECT * FROM CLIENTS WHERE Discount BETWEEN 0.3 AND 0.5 AND SURNAME LIKE N'Рос%'
SELECT * FROM Clients WHERE Discount = 0.1 OR Discount = 0.23 OR Discount = 0.12
SELECT Surname, Name, Patronymic, BirthDate FROM Clients WHERE BirthDate > 2000 AND Name = N'Полина' OR NAME = N'Павел'
SELECT id,Surname, Name, Patronymic, BirthDate FROM Clients WHERE BirthDate < 1996    
