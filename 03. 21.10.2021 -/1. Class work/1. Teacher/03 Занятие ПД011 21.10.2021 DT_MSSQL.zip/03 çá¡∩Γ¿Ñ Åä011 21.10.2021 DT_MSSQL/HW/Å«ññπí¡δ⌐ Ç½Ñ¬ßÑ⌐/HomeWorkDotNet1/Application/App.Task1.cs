﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWorkDotNet1.Application
{
    internal partial class App
    {

        // чтение из исходного файла
        public void ReadText(string FileName)
        {
            // читаем исходный файл и , к сожалению, тут же выполняем обрабортку
            using (StreamReader sr = new StreamReader(File.OpenRead(FileName), Encoding.UTF8))
            {


                Console.WriteLine($"Исходный файл {FileName}");
                int i = 0;

                string str;
                while (!sr.EndOfStream)
                {
                    // пока не достигнут конец файла
                    str = sr.ReadLine(); // читать строку
                    // режем строку
                    string[] numbers = str.Split(' ');

                    // читаем под строки т.к. формат файла нам известен
                    // вывод на экран
                    Console.WriteLine(str);
                    arrayTuple[i].a = int.Parse(numbers[0]);
                    arrayTuple[i].b = int.Parse(numbers[1]);
                    arrayTuple[i].c = int.Parse(numbers[2]);



                    // находим среднее значение и записываем его
                    arrayTuple[i].median = arrayTuple[i].a;
                    if (arrayTuple[i].a < arrayTuple[i].b && arrayTuple[i].a < arrayTuple[i].c) arrayTuple[i].median = Math.Min(arrayTuple[i].b, arrayTuple[i].c);
                    if (arrayTuple[i].a > arrayTuple[i].b && arrayTuple[i].a > arrayTuple[i].c) arrayTuple[i].median = Math.Max(arrayTuple[i].b, arrayTuple[i].c);                 


                    i++;
                } // while

            }


        }

        // узнать размер файла
        public int GetSizeFile(string fileName) {
            int i = 0;
            using (StreamReader sr = new StreamReader(File.OpenRead(fileName), Encoding.UTF8))
                while (!sr.EndOfStream) {
                    sr.ReadLine();
                    i++;
                }

            return i;
        }


        // запись нового файла
        public void WriteText(string resultName)
        {
            // очищаем файл
            File.WriteAllText(resultName, String.Empty);

            using (StreamWriter sw = new StreamWriter(resultName, true, Encoding.UTF8))
            {
                Console.WriteLine($"Новый файл {resultName}");

                string temp;

                for (int i = 0; i < arrayTuple.Length; i++)
                {
                    // создаем строку нужного формата
                    temp = $"{arrayTuple[i].a} {arrayTuple[i].b} {arrayTuple[i].c} \t{arrayTuple[i].median}";
                    sw.WriteLine(temp); // записуем строку
                    Console.WriteLine(temp);
                    temp = ""; //очищаем строку
                }
                                
            } 
            

           
        }



        public void DemoTask1() {

            ReadText(fileName1);
            WriteText(resultName1);


        }


    }
}
