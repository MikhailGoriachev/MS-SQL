﻿using HomeWorkDotNet1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWorkDotNet1.Application
{
    internal partial class App
    {
        // задание 1
        public string fileName1 = @"text.txt";
        public string resultName1 = @"result.txt";
        public (int a, int b, int c, int median)[] arrayTuple;


        // задание 2
        public string fileName2 = @"text2.txt";
       


        // ансамбль конструкторов
        public App()
        {
            arrayTuple = new (int a, int b, int c, int median)[GetSizeFile(fileName1)];
            
        } // App


    }
}
