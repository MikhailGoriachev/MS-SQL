﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWorkDotNet1.Application
{
    internal partial class App
    {
        // с учетом регистра
        public int CountWordsSensitive(string fileName) {

            string text = File.ReadAllText(fileName, Encoding.UTF8);
            string[] words = text.Split(' ');

            int count = 0;

            for (int i = 0; i < words.Length; i++)
            {
                string temp = words[i];
                if (temp.Length > 1 & (temp[0] == temp[temp.Length - 1]))
                    count++;
            }

            return count;
        }

        // без учета регистра
        public int CountWordsInSensitive(string fileName)
        {
            string text = File.ReadAllText(fileName, Encoding.UTF8);
            text.ToLower();
            string[] words = text.Split(' ');

            int count = 0;

            for (int i = 0; i < words.Length; i++)
            {
                string temp = words[i];
                if (temp.Length > 1 & (temp[0] == temp[temp.Length - 1]))
                    count++;
            }

            return count;    
        }

        // вывод текста на экран
        public void ShowTextTask2(string fileName)
        {
            string text = File.ReadAllText(fileName, Encoding.UTF8);
            Console.WriteLine(text);
        }


        public void DemoTask2()
        {
            Console.WriteLine($"Исходный файл {fileName2}");
            ShowTextTask2(fileName2);
            Console.WriteLine($"\nКоличество слов в тексте, у которых первый и последний символы совпадают:");
            Console.WriteLine($"C учетом регистра = {CountWordsSensitive(fileName2)}");
            Console.WriteLine($"Без учета регистра = {CountWordsInSensitive(fileName2)}");
           

        }


    }
}
