﻿--Выбирает из таблицы Clients информацию о клиентах, процент скидки для которых находится в диапазоне от 0,3% до 0,5% и фамилия начинается на «Рос»
select
   *
from
    Clients
where      
    (Surname like N'Рос%' ) and Customer_discount between 0.3 and 0.5;      

--Выбирает из таблицы Clients информацию о клиентах с процентом скидки 0,1% или 0,23% или 0,12%
--Выводить идентификатор, фамилию, имя, отчество и процент скидки, упорядочить по фамилии клиентов
select
   Id
   , Surname
   , Name
   , Patronymic
   , Customer_discount
from
    Clients
where      
    Customer_discount in (0.1, 0.23, 0.12)   
order by
    Surname;

--Выбирает из таблицы Clients информацию о клиентах, с годом рождения, большим 2000 и именами Павел или Полина. Выводить фамилию, имя, отчество и год рождения 
select
   Surname
   , Name
   , Patronymic
   , Year
from
    Clients
where      
    (Name in (N'Павел',N'Полина')) and Year>2000 ;

--Выбирает из таблицы Clients информацию о клиентах, с годом рождения, меньшим 1996. Выводить идентификатор, фамилию, имя, отчество и год рождения.
--Упорядочить по году рождения и фамилии
select
   Surname
   , Name
   , Patronymic
   , Year
from
    Clients
where      
    Year < 1996
order by
    Year , Surname;