﻿--Выбирает из таблицы Types все столбцы всех записей, упорядочить по названию вида страхования
select
   *
from
    Types
order by
    Name_of_type_insurance;

--Выбирает из таблицы Types информацию о типах страхования имущества (должна присутствовать строка «имуществ»), упорядочить по убыванию цены  
select
   *
from
    Types
where
    Name_of_type_insurance like N'имуществ%' or Name_of_type_insurance like N'%имуществ%' or Name_of_type_insurance like N'%имуществ%'
order by
    Price;

--Выбирает из таблицы Types информацию о видах страхования со стоимостью от 500 рублей до 1200 рублей, упорядочить по возрастанию цены 
select
   *
from
    Types
where
    Price between 500 and 1200
order by
    Price;