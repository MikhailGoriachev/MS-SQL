﻿using System;
using System.IO;


namespace Sharp_Homework
{
	internal static class Program
	{
		public static void Main(string[] args)
		{
			App app = new();

			app.Run();
		}
	}
}