﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using Main.Utilities;


namespace Sharp_Homework
{
	public sealed class Controller
	{
		private static readonly string RegexPatternForCountWords = @"\b(?'first'\w)\w+(\k'first')\b";


		/// <summary>
		///		Сохранение средних чисел в новый файл
		/// </summary>
		/// <param name="path">Путь к исходному файлу</param>
		/// <param name="resultFilePath">Путь к результирующему файлу</param>
		/// <param name="averages">Коллекция средних чисел</param>
		public void SaveAveragesToFile(string path, string resultFilePath, IEnumerable<int> averages) =>
			// Получим итератор по файлу
			File.ReadLines(path)
				// Начнем итерацию по исходному файлу и по коллекциюю средних чисел
				// Вернем перечислитель форматированных строк для нового файла
				.Zip(averages, (s, i) => $"{s}\t\t{i}")
				// Создадим новый файл, запишем в него каждую строку
				.Aggregate(File.CreateText(resultFilePath), (writer, s) =>
				{
					writer.WriteLine(s);

					return writer;
				})
				// Очистим неуправляемые ресурсы файлового потока
				.Dispose();


		public IEnumerable<int> FindAverages(string path) =>
			// Получим итератор по файлу
			File.ReadLines(path)
				// Получим перечислитель по цифрам в строке
				.Select(GetAllNumbersInString)
				// Найдем среднее в наборе цифер и добавим его в список
				.Aggregate(new List<int>(), (result, numbers) =>
				{
					// Отсортируем числа в строке, возьмем второе число (из 3 чисел оно будет средним)
					result.Add(numbers.OrderBy(i => i).ToArray()[1]);

					return result;
				});


		private IEnumerable<int> GetAllNumbersInString(string input) =>
			input
				// Разделим строку на токены
				.Split(' ', StringSplitOptions.RemoveEmptyEntries)
				// Преобразуем каждую цифру в целое число
				.Select(int.Parse);


		public void ShowFile(string path)
		{
			foreach (var line in File.ReadLines(path))
				Console.WriteLine(line);
		}


		public (int sensitive, int insensitive) CountWordsWhereFirstEqualsToLast(string path)
		{
			// Обьект регулярного выражения для поиска с учетом регистра
			Regex sensitive = new(RegexPatternForCountWords,
				RegexOptions.Compiled);

			// Обьект регулярного выражения для поиска без учета регистра
			Regex noSensitive = new(RegexPatternForCountWords,
				RegexOptions.Compiled | RegexOptions.IgnoreCase);

			// Прочитаем все строки в качестве массива
			var lines = File.ReadAllLines(path);

			return (CountOccurances(sensitive, lines), CountOccurances(noSensitive, lines));
		}


		/// <summary>
		///		Подсчет совпадений по регулярному выражению
		/// </summary>
		/// <param name="regex">Обьект регулярного выражения для обработки</param>
		/// <param name="lines">Перечислитель строк - цель для регулярного выражения</param>
		/// <returns>Сумма вхождений для каждой строки</returns>
		private int CountOccurances(Regex regex, IEnumerable<string> lines) =>
			lines
				.Select(s => regex.Matches(s).Count)
				.Sum();
	}
}