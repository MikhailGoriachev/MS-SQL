﻿#nullable enable
using System;
using System.Collections.Generic;
using System.Drawing;


namespace Main.Utilities.TableFormatter
{


	public sealed class TableFormatter<T>
	{
		private readonly TablePrinter<T> _tablePrinter = new();


		public TableOptions Options { get; set; } = new();


		public int TableWidth => _tablePrinter.Footer.Length;


		public void Show(T target) => Show(new[] { target });


		public void Show(IEnumerable<T> targets) => Show(targets, null);


		public void Show(IEnumerable<T> targets, Predicate<T> predicate) =>
			Show(targets, i =>
			{
				if (predicate?.Invoke(i) ?? false)
					Options.ColorByPredicate.AsCurrent();
			});


		public void Show(IEnumerable<T> targets, Action<T> output)
		{
			var old = Color.Instantiate();
			Options.DefaultColor.AsCurrent();

			var (left, top) = (Options.CursorPosition.X, Options.CursorPosition.Y);

			foreach (var s in _tablePrinter.Header)
			{
				Console.SetCursorPosition(left, top++);
				Console.WriteLine(s);
			}

			foreach ((T item, string row) in _tablePrinter.ConvertObjectsToTableRow(targets))
			{
				output?.Invoke(item);

				Console.SetCursorPosition(left, top++);
				Console.Write(row);

				Options.DefaultColor.AsCurrent();
			}

			Console.SetCursorPosition(left, top++);
			Console.WriteLine(_tablePrinter.Footer);

			Options.CursorPosition = new Point(left, top);
			old.AsCurrent();
		}
	}


}
