﻿using System;
using Main.Utilities.Menu;


namespace Sharp_Homework
{
	public sealed class App : MenuWrapper
	{
		private static readonly string FirstTaskSourceFile = @"..\..\..\data.txt";
		private static readonly string FirstTaskResultFile = @"..\..\..\result.txt";
		private static readonly string SecondTaskSourceFile = @"..\..\..\text.txt";
		private Controller _controller = new();


		public App() =>
			Menu = new("Главное меню приложения", new[]
			{
				new MenuItem("Задача 1. Найти среднее число в каждой строке файла состоящей из 3 чисел",
					FirstTask),
				new MenuItem("Задача 2. Посчитать кол-во слов с одинаковой первой и последней буквами",
					SecondTask)
			});


		private void FirstTask()
		{
			_controller.ShowFile(FirstTaskSourceFile);

			var averages = _controller.FindAverages(FirstTaskSourceFile);

			_controller.SaveAveragesToFile(FirstTaskSourceFile,
				FirstTaskResultFile, averages);

			Console.WriteLine("\n\n");
			_controller.ShowFile(FirstTaskResultFile);
		}


		private void SecondTask()
		{
			var (sensitive, insensitive) = _controller
				.CountWordsWhereFirstEqualsToLast(SecondTaskSourceFile);

			Console.WriteLine("Количество слов у которых первый и последний символы совпадают:\n");
			Console.WriteLine($"\tБез учета регистра (insensitive): {insensitive}");
			Console.WriteLine($"\tС учетом регистра (sensitive): {sensitive}");
		}
	}
}