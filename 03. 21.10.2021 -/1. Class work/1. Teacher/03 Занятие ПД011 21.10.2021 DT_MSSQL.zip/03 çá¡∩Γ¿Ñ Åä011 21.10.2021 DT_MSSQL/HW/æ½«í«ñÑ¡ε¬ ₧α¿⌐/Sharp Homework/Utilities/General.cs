﻿#nullable enable
using System;


namespace Main.Utilities
{


	public static class General
	{
		public static readonly Random Rand = new();


		public static void Pause()
		{
			Console.Write("Нажмите любую клавишу для продолжения...");
			Console.ReadKey(true);
		}


		public static void CursorToBottomAndPause()
		{
			CursorToBottom();
			Pause();
		}


		public static void CursorToBottom() => Console.SetCursorPosition(0, Console.WindowHeight - 1);


		public static void CursorToPositionAndPause(int left, int top)
		{
			Console.SetCursorPosition(left, top);
			Pause();
		}
	}


}
