﻿-- 1
-- Выбирает из таблицы Types все столбцы всех записей, 
-- упорядочить по названию вида страхования
select * from Types
order by InsuranceType asc


-- 2
-- Выбирает из таблицы Clients информацию о клиентах, процент скидки для которых 
-- находится в диапазоне от 0,3% до 0,5% и фамилия начинается на «Рос»
select * from Clients
where DiscountPercent between 0.3 and 0.5
	  and 
	  Surname like N'Рос%'


-- 3
-- Выбирает из таблицы Clients информацию о клиентах с процентом скидки 0,1% или 0,23% или 0,12%
-- Выводить идентификатор, фамилию, имя, отчество и процент скидки, упорядочить по фамилии клиентов
select Id, Surname, FirstName, Patronymic, DiscountPercent 
from Clients
where DiscountPercent in (0.1, 0.23, 0.12)
order by Surname asc


-- 4
-- Выбирает из таблицы Types информацию о типах страхования имущества 
-- (должна присутствовать строка «имуществ»), упорядочить по убыванию цены  
select * from Types
order by InsurancePrice desc


-- 5
-- Выбирает из таблицы Clients информацию о клиентах, с годом рождения, 
-- большим 2000 и именами Павел или Полина. Выводить фамилию, имя, отчество и год рождения 
select Surname, FirstName, Patronymic, BirthYear
from Clients
where BirthYear > 2000 and FirstName in (N'Павел', N'Полина')


-- 6
-- Выбирает из таблицы Types информацию о видах страхования со 
-- стоимостью от 500 рублей до 1200 рублей, упорядочить по возрастанию цены 
select * from Types
where InsurancePrice between 500 and 1200
order by InsurancePrice asc


-- 7
-- Выбирает из таблицы Clients информацию о клиентах, с годом рождения, меньшим 1996. 
-- Выводить идентификатор, фамилию, имя, отчество и год рождения.
-- Упорядочить по году рождения и фамилии
select Id, Surname, FirstName, Patronymic, BirthYear from Clients
where BirthYear < 1996
order by BirthYear, Surname
