﻿CREATE TABLE [dbo].[Table] (
    [Id]             INT           IDENTITY (1, 1) NOT NULL,
    [InsuranceName]  NVARCHAR (50) NOT NULL,
    [InsurancePrice] FLOAT (53)    NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [CK_Types_InsurancePrice] CHECK ([InsurancePrice]>(0)), 
);
