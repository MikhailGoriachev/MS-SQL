﻿select
	*
from
	[Types]
order by 
	InsuranceName
;

select 
	*
from 
    [Types]
where
	InsuranceName like N'%имуществ%'
order by
	InsurancePrice desc
;

select
	*
from 
	[Types]
where
	InsurancePrice between 500 and 1200
order by 
	InsurancePrice
	;
