﻿SET IDENTITY_INSERT [dbo].[Types] ON
INSERT INTO [dbo].[Types] ([Id], [InsuranceName], [InsurancePrice]) VALUES (1, N'Медицинское страхование', 930)
INSERT INTO [dbo].[Types] ([Id], [InsuranceName], [InsurancePrice]) VALUES (2, N'Страхование от несчастных случаев и болезней', 800)
INSERT INTO [dbo].[Types] ([Id], [InsuranceName], [InsurancePrice]) VALUES (3, N'Страхование средств наземного транспорта', 1450)
INSERT INTO [dbo].[Types] ([Id], [InsuranceName], [InsurancePrice]) VALUES (4, N'Страхование средств железнодорожного транспорта', 550)
INSERT INTO [dbo].[Types] ([Id], [InsuranceName], [InsurancePrice]) VALUES (5, N'Страхование средств воздушного транспорта', 1240)
INSERT INTO [dbo].[Types] ([Id], [InsuranceName], [InsurancePrice]) VALUES (6, N'Страхование средств водного транспорта', 1000)
INSERT INTO [dbo].[Types] ([Id], [InsuranceName], [InsurancePrice]) VALUES (7, N'Страхование грузов', 1500)
INSERT INTO [dbo].[Types] ([Id], [InsuranceName], [InsurancePrice]) VALUES (8, N'Сельскохозяйственное страхование', 1650)
INSERT INTO [dbo].[Types] ([Id], [InsuranceName], [InsurancePrice]) VALUES (9, N'Страхование имущества юридических лиц', 400)
INSERT INTO [dbo].[Types] ([Id], [InsuranceName], [InsurancePrice]) VALUES (10, N'Страхование имущества граждан', 850)
INSERT INTO [dbo].[Types] ([Id], [InsuranceName], [InsurancePrice]) VALUES (11, N'Страхование финансовых рисков', 720)
INSERT INTO [dbo].[Types] ([Id], [InsuranceName], [InsurancePrice]) VALUES (12, N'Страхование предпринимательских рисков', 1080)
SET IDENTITY_INSERT [dbo].[Types] OFF
