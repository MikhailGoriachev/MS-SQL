﻿select
	*
from
	Clients
where
	Surname like N'Рос%'
	and
	Discount between 0.3 and 0.5
;
select
	id
	,Surname
	,[Name]
	,Patronymic
	,Discount
from
	Clients
where
	Discount in (0.1, 0.23, 0.12)
order by
	Surname
;

select
	Surname
	,[Name]
	,Patronymic
	,DOB
from 
	Clients
where
	DOB > 2000
	and
	[Name] in (N'Павел',N'Полина')
	;

select
	id
	,Surname
	,[Name]
	,Patronymic
	,DOB
from
	Clients
where
	DOB < 1996
order by 
	DOB 
	,Surname
;
