﻿SET IDENTITY_INSERT [dbo].[Clients] ON
INSERT INTO [dbo].[Clients] ([Id], [Surname], [Name], [Patronymic], [DOB], [Discount]) VALUES (1, N'Ковалёва', N'Анна', N'Дмитриевна', 1998, 0)
INSERT INTO [dbo].[Clients] ([Id], [Surname], [Name], [Patronymic], [DOB], [Discount]) VALUES (2, N'Мельничук', N'Константин', N'Вадимов', 2000, 1)
INSERT INTO [dbo].[Clients] ([Id], [Surname], [Name], [Patronymic], [DOB], [Discount]) VALUES (3, N'Комаров', N'Максим', N'Евгеньевич', 2004, 0)
SET IDENTITY_INSERT [dbo].[Clients] OFF
