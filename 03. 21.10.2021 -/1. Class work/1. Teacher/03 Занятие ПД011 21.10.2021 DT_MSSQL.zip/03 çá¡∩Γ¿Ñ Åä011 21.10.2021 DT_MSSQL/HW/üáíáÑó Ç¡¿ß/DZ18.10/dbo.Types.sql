﻿CREATE TABLE [dbo].[Table]
(
	[Id] INT NULL PRIMARY KEY IDENTITY, 
    [InsuranceName] NVARCHAR(50) NOT NULL, 
    [InsurancePrice] FLOAT NOT NULL, 
    CONSTRAINT [CK_Types_InsurancePrice] CHECK (InsurancePrice > 0)
)
