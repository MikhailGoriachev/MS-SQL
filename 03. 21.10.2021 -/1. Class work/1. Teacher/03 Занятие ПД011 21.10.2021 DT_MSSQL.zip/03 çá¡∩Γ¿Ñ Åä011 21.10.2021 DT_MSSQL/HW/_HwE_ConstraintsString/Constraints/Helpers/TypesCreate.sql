﻿CREATE TABLE [dbo].[Types] (
    [Id]    INT            IDENTITY (1, 1) NOT NULL,
    [Name]  NVARCHAR (150) NOT NULL,
    [Price] MONEY          NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [CK_Types_Price] CHECK ([Price]>(0))
);

