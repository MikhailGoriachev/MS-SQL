﻿-- перезапуск идентификаторов записей
-- выдавать после удаления всех записей

-- удаление всех записей из таблицы
delete from Clients;

-- dbcc checkident (имяТаблицы, reseed, начальноеЗначениеПК)
dbcc checkident ('Clients', reseed, 0);
go


delete from [Types];
dbcc checkident ([Types], reseed, 0);
go