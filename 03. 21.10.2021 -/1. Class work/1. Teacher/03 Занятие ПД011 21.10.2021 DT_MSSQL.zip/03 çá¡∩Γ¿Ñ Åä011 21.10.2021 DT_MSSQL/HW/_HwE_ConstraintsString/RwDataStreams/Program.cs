﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;

using RwDataStreams.Helpers;
using RwDataStreams.App;

/*
 * Задача 1.
 * В трех строках текстового файла data.txt (в папке исходного текста) через
 * пробел записаны три числа, например, так:
 * 3 5 3
 * 2 1 3
 * 1 3 5
 * Для каждого набора определите среднее число (т.е. число между минимальным
 * и максимальным из чисел) и выведите получившиеся четверки чисел в текстовый
 * файл с именем result.txt в папке исходного текста. Т.е. должно получиться
 * следующее:
 * 3 5 3		3
 * 2 1 3		2
 * 1 3 5 		3
 *
 * Задача 2.
 * В  текстовом  файле  найти  количество слов  в  тексте, у которых первый и
 * последний символы совпадают (выполнять поиск дважды – с учетом и без учета
 * регистра символов). Вывести текстовый файл, найденные слова в консоль.
 *
 */
namespace RwDataStreams
{
    class Program
    {
        static void Main(string[] args) {
            Console.Title = "Задание на 21.10.2021 - текстовые потоки данных в C#";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem {HotKey = ConsoleKey.Q, Text = "Задача 1. Обработка текстового файла целых чисел"},
                new MenuItem {HotKey = ConsoleKey.W, Text = "Задача 2. Регистронезависимая обработка текстового файла"},
                new MenuItem {HotKey = ConsoleKey.E, Text = "Задача 2. Регистрозависимая обработка текстового файла"},
                //----------------------------------------------------------------------------------------------
                new MenuItem {HotKey = ConsoleKey.Z, Text = "Выход"},
            };

            // Создание экземпляра класса приложения
            Application app = new Application();

            // главный цикл приложения
            while (true) {
                try {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  ООП C# - текстовые потоки данных, чтение и запись");
                    Utils.ShowMenu(12, 5, "Меню приложения для демонстрации работы с текстовыми файлами в C#", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg =
                        "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch (key) {

                        // Задача 1. Обработка текстового файла целых чисел
                        case ConsoleKey.Q:
                            app.SolveTask1();
                            break;

                        // Задача 2. Регистронезависимая обработка текстового файла
                        case ConsoleKey.W:
                            app.SolveTask2();
                            break;

                        // Задача 2. Регистрозависимая обработка текстового файла
                        case ConsoleKey.E:
                            app.SolveTask2(false);
                            break;

                        // Выход из приложения назначен на клавишу F10 или клавишу M или клавишу Escape
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor(); // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                } // try

                // обработка исключений - просто вывести сообщение
                catch (Exception ex) {
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                } // try-catch
            } // while
        } // Main
    }
}
