﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

using RwDataStreams.Helpers;

/*
 * Решение задач
 */
namespace RwDataStreams.App
{
    internal class Application
    {
        // имя файла исходных данных для задачи 1
        private string _fileNameTask1;

        // имя файла результатов для задачи 1
        private string _fileNameTask1Result;

        // имя файла для задачи 2
        private string _fileNameTask2;


        #region Конструкторы класса

        public Application():this("data.txt", "result.txt", "text.txt") { } // Application

        public Application(string fileNameTask1, string fileNameTask1Result, string fileNameTask2) {
            _fileNameTask1 = fileNameTask1;
            _fileNameTask1Result = fileNameTask1Result;
            _fileNameTask2 = fileNameTask2;
        } // Application

        #endregion


        #region задача 1

        // Задача 1. Обработка текстового файла целых чисел
        public void SolveTask1() {
            Utils.ShowNavBarTask("  Задача 1. Обработка текстового файла целых чисел");

            // прочитать файл и вывести его в консоль
            string[] text = File.ReadAllLines("..\\..\\" + _fileNameTask1, Encoding.UTF8);
            Console.WriteLine("\n\n\n\tФайл данных прочитан в коллекцию:");
            Array.ForEach(text, item => Console.WriteLine($"\t{item}"));
            
            // результьтаты обработки - массив строк для записи в файл результатов
            string[] result = new string[text.Length];

            // обработка прочитанных из файла данных
            for (int i = 0; i < text.Length; ++i) {
                int a, b, c;
                (a, b, c) = ParseInt(text[i]);

                // int mid = Mid(a, b, c);
                // result[i] = ($"{a} {b} {c}    {mid}");
                result[i] = ($"{a} {b} {c}    {Mid(a, b, c)}");
            } // foreach

            // вывести сформированные данные в файл
            File.WriteAllLines("..\\..\\" + _fileNameTask1Result, result);

            // вывести результат обработки в консоль
            Console.WriteLine("\n\n\tКоллекция обработана, выведена в файл:");
            Array.ForEach(result, item => Console.WriteLine($"\t{item}"));
        } // SolveTask1      


        // распарсить строку, содержащую три целых числа
        (int a, int b, int c) ParseInt(string line) {
            string[] tokens = line.Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
            return (int.Parse(tokens[0]), int.Parse(tokens[1]), int.Parse(tokens[2]));
        } // ParseInt


        // возвращает среднее значение из трех аргументов метода
        int Mid(int a, int b, int c) {
            int mid;

            if (b <= a && a <= c || b >= a && a >= c)
                mid = a;
            else if (a <= b && b <= c || a >= b && b >= c)
                mid = b;
            else
                mid = c;

            return mid;
        } // Mid
        #endregion


        #region задача 2

        // Задача 2. Регистронезависимая или регистрозависимая обработка текстового файла
        public void SolveTask2(bool ignoreCase = true) {
            string mode = ignoreCase ? "не" : "";
            Utils.ShowNavBarTask($"  Задача 2. Регистро{mode}зависимая обработка текстового файла");

            // прочитать файл в коллекцию строк, вывести коллекцию строк в консоль
            string[] text = File.ReadAllLines("..\\..\\" + _fileNameTask2, Encoding.UTF8);
            Console.WriteLine("\n\n\tТекст для обработки:");
            Array.ForEach(text, line => Console.WriteLine($"\t│ {line.PadRight(80)} │"));

            // обработка коллекции строк по заданию
            Dictionary<string, int> words = ProcessText(text, ignoreCase);

            // вывести найденные слова
            int y = 6;
            int count = 0;
            foreach (var word in words.Keys) {
                Utils.WriteXY(100, y++, $"{word, -18}: {words[word], 3}", ConsoleColor.Cyan);
                count += words[word];
            } // foreach
            Utils.WriteXY(100, y, $"Всего найдено слов: {count, 3}", ConsoleColor.White);
        } // SolveTask2 


        // возвращает коллекцию слов, начинающихся и заканчивающихся на одну
        // и ту же букву
        Dictionary<string, int> ProcessText(string[] text, bool ignoreCase) {
            Dictionary<string, int> words = new Dictionary<string, int>();

            // просматриваем текст по строкам
            foreach (var line in text) {
                // если указана регистронезависимость обработки, переводим
                // очередную строку в нижний регистр
                string line1 = ignoreCase?line.ToLower():line;
                
                // получить слова из строки текста
                string[] tokens = line1.Split(" .,!?:-\n\t".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                
                // просмотр слов/токенов из строки текста
                foreach (var t in tokens) {
                    // если первая и последняя буквы совпадают, сохранить слово в коллекции
                    if (t[0] == t[t.Length - 1]) {
                        if (words.ContainsKey(t))
                            words[t]++;
                        else
                            words[t] = 1;
                    } // if
                } // foreach t
                
            } // foreach line

            return words;
        } // ProcessText

        #endregion

    } // class Application
}
