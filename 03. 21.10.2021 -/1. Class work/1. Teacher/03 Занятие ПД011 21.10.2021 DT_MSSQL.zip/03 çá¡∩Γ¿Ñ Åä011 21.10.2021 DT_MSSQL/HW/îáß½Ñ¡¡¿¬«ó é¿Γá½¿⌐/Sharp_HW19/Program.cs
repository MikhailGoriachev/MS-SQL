﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sharp_HW19
{
	class Program
	{
		static void Main(string[] args)
		{
			Utilities.Palette.Ordinary.SetToConsole();

			App app = new App();
			app.Run();
		}
	}
}
