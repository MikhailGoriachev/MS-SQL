﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sharp_HW19
{
	internal partial class App
	{
		private Menu _mainMenu;
		private string inputFileName1 = "data1.txt";
		private string outputFileName1 = "result1.txt";
		private string inputFileName2 = "data2.txt";
		private string outputFileName2 = "result2.txt";

		public App() : this("data1.txt", "result1.txt", "data2.txt", "result2.txt")
		{}

		public App(string inputFileName1, string outputFileName1, string inputFileName2, string outputFileName2)
		{
			this.inputFileName1 = inputFileName1;
			this.outputFileName1 = outputFileName1;
			this.inputFileName2 = inputFileName2;
			this.outputFileName2 = outputFileName2;
			InitMenu();
		}
		
		// Создание объектов меню
		private void InitMenu()
		{
			// Главное меню
			_mainMenu = new Menu(new[]
				{
					new Menu.MenuItem("Задание 1", MainMenuItem1),
					new Menu.MenuItem("Задание 2", MainMenuItem2),
					new Menu.MenuItem("Выход")
				}, new Point(5, 5),
				"Меню приложения");
		}

		public void Run() => _mainMenu.Run();
	}
}
