﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Sharp_HW19
{
	internal partial class App
	{
		private void MainMenuItem1()
		{
			Utilities.ShowNavBar("    Задача 1");

			GenerateFileTask1();

			if (!File.Exists(inputFileName1))
			{
				Console.WriteLine("    Файл исходных данных не найден");
				return;
			}
			
			List<string> strings = new List<string>();

			using (StreamReader sr = new StreamReader(File.OpenRead(inputFileName1), Encoding.UTF8))
			{
				while (!sr.EndOfStream)
					strings.Add(sr.ReadLine());
			}

			Console.WriteLine($"    Файл прочитан. Данные:\n\n");
			strings.ForEach(str => Console.WriteLine($"    {str}"));
			
			// Обработка считанных данных по заданию для записи в файл
			for (int i = 0; i < strings.Count; i++)
				strings[i] = strings[i] +
				             $"     {(strings[i].Split().Select(int.Parse).ToArray().OrderBy(x => x).ToArray()[1])}";

			Console.WriteLine($"\n\n    Данные для записи в файл:\n\n");
			strings.ForEach(x => Console.WriteLine($"{Utilities.spaces}{x}"));

			File.WriteAllLines(outputFileName1, strings);

			Console.WriteLine($"\n\n    Файл {outputFileName1} записан.\n");
		}


		private void GenerateFileTask1()
		{
			File.WriteAllLines(inputFileName1, new []
			{
				$"{Utilities.GenerateInt(0,10)} {Utilities.GenerateInt(0,10)} {Utilities.GenerateInt(0,10)}",
				$"{Utilities.GenerateInt(0,10)} {Utilities.GenerateInt(0,10)} {Utilities.GenerateInt(0,10)}",
				$"{Utilities.GenerateInt(0,10)} {Utilities.GenerateInt(0,10)} {Utilities.GenerateInt(0,10)}",
				$"{Utilities.GenerateInt(0,10)} {Utilities.GenerateInt(0,10)} {Utilities.GenerateInt(0,10)}",
			});
		}
	}
}
