﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;

namespace Sharp_HW19
{
	internal partial class App
	{
		private void MainMenuItem2()
		{
			Utilities.ShowNavBar("    Задача 2");

			if (!File.Exists(inputFileName2))
				GenerateFileTask2();


			List<string> strings = new List<string>();

			using (StreamReader sr = new StreamReader(File.OpenRead(inputFileName2), Encoding.UTF8))
			{
				while (!sr.EndOfStream)
					strings.Add(sr.ReadLine());
			}

			List<string> words = new List<string>();
			

			strings.ForEach(str =>
			{
				words.AddRange(
					(str.Trim(' ').Split(' ','.',',','?','!',';').ToArray().Select(x => x)
						.Where(x => (x.Length > 1 && x[0] == x[x.Length - 1]))));
			});


			Console.Write($"    Файл обработан. Слова, у которых первый и последний символ совпадают :\n\n    ");
			
			words.ForEach(str => Console.Write($"{str}, "));

			Console.Write("\r\r\n\n    В тексте:\n\n    ");

			strings.ForEach(str => Console.Write($"    {str}\n"));
		}

		private void GenerateFileTask2()
		{
			string[] text = {
				"    Повседневная практика показывает, что постоянный количественный",
				"рост и сфера нашей активности способствует подготовки и реализации модели",
				"развития.",
				"	Разнообразный и богатый опыт постоянный количественный рост и сфера нашей",
				"активности позволяет выполнять важные задания по разработке модели",
				"развития.Значимость этих проблем настолько очевидна, что укрепление и",
				"развитие структуры позволяет оценить значение системы обучения кадров,",
				"соответствует насущным потребностям.Разнообразный и богатый опыт",
				"консультация с широким активом требуют определения и уточнения направлений",
				"прогрессивного развития.Таким образом постоянный количественный рост и",
				 "сфера нашей активности требуют определения и уточнения новых предложений."

			};
			File.WriteAllLines(inputFileName2, text);
		}
	}
}