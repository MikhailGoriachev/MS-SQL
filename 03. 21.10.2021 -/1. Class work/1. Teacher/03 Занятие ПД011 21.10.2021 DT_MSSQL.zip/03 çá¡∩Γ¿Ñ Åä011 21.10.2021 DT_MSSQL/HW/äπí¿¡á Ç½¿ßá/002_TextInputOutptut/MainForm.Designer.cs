﻿
namespace _002_TextInputOutptut
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.BtnIf17 = new System.Windows.Forms.Button();
            this.BtnIf15 = new System.Windows.Forms.Button();
            this.BtnQuit = new System.Windows.Forms.Button();
            this.GrbInputData = new System.Windows.Forms.GroupBox();
            this.GrbResult = new System.Windows.Forms.GroupBox();
            this.TxbFirstNumber = new System.Windows.Forms.TextBox();
            this.LblFirstNumber = new System.Windows.Forms.Label();
            this.LblSecondNumber = new System.Windows.Forms.Label();
            this.TxbSecondNumber = new System.Windows.Forms.TextBox();
            this.LblThirdNumber = new System.Windows.Forms.Label();
            this.TxbThirdNumber = new System.Windows.Forms.TextBox();
            this.LblResult = new System.Windows.Forms.Label();
            this.ErpFirstNumber = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErpSecondNumber = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErpThirdNumber = new System.Windows.Forms.ErrorProvider(this.components);
            this.GrbInputData.SuspendLayout();
            this.GrbResult.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ErpFirstNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpSecondNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpThirdNumber)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnIf17
            // 
            this.BtnIf17.BackColor = System.Drawing.Color.Linen;
            this.BtnIf17.Image = global::_002_TextInputOutptut.Properties.Resources._3300757;
            this.BtnIf17.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnIf17.Location = new System.Drawing.Point(302, 257);
            this.BtnIf17.Name = "BtnIf17";
            this.BtnIf17.Size = new System.Drawing.Size(274, 54);
            this.BtnIf17.TabIndex = 1;
            this.BtnIf17.Tag = "";
            this.BtnIf17.Text = "Удвоить числа или заменить на противоположные";
            this.BtnIf17.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnIf17.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnIf17.UseVisualStyleBackColor = false;
            this.BtnIf17.Click += new System.EventHandler(this.BtnIf17_Click);
            // 
            // BtnIf15
            // 
            this.BtnIf15.BackColor = System.Drawing.Color.Linen;
            this.BtnIf15.Image = global::_002_TextInputOutptut.Properties.Resources._3300757;
            this.BtnIf15.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnIf15.Location = new System.Drawing.Point(22, 257);
            this.BtnIf15.Name = "BtnIf15";
            this.BtnIf15.Size = new System.Drawing.Size(274, 54);
            this.BtnIf15.TabIndex = 0;
            this.BtnIf15.Text = "Сумма двух наибольших чисел";
            this.BtnIf15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnIf15.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnIf15.UseVisualStyleBackColor = false;
            this.BtnIf15.Click += new System.EventHandler(this.BtnIf15_Click);
            // 
            // BtnQuit
            // 
            this.BtnQuit.BackColor = System.Drawing.Color.Linen;
            this.BtnQuit.Image = global::_002_TextInputOutptut.Properties.Resources._3389170;
            this.BtnQuit.Location = new System.Drawing.Point(603, 257);
            this.BtnQuit.Name = "BtnQuit";
            this.BtnQuit.Size = new System.Drawing.Size(54, 54);
            this.BtnQuit.TabIndex = 2;
            this.BtnQuit.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnQuit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnQuit.UseVisualStyleBackColor = false;
            this.BtnQuit.Click += new System.EventHandler(this.BtnQuit_Click);
            // 
            // GrbInputData
            // 
            this.GrbInputData.BackColor = System.Drawing.Color.Linen;
            this.GrbInputData.Controls.Add(this.LblThirdNumber);
            this.GrbInputData.Controls.Add(this.TxbThirdNumber);
            this.GrbInputData.Controls.Add(this.LblSecondNumber);
            this.GrbInputData.Controls.Add(this.TxbSecondNumber);
            this.GrbInputData.Controls.Add(this.LblFirstNumber);
            this.GrbInputData.Controls.Add(this.TxbFirstNumber);
            this.GrbInputData.Location = new System.Drawing.Point(22, 26);
            this.GrbInputData.Name = "GrbInputData";
            this.GrbInputData.Size = new System.Drawing.Size(274, 210);
            this.GrbInputData.TabIndex = 3;
            this.GrbInputData.TabStop = false;
            this.GrbInputData.Text = " Исходные данные: ";
            // 
            // GrbResult
            // 
            this.GrbResult.BackColor = System.Drawing.Color.Linen;
            this.GrbResult.Controls.Add(this.LblResult);
            this.GrbResult.Location = new System.Drawing.Point(302, 26);
            this.GrbResult.Name = "GrbResult";
            this.GrbResult.Size = new System.Drawing.Size(355, 210);
            this.GrbResult.TabIndex = 4;
            this.GrbResult.TabStop = false;
            this.GrbResult.Text = " Результат: ";
            // 
            // TxbFirstNumber
            // 
            this.TxbFirstNumber.Location = new System.Drawing.Point(6, 47);
            this.TxbFirstNumber.Name = "TxbFirstNumber";
            this.TxbFirstNumber.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.TxbFirstNumber.Size = new System.Drawing.Size(240, 27);
            this.TxbFirstNumber.TabIndex = 0;
            this.TxbFirstNumber.Text = "0";
            this.TxbFirstNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TxbFirstNumber.TextChanged += new System.EventHandler(this.TxbFirstNumber_TextChanged);
            // 
            // LblFirstNumber
            // 
            this.LblFirstNumber.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblFirstNumber.Location = new System.Drawing.Point(5, 30);
            this.LblFirstNumber.Name = "LblFirstNumber";
            this.LblFirstNumber.Size = new System.Drawing.Size(125, 16);
            this.LblFirstNumber.TabIndex = 1;
            this.LblFirstNumber.Text = "Первое число:";
            // 
            // LblSecondNumber
            // 
            this.LblSecondNumber.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblSecondNumber.Location = new System.Drawing.Point(6, 88);
            this.LblSecondNumber.Name = "LblSecondNumber";
            this.LblSecondNumber.Size = new System.Drawing.Size(125, 16);
            this.LblSecondNumber.TabIndex = 3;
            this.LblSecondNumber.Text = "Второе число:";
            // 
            // TxbSecondNumber
            // 
            this.TxbSecondNumber.Location = new System.Drawing.Point(7, 105);
            this.TxbSecondNumber.Name = "TxbSecondNumber";
            this.TxbSecondNumber.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.TxbSecondNumber.Size = new System.Drawing.Size(240, 27);
            this.TxbSecondNumber.TabIndex = 2;
            this.TxbSecondNumber.Text = "0";
            this.TxbSecondNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TxbSecondNumber.TextChanged += new System.EventHandler(this.TxbSecondNumber_TextChanged);
            // 
            // LblThirdNumber
            // 
            this.LblThirdNumber.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblThirdNumber.Location = new System.Drawing.Point(6, 146);
            this.LblThirdNumber.Name = "LblThirdNumber";
            this.LblThirdNumber.Size = new System.Drawing.Size(125, 16);
            this.LblThirdNumber.TabIndex = 5;
            this.LblThirdNumber.Text = "Третье число:";
            // 
            // TxbThirdNumber
            // 
            this.TxbThirdNumber.Location = new System.Drawing.Point(7, 163);
            this.TxbThirdNumber.Name = "TxbThirdNumber";
            this.TxbThirdNumber.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.TxbThirdNumber.Size = new System.Drawing.Size(240, 27);
            this.TxbThirdNumber.TabIndex = 4;
            this.TxbThirdNumber.Text = "0";
            this.TxbThirdNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TxbThirdNumber.TextChanged += new System.EventHandler(this.TxbThirdNumber_TextChanged);
            // 
            // LblResult
            // 
            this.LblResult.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.LblResult.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblResult.Location = new System.Drawing.Point(0, 26);
            this.LblResult.Name = "LblResult";
            this.LblResult.Size = new System.Drawing.Size(354, 183);
            this.LblResult.TabIndex = 0;
            this.LblResult.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ErpFirstNumber
            // 
            this.ErpFirstNumber.ContainerControl = this;
            // 
            // ErpSecondNumber
            // 
            this.ErpSecondNumber.ContainerControl = this;
            // 
            // ErpThirdNumber
            // 
            this.ErpThirdNumber.ContainerControl = this;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Linen;
            this.ClientSize = new System.Drawing.Size(680, 338);
            this.Controls.Add(this.GrbResult);
            this.Controls.Add(this.GrbInputData);
            this.Controls.Add(this.BtnQuit);
            this.Controls.Add(this.BtnIf17);
            this.Controls.Add(this.BtnIf15);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.Text = "Задание на 20.10.2021";
            this.GrbInputData.ResumeLayout(false);
            this.GrbInputData.PerformLayout();
            this.GrbResult.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ErpFirstNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpSecondNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpThirdNumber)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnIf15;
        private System.Windows.Forms.Button BtnIf17;
        private System.Windows.Forms.Button BtnQuit;
        private System.Windows.Forms.GroupBox GrbInputData;
        private System.Windows.Forms.GroupBox GrbResult;
        private System.Windows.Forms.Label LblThirdNumber;
        private System.Windows.Forms.TextBox TxbThirdNumber;
        private System.Windows.Forms.Label LblSecondNumber;
        private System.Windows.Forms.TextBox TxbSecondNumber;
        private System.Windows.Forms.Label LblFirstNumber;
        private System.Windows.Forms.TextBox TxbFirstNumber;
        private System.Windows.Forms.Label LblResult;
        private System.Windows.Forms.ErrorProvider ErpFirstNumber;
        private System.Windows.Forms.ErrorProvider ErpSecondNumber;
        private System.Windows.Forms.ErrorProvider ErpThirdNumber;
    }
}

