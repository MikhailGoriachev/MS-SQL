﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Задание.Helpers;

namespace Задание.Models
{
    // Класс User, содержит следующие поля:
    //            числовой идентификатор - int;
    //            фамилия, имя - string;
    //            знак Зодиака - string;
    //            дата рождения - DateTime
    internal class User {
        private int _id;                // числовой идентификатор
        public int Id {
            get => _id;
            set => _id = value;
        } // Id

        private string _name;           // фамилия, имя 
        public string Name {
            get => _name;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("User. Некорректное значение фамилии и имени!"); _name = value; }
        } // Name

        private string _zodiacSign;      // знак Зодиака
        public string ZodiacSign {
            get => _zodiacSign;
            private set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("User. Некорректное значение знака Зодиака!"); _zodiacSign = value; }
        } // ZodiacSign

        private DateTime _dateOfBirth;     // дата рождения
        public DateTime DateOfBirth {
            get => _dateOfBirth;
            set { 
                if (value > DateTime.Now) throw new Exception("User. Некорректное значение даты рождения!");

                // определение знака зодиака
                string zSign;
                if (value >= new DateTime(value.Year, 3, 21) && value <= new DateTime(value.Year, 4, 20))
                    zSign = "Овен";
                else if (value >= new DateTime(value.Year, 4, 21) && value <= new DateTime(value.Year, 5, 21))
                    zSign = "Телец";
                else if (value >= new DateTime(value.Year, 5, 22) && value <= new DateTime(value.Year, 6, 21))
                    zSign = "Близнецы";
                else if (value >= new DateTime(value.Year, 6, 22) && value <= new DateTime(value.Year, 7, 22))
                    zSign = "Рак";
                else if (value >= new DateTime(value.Year, 7, 23) && value <= new DateTime(value.Year, 8, 21))
                    zSign = "Лев";
                else if (value >= new DateTime(value.Year, 8, 22) && value <= new DateTime(value.Year, 9, 23))
                    zSign = "Дева";
                else if (value >= new DateTime(value.Year, 9, 24) && value <= new DateTime(value.Year, 10, 23))
                    zSign = "Весы";
                else if (value >= new DateTime(value.Year, 10, 24) && value <= new DateTime(value.Year, 11, 23))
                    zSign = "Скорпион";
                else if (value >= new DateTime(value.Year, 11, 24) && value <= new DateTime(value.Year, 12, 22))
                    zSign = "Стрелец";
                else if (value >= new DateTime(value.Year, 12, 23) && value <= new DateTime(value.Year + 1, 1, 20))
                    zSign = "Козерог";
                else if (value >= new DateTime(value.Year - 1, 12, 23) && value <= new DateTime(value.Year, 1, 20))
                    zSign = "Козерог";
                else if (value >= new DateTime(value.Year, 1, 21) && value <= new DateTime(value.Year, 2, 19))
                    zSign = "Водолей";
                else zSign = "Рыбы";

                ZodiacSign = zSign;
                _dateOfBirth = value;
            } // set
        } // DateOfBirth

        // представление объекта в виде строки таблицы
        public string ToTableRow() =>
            $"│ {_id, 6} │ {_name, -22} │ {_zodiacSign, -12} │ {_dateOfBirth, 13:dd/MM/yyyy} │";

        // статическое свойство для вывода шапки таблицы
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌────────┬────────────────────────┬──────────────┬───────────────┐\n" +
                $"{spaces}│ Идент. │      Фамилия, имя      │ знак Зодиака │ дата рождения │\n" +
                $"{spaces}├────────┼────────────────────────┼──────────────┼───────────────┤\n";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└────────┴────────────────────────┴──────────────┴───────────────┘";

        // Фабричный метод для создания пользователя из случайных данных
        public static User Generate(int id) {
            // массив фамилий для создания персоны
            string[] names = new[] { "Семенов Иван", "Дунаев Николай", "Харламова Ольга", "Олегова Наталья", "Янковский Олег", "Абалкин Семён",
                                        "Романова Мария", "Воликов Геннадий", "Жукова Елена", "Соколов Станислав", "Лебедев Роман" };

            return new User {
                Id = id,
                Name = names[Utils.Random.Next(names.Length)],
                DateOfBirth = new DateTime(Utils.GetRand(1930, 2016), Utils.GetRand(1, 12), Utils.GetRand(1, 28))
            };
        } // Generate

        public override string ToString() =>
            $"[{Name}, {DateTime.Now.Year - DateOfBirth.Year} лет, {ZodiacSign}]";
        

    } // // User
}
