﻿using System;
using Задание.Models;
using Задание.Helpers;

namespace Задание.Application
{

    // Класс приложения - обработка по заданию
    // Данные для обработки и конструкторы
    internal partial class App {
        Department _department;


        // конструктор по умолчанию
        public App() : this(new Department()) { }


        // конструктор с внедрением зависимостей
        public App(Department department) {
            _department = department;
        } // App


        // Начальное формирование коллекции пользователей
        public void DepartmentInitialize() {
            Utils.ShowNavBarTask("    Начальное формирование коллекции пользователей");

            _department.Initialize();
            _department.Show("Данные сформированы: ", 12);
        } // DepartmentInitialize


        // Вывод коллекции пользователей
        public void DepartmentShow() {
            Utils.ShowNavBarTask("    Вывод коллекции пользователей");

            _department.Show("Коллекция пользователей: ", 12);
        } // DepartmentShow


        // Удаление всех пользователей старше 60 лет
        public void DemoRemoveAllOlderThan()
        {
            Utils.ShowNavBarTask("    Удаление всех пользователей старше 60 лет");

            _department.RemoveAllOlderThan(60);
            _department.Show("Пользователи удалены: ", 12);
        } // DemoRemoveAllOlderThan


        // Добавление трех пользователей со знаком Рыбы
        public void DemoAddUsers() {
            Utils.ShowNavBarTask("    Добавление трех пользователей со знаком Рыбы");

            int id = _department.UsersCount;
            _department.AddUser(new User { Name = "Харламова Оксана", Id = ++id, DateOfBirth = new DateTime(Utils.GetRand(1930, 2016), 3, Utils.GetRand(1, 21)) });
            _department.AddUser(new User { Name = "Янковский Иван", Id = ++id, DateOfBirth = new DateTime(Utils.GetRand(1930, 2016), 3, Utils.GetRand(1, 21)) });
            _department.AddUser(new User { Name = "Рожкова Елена", Id = ++id, DateOfBirth = new DateTime(Utils.GetRand(1930, 2016), 3, Utils.GetRand(1, 21)) });
            _department.Show("Пользователи добавлены: ", 12);
        } // DemoAddUsers


        // Заменить все записи знака Овен
        public void DemoReplaceUsers() {
            Utils.ShowNavBarTask("    Заменить все записи знака Овен");

            _department.ReplaceAllByZodiacSign("Овен");
            _department.Show("Пользователи заменены: ", 12);
        } // DemoReplaceUsers

        // Вывести список записей с заданным знаком Зодиака
        public void ShowByZodiacSign() {
            Utils.ShowNavBarTask("    Вывести список записей с заданным знаком Зодиака");


            string[] zodSigns = new[] { "Овен", "Телец",    "Близнецы", "Рак",     "Лев",     "Дева",
                                        "Весы", "Скорпион", "Стрелец",  "Козерог", "Водолей", "Рыбы" };

            string zodSign = zodSigns[Utils.GetRand(0, zodSigns.Length - 1)];
            _department.Show($"Заданный знак Зодиака: {zodSign}", 12, _department.GetByZodiacSign, zodSign);
        } // ShowByZodiacSign

        // Вывести список записей с заданной фамилией
        public void ShowSurname() {
            Utils.ShowNavBarTask("    Вывести список записей с заданной фамилией");

            string[] surnames = new[] { "Семенов",   "Воликов",  "Жукова",  "Янковский", "Абалкин",   "Романова",
                                        "Харламова", "Жеребцов", "Куликов", "Крутых",    "Петренко",  "Рожкова" };

            string surname = surnames[Utils.GetRand(0, surnames.Length - 1)];
            _department.Show($"Заданная фамилия: {surname}", 12, _department.GetBySurname, surname);
        } // ShowSurname

        // Вывести список записей с заданным месяцем рождения
        public void ShowByMonth(){
            Utils.ShowNavBarTask("    Вывести список записей с заданным месяцем рождения");

            int month = Utils.GetRand(1, 12);
            _department.Show($"Номер заданного месяца: {month}", 12, _department.GetByMonth, month);
        } // ShowByMonth


        // Cортировка по дате рождения
        public void DemoOrderByDateOfBirth(){
            Utils.ShowNavBarTask("    Cортировка по дате рождения");

            _department.OrderByDateOfBirth();
            _department.Show("Коллекция пользователей отсортирована по дате рождения: ", 12);
        } // DemoOrderByDateOfBirth


        // Cортировка по названиям знаков Зодиака
        public void DemoOrderByZodiacSign() {
            Utils.ShowNavBarTask("    Cортировка по названиям знаков Зодиака");

            _department.OrderByZodiacSign();
            _department.Show("Коллекция пользователей отсортирована по названиям знаков Зодиака: ", 12);
        } // DemoOrderByDateOfBirth


        // Cортировка по фамилии, имени
        public void DemoOrderByName()  {
            Utils.ShowNavBarTask("    Cортировка по фамилии, имени");

            _department.OrderByName();
            _department.Show("Коллекция пользователей отсортирована по фамилии, имени: ", 12);
        } // DemoOrderByName



    } // class App
}