﻿-- Прокат автомобилей

drop table if exists Rentals
drop table if exists Cars
drop table if exists Brands
drop table if exists Colors
drop table if exists Clients


--таблица клиентов
CREATE TABLE [dbo].[Clients]
(
	[Id]         INT          NOT NULL PRIMARY KEY identity(1,1),  
    [Surname]    NVARCHAR(60) NOT NULL,  -- фамилия
    [Name]       NVARCHAR(60) NOT NULL,  -- имя
    [Patronymic] NVARCHAR(60) NULL,      -- очество
    [Passport]   NVARCHAR(15)          NOT NULL   -- паспорт

);
go


-- таблица марок автомобилей 
CREATE TABLE [dbo].[Brands]
(
	[Id]    INT          NOT NULL PRIMARY KEY IDENTITY(1,1), 
    [Brand] NVARCHAR(50) NOT NULL   -- марка автомобиля
	
);
go 


-- таблица цветов 
CREATE TABLE [dbo].[Colors]
(
	[Id]    INT          NOT NULL PRIMARY KEY IDENTITY(1,1), 
    [Color] NVARCHAR(10) NOT NULL --цвет 
);
go

-- таблица машин
CREATE TABLE [dbo].[Cars]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY(1,1), 
    [IdBrand] INT NOT NULL,           -- ключ к марке автомобиля
    [IdColor] INT NOT NULL,           -- ключ к цвету автомобиля
    [Plate] NVARCHAR(15) NOT NULL,    -- номер автомобиля
    [YearOfManufacture] INT NOT NULL, -- год изготовляния 
    [InsurancePay] INT NOT NULL,      -- страховая стоимость автомобиля
    [Rental] INT NOT NULL,             -- стоимость одного дня проката

	CONSTRAINT FK_CARS_BRANDS FOREIGN KEY ([IdBrand]) references Brands(id),
	CONSTRAINT FK_CARS_COLORS FOREIGN kEY ([IdColor]) references Colors(id)

);
go
-- таблица данных об аренде машины  
CREATE TABLE [dbo].[Rentals] 
(
   [Id]              INT  NOT NULL PRIMARY KEY IDENTITY (1,1),
   [IdClient]        INT  NOT NULL, 
   [IdCar]           INT  NOT NULL, 
   [RentalStartDate] DATE NOT NULL,  -- дата начала проката 
   [DURATION]        INT  NOT NULL,  -- количество дней проката

   CONSTRAINT [CK_RENTAL_DURATION] CHECK       ([Duration] between 1 and 30),

   CONSTRAINT [FK_Rental_Clients]  FOREIGN KEY ([IdClient])    REFERENCES [Clients]([Id]), 
   CONSTRAINT [FK_Rental_Cars]     FOREIGN KEY ([IdCar])       REFERENCES [CARS]([Id])
);
go



