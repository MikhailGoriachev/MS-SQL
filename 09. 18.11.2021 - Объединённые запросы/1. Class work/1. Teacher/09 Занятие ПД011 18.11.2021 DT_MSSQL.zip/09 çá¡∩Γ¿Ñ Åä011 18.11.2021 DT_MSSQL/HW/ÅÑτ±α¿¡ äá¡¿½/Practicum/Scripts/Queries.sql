﻿--Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях заданной модели (например, ВАЗ-2110)
declare @carBrand nvarchar(15) = N'Audi'; 
select
  Cars.Id
  , Cars.IdBrand
  , Cars.IdColor
  , Cars.Plate
  , Cars.YearOfManufacture
  , Cars.InsurancePay
  , Cars.Rental
  from 
   Cars join Brands on Cars.IdBrand = Brands.Id
   where 
   Cars.IdBrand = @carBrand
-- Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях, изготовленных до заданного года (например, до 2016)
declare @year int = 2016
select 
  Cars.Id
  , Cars.IdBrand
  , Cars.IdColor
  , Cars.Plate
  , Cars.YearOfManufacture
  , Cars.InsurancePay
  , Cars.Rental
  from 
  Cars join Brands on Cars.YearOfManufacture = Brand.Id
  where 
     Cars.YearOfManufacture < 2016
-- Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях, имеющих заданные модель и цвет, изготовленных после заданного года
declare @brand nvarchar(15) = N'Audi', @color nvarchar(10) = N'red', @year nvarchar(5) = 2005
select 
  Cars.Id
  , Cars.IdBrand
  , Cars.IdColor
  , Cars.Plate
  , Cars.YearOfManufacture
  , Cars.InsurancePay
  , Cars.Rental
  from 
  Cars join Brands on Cars.IdBrand = Brands.Id and 
  Cars join Colors on Cars.IdColor = Color.Id
  where 
  Cars.IdBrand = @brand and Cars.IdColor = @color and Cars.YearOfManufacture = @year