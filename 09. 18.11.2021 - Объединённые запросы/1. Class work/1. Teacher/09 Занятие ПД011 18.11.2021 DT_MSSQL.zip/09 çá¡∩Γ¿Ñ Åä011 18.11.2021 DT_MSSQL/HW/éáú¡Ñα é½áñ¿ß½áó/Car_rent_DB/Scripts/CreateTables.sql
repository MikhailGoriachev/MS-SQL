﻿
-- Удаление всех таблиц
drop table if exists Rentals;
drop table if exists Cars;
drop table if exists Brands;
drop table if exists Colors;
drop table if exists Clients;



-- Таблица моделей авто
create table dbo.Brands
(
	Id          int not null primary key identity (1, 1), 
	Brand   nvarchar(100) not null,

);
go



-- Таблица клиентов
create table dbo.Clients (
	Id int not null primary key identity (1,1),
	Client_name nvarchar(60) not null,    -- Фамилия 
	Surname		nvarchar(50) not null,    -- Имя 
	Patronymic	nvarchar(60) not null,    -- Отчество 
	Passport nvarchar(60) not null,    -- Номер паспорта
	
);
go	

-- Цвета автомобилей
create table dbo.Colors (
	Id          int not null primary key identity (1, 1), 
	Color   nvarchar(20) not null,

);
go

-- Таблица автомобилей
create table dbo.Cars (
	Id          int not null primary key identity (1, 1), 
	IdBrand int not null,
	IdColor int not null,
	Plate nvarchar(10) not null,
	Prod_year int  not null,
	Insurance_pay int not null,
	Daily_price int not null

	-- Связи с другими таблицами
	constraint FK_Cars_Brands foreign key (IdBrand) references dbo.Brands (Id) ,
	constraint FK_Cars_Colors    foreign key (IdColor)    references dbo.Colors  (Id),

	--  Ограничения вводимых полей

	constraint CK_Cars_Prod_year  check (Prod_year > 2000),
	constraint CK_Cars_Insurance_pay  check (Insurance_pay > 0),
	constraint CK_Cars_Daily_price  check (Daily_price > 0)


);
go

-- Таблица прокатов
create table dbo.Rentals (
	Id          int not null primary key identity (1, 1), 
	IdClient int not null,
	IdCar int not null,
	DateStart Date not null,
	Duration int not null,

	
	--Связь с другими таблицами 
	constraint FK_Rentals_Clients foreign key (IdClient) references dbo.Clients (Id) ,
	constraint FK_Rentals_Car foreign key (IdCar) references dbo.Cars (Id) ,

	--Ограничения 
	constraint CK_Rentals_Duration check (Duration > 0 and Duration < 16),


);
go

/*create table dbo. (
	Id          int not null primary key identity (1, 1), 
);
go	

-- Связи с другими таблицами
	constraint FK_ _ foreign key (Id) references dbo. (Id) ,
	constraint FK_ _    foreign key (Id)    references dbo.  (Id)
*/