﻿-- 001 Выбирает из таблицы АВТОМОБИЛИ информацию об
--        автомобилях заданной модели 
declare @Model nvarchar(40) = N'Audi'
select 
	Brands.Brand as Brand
   ,Colors.Color
   ,Cars.Plate as License_plate
   ,Cars.Prod_year as Produced
   ,Cars.Insurance_pay
   ,Cars.Daily_price
from 
	Cars join Brands on Cars.IdBrand = Brands.Id
			join Colors on Cars.IdColor = Colors.Id
where 
	Brands.Brand like @Model
	go

-- 002 Выбирает из таблицы АВТОМОБИЛИ информацию об
--     автомобилях, изготовленных до заданного года
--     (например, до 2016)
declare @Year int = 2015
select 
    Cars.Prod_year as Produced
   ,Brands.Brand as Brand
   ,Colors.Color
   ,Cars.Plate as License_plate
   ,Cars.Insurance_pay
   ,Cars.Daily_price
from 
	Cars join Brands on IdBrand = Brands.Id
		 join Colors on Cars.IdColor = Colors.Id
where 
	Cars.Prod_year <= @Year;
go

-- 003 Выбирает из таблицы АВТОМОБИЛИ информацию об
--     автомобилях, имеющих заданные модель и цвет,
--     изготовленных после заданного года
declare @Year int = 2011, @Brand nvarchar(30)= N'Audi', @Color int = 1;
select 
    Cars.Prod_year as Produced
   ,Brands.Brand as Brand
   ,Colors.Color
   ,Cars.Plate as License_plate
   ,Cars.Insurance_pay
   ,Cars.Daily_price
from 
	Cars join Brands on Cars.IdBrand = Brands.Id
	     join Colors on Cars.IdColor = Colors.Id
where 
	Cars.Prod_year > @Year and Brands.Brand like @Brand and IdColor = @Color;
go

-- 004 Выбирает из таблицы АВТОМОБИЛИ информацию об
--     автомобиле с заданным госномером. N'MC871H'
declare @Plate nvarchar(15) = N'MC871H'
select 
    Cars.Prod_year as Produced
   ,Brands.Brand as Brand
   ,Colors.Color
   ,Cars.Plate as License_plate
   ,Cars.Insurance_pay
   ,Cars.Daily_price
from 
	Cars join Brands on Cars.IdBrand = Brands.Id
		join Colors on Cars.IdColor = Colors.Id
where 
	Cars.Plate like @Plate;
go

-- 005 Выбирает из таблиц Clients, Cars и
--     Rentals информацию обо всех зафиксированных фактах проката автомобилей (ФИО
--     клиента, Модель автомобиля, Госномер автомобиля,
--     дата проката) в некоторый заданный интервал
--     времени. Нижняя и верхняя границы интервала
--     задаются при выполнении запроса
declare @StartDate Date = '2021/02/21', @EndtDate Date = '2021/09/02'
select 
	Clients.Surname + N'.' + SUBSTRING(Clients.Client_name,1,1) + N'.' + SUBSTRING(Clients.Patronymic,1,1) as Client
	,Brands.Brand
	,Cars.Plate
	,Rentals.DateStart
from 
	Rentals join Clients on Rentals.IdClient = Clients.Id
			join (Cars join Brands on Cars.IdBrand = Brands.Id 
					   join Colors on Cars.IdColor = Colors.Id) 
		    on Rentals.IdCar = Cars.Id
where
	Rentals.DateStart >= @StartDate and Rentals.DateStart <= @EndtDate
go


-- 006 Вычисляет для каждого факта проката стоимость проката. 
--      Включает поля Дата проката, Госномер
--      автомобиля, Модель автомобиля, Стоимость
--      проката. Сортировка по полю Дата проката
select 
	 Rentals.DateStart as [Date]
	,Brands.Brand
	,Cars.Plate
	,Cars.Daily_price*Rentals.Duration as Price
from 
		Rentals join Clients on Rentals.IdClient = Clients.Id
			join (Cars join Brands on Cars.IdBrand = Brands.Id 
					   join Colors on Cars.IdColor = Colors.Id) 
		    on Rentals.IdCar = Cars.Id
order by 
	Rentals.DateStart
go

-- 007 Запрос с левым соединением
--     Для всех автомобилей прокатной фирмы вычисляет
--     количество фактов проката, сумму за прокаты
-- Попытка применения подзапросов
Select 
	Brands.Brand
	,Cars.Plate
    ,(Select COUNT(SubCars.id) from Cars as SubCars  where SubCars.Id = Rentals.IdCar) as CountRentals
	,(Select SubCar_2.Daily_price from Cars as SubCar_2  where SubCar_2.Id = Rentals.IdCar)*Rentals.Duration as GenralPrice 
from 
	Rentals join (Cars join Brands on Cars.IdBrand = Brands.Id) on Rentals.IdCar = Cars.Id
go

-- Левое соеденение
Select
	(Select Brands.Brand from Brands where Brands.Id = Cars.IdBrand) as Brands -- Не понял как и почему это работает, если у нас группировка только по Cars.Idband
	
	,Count(Rentals.IdCar) as CountRentals
	,ISNULL(SUM(Cars.Daily_price*Rentals.Duration),0) as Price
	--,Cars.Daily_price*Rentals.Duration as Price
from 
	(Cars join Brands on Cars.IdBrand = Brands.Id) left join Rentals on Rentals.IdCar = Cars.Id
group by 
Cars.IdBrand
go

-- 008 Выполняет группировку по полю Год выпуска
--      Для каждого года вычисляет
--      минимальное и максимальное значения по
--      полю Стоимость одного дня проката
Select 
Cars.Prod_year
 ,MIN(Cars.Daily_price) as MinDailyPrice
 ,Max(Cars.Daily_price) as MaxDailyPrice
 ,COUNT(Cars.Id) as CarsAmount
from 
	Cars
group by
Cars.Prod_year
go


-- 009 Добавляет в таблицу ФАКТЫ_ПРОКАТА данные о
--     факте проката 

--Вывод до
select 
	 Rentals.DateStart as [Date]
	 ,Clients.Surname + SUBSTRING(Clients.Client_name,1,1) + N'.' + SUBSTRING(Clients.Patronymic,1,1) as Client
	 ,Clients.Passport 
	,Brands.Brand
	,Cars.Plate
	,Cars.Daily_price*Rentals.Duration as Price
from 
		Rentals join Clients on Rentals.IdClient = Clients.Id
			join (Cars join Brands on Cars.IdBrand = Brands.Id 
					   join Colors on Cars.IdColor = Colors.Id) 
		    on Rentals.IdCar = Cars.Id
go

-- Удаление прежде добаленных значений (В частном случае работает правильно)
declare @Date_1 Date = '2021/11/05',@Date_2 Date = '2021/10/13';

delete from 
 Rentals
where 
	DateStart = @Date_1 or DateStart = @Date_2;


Insert Rentals
	(IdClient,IdCar,DateStart,Duration )
values
	(15,9 ,'2021/11/05',13 ),
	(11,2 ,'2021/10/13',11 );
go

--Вывод после добавления
select 
	 Rentals.DateStart as [Date]
	,Clients.Surname + N' ' +  SUBSTRING(Clients.Client_name,1,1) + N'.' + SUBSTRING(Clients.Patronymic,1,1) as Client
	,Clients.Passport 
	,Brands.Brand
	,Cars.Plate
	,Cars.Daily_price*Rentals.Duration as Price
from 
		Rentals join Clients on Rentals.IdClient = Clients.Id
			join (Cars join Brands on Cars.IdBrand = Brands.Id 
					   join Colors on Cars.IdColor = Colors.Id) 
		    on Rentals.IdCar = Cars.Id
go

--Вывод при помощи подзапроса
select
	Rentals.DateStart
	,(Select Clients.Surname + N' ' +  SUBSTRING(Clients.Client_name,1,1) + N'.' + SUBSTRING(Clients.Patronymic,1,1) 
	     from Clients 
		 where Clients.Id = Rentals.IdClient) as Client -- Id клиента в таблице клиентов равен текущему Id клиента в Rentals
	,(Select Clients.Passport from Clients where Clients.Id = Rentals.IdClient) as Passport

	,(Select Brands.Brand 
		from Cars join Brands on Cars.IdBrand = Brands.Id 
		where Cars.Id = Rentals.IdCar) as Brand -- Из общего агрегата в подзапросе достаём модель авто

	,(Select Cars.Plate from Cars where Cars.Id = Rentals.IdCar) as License_Plate

	,(Select Cars.Daily_price from Cars where Cars.Id = Rentals.IdCar) as Price

from 
   Rentals

-- 010 Добавляет в таблицу АВТОМОБИЛИ данные о новом
--     автомобиле в прокатной фирме


--Предварительное удаление
declare @Plate_1 nvarchar(10) = N'PC434H',@Plate_2 nvarchar(10) = N'CK368P',@Plate_3 nvarchar(10) = N'KH221B';

delete from 
 Cars
where 
	Cars.Plate = @Plate_1 or Cars.Plate = @Plate_2 or Cars.Plate = @Plate_3

--Вывод до
Select 
	(Select Brands.Brand from Brands where Brands.Id = Cars.IdBrand) as Brand
	,(Select Colors.Color from Colors where Colors.Id = Cars.IdColor) as Color 
	,Cars.Plate 
	,Cars.Prod_year 
	,Cars.Insurance_pay as Car_cost
	,Cars.Daily_price as Rental_cost
from 
	Cars

-- Добавление значений 
Insert Cars
(IdBrand,IdColor,Plate,Prod_year,Insurance_pay,Daily_price)
values
    (4 , 2 ,@Plate_1,2019,70000 ,98),
    (15 ,3 ,N'CK368P',2016,31000 ,60),
    (11 ,1 ,N'KH221B',2017,20000 ,75);
	go

-- Вывод после добавления
Select 
 Brands.Brand
 ,Colors.Color
 ,Cars.Plate
 ,Cars.Prod_year as Produced
 ,Cars.Insurance_pay as Car_cost
 ,Cars.Daily_price as Rental_price
from
	Cars join Brands on Cars.IdBrand = Brands.Id
		join Colors on Cars.IdColor = Colors.Id

-- 011 Удаляет из таблицы ФАКТЫ_ПРОКАТА запись по
--     идентификатору

--Вывод до удаления
select 
	 Rentals.Id as N
	 ,Rentals.DateStart as [Date]
	,Clients.Surname + N' ' +  SUBSTRING(Clients.Client_name,1,1) + N'.' + SUBSTRING(Clients.Patronymic,1,1) as Client
	,Clients.Passport 
	,Brands.Brand
	,Cars.Plate
	,Cars.Daily_price*Rentals.Duration as Price
from 
		Rentals join Clients on Rentals.IdClient = Clients.Id
			join (Cars join Brands on Cars.IdBrand = Brands.Id 
					   join Colors on Cars.IdColor = Colors.Id) 
		    on Rentals.IdCar = Cars.Id
go

 declare @DelId int = 4
 delete from 
 Rentals
 where 
	Rentals.Id = 4

--Вывод после удаления
select 
	 Rentals.Id as N
	,Rentals.DateStart as [Date]
	,Clients.Surname + N' ' +  SUBSTRING(Clients.Client_name,1,1) + N'.' + SUBSTRING(Clients.Patronymic,1,1) as Client
	,Clients.Passport 
	,Brands.Brand
	,Cars.Plate
	,Cars.Daily_price*Rentals.Duration as Price
from 
		Rentals join Clients on Rentals.IdClient = Clients.Id
			join (Cars join Brands on Cars.IdBrand = Brands.Id 
					   join Colors on Cars.IdColor = Colors.Id) 
		    on Rentals.IdCar = Cars.Id
go

-- 012 Удаляет из таблицы ФАКТЫ_ПРОКАТА записи за
--     указанный период для заданного клиента
--Вывод до удаления
select 
	 Rentals.Id as N
	 ,Rentals.DateStart as [Date]
	,Clients.Surname + N' ' +  SUBSTRING(Clients.Client_name,1,1) + N'.' + SUBSTRING(Clients.Patronymic,1,1) as Client
	,Clients.Passport 
	,Brands.Brand
	,Cars.Plate
	,Cars.Daily_price*Rentals.Duration as Price
from 
		Rentals join Clients on Rentals.IdClient = Clients.Id
			join (Cars join Brands on Cars.IdBrand = Brands.Id 
					   join Colors on Cars.IdColor = Colors.Id) 
		    on Rentals.IdCar = Cars.Id
go

 declare @DatLow int = 2,@DatHi int = 5; 
 delete from 
 Rentals
 where 
	Month(Rentals.DateStart) between @DatLow and @DatHi

--Вывод после удаления
select 
	 Rentals.Id as N
	,Rentals.DateStart as [Date]
	,Clients.Surname + N' ' +  SUBSTRING(Clients.Client_name,1,1) + N'.' + SUBSTRING(Clients.Patronymic,1,1) as Client
	,Clients.Passport 
	,Brands.Brand
	,Cars.Plate
	,Cars.Daily_price*Rentals.Duration as Price
from 
		Rentals join Clients on Rentals.IdClient = Clients.Id
			join (Cars join Brands on Cars.IdBrand = Brands.Id 
					   join Colors on Cars.IdColor = Colors.Id) 
		    on Rentals.IdCar = Cars.Id
go

-- 013 Увеличивает значение в поле Стоимость одного дня
--     проката на заданное количество процентов для
--     автомобилей, изготовленных после заданного года

-- Вывод до изменения
Select 
 Brands.Brand
 ,Cars.Plate
 ,Cars.Prod_year as Produced
 ,Cars.Daily_price as Rental_price
from
	Cars join Brands on Cars.IdBrand = Brands.Id
		join Colors on Cars.IdColor = Colors.Id

-- изменение 
declare @Year int = 2014, @Percentage float = 0.12

update 
	Cars
set
    Daily_price += Daily_price*@Percentage
where
	Cars.Id = some (Select SubCars.Id from Cars as SubCars where SubCars.Prod_year > @Year) -- Любое вхождение. Хотя бы 1 значение дожно соответствовать Cars.Id

-- Вывод после изменения
Select 
 Brands.Brand
 ,Cars.Plate
 ,Cars.Prod_year as Produced
 ,Cars.Daily_price as Rental_price
from
	Cars join Brands on Cars.IdBrand = Brands.Id
		join Colors on Cars.IdColor = Colors.Id
order by 
	Cars.Prod_year desc

-- 014 Изменяет данные клиента по его идентификатору на
--     указанные в параметрах запроса значение
-- Вывод до 
Select
	Clients.Id as N
	,Clients.Surname + N' ' +  SUBSTRING(Clients.Client_name,1,1) + N'.' + SUBSTRING(Clients.Patronymic,1,1) as Full_name
	,Clients.Passport 
from 
	Clients

-- изменение 
declare @ChosenId int = 4, 
		@Client_name nvarchar(60) =N'Дмитрий',
		@Surname nvarchar(50) =  N'Румянцев ',
		@Patronymic	nvarchar(60) = N'Николавевич',
		@Passport nvarchar(25) = N'BE15321';
						  
update 					  
	Clients
set
     Clients.Client_name = @Client_name
	,Clients.Surname = @Surname
	,Clients.Patronymic = @Patronymic
	,Clients.Passport = @Passport
where
	Clients.Id = @ChosenId


-- Вывод после
Select
	Clients.Id as N
	,Clients.Surname + N' ' +  SUBSTRING(Clients.Client_name,1,1) + N'.' + SUBSTRING(Clients.Patronymic,1,1) as Full_name
	,Clients.Passport 
from 
	Clients