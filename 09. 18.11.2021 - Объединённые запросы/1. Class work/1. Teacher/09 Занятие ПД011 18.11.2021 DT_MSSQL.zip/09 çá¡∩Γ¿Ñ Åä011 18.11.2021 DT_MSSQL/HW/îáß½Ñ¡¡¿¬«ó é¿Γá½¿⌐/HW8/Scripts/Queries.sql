﻿
-- таблица цветов
select 
	*
from
	Colors;
go

-- таблица брендов\моделей
select
	*
from
	BrandModels
go

-- таблица клиентов
select
	*
from
	Clients
go

-- таблица автомобилей с расшифровкой
select
	Cars.Id
	, BrandModels.BrandModel
	, Colors.Color
	, Cars.YearMade
	, Cars.RegNumber
	, Cars.InsuranceCost
	, Cars.DayCost
from 
	Cars join BrandModels on Cars.IdBrandModel = BrandModels.Id
		 join Colors	  on Cars.IdColor	   = Colors.Id;
go

-- таблица фактов проката с расшифровкой
select
	RentalFacts.Id
	--
	, BrandModels.BrandModel
	, Colors.Color
	, Cars.YearMade
	, Cars.RegNumber
	, Cars.InsuranceCost
	, Cars.DayCost
	--
	, Clients.Surname
	, Clients.Name
	, Clients.Patronymic
	, Clients.Passport
	--
	, RentalFacts.BeginDate
	, RentalFacts.RentDays	
from
	RentalFacts join (Cars join BrandModels on Cars.IdBrandModel = BrandModels.Id
						   join Colors	    on Cars.IdColor	     = Colors.Id) on RentalFacts.IdCar = Cars.Id
				join Clients on RentalFacts.IdClient = Clients.Id
order by BeginDate;
go


-- Запросы по заданию

--1	Запрос с параметром
--  Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях 
--  заданной модели (например, ВАЗ-2110)
declare @model nvarchar(30) = N'Honda Accord';

select
	Cars.Id
	, BrandModels.BrandModel
	, Colors.Color
	, Cars.YearMade
	, Cars.RegNumber
	, Cars.InsuranceCost
	, Cars.DayCost
from 
	Cars join BrandModels on Cars.IdBrandModel = BrandModels.Id
						   join Colors	    on Cars.IdColor	     = Colors.Id
where BrandModel = @model;
go

--2	Запрос с параметром
--  Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях,
--  изготовленных до заданного года (например, до 2016)
declare @YOM int = 2016;

select
	Cars.Id
	, BrandModels.BrandModel
	, Colors.Color
	, Cars.YearMade
	, Cars.RegNumber
	, Cars.InsuranceCost
	, Cars.DayCost
from 
	Cars join BrandModels on Cars.IdBrandModel = BrandModels.Id
						   join Colors	    on Cars.IdColor	     = Colors.Id
where YearMade < @YOM;
go


--3	Запрос с параметром
--  Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях,
--  имеющих заданные модель и цвет,
--  изготовленных после заданного года
declare @brandModel nvarchar(30) = N'Honda Accord',
		@color nvarchar(20) = N'Red',
		@year int = 2017;

select
	Cars.Id
	, BrandModels.BrandModel
	, Colors.Color
	, Cars.YearMade
	, Cars.RegNumber
	, Cars.InsuranceCost
	, Cars.DayCost
from 
	Cars join BrandModels on Cars.IdBrandModel = BrandModels.Id
						   join Colors	    on Cars.IdColor	     = Colors.Id
where BrandModel = @brandModel and Color = @color and YearMade > @year;
go


--4	Запрос с параметром	
--  Выбирает из таблицы АВТОМОБИЛИ информацию об автомобиле с заданным госномером.
declare @regNum nvarchar(6) = N'С441УЕ';

select
	Cars.Id
	, BrandModels.BrandModel
	, Colors.Color
	, Cars.YearMade
	, Cars.RegNumber
	, Cars.InsuranceCost
	, Cars.DayCost
from 
	Cars join BrandModels on Cars.IdBrandModel = BrandModels.Id
						   join Colors	    on Cars.IdColor	     = Colors.Id
where RegNumber = @regNum;
go


--5	Запрос с параметром	
--  Выбирает из таблиц КЛИЕНТЫ, АВТОМОБИЛИ и ФАКТЫ_ПРОКАТА информацию обо всех 
--  зафиксированных фактах проката автомобилей (ФИО клиента, Модель автомобиля,
--  Госномер автомобиля, дата проката) в некоторый заданный интервал времени.
--  Нижняя и верхняя границы интервала задаются при выполнении запроса
declare @from date = '2021-01-01', @to date = '2021-06-01';

select
	RentalFacts.Id
	, Clients.Surname
	, Clients.Name
	, Clients.Patronymic
	, BrandModels.BrandModel
	, Cars.RegNumber
	, RentalFacts.BeginDate	
from
	RentalFacts join (Cars join BrandModels on Cars.IdBrandModel = BrandModels.Id
						   join Colors	    on Cars.IdColor	     = Colors.Id) on RentalFacts.IdCar = Cars.Id
				join Clients on RentalFacts.IdClient = Clients.Id
where BeginDate between @from and @to;
go



--6	Запрос с вычисляемыми полями	
--  Вычисляет для каждого факта проката стоимость проката. 
--  Включает поля Дата проката, Госномер автомобиля, Модель автомобиля,
--  Стоимость проката. Сортировка по полю Дата проката

select 
	RentalFacts.BeginDate	
	, Cars.RegNumber
	, BrandModels.BrandModel
	,(Cars.DayCost * RentalFacts.RentDays) as RentPrice
from
	RentalFacts join (Cars join BrandModels on Cars.IdBrandModel = BrandModels.Id
						   join Colors	    on Cars.IdColor	     = Colors.Id) on RentalFacts.IdCar = Cars.Id
				join Clients on RentalFacts.IdClient = Clients.Id
order by RentPrice;
go

--7	Запрос с левым соединением
--  Для всех автомобилей прокатной фирмы вычисляет количество фактов проката,
--  сумму вырученную за прокаты
select
	Cars.RegNumber
	, BrandModels.BrandModel
	, Count(RentalFacts.Id)
	, Sum(Cars.DayCost * RentalFacts.RentDays) as TotalSum
from
	(Cars join BrandModels on Cars.IdBrandModel = BrandModels.Id
		  join Colors	    on Cars.IdColor	     = Colors.Id) 
	 left join RentalFacts on Cars.Id = RentalFacts.IdCar
group by RegNumber, BrandModel
order by TotalSum desc;
go

--8	Итоговый запрос
--  Выполняет группировку по полю Год выпуска автомобиля.
--  Для каждого года вычисляет минимальное и максимальное значения по полю Стоимость одного дня проката
select
	Cars.YearMade
	, Min(Cars.DayCost) as MinDayCost
	, Max(Cars.DayCost) as MinDayCost
from Cars
group by YearMade;
go

	
--9	Запрос на добавление
--  Добавляет в таблицу ФАКТЫ_ПРОКАТА данные о факте проката.
--  Данные передавайте параметрами, используйте подзапросы
declare @carRegNum nvarchar(6) = N'Е155РХ',
		@clientPassport nvarchar(15) = N'9321044681',
		@date date = '2021-11-17',
		@days int = 7;

insert RentalFacts
	(IdCar, IdClient, BeginDate, RentDays)
values
	(
		(select Id from Cars where RegNumber = @carRegNum),
		(select Id from Clients where Passport = @clientPassport),
		@date,
		@days
	);
go

--10	Запрос на добавление
--  Добавляет в таблицу АВТОМОБИЛИ данные о новом автомобиле в прокатной фирме.
--  Данные автомобиля задавайте параметрами, используйте подзапросы.
declare @model nvarchar(30) = N'Hyundai Tucson',
		@color nvarchar(20) = N'Yellow',
		@year int = 2020,
		@regnum nvarchar(6) = N'A550BT',
		@insCost int = 570000,
		@dayCost int = 2000;

insert Cars
	(IdBrandModel, IdColor, YearMade, RegNumber, InsuranceCost, DayCost)
values
	(
		(select Id from BrandModels where BrandModel = @model),
		(select Id from Colors where Color = @color),
		@year, @regnum, @insCost, @dayCost
	);
go
		
--11	Запрос на удаление
--  Удаляет из таблицы ФАКТЫ_ПРОКАТА запись по идентификатору, заданному параметром запроса
declare @id int = 13

select *
from RentalFacts;

delete from
	RentalFacts
where 
	RentalFacts.Id = @id;

select *
from RentalFacts;

go


--12	Запрос на удаление
--  Удаляет из таблицы ФАКТЫ_ПРОКАТА записи за указанный период для заданного клиента.
declare @from date = '2021-01-01', @to date = '2021-05-01';

select *
from RentalFacts;

delete from	
	RentalFacts
where 
	BeginDate between @from and @to;

select *
from RentalFacts;
go

--13	Запрос на обновление
--  Увеличивает значение в поле Стоимость одного дня проката на заданное
--  количество процентов для автомобилей, изготовленных после заданного года
declare @year int = 2017, @percent float = 10;

select
	Cars.Id
	, BrandModels.BrandModel
	, Cars.YearMade
	, Cars.RegNumber
	, Cars.InsuranceCost
	, Cars.DayCost
from 
	Cars join BrandModels on Cars.IdBrandModel = BrandModels.Id;

update 
	Cars
set
	DayCost += DayCost * @percent / 100
where 
	YearMade > @year;


select
	Cars.Id
	, BrandModels.BrandModel
	, Cars.YearMade
	, Cars.RegNumber
	, Cars.InsuranceCost
	, Cars.DayCost
from 
	Cars join BrandModels on Cars.IdBrandModel = BrandModels.Id;

go


--14	Запрос на обновление
--  Изменяет данные клиента по его идентификатору на указанные в параметрах запроса значение
declare @id int = 1,
	@surname nvarchar(60) = N'Иванов',
	@name nvarchar(50) = N'Иван',
	@patronymic nvarchar(60) = N'Иванович';

select
	*
from
	Clients


update 
	Clients
set
	Surname = @surname ,
	Name = @name,
	Patronymic = @patronymic
where Id = @id;


select
	*
from
	Clients

go