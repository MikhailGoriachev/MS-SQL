﻿--База данных «Прокат автомобилей»

--Описание предметной области
--Фирма выдает напрокат автомобили. При этом фиксируется информация о клиенте, информация об автомобиле,
--дата начала проката и количество дней проката. 
--Стоимость одного дня проката является фиксированной для
--каждого автомобиля. В случае аварии клиент выплачивает фирме возмещение в размере, равном некоторому 
--проценту от страховой стоимости автомобиля.
--Стоимость проката автомобиля определяется как 
--Стоимость одного дня проката * Количество дней проката. 
--Фирма ежегодно страхует автомобили, выдаваемые клиентам. 
--Страховой взнос, выплачиваемый фирмой, равен 10% от страховой стоимости автомобиля.


drop table if exists RentalFacts;
drop table if exists Cars;
drop table if exists Clients;
drop table if exists Colors;
drop table if exists BrandModels;

-- Таблица цветов автомобилей
create table dbo.Colors
(
	Id          int          not null primary key identity (1, 1),
	Color		nvarchar(20) not null,  -- название цвета
);
go

-- Таблица бренд/модель автомобилей
create table dbo.BrandModels
(
	Id          int          not null primary key identity (1, 1),
	BrandModel  nvarchar(30) not null -- бренд и модель
);
go

-- Таблица информации об автомобилях
create table dbo.Cars
(
	Id				int			not null primary key identity (1, 1),
	IdBrandModel	int			not null, -- бренд и модель, внешний ключ
	IdColor			int			not null, -- цвет авто, внешний ключ
	YearMade		int			not null, -- год выпуска
	RegNumber		nvarchar(6) not null, -- гос.номер авто
	InsuranceCost	int			not null, -- страховая стоимость авто
	DayCost			int			not null, -- стоимость аренды авто за день

	constraint CK_Cars_InsuranceCost check (InsuranceCost > 0),
	constraint CK_Cars_DayCost check (DayCost > 0),

	constraint FK_Cars_BrandModels foreign key (IdBrandModel) references dbo.BrandModels(Id),
	constraint FK_Cars_Colors foreign key (IdColor) references dbo.Colors(Id),
);
go

-- Таблица записей о клиентах (ФИО не выносил в отдельную таблицу т.к. кроме клиентов в БД схожих полей нет)
create table dbo.Clients
(
	Id				int			not null primary key identity (1, 1),
	Surname     nvarchar(60) not null,    -- Фамилия клиента
	[Name]      nvarchar(50) not null,    -- Имя клиента
	Patronymic  nvarchar(60) not null,    -- Отчество клиента
	Passport	nvarchar(15) not null,	  -- Серия и номер паспорта клиента
);
go

-- Таблица фактов аренды
create table dbo.RentalFacts
(
	Id				int		not null primary key identity (1, 1),
	IdCar			int		not null, -- id автомобиля, внешний ключ
	IdClient		int		not null, -- id клиента, внешний ключ
	BeginDate		date	not null, -- дата начала аренды
	RentDays		int		not null  -- количество дней аренды

	constraint CK_RentalFacts_RentDays check (RentDays > 0),

	constraint FK_RentalFacts_Cars foreign key (IdCar) references dbo.Cars(Id),
	constraint FK_RentalFacts_Clients foreign key (IdClient) references dbo.Clients(Id),
);
go