﻿-- Создание таблиц базы данных

drop table if exists Rentals;
drop table if exists Cars;
drop table if exists Clients;
drop table if exists Brands;
drop table if exists Colors;
go


-- Таблица КЛИЕНТЫ (Clients)
create table dbo.Clients (
	Id          int          not null primary key identity (1, 1),
	Surname     nvarchar(60) not null,    -- Фамилия 
	[Name]      nvarchar(50) not null,    -- Имя 
	Patronymic  nvarchar(60) not null,    -- Отчество 
    Passport    nvarchar(15) not null     -- Серия-номер паспорта 
);
go


-- Таблица моделей автомобилей 
create table dbo.Brands (
	Id          int          not null primary key identity (1, 1),
	Brand       nvarchar(20) not null,    -- Модель  
);
go

-- Таблица цветов автомобилей 
create table dbo.Colors (
	Id          int          not null primary key identity (1, 1),
	Color       nvarchar(20) not null,    -- Цвет
);
go

-- Таблица АВТОМОБИЛИ (Cars)
create table dbo.Cars(
	Id           int          not null primary key identity (1, 1),
	IdBrand      int          not null,  -- Модель автомобиля 
	IdColor      int          not null,	 -- Цвет автомобиля 
	Plate        nvarchar(9)  not null,	 -- Госномер автомобиля 
	YearManuf    int          not null,	 -- Год выпуска автомобиля 
	InsurancePay int          not null,	 -- Страховая стоимость автомобиля
	Rental       int          not null,	 -- Стоимость одного дня проката

	constraint CK_Cars_YearManuf check (YearManuf > 2005),
	constraint CK_Cars_InsurancePay check (InsurancePay > 0),
	constraint CK_Cars_Rental check (Rental > 0),

	constraint FK_Cars_Brands foreign key (IdBrand) references dbo.Brands(Id),
	constraint FK_Cars_Colors foreign key (IdColor) references dbo.Colors(Id),
);
go


-- Таблица ФАКТЫ_ПРОКАТА (Rentals)
create table dbo.Rentals(
	Id           int          not null primary key identity (1, 1),
	IdClient     int          not null,
	IdCar        int          not null,
	DateStart    date         not null,
	Duration     int          not null,

	constraint CK_Rentals_Duration check (Duration > 0 and Duration <= 15),
);