﻿-- База данных «Прокат автомобилей»

-- вывод всех таблиц с рашифровкой полей связанных таблиц
select
    *
from
    Clients;
go


select
   *
from
   Colors;
go


select
    *
from
    Brands;
go

-- автомобили с расшифровкой
select
    Cars.Id
    , Brands.Brand
    , Colors.Color
    , Cars.Plate
    , Cars.YearManuf
    , Cars.InsurancePay
    , Cars.Rental
from
    Cars join Colors on Cars.IdColor = Colors.Id
         join Brands on Cars.IdBrand = Brands.Id;
go


-- прокаты с расшифровкой
select
    Rentals.Id
    , Clients.Surname  + ' ' + SUBSTRING(Clients.Name, 1, 1) + '. ' + SUBSTRING(Clients.Patronymic, 1, 1) + '. ' as Client
    , Brands.Brand
    , Colors.Color
    , Cars.Plate
    , Cars.YearManuf
    , Cars.InsurancePay
    , Cars.Rental
from 
    Rentals join (Cars join Colors on Cars.IdColor = Colors.Id join Brands on Cars.IdBrand = Brands.Id) on Rentals.IdCar = Cars.Id
            join Clients on Rentals.IdClient = Clients.Id
go

-----------------------------------------------------------------------------------------------------

-- 1. Запрос с параметром	
--   Выбирает из таблицы АВТОМОБИЛИ 
--   информацию об автомобилях заданной модели (например, ВАЗ-2110)
declare @brand nvarchar(20) = N'ВАЗ-2110';
select
    Cars.Id
    , Brands.Brand
    , Colors.Color
    , Cars.Plate
    , Cars.YearManuf
    , Cars.InsurancePay
    , Cars.Rental
from
    Cars join Colors on Cars.IdColor = Colors.Id
         join Brands on Cars.IdBrand = Brands.Id
where 
    Cars.IdBrand = (select Id from Brands where Brand = @brand);
go


-- 2. Запрос с параметром	
--    Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях, 
--    изготовленных до заданного года (например, до 2016)
declare @year int = 2011;
select
    Cars.Id
    , Brands.Brand
    , Colors.Color
    , Cars.Plate
    , Cars.YearManuf
    , Cars.InsurancePay
    , Cars.Rental
from
    Cars join Colors on Cars.IdColor = Colors.Id
         join Brands on Cars.IdBrand = Brands.Id
where 
    YearManuf < @year;
go


-- 3. Запрос с параметром	
--    Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях, 
--    имеющих заданные модель и цвет, изготовленных после заданного года
declare @brand nvarchar(20) = N'ВАЗ-2110', @color  nvarchar(20) = N'чёрный', @year int = 2008;
select
    Cars.Id
    , Brands.Brand
    , Colors.Color
    , Cars.Plate
    , Cars.YearManuf
    , Cars.InsurancePay
    , Cars.Rental
from
    Cars join Colors on Cars.IdColor = Colors.Id
         join Brands on Cars.IdBrand = Brands.Id
where 
    Cars.IdBrand = (select Id from Brands where Brand = @brand) and
    Cars.IdColor = (select Id from Colors where Color = @color) and
    YearManuf > @year;
go

-- 4. Запрос с параметром	
--    Выбирает из таблицы АВТОМОБИЛИ информацию об автомобиле с заданным госномером.
declare @plate nvarchar(20) = N'BTM943K';
select
    Cars.Id
    , Brands.Brand
    , Colors.Color
    , Cars.Plate
    , Cars.YearManuf
    , Cars.InsurancePay
    , Cars.Rental
from
    Cars join Colors on Cars.IdColor = Colors.Id
         join Brands on Cars.IdBrand = Brands.Id
where 
    Cars.Plate = @plate;
go

-- 5. Запрос с параметром	
--    Выбирает из таблиц КЛИЕНТЫ, АВТОМОБИЛИ и ФАКТЫ_ПРОКАТА 
--    информацию обо всех зафиксированных фактах проката автомобилей
--    (ФИО клиента, Модель автомобиля, Госномер автомобиля, дата проката) 
--    в некоторый заданный интервал времени.
--    Нижняя и верхняя границы интервала задаются при выполнении запроса
declare @lo date = '2021-11-20', @hi date = '2021-12-15';
select
    Rentals.Id
    , Clients.Surname 
    , Clients.[Name]
    , Clients.Patronymic
    , Brands.Brand
    , Cars.Plate
    , Rentals.DateStart
from 
    Rentals join (Cars join Colors on Cars.IdColor = Colors.Id join Brands on Cars.IdBrand = Brands.Id) on Rentals.IdCar = Cars.Id
            join Clients on Rentals.IdClient = Clients.Id
where 
    Rentals.DateStart between @lo and @hi;
go


-- 6. Запрос с вычисляемыми полями	
--    Вычисляет для каждого факта проката стоимость проката. 
--    Включает поля Дата проката, Госномер автомобиля, Модель автомобиля, Стоимость проката. 
--    Сортировка по полю Дата проката
select
    Rentals.Id
    , Rentals.DateStart
    , Cars.Plate
    , Brands.Brand
    -- Стоимость проката = Стоимость одного дня проката * Количество дней проката. 
    , Cars.Rental * Rentals.Duration as RentalPrice
from 
    Rentals join (Cars join Brands on Cars.IdBrand = Brands.Id) on Rentals.IdCar = Cars.Id
order by
    DateStart;    
go


-- 7. Запрос с левым соединением	
--    Для всех автомобилей прокатной фирмы вычисляет количество фактов проката, 
--    сумму вырученную за прокаты
select
    Cars.Id
    , Brands.Brand
    , Colors.Color
    , Cars.Plate
    , COUNT(Rentals.Id) as AmountRentals
    , Sum(Cars.Rental * Rentals.Duration) as RentalPrice
from 
    (Cars join Colors on Cars.IdColor = Colors.Id join Brands on Cars.IdBrand = Brands.Id) left join Rentals on Rentals.IdCar = Cars.Id
group by
    Cars.Id
    , Brands.Brand
    , Colors.Color
    , Cars.Plate;  
go

-- 8. Итоговый запрос	
--    Выполняет группировку по полю Год выпуска автомобиля.
--    Для каждого года вычисляет минимальное и максимальное 
--    значения по полю Стоимость одного дня проката
select
    YearManuf
    , COUNT(*) as Amount
    , MIN(Rental) as MinPrice
    , MAX(Rental) as MaxPrice
from
    Cars
group by
    YearManuf
go


-- 9. Запрос на добавление	
--    Добавляет в таблицу ФАКТЫ_ПРОКАТА данные о факте проката. 
--    Данные передавайте параметрами, используйте подзапросы
declare @passport nvarchar(15) = '12 21 091911',
        @plate nvarchar(9) = 'HTT164B', 
        @date date ='2021-12-2', 
        @duration int = 5;
insert into 
	Rentals(IdClient, IdCar, DateStart, Duration)
values
	((select id from Clients where Passport = @passport),  (select id from Cars where Plate = @plate), @date, @duration);
go


-- 10. Запрос на добавление
--     Добавляет в таблицу АВТОМОБИЛИ данные о новом автомобиле в прокатной фирме. 
--     Данные автомобиля задавайте параметрами, используйте подзапросы.
declare @brand nvarchar(20) = 'Honda', 
        @color nvarchar(20) = N'чёрный', 
        @plate nvarchar(9) = 'HAA964B',
        @yearManuf int = 2021, 
        @insurancePay int =50000, 
        @rental int = 1900;
insert into 
	Cars (IdBrand, IdColor, Plate, YearManuf, InsurancePay, Rental)
values
	((select id from Brands where Brand = @brand), 
    (select id from Colors where Color = @color),
    @plate, @yearManuf, @insurancePay, @rental);
go

-- 11. Запрос на удаление	
--     Удаляет из таблицы ФАКТЫ_ПРОКАТА запись по идентификатору, заданному параметром запроса
declare @id int = 5;
delete from 
    Rentals
where
    Rentals.Id = @id;
go

-- 12. Запрос на удаление	
--     Удаляет из таблицы ФАКТЫ_ПРОКАТА записи за указанный период для заданного клиента.
declare @passport nvarchar(15) = '12 21 345671',
        @lo date = '2021-11-20', @hi date = '2021-12-15';

delete from 
    Rentals
where
    Rentals.IdClient = (select Id from Clients where Passport = @passport) and
    DateStart between @lo and @hi;
go

-- 13. Запрос на обновление
--     Увеличивает значение в поле Стоимость одного дня проката 
--     на заданное количество процентов для автомобилей,
--     изготовленных после заданного года
-- модификация записей по заданию
declare @percent int = 10, @year int = 2011
-- до обновления
select
    Cars.Id
    , Cars.Plate
    , Cars.YearManuf
    , Cars.Rental
from
    Cars 
Order by 
    Cars.Id;

-- модификация записей по заданию
update 
    Cars
set
    Rental *=  (100. + @percent) / 100.
from
    Cars
where
    Cars.YearManuf > @year;

-- после обновления
select
    Cars.Id
    , Cars.Plate
    , Cars.YearManuf
    , Cars.Rental
from
    Cars 
Order by 
    Cars.Id;
go


-- 14. Запрос на обновление
--     Изменяет данные клиента по его идентификатору на указанные в параметрах запроса значение
declare @id int = 5,
        @surname nvarchar(60)    = N'Иванов',
        @name nvarchar(50)       = N'Иван',
        @patronymic nvarchar(60) = N'Иванович';
-- до обновления
select
    *
from
    Clients
where 
    Id = @id;

-- модификация записей по заданию
update 
    Clients
set
    [Surname] = @surname,
    [Name] = @name,
    Patronymic = @patronymic
from
    Clients
where
    Id = @id;

-- после обновления
select
    *
from
    Clients
where 
    Id = @id;
go