﻿
drop table if exists Rentals;
drop table if exists Cars;
drop table if exists Clients;
drop table if exists Brands;
drop table if exists Colors;

-- Клиенты
create table Clients (
	Id          int          not null primary key identity (1, 1),
	Surname     nvarchar(60) not null, -- фамилия    
	[Name]      nvarchar(60) not null, -- имя    
	Patronymic  nvarchar(60) not null, -- отчество    
	Passport    nvarchar(13) not null  -- серия и номер паспорта
);
go

-- Брэнды
create table Brands (
	Id     int          not null primary key identity (1, 1),
	Brand  nvarchar(25) not null -- брэнд
);
go

-- Цвета
create table Colors (
	Id     int          not null primary key identity (1, 1),
	Color  nvarchar(40) not null -- цвет
);
go

-- Автомобили
create table Cars (
	Id			     int			not null primary key identity (1, 1),
	IdBrand		     int			not null,  -- брэнд
	IdColor		     int			not null,  -- цвет
	Plate		     nvarchar(9)	not null,  -- гос номер
	YearManufac      int			not null,  -- год выпуска
	InsurancePay     int			not null,  -- страховая стоимость
	Rental			 int			not null,  -- стоимость 1 дня проката

	constraint CK_Cars_YearManufac	 check (YearManufac between 2005 and 2021),
	constraint CK_Cars_InsurancePay  check (InsurancePay>0),
	constraint CK_Cars_Rental		 check (Rental > 0),

	constraint FK_Cars_Brands foreign key (IdBrand) references dbo.Brands(Id),
	constraint FK_Cars_Colors foreign key (IdColor) references dbo.Colors(Id)
);
go

--  ФАКТЫ ПРОКАТА
create table Rentals (
	Id		    int  not null primary key identity (1, 1),
	IdClient    int  not null, -- клиент
	IdCar	    int  not null, -- автомобиль
	DateStart   Date not null, -- дата
	Duration    int  not null, -- Количество дней проката

	constraint CK_Rentals_Duration check (Duration between 1 and 15),

	constraint FK_Rentals_Clients  foreign key (IdClient) references dbo.Clients(Id),
	constraint FK_Rentals_Cars	   foreign key (IdCar)    references dbo.Cars(Id),
);
go

