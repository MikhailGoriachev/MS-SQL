﻿


-- 1 запрос
-- Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях
-- заданной модели (например, ВАЗ-2110)

declare @brand nvarchar(50) = N'Volkswagen Jetta';

select
	 Cars.Id
	,Brands.Brand
	,Colors.Color
	,Cars.Plate
	,Cars.YearManufac
	,Cars.InsurancePay
	,Cars.Rental
from
	Cars join Brands on Cars.IdBrand = Brands.Id
		 join Colors on Cars.IdColor = Colors.Id
where
	Brands.Brand = @brand;
go
	 

-- 2 запрос
-- Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях, 
-- изготовленных до заданного года (например, до 2016)

declare @year int = 2013;

select
	 Cars.Id
	,Brands.Brand
	,Colors.Color
	,Cars.Plate
	,Cars.YearManufac
	,Cars.InsurancePay
	,Cars.Rental
from
	Cars join Brands on Cars.IdBrand = Brands.Id
		 join Colors on Cars.IdColor = Colors.Id
where
	Cars.YearManufac < @year;
go


-- 3 запрос
-- Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях, 
-- имеющих заданные модель и цвет, изготовленных после заданного года

declare @year   int          = 2006,
		@brand  nvarchar(50) = N'BMW X7',
		@color  nvarchar(25) = N'Оранжевый';

select
	 Cars.Id
	,Brands.Brand
	,Colors.Color
	,Cars.Plate
	,Cars.YearManufac
	,Cars.InsurancePay
	,Cars.Rental
from
	Cars join Brands on Cars.IdBrand = Brands.Id
		 join Colors on Cars.IdColor = Colors.Id
where
	Cars.YearManufac > @Year
	and Brands.Brand = @brand
	and Colors.Color = @color;
go


-- 4 запрос
-- Выбирает из таблицы АВТОМОБИЛИ 
-- информацию об автомобиле с заданным госномером.

declare @plate nvarchar(9) = N'KO 173 A';

select
	 Cars.Id
	,Brands.Brand
	,Colors.Color
	,Cars.Plate
	,Cars.YearManufac
	,Cars.InsurancePay
	,Cars.Rental
from
	Cars join Brands on Cars.IdBrand = Brands.Id
		 join Colors on Cars.IdColor = Colors.Id
where
	Cars.Plate = @plate;
go


-- 5 запрос
-- Выбирает из таблиц КЛИЕНТЫ, АВТОМОБИЛИ и ФАКТЫ_ПРОКАТА 
-- информацию обо всех зафиксированных фактах проката автомобилей
-- (ФИО клиента, Модель автомобиля, Госномер автомобиля, дата проката)
-- в некоторый заданный интервал времени.
-- Нижняя и верхняя границы интервала задаются при выполнении запроса

declare @lowDate  Date = '11-01-2021',
		@highDate Date = '11-12-2021';

select
	Rentals.Id
	,Clients.Surname
	,Clients.[Name]
	,Clients.Patronymic
	,Brands.Brand
	,Cars.Plate
	,Rentals.DateStart
from
	Rentals join Clients		   on Rentals.IdClient = Clients.Id
		    join (Cars join Brands on Cars.IdBrand     =  Brands.Id join Colors on Cars.IdColor = Colors.Id)
								   on Rentals.IdCar    = Cars.Id
where
	Rentals.DateStart between @lowDate and @highDate;
go


-- 6 запрос
-- Вычисляет для каждого факта проката стоимость проката. 
-- Включает поля Дата проката, Госномер автомобиля,
-- Модель автомобиля, Стоимость проката. 
-- Сортировка по полю Дата проката

select
	Rentals.Id
	,Rentals.DateStart
	,Cars.Plate
	,Brands.Brand
	,Cars.Rental * Rentals.Duration as RentalPrice
from
	Rentals join (Cars join Brands on Cars.IdBrand =  Brands.Id) on Rentals.IdCar = Cars.Id


-- 7 запрос
-- Для всех автомобилей прокатной фирмы вычисляет
-- количество фактов проката, 
-- сумму вырученную за прокаты

select
	 Cars.Id
	,Brands.Brand
	,Colors.Color
	,Cars.Plate
	,Cars.YearManufac
	,Cars.InsurancePay
	,Cars.Rental
	,Count(Rentals.IdCar) as AmountCars
	,Sum(Cars.Rental * Rentals.Duration) as SumRentalPrice
from
	(Cars join Brands on Cars.IdBrand = Brands.Id
		  join Colors on Cars.IdColor = Colors.Id) left join Rentals on Cars.Id = Rentals.IdCar
group by
	Cars.Id
	,Brands.Brand
	,Colors.Color
	,Cars.Plate
	,Cars.YearManufac
	,Cars.InsurancePay
	,Cars.Rental;
go


-- 8 запрос
-- Выполняет группировку по полю Год выпуска автомобиля.
-- Для каждого года вычисляет минимальное и максимальное значения
-- по полю Стоимость одного дня проката

select
	 Cars.YearManufac
	,MIN(Cars.Rental) as MinPriceRentalOneDay
	,AVG(Cars.Rental) as AvgPriceRentalOneDay
	,MAX(Cars.Rental) as MaxPriceRentalOneDay
from 
	Cars
group by
	Cars.YearManufac;
go	


-- 9 запрос
-- Добавляет в таблицу ФАКТЫ_ПРОКАТА данные о факте проката. 
-- Данные передавайте параметрами, используйте подзапросы

declare @idClient  int  = 2,
		@idCar	   int  = 1,
		@dateStart Date = N'12-12-2022',
		@duration  int  = 7;

insert into Rentals
	(IdClient, IdCar, DateStart, Duration)
values
	((select id from clients where id = @idClient), (select id from cars where id = @idCar)
	, @dateStart, @duration);
go


-- 10 запрос
-- Добавляет в таблицу АВТОМОБИЛИ данные о новом автомобиле в прокатной фирме. 
-- Данные автомобиля задавайте параметрами, используйте подзапросы.

declare @idBrand int         = 2,
		@idColor int         = 3,
		@plate   nvarchar(9) = N'K 999 HH',
		@yearMan int         = 2015,
		@insPay  int		 = 190000,
		@rental  int		 = 2850;

insert into Cars
	(IdBrand, IdColor, Plate, YearManufac, InsurancePay, Rental)
values
	((select Id from brands where id = @idbrand), (select id from colors where id = @idColor)
	, @plate, @yearMan, @insPay, @rental);
go


-- 11 запрос
-- Удаляет из таблицы ФАКТЫ_ПРОКАТА запись по идентификатору,
-- заданному параметром запроса

declare @deleteId int = 2;

delete from
	Rentals
where 
	Rentals.Id = @deleteId;
go


-- 12 запрос
-- Удаляет из таблицы ФАКТЫ_ПРОКАТА 
-- записи за указанный период для заданного клиента.

declare @lowDate  Date = '10-28-2021',
		@highDate Date = '12-14-2021',
		@idClient int  = 1;

delete from
	Rentals
where 
	Rentals.DateStart between @lowDate and @highDate
	and IdClient = @idClient;
go


-- 13 запрос
-- Увеличивает значение в поле Стоимость одного дня проката 
-- на заданное количество процентов для автомобилей, 
-- изготовленных после заданного года

declare @percent int = 25,
		@year    int = 2015;

update 
	Cars
set
	Rental += Rental * @percent / 100
where
	YearManufac > @year;


-- 14 запрос
-- Изменяет данные клиента по его идентификатору 
-- на указанные в параметрах запроса значение

declare @surname    nvarchar(60) = N'Николаева',
		@name       nvarchar(50) = N'Маргарита',
		@patronymic nvarchar(60) = N'Максимовна',
		@passpors   nvarchar(15) = '91 81 716314',
		@id		    int          = 3;

update 
	Clients
set
	Surname     = @surname
	,[Name]     = @name
	,Patronymic = @patronymic
	,Passport   = @passpors
where
	Id = @id;
go
