﻿-- 1
-- Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях заданной модели (например, ВАЗ-2110)
declare @model nvarchar(max) = 'lorem'

select * from Cars
where Model = @model

go


-- 2
-- Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях, изготовленных 
-- до заданного года (например, до 2016)
declare @year int = 2016

select * from Cars
where ProductionYear < @year

go


-- 3
-- Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях, 
-- имеющих заданные модель и цвет, изготовленных после заданного года
declare @year int = 2004,
		@model nvarchar(max) = 'Cras',
		@color int = 3

select * from Cars
where 
	ProductionYear > @year and
	Model = @model and
	ColorId = @color

go


-- 4
-- Выбирает из таблицы АВТОМОБИЛИ информацию об автомобиле с заданным госномером.
declare @licenseNumber nvarchar(max) = 'A026NG'

select * from Cars
where LicenseNumber = @licenseNumber

go


-- 5
-- Выбирает из таблиц КЛИЕНТЫ, АВТОМОБИЛИ и ФАКТЫ_ПРОКАТА информацию обо всех 
-- зафиксированных фактах проката автомобилей (ФИО клиента, Модель автомобиля, Госномер 
-- автомобиля, дата проката) в некоторый заданный интервал времени. Нижняя и верхняя границы 
-- интервала задаются при выполнении запроса
declare @min date = '2021-06-24',
		@max date = '2022-10-02'

select
	Surname + '.' + Firstname + '.' + Patronymic as FullName,
	Model,
	LicenseNumber,
	StartDate
from Orders o
join Cars ca on o.CarId = ca.Id
join Clients cl on o.ClientId = cl.Id
where StartDate between @min and @max

go


-- 6
-- Вычисляет для каждого факта проката стоимость проката. Включает поля Дата проката, 
-- Госномер автомобиля, Модель автомобиля, Стоимость проката. Сортировка по полю Дата проката
select
	StartDate,
	LicenseNumber,
	Model,
	dbo.CalculateRentTotal(PriceForDay, Duration) as Total
from Orders o
join Cars c on o.CarId = c.Id

go


-- 7
-- Для всех автомобилей прокатной фирмы вычисляет количество фактов проката, сумму вырученную за прокаты
select 
	c.Model,
	Count(CarId) as Count,
	Sum(dbo.CalculateRentTotal(PriceForDay, Duration)) as Total
from Cars c
left join Orders o on o.CarId = c.Id
group by c.Model

go


-- 8
-- Выполняет группировку по полю Год выпуска автомобиля. Для каждого года вычисляет минимальное 
-- и максимальное значения по полю Стоимость одного дня проката
select
	ProductionYear,
	Min(PriceForDay) as MinPrice,
	Max(PriceForDay) as MaxPrice
from Cars
group by ProductionYear

go


-- 9
-- Добавляет в таблицу ФАКТЫ_ПРОКАТА данные о факте проката. 
-- Данные передавайте параметрами, используйте подзапросы
declare @car int = 7,
		@client int = 59,
		@startDate date = '06.30.21',
		@duration int = 27

insert into Orders
	(CarId, ClientId, StartDate, Duration)
values
	(@car,@client,@startDate,@duration);

go


-- 10
-- Добавляет в таблицу АВТОМОБИЛИ данные о новом автомобиле в прокатной фирме. 
-- Данные автомобиля задавайте параметрами, используйте подзапросы.
declare @model nvarchar(max) = 'a',
		@brand int = 40,
		@color int = 3,
		@license nvarchar(max) = 'I544GG',
		@productionYear int = 2008,
		@insurance int = 9663835,
		@priceForDay money = 3000

insert into Cars
	(Model, BrandId, ColorId, LicenseNumber, ProductionYear, InsurancePayment, PriceForDay)
values
	(@model,@brand,@color,@license,@productionYear,@insurance,@priceForDay);

go


-- 11
-- Удаляет из таблицы ФАКТЫ_ПРОКАТА запись по идентификатору, заданному параметром запроса
declare @id int = 7

delete from Orders
where Id = @id

go


-- 12
-- Удаляет из таблицы ФАКТЫ_ПРОКАТА записи за указанный период для заданного клиента.
declare @clientId int = 4,
		@min date = '01.01.2000',
		@max date = '01.01.2025'

delete from Orders
where 
	ClientId = @clientId and
	StartDate between @min and @max

go


-- 13
-- Увеличивает значение в поле Стоимость одного дня проката на заданное количество 
-- процентов для автомобилей, изготовленных после заданного года
declare @percent float = 3.5,
		@year int = 2017

update Cars
set PriceForDay += (PriceForDay / 100) * @percent
where ProductionYear > @year

go


-- 14
-- Изменяет данные клиента по его идентификатору на указанные в параметрах запроса значение
declare @id int = 30,
		@surname nvarchar(max) = 'Mckay',
		@firstname nvarchar(max) = 'Jael',
		@patronymic nvarchar(max) = 'J',
		@passport nvarchar(max) = 'LT220446822368805627'

update Clients
set 
	Surname = @surname,
	Firstname = @firstname,
	Patronymic = @patronymic,
	Passport = @passport
where Id = @id

go