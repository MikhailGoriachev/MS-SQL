﻿/* База данных «Прокат автомобилей» */

-- Вывод записей таблицы автомобилей с расшифровкой всех полей
select
    Cars.Id 
    , BrandModels.BrandModel
    , Colors.Color
    , Cars.Plate
    , Cars.YearManuf
    , Cars.InsurValue
    , Cars.Rental
from
    Cars join BrandModels on Cars.IdBrand = BrandModels.Id
         join Colors on Cars.IdColor = Colors.Id;
go

-- Вывод записей таблицы фактов проката с расшифровкой всех полей
select
    Hires.Id
    , Cars.Plate
    , Cars.Rental
    , BrandModels.BrandModel
    , Colors.Color
    , Clients.Surname + N' ' + Substring(Clients.[Name], 1, 1) + N'.' + 
          Substring(Clients.Patronymic, 1, 1) + N'.' as Client
    , Hires.DateStart
    , Hires.Duration
from
    Hires join (Cars join BrandModels on Cars.IdBrand = BrandModels.Id
                     join Colors on Cars.IdColor = Colors.Id) 
               on Hires.IdCar = Cars.Id
          join clients on Hires.IdClient = Clients.Id
-- order by
--    Cars.Plate
;
go

--  1. Запрос с параметром	
--     Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях заданной модели
--     (например, ВАЗ-2110)
-- declare @brandModel nvarchar(30) = N'Volkswagen Polo';
declare @brandModel nvarchar(30) = N'Suzuki Grand Vitara';

select
    Cars.Id 
    , BrandModels.BrandModel
    , Colors.Color
    , Cars.Plate
    , Cars.YearManuf
    , Cars.InsurValue
    , Cars.Rental
from
    Cars join BrandModels on Cars.IdBrand = BrandModels.Id
         join Colors on Cars.IdColor = Colors.Id
where
    BrandModels.BrandModel = @brandModel;
go


--  2. Запрос с параметром	
--     Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях, изготовленных 
--     до заданного года (например, до 2016)
declare @yearManuf int = 2018;

select
    Cars.Id 
    , BrandModels.BrandModel
    , Colors.Color
    , Cars.Plate
    , Cars.YearManuf
    , Cars.InsurValue
    , Cars.Rental
from
    Cars join BrandModels on Cars.IdBrand = BrandModels.Id
         join Colors on Cars.IdColor = Colors.Id
where
    Cars.YearManuf < @yearManuf;
go

--  3. Запрос с параметром	
--     Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях, имеющих 
--     заданные модель и цвет, изготовленных после заданного года
declare @brandModel nvarchar(30) = N'Skoda Fabia New', @color nvarchar(30)=N'фиолетовый', 
        @yearManuf int = 2016;

select
    Cars.Id 
    , BrandModels.BrandModel
    , Colors.Color
    , Cars.Plate
    , Cars.YearManuf
    , Cars.InsurValue
    , Cars.Rental
from
    Cars join BrandModels on Cars.IdBrand = BrandModels.Id
         join Colors on Cars.IdColor = Colors.Id
where
    BrandModels.BrandModel = @brandModel and Colors.Color = @color and Cars.YearManuf > @yearManuf;
go

--  4. Запрос с параметром	
--     Выбирает из таблицы АВТОМОБИЛИ информацию об автомобиле с заданным
--     госномером
-- declare @plate nvarchar(12) = N'С168РК';
declare @plate nvarchar(12) = N'С';

select
    Cars.Id 
    , BrandModels.BrandModel
    , Colors.Color
    , Cars.Plate
    , Cars.YearManuf
    , Cars.InsurValue
    , Cars.Rental
from
    Cars join BrandModels on Cars.IdBrand = BrandModels.Id
         join Colors on Cars.IdColor = Colors.Id
where
    -- Cars.Plate = @plate;
    Cars.Plate like @plate + N'%';
go


--  5. Запрос с параметром	
--     Выбирает из таблиц КЛИЕНТЫ, АВТОМОБИЛИ и ФАКТЫ_ПРОКАТА информацию обо
--     всех зафиксированных фактах проката автомобилей (ФИО клиента, Модель 
--     автомобиля, Госномер автомобиля, дата проката) в некоторый заданный 
--     интервал времени. Нижняя и верхняя границы интервала задаются при 
--     выполнении запроса
declare @from date = '10-01-2021', @to date = '10-31-2021';

select
    Hires.Id
    , Clients.Surname + N' ' + Substring(Clients.[Name], 1, 1) + N'.' + 
          Substring(Clients.Patronymic, 1, 1) + N'.' as Client
    , BrandModels.BrandModel
    , Cars.Plate
    , Hires.DateStart
    , Hires.Duration
from
    Hires join (Cars join BrandModels on Cars.IdBrand = BrandModels.Id) 
               on Hires.IdCar = Cars.Id
          join clients on Hires.IdClient = Clients.Id
where
    Hires.DateStart between @from and @to 
order by
    Hires.DateStart;
go

--  6. Запрос с вычисляемыми полями	
--     Вычисляет для каждого факта проката стоимость проката. Включает поля 
--     Дата проката, Госномер автомобиля, Модель автомобиля, Стоимость проката.
--     Сортировка по полю Дата проката
select
    Hires.Id
    , Hires.DateStart
    , Cars.Plate
    , BrandModels.BrandModel
    , Cars.Rental                  as RentalPerDay
    , Hires.Duration
    , Cars.Rental * Hires.Duration as Price 
from
    Hires join (Cars join BrandModels on Cars.IdBrand = BrandModels.Id) 
               on Hires.IdCar = Cars.Id
order by
    Hires.DateStart;
go


--  7. Запрос с левым соединением	
--     Для всех автомобилей прокатной фирмы вычисляет количество фактов 
--     проката, сумму вырученную за прокаты
select
    Cars.Id
    , Cars.Plate
    , Count(Hires.IdCar) as Amount
    , IsNull(Sum(Cars.Rental * Hires.Duration), 0) as SumRental
from
    Cars left join Hires on Cars.Id = Hires.IdCar
group by
    Cars.Id, Cars.Plate;
go


--  8. Итоговый запрос	
--     Выполняет группировку по полю Год выпуска автомобиля. Для каждого года 
--     вычисляет минимальное и максимальное значения по полю Стоимость одного 
--     дня проката
select
    YearManuf
    , Count(*)    as AmountYearManuf
    , Min(Rental) as MinRental
    , Max(Rental) as MaxRental
from  
    Cars
group by
    YearManuf;
go


--  9. Запрос на добавление	
--     Добавляет в таблицу ФАКТЫ_ПРОКАТА данные о факте проката. 
--     Данные передавайте параметрами, используйте подзапросы
declare @passport nvarchar(15) = '13 21 185659', @plate nvarchar(12) = N'С192РК', 
        @dateStart date = '12-6-2021', @duration int = 15;

insert Hires
    (IdClient, IdCar, DateStart, Duration)
values (
    (select Id from Clients where Passport = @passport),
    (select Id from Cars where Plate = @plate), 
    @dateStart, @duration);
go

-- 10. Запрос на добавление	
--     Добавляет в таблицу АВТОМОБИЛИ данные о новом автомобиле в прокатной 
--     фирме. Данные автомобиля задавайте параметрами, используйте подзапросы
declare @brandModel nvarchar(30)=N'Mercedes 210', @color nvarchar(30) = N'серебристый',
       @plate nvarchar(12)=N'М345РК', @yearManuf int = 2020, @insurValue int = 4500000,
       @rental int = 5100;

insert Cars
   (IdBrand, IdColor, Plate, YearManuf, InsurValue, Rental)
values (
   (select Id from BrandModels where BrandModel = @brandModel),
   (select Id from Colors where color = @color),
   @plate, @yearManuf, @insurValue, @rental);
go


-- 11. Запрос на удаление	
--     Удаляет из таблицы ФАКТЫ_ПРОКАТА запись по идентификатору, заданному 
--     параметром запроса
declare @id int = 22;

delete from  
    Hires
where
    Id = @id;
go


-- 12. Запрос на удаление	
--     Удаляет из таблицы ФАКТЫ_ПРОКАТА записи за указанный период 
--     для заданного клиента
declare @passport nvarchar(15) = N'09 20 001981', @from date = '09-01-2021', @to date = '11-30-2021';

delete from  
    Hires
where
    IdClient = (select Id from Clients where Passport = @passport)
    and 
    DateStart between @from and @to;
go


-- 13. Запрос на обновление	
--     Увеличивает значение в поле Стоимость одного дня проката на заданное 
--     количество процентов для автомобилей, изготовленных после заданного года
declare @percent float = 10, @yearManuf int = 2018;

update
    Cars
set
    Rental *= (100 + @percent) / 100
where
    Cars.YearManuf > @yearManuf;
go

-- 14. Запрос на обновление	
--     Изменяет данные клиента по его идентификатору на указанные в параметрах 
--     запроса значение
declare @id int = 1,
	@surname    nvarchar(60) = N'Иванов',
	@name       nvarchar(50) = N'Иван',
	@patronymic nvarchar(60) = N'Иванович',
    @passport   nvarchar(15) = N'99 21 000001';

update
    Clients
set
    Surname = @surname
    , [Name] = @name
    , Patronymic = @patronymic
    , Passport = @passport
where
    Clients.Id = @id;
go
