﻿--запрос 1
--Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях заданной модели 
declare @Brand NVARCHAR(40) = N'ВАЗ-2110';
select
	Cars.Id,
	Cars.InsurancePay,
	Cars.Plate,
	Cars.Rental,
	Cars.[Year],
	Brands.Brand,
	Colors.Color
from
	Cars join Brands on Cars.IdBrand = Brands.Id
		 join Colors on Cars.IdColor = Colors.Id
where
	Brand like @Brand;
go

--запрос 2
--Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях, изготовленных до заданного года
declare @YearMin INT = 2005; 
declare @YearMax INT = 2015;
select
	Cars.Id,
	Cars.InsurancePay,
	Cars.Plate,
	Cars.Rental,
	Cars.[Year],
	Brands.Brand,
	Colors.Color
from
	Cars join Brands on Cars.IdBrand = Brands.Id
		 join Colors on Cars.IdColor = Colors.Id
where
	[Year] between @YearMin and @YearMax;
go

--запрос 3
--Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях,
--имеющих заданные модель и цвет, изготовленных после заданного года
select
	Cars.Id,
	Cars.InsurancePay,
	Cars.Plate,
	Cars.Rental,
	Cars.[Year],
	Brands.Brand,
	Colors.Color
from
	Cars join Brands on Cars.IdBrand = Brands.Id
		 join Colors on Cars.IdColor = Colors.Id
where
	Brand like N'ВАЗ-2110' and
	[Year] < 2016	and
	Color like N'Белая';
go

--запрос 4
--Выбирает из таблицы АВТОМОБИЛИ информацию об автомобиле с заданным госномером.

select
	Cars.Id,
	Cars.InsurancePay,
	Cars.Plate,
	Cars.Rental,
	Cars.[Year],
	Brands.Brand,
	Colors.Color
from
	Cars join Brands on Cars.IdBrand = Brands.Id
		 join Colors on Cars.IdColor = Colors.Id
where
	Plate = N'В444ГУ';
go

--запрос 5
--Выбирает из таблиц КЛИЕНТЫ, АВТОМОБИЛИ и ФАКТЫ_ПРОКАТА информацию обо всех 
--зафиксированных фактах проката автомобилей (ФИО клиента, Модель автомобиля, 
--Госномер автомобиля, дата проката) в некоторый заданный интервал времени. 
--Нижняя и верхняя границы интервала задаются при выполнении запроса

select
	Rentals.Id,
	Clients.Surname,
	Clients.[Name],
	Clients.Patronymic,
	Brands.Brand,
	Cars.Plate,
	Rentals.DateStart
from
	Rentals join Clients on Rentals.IdClient = Clients.Id
			join(Cars join Brands on Cars.IdBrand = Brands.Id 
			join Colors on Cars.IdColor = Colors.Id)
			on Rentals.IdCar = Cars.Id
where
	Rentals.DateStart between '2021-01-11' and '2021-06-20';
go

--запрос 6
--Вычисляет для каждого факта проката стоимость проката. 
--Включает поля Дата проката, Госномер автомобиля, Модель автомобиля, Стоимость проката. 
--Сортировка по полю Дата проката
select
	Rentals.Id,
	Rentals.DateStart,
	Cars.Plate,
	Brands.Brand,
	Cars.Rental * Rentals.Duration as RentalCost
from
	Rentals join (Cars join Brands on Cars.IdBrand = Brands.Id)
								   on Rentals.IdCar = Cars.Id;
go

--запрос 7
--Для всех автомобилей прокатной фирмы вычисляет количество фактов проката, 
--сумму вырученную за прокаты
select 
	Cars.Id,
	Brands.Brand,
	Colors.Color,
	Cars.InsurancePay,
	Cars.Plate,
	Cars.Rental,
	Cars.[Year],
	Count(Rentals.IdCar) as NumberОfСars,
	Sum(Cars.Rental * Rentals.Duration) as SumRental
from
	(Cars join Brands on Cars.IdBrand = Brands.Id
		  join Colors on Cars.IdColor = Colors.Id) 
	 left join Rentals on Cars.Id = Rentals.IdCar
group by
	Cars.Id,
	Brands.Brand,
	Colors.Color,
	Cars.Plate,
	Cars.[Year],
	Cars.InsurancePay,
	Cars.Rental;
go

--запрос 8
--Выполняет группировку по полю Год выпуска автомобиля. 
--Для каждого года вычисляет минимальное и максимальное значения
--по полю Стоимость одного дня проката

select
	Cars.[Year],
	Min(Cars.Rental)as MinRental,
	MAX(Cars.Rental)as MaxRental,
	AVG(Cars.Rental)as AVGRental
from
	Cars
group by
	Cars.Year;
go

--запрос 9 
--Добавляет в таблицу ФАКТЫ_ПРОКАТА данные о факте проката.
--Данные передавайте параметрами, используйте подзапросы
declare @IdClient INT = 8;
declare @IdCar INT = 3;
declare @DateStart Date = '2021-12-08';
declare @Duration INT = 7;
insert Rentals
	(IdClient, IdCar, DateStart, Duration)
values
	((select Id from Clients where Id = @IdClient),
	(select Id from Cars where Id = @IdCar), @DateStart, @Duration);
go
--запрос 10
--Добавляет в таблицу АВТОМОБИЛИ данные о новом автомобиле в прокатной фирме. 
--Данные автомобиля задавайте параметрами, используйте подзапросы.
declare @IdBrand INT = 1;
declare @IdColor INT = 3;
declare @Plate	NVARCHAR(10) = N'Г210АМ';
declare @Year INT = 2007;
declare @InsurancePay INT = 1200;
declare @Rental INT = 2000;

insert into Cars
	(IdBrand, IdColor, Plate,[Year], InsurancePay, Rental)
values
	((select Id from Brands where Id = @IdBrand),
	(select Id from Colors where Id = @IdColor), @plate, @Year, @InsurancePay, @Rental);
go
--запрос 11
--Удаляет из таблицы ФАКТЫ_ПРОКАТА запись по 
--идентификатору, заданному параметром запроса
declare @Param INT =5
delete from Rentals where Rentals.Id = @Param;
go

--запрос 12
--Удаляет из таблицы ФАКТЫ_ПРОКАТА записи 
--за указанный период для заданного клиента.

declare @Passport NVARCHAR(20) = N'11 21 098181';

delete from Rentals where Rentals.IdClient in (select Id from Clients where Passport = @Passport) 
and
Rentals.DateStart between '2021-02-02' and '2021-04-24';
go

--запрос 13
--Увеличивает значение в поле Стоимость одного дня проката на заданное 
--количество процентов для автомобилей, изготовленных после заданного года
declare @Percent INT = 2;
declare @Year INT = 2017;
update
	Cars
set
	Rental += Rental * @Percent / 100
where
	[Year] > @Year;

--запрос 14
--Изменяет данные клиента по его идентификатору 
--на указанные в параметрах запроса значение

declare @Surname nvarchar(60) = N'Комаров';
declare @Name nvarchar(60) = N'Максим';
declare @Patronymic nvarchar(60) = N'Сергеевич';
declare @Passport nvarchar(20) = N'11 20 421420';
declare @Id int	= 7;

update Clients 
set 
	Surname = @Surname,
	[Name] = @Name,
	Patronymic = @Patronymic, 
	Passport = @Passport
where
	Id = @Id;
go