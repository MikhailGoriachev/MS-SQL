﻿
--удаление таблиц
drop table if exists Rentals;
drop table if exists Cars;
drop table if exists Clients;
drop table if exists Colors;
drop table if exists Brands;
go

--создание таблиц
--Таблица клиентов
create table dbo.Clients(
	Id			    INT			NOT NULL	PRIMARY KEY IDENTITY(1,1),
	Surname			NVARCHAR(80)NOT NULL,	--Фамилия
	[Name]			NVARCHAR(80)NOT NULL,	--Имя
	Patronymic		NVARCHAR(80)NOT NULL,	--Отчество
	Passport		NVARCHAR(30)NOT NULL	--Номер паспорта
);
go

--Таблица моделей машин
create table dbo.Brands(
	Id			    INT			NOT NULL	PRIMARY KEY IDENTITY(1,1),
	Brand			NVARCHAR(80)NOT NULL	--Модель машины
);
go

--Таблица цветов машин
create table dbo.Colors(
	Id			    INT			NOT NULL	PRIMARY KEY IDENTITY(1,1),
	Color			NVARCHAR(50)NOT NULL	--Цвет машины
);
go

--Таблица машин
create table dbo.Cars (
	Id			    INT			NOT NULL	PRIMARY KEY IDENTITY(1,1),
	IdBrand			INT			NOT NULL,	--Внешний ключ на таблицу модели машин
	IdColor			INT			NOT NULL,	--Внешний ключ на таблицу цветов машин
	Plate			NVARCHAR(10)NOT NULL,	--Номера машины
	[Year]			INT			NOT NULL,	--Год выпуска машины
	InsurancePay	INT			NOT NULL,	--Страхование
	Rental			INT			NOT NULL,	--Стоимость Аренды
	
	--Ограничения значений параметров
	constraint CK_Cars_Year check ([Year] >= 2005),
	constraint CK_Cars_InsurancePay check (InsurancePay > 0),
	constraint CK_Cars_Rental check (Rental > 0),
	--Внешние ключи на таблицы моделей и цветов
	constraint FK_Cars_Brands foreign key (IdBrand) references dbo.[Brands](Id),
	constraint FK_Cars_Colors foreign key (IdColor) references dbo.[Colors](Id)
	
);
go

--Таблица Аренды
create table dbo.Rentals(
	Id			    INT			NOT NULL	PRIMARY KEY IDENTITY(1,1),
	IdClient		INT			NOT NULL,	--Внешний ключ на таблицу клиентов
	IdCar			INT			NOT NULL,	--Внешний ключ на таблицу машин	
	DateStart		Date		NOT NULL,	--Дата начала проката
	Duration		INT			NOT NULL,	--Количество дней проката
	--Ограничения значений параметров
	constraint CK_Rentals_Duration check (Duration > 0),
	--Внешние ключи на таблицы клиентов и машин
	constraint FK_Rentals_Clients foreign key (IdClient) references dbo.[Clients](Id),
	constraint FK_Rentals_Cars foreign key (IdCar) references dbo.[Cars](Id)
);
go