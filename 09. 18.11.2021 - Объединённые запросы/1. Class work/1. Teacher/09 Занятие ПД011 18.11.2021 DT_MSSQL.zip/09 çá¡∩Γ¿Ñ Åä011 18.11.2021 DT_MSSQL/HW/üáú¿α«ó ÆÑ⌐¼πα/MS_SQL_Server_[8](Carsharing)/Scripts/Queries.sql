﻿
--			-> Запрос №1 [ Запрос с параметром ] <-
-- Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях
-- заданной модели (например, ВАЗ-2110)
declare @brand nvarchar(80) = N'Volkswagen Tiguan';
select
	 Cars.Id
	,Brands.Brand
	,Colors.Color
	,Cars.Plate
	,Cars.YearMount
	,Cars.InsurancePay
	,Cars.Rental
from
	Cars join Brands on Cars.IdBrand =  Brands.Id
		 join Colors on Cars.IdColor = Colors.Id
where
	Brands.Brand = @brand;
go
	 

--			-> Запрос №2 [ Запрос с параметром ] <-
-- Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях, 
-- изготовленных до заданного года (например, до 2016)
declare @HiYear int = 2009;
select
	 Cars.Id
	,Brands.Brand
	,Colors.Color
	,Cars.Plate
	,Cars.YearMount
	,Cars.InsurancePay
	,Cars.Rental
from
	Cars join Brands on Cars.IdBrand =  Brands.Id
		 join Colors on Cars.IdColor = Colors.Id
where
	Cars.YearMount < @HiYear;
go


--			-> Запрос №3 [ Запрос с параметром ] <-
-- Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях, 
-- имеющих заданные модель и цвет, изготовленных после заданного года
declare @loYear int          = 2006         ;
declare @brand  nvarchar(80) = N'BMW X5'    ;
declare @color  nvarchar(80) = N'Фиолетовый';
select
	 Cars.Id
	,Brands.Brand
	,Colors.Color
	,Cars.Plate
	,Cars.YearMount
	,Cars.InsurancePay
	,Cars.Rental
from
	Cars join Brands on Cars.IdBrand =  Brands.Id
		 join Colors on Cars.IdColor = Colors.Id
where
	Cars.YearMount > @loYear and Brands.Brand = @brand and Colors.Color = @color;
go


--			-> Запрос №4 [ Запрос с параметром ] <-
-- Выбирает из таблицы АВТОМОБИЛИ 
-- информацию об автомобиле с заданным госномером.
declare @plate nvarchar(9) = N'С 682 КК';
select
	 Cars.Id
	,Brands.Brand
	,Colors.Color
	,Cars.Plate
	,Cars.YearMount
	,Cars.InsurancePay
	,Cars.Rental
from
	Cars join Brands on Cars.IdBrand =  Brands.Id
		 join Colors on Cars.IdColor = Colors.Id
where
	Cars.Plate = @plate;
go


--			-> Запрос №5 [ Запрос с параметром ] <-
-- Выбирает из таблиц КЛИЕНТЫ, АВТОМОБИЛИ и ФАКТЫ_ПРОКАТА 
-- информацию обо всех зафиксированных фактах проката автомобилей
-- (ФИО клиента, Модель автомобиля, Госномер автомобиля, дата проката)
-- в некоторый заданный интервал времени.
-- Нижняя и верхняя границы интервала задаются при выполнении запроса
declare @loDate Date = '2021-10-11', @hiDate Date = '2021-11-22';
select
	Rentals.Id
	,Clients.Surname
	,Clients.[Name]
	,Clients.Patronymic
	,Brands.Brand
	,Cars.Plate
	,Rentals.DateStart
from
	Rentals join Clients on Rentals.IdClient = Clients.Id
		    join (Cars join Brands on Cars.IdBrand =  Brands.Id
					   join Colors on Cars.IdColor = Colors.Id)
				 on Rentals.IdCar = Cars.Id
where
	Rentals.DateStart between @loDate and @hiDate;
go


--			-> Запрос №6 [ Запрос с вычисляемыми полями ] <-
-- Вычисляет для каждого факта проката стоимость проката. 
-- Включает поля Дата проката, Госномер автомобиля, Модель автомобиля, Стоимость проката. 
-- Сортировка по полю Дата проката
select
	Rentals.Id
	,Rentals.DateStart
	,Cars.Plate
	,Brands.Brand
	,Cars.Rental * Rentals.Duration as RentalsPrice
from
	Rentals join (Cars join Brands on Cars.IdBrand =  Brands.Id)
				 on Rentals.IdCar = Cars.Id


--			-> Запрос №7 [ Запрос с левым соединением ] <-
-- Для всех автомобилей прокатной фирмы вычисляет количество фактов проката, 
-- сумму вырученную за прокаты
select
	 Cars.Id
	,Brands.Brand
	,Colors.Color
	,Cars.Plate
	,Cars.YearMount
	,Cars.InsurancePay
	,Cars.Rental
	,Count(Rentals.IdCar) as AmountCars
	,Sum(Cars.Rental * Rentals.Duration) as SumRentalsPrice
from
	(Cars join Brands on Cars.IdBrand = Brands.Id
		  join Colors on Cars.IdColor = Colors.Id) left join Rentals 
				on Cars.Id = Rentals.IdCar
group by
	Cars.Id
	,Brands.Brand
	,Colors.Color
	,Cars.Plate
	,Cars.YearMount
	,Cars.InsurancePay
	,Cars.Rental;
go


--			-> Запрос №8 [ Итоговый запрос ] <-
-- Выполняет группировку по полю Год выпуска автомобиля.
-- Для каждого года вычисляет минимальное и максимальное значения
-- по полю Стоимость одного дня проката
select
	 Cars.YearMount
	,MIN(Cars.Rental) as MinPriceRentalOneDay
	,AVG(Cars.Rental) as AvgPriceRentalOneDay
	,MAX(Cars.Rental) as MaxPriceRentalOneDay
from 
	Cars
group by
	Cars.YearMount;
go	


--			-> Запрос №9 [ Запрос на добавление ] <-
-- Добавляет в таблицу ФАКТЫ_ПРОКАТА данные о факте проката. 
-- Данные передавайте параметрами, используйте подзапросы

			-- [Вывод перед добавлением в таблицу Realtors]
select
	 Rentals.Id
	,Clients.Surname
	,Clients.[Name]
	,Clients.Patronymic
	,Clients.Passport
	,Brands.Brand
	,Colors.Color
	,Cars.Plate
	,Cars.YearMount
	,Rentals.DateStart
	,Rentals.Duration
from
	Rentals  join (Cars join Brands on Cars.IdBrand = Brands.Id
					    join Colors on Cars.IdColor = Colors.Id) 
			      on Cars.Id = Rentals.IdCar
		     join Clients on Rentals.IdClient =Clients.Id;
go


			-- [Добавление в таблицу Rentals]
declare  @idClient   int  = 5;
declare  @idCar      int  = 15;
declare  @dateStart  Date = '2021-12-22';
declare  @duration   int  = 15;

			-- [Добавление в таблицу Rentals]
insert into Rentals
	(IdClient,IdCar,DateStart,Duration)
values
	((select Id from Clients where Id = @idClient),  
	 (select Id from Cars    where Id = @idCar   ),
	  @dateStart, @duration                       );
go
 
		-- [Вывод после добавления в таблицу Realtors]
select
	 Rentals.Id
	,Clients.Surname
	,Clients.[Name]
	,Clients.Patronymic
	,Clients.Passport
	,Brands.Brand
	,Colors.Color
	,Cars.Plate
	,Cars.YearMount
	,Rentals.DateStart
	,Rentals.Duration
from
	Rentals  join (Cars join Brands on Cars.IdBrand = Brands.Id
					    join Colors on Cars.IdColor = Colors.Id) 
			      on Cars.Id = Rentals.IdCar
		     join Clients on Rentals.IdClient =Clients.Id;
go


--			-> Запрос №10 [ Запрос на добавление ] <-
-- Добавляет в таблицу АВТОМОБИЛИ данные о новом автомобиле в прокатной фирме. 
-- Данные автомобиля задавайте параметрами, используйте подзапросы.

		-- [Вывод перед добавлением в таблицу Cars]
select
	 Cars.Id
	,Brands.Brand
	,Colors.Color
	,Cars.Plate
	,Cars.YearMount
	,Cars.InsurancePay
	,Cars.Rental
from
	Cars join Brands on Cars.IdBrand =  Brands.Id
		 join Colors on Cars.IdColor = Colors.Id
go


			-- [Добавление в таблицу Cars]
declare  @idBrand        int         = 13;
declare  @idColor        int         = 5;
declare  @plate          nvarchar(9) = N'О 268 AX';
declare  @yearMount      int         = 2019;
declare  @insurancePay   int         = 240000;
declare  @rental         int         = 3000;
insert into Cars
	(IdBrand,IdColor,Plate,YearMount,InsurancePay,Rental)
values
	((select Id from Brands where Id = @idBrand),  
	 (select Id from Colors where Id = @idColor),
	  @plate, @yearMount, @insurancePay, @rental);
go

 
		-- [Вывод после добавления в таблицу Cars]
select
	 Cars.Id
	,Brands.Brand
	,Colors.Color
	,Cars.Plate
	,Cars.YearMount
	,Cars.InsurancePay
	,Cars.Rental
from
	Cars join Brands on Cars.IdBrand =  Brands.Id
		 join Colors on Cars.IdColor = Colors.Id
go


--			-> Запрос №11 [ Запрос на удаление ] <-
-- Удаляет из таблицы ФАКТЫ_ПРОКАТА запись по идентификатору,
-- заданному параметром запроса

			-- [Вывод перед удалением из таблицы Realtors]
select
	 Rentals.Id
	,Clients.Surname
	,Clients.[Name]
	,Clients.Patronymic
	,Clients.Passport
	,Brands.Brand
	,Colors.Color
	,Cars.Plate
	,Cars.YearMount
	,Rentals.DateStart
	,Rentals.Duration
from
	Rentals  join (Cars join Brands on Cars.IdBrand = Brands.Id
					    join Colors on Cars.IdColor = Colors.Id) 
			      on Cars.Id = Rentals.IdCar
		     join Clients on Rentals.IdClient =Clients.Id;
go

		-- [Удаление из таблицы Realtors по указанному Id]
declare @deleteId int = FLOOR(Rand()* (31-1)+1);
delete from
	Rentals
where Rentals.Id = @deleteId;
go


			-- [Вывод после удаления из таблицы Realtors]
select
	 Rentals.Id
	,Clients.Surname
	,Clients.[Name]
	,Clients.Patronymic
	,Clients.Passport
	,Brands.Brand
	,Colors.Color
	,Cars.Plate
	,Cars.YearMount
	,Rentals.DateStart
	,Rentals.Duration
from
	Rentals  join (Cars join Brands on Cars.IdBrand = Brands.Id
					    join Colors on Cars.IdColor = Colors.Id) 
			      on Cars.Id = Rentals.IdCar
		     join Clients on Rentals.IdClient =Clients.Id;
go


--			-> Запрос №12 [ Запрос на удаление ] <-
-- Удаляет из таблицы ФАКТЫ_ПРОКАТА 
-- записи за указанный период для заданного клиента.

			-- [Вывод перед удалением из таблицы Realtors]
select
	 Rentals.Id
	,Clients.Surname
	,Clients.[Name]
	,Clients.Patronymic
	,Clients.Passport
	,Brands.Brand
	,Colors.Color
	,Cars.Plate
	,Cars.YearMount
	,Rentals.DateStart
	,Rentals.Duration
from
	Rentals  join (Cars join Brands on Cars.IdBrand = Brands.Id
					    join Colors on Cars.IdColor = Colors.Id) 
			      on Cars.Id = Rentals.IdCar
		     join Clients on Rentals.IdClient =Clients.Id;
go

		-- [Удаление из таблицы Realtors по указанному Id]
declare @loDate   Date         = '2021-09-03'   , @hiDate Date = '2021-10-03';
declare @passport nvarchar(12) = N'11 21 121212';
delete from
	Rentals
where 
	Rentals.IdClient in (select Id from Clients where Passport = @passport) and 
	Rentals.DateStart between @loDate and @hiDate;
go


			-- [Вывод после удаления из таблицы Realtors]
select
	 Rentals.Id
	,Clients.Surname
	,Clients.[Name]
	,Clients.Patronymic
	,Clients.Passport
	,Brands.Brand
	,Colors.Color
	,Cars.Plate
	,Cars.YearMount
	,Rentals.DateStart
	,Rentals.Duration
from
	Rentals  join (Cars join Brands on Cars.IdBrand = Brands.Id
					    join Colors on Cars.IdColor = Colors.Id) 
			      on Cars.Id = Rentals.IdCar
		     join Clients on Rentals.IdClient =Clients.Id;
go


--			-> Запрос №13 [ Запрос на обновление ] <-
-- Увеличивает значение в поле Стоимость одного дня проката 
-- на заданное количество процентов для автомобилей, 
-- изготовленных после заданного года
		
		-- [Вывод перед изменениями в таблице Cars]
select
	 Cars.Id
	,Brands.Brand
	,Colors.Color
	,Cars.Plate
	,Cars.YearMount
	,Cars.InsurancePay
	,Cars.Rental
from
	Cars join Brands on Cars.IdBrand =  Brands.Id
		 join Colors on Cars.IdColor = Colors.Id
go
	
	-- [Изменение данных в таблице Cars]
declare @Percent int = FLOOR(Rand()* (16-1)+1);
declare @Year    int = FLOOR(Rand()* (2011-2006)+2006);
update 
	Cars
set
	Rental += Rental * @Percent / 100
where
	YearMount > @Year;

	
		-- [Вывод после изменений в таблице Cars]
select
	 Cars.Id
	,Brands.Brand
	,Colors.Color
	,Cars.Plate
	,Cars.YearMount
	,Cars.InsurancePay
	,Cars.Rental
	,@Percent  as [Percent]
	,@Year     as [Year]
from
	Cars join Brands on Cars.IdBrand =  Brands.Id
		 join Colors on Cars.IdColor = Colors.Id
go


--			-> Запрос №14 [ Запрос на обновление ] <-
-- Изменяет данные клиента по его идентификатору 
-- на указанные в параметрах запроса значение

		-- [Вывод перед изменениями в таблице Clients]
select
	 Clients.Id
	 ,Clients.Surname
	 ,Clients.[Name]
	 ,Clients.Patronymic
	 ,Clients.Passport
from
	Clients
go


	-- [Изменение данных в таблице Clients]
declare  @Surname    nvarchar(60) = N'Паучков'             ;
declare  @Name       nvarchar(50) = N'Иван'	               ;
declare  @Patronymic nvarchar(60) = N'Анатолиевич'         ;
declare  @Passpors   nvarchar(15) = N'09 20 110022'        ;
declare  @Id		 int          = FLOOR(Rand()* (16-1)+1);

update 
	Clients
set
	Surname     = @Surname
	,[Name]     = @Name
	,Patronymic = @Patronymic
	,Passport   = @Passpors
where
	Id = @Id;
go
 
 		-- [Вывод после изменений в таблице Clients]
select
	 Clients.Id
	 ,Clients.Surname
	 ,Clients.[Name]
	 ,Clients.Patronymic
	 ,Clients.Passport
from
	Clients
go
