﻿ -- ==================>  Создание таблиц  <==================

 -- удаление существующих таблиц, работает в MS SQL Server 2016+
drop table if exists Rentals;
drop table if exists Cars;
drop table if exists Clients;
drop table if exists Brands;
drop table if exists Colors; 
go


-- Создание основной таблицы "Клиенты" (Clients)
create table dbo.Clients(
	Id         int			not null primary key identity (1,1),
	Surname    nvarchar(60) not null, -- фамилия
	[Name]     nvarchar(50) not null, -- имя
	Patronymic nvarchar(60) not null, -- отчество
	Passport   nvarchar(15) not null  -- паспорт
);
go


-- Создание таблицы "Модель автомобиля" (Brands)
create table dbo.Brands(
	Id      int           not null primary key identity (1,1),
	Brand   nvarchar(80) not null -- модель автомобиля
);
go


-- Создание таблицы "Цвета автомобиля" (Colors)
create table dbo.Colors(
	Id      int          not null primary key identity (1,1),
	Color   nvarchar(50) not null  -- цвет автомобиля
);
go

-- Создание основной таблицы "Машины" (Cars)
create table dbo.Cars(
	Id           int         not null primary key identity (1,1),
	IdBrand      int         not null, -- Внешний ключ. Связь с таблицей моделей автомобиля (Brands)
	IdColor      int         not null, -- Внешний ключ. Связь с таблицей цветов автомобилей (Colors)
	Plate        nvarchar(9) not null, -- Гос. номер
	YearMount    int         not null, -- год выпуска автомобиля
	InsurancePay int         not null, -- страховая стоимость
	Rental       int         not null, -- стоимость 1 дня проката
	
	-- Проверки полей таблицы
	constraint CK_Cars_InsurancePay check (InsurancePay > 0),
	constraint CK_Cars_Rental       check (Rental between 1 and InsurancePay),
	constraint CK_Cars_YeatMount    check (YearMount > 2005),
	
	-- внешний ключ - связь М:1 к таблице Brands(модель автомобиля)
	constraint FK_Cars_Brands foreign key (IdBrand) references dbo.Brands(Id),
	-- внешний ключ - связь М:1 к таблице Colors(цвет автомобиля)
	constraint FK_Cars_Colors foreign key (IdColor) references dbo.Colors(Id),

);
go

-- Создание основной таблицы "Факты проката" (Rentals)
create table dbo.Rentals(
	Id        int   not null primary key identity(1,1),
	IdClient  int   not null, -- Внешний ключ. Связь с таблицей клиентов    (Clients)
	IdCar     int   not null, -- Внешний ключ. Связь с таблицей автомобилей (Cars)
	DateStart Date  not null, -- Дата начала проката
	Duration  int   not null, -- Количество дней проката

	constraint CK_Rentals_Duration check (Duration between 1 and 15),
	
	-- внешний ключ - связь М:1 к таблице Clients(клиенты)
	constraint FK_Rentals_Clients foreign key (IdClient) references dbo.Clients(Id), 
	
	-- внешний ключ - связь М:1 к таблице Cars(автомобили)
	constraint FK_Rentals_Cars foreign key (IdCar) references dbo.Cars(Id), 

);








