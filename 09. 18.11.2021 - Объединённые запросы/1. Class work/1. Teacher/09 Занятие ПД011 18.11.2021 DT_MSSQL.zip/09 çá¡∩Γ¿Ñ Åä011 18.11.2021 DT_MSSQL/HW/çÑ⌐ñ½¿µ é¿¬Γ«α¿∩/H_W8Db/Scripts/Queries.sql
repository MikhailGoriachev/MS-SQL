﻿-- База данных «Прокат автомобилей»

-- 1. Запрос с параметром
-- Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях
-- заданной модели (например, ВАЗ-2110)
declare @modelCar nvarchar(15) ='BMW'
select
   Models.Model
   , Colors.Color
   , Cars.CarNumber
   , Cars.[Year]
   , Cars.InsurancePay
   , Cars.PayRentalDay
from
   Cars join Models on Cars.IdModel = Models.Id
        join Colors on Cars.IdColor = Colors.Id
where
   Models.Model = @modelCar;
go


-- 2. Запрос с параметром
-- Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях,
-- изготовленных до заданного года (например, до 2016)
declare @yearCar int = 2019
select
   Models.Model
   , Colors.Color
   , Cars.CarNumber
   , Cars.[Year]
   , Cars.InsurancePay
   , Cars.PayRentalDay
from
   Cars join Models on Cars.IdModel = Models.Id
        join Colors on Cars.IdColor = Colors.Id
where
   Cars.[Year] < @yearCar;
go


-- 3. Запрос с параметром
-- Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях,
-- имеющих заданные модель и цвет,
-- изготовленных после заданного года
declare @yearCar int = 2017;
declare @modelCar nvarchar(10) ='Lexus', @colorCar nvarchar(15) = N'чёрный';
select
   Models.Model
   , Colors.Color
   , Cars.CarNumber
   , Cars.[Year]
   , Cars.InsurancePay
   , Cars.PayRentalDay
from
   Cars join Models on Cars.IdModel = Models.Id
        join Colors on Cars.IdColor = Colors.Id
where
   Models.Model = @modelCar and Colors.Color = @colorCar and Cars.[Year] > @yearCar;
go


-- 4. Запрос с параметром
-- Выбирает из таблицы АВТОМОБИЛИ информацию об автомобиле с заданным госномером.
declare @numCar nvarchar(15) = N'PE968C'
select
   Models.Model
   , Colors.Color
   , Cars.CarNumber
   , Cars.[Year]
   , Cars.InsurancePay
   , Cars.PayRentalDay
from
   Cars join Models on Cars.IdModel = Models.Id
        join Colors on Cars.IdColor = Colors.Id
where
  Cars.CarNumber = @numCar;
go


-- 5. Запрос с параметром
-- Выбирает из таблиц КЛИЕНТЫ, АВТОМОБИЛИ и ФАКТЫ_ПРОКАТА
-- информацию обо всех зафиксированных фактах проката автомобилей
-- (ФИО клиента, Модель автомобиля, Госномер автомобиля, дата проката)
-- в некоторый заданный интервал времени.
-- Нижняя и верхняя границы интервала задаются при выполнении запроса
declare @loDate date = '05-01-2021', @hiDate date = '10-01-2021';
select
   Clients.Surname
   , Clients.[Name]
   , Clients.Patronymic
   , Models.Model
   , Cars.CarNumber
   , Rentals.RentalStartDate
from
   Rentals join(Cars join Models on Cars.IdModel = Models.Id)
           on Rentals.IdCar = Cars.Id
           join Clients on Rentals.IdClient = Clients.Id
where
    Rentals.RentalStartDate between @loDate and @hiDate;
go


--6. Запрос с вычисляемыми полями
-- Вычисляет для каждого факта проката стоимость проката.
-- Включает поля Дата проката, Госномер автомобиля,
-- Модель автомобиля, Стоимость проката.
-- Сортировка по полю Дата проката
select
   Rentals.RentalStartDate
   , Cars.CarNumber
   , Models.Model
   -- Стоимость проката автомобиля определяется как 
   -- Стоимость одного дня проката * Количество дней проката. 
   , (Cars.PayRentalDay * Rentals.Duration) / 1.1 as CostRental
from
      Rentals join(Cars join Models on Cars.IdModel = Models.Id)
           on Rentals.IdCar = Cars.Id
order by
    Rentals.RentalStartDate;
go


-- 7. Запрос с левым соединением
-- Для всех автомобилей прокатной фирмы вычисляет
-- количество фактов проката,
-- сумму вырученную за прокаты
select
   Models.Model
   , Count(Rentals.Id) as AmountRental
   , Sum(Cars.PayRentalDay * Rentals.Duration) as SumRental
from
    Rentals left join(Cars join Models on Cars.IdModel = Models.Id)
            on Rentals.IdCar = Cars.Id
group by
    Models.Model
go


-- 8. Итоговый запрос
-- Выполняет группировку по полю Год выпуска автомобиля.
-- Для каждого года вычисляет минимальное и максимальное значения
-- по полю Стоимость одного дня проката
select
   Cars.[Year]
   , Min(Cars.PayRentalDay) as MinPayRentalDay
   , Max(Cars.PayRentalDay) as MaxPayRentalDay
from 
      Cars join Models on Cars.IdModel = Models.Id
        join Colors on Cars.IdColor = Colors.Id
group  by
   Cars.[Year];
go



-- 9. Запрос на добавление
-- Добавляет в таблицу ФАКТЫ_ПРОКАТА данные о факте проката.
-- Данные передавайте параметрами, используйте подзапросы
insert into Rentals
   (IdClient, IdCar, RentalStartDate, Duration)
values
   ((select Clients.Id from Clients where Surname = N'Котов'),
    (select Cars.Id from Cars join Models on Cars.IdModel = Models.Id
                    where Models.Model = 'Infiniti'),
    '10-01-2021', 10);


-- 10. Запрос на добавление
-- Добавляет в таблицу АВТОМОБИЛИ данные о новом автомобиле в прокатной фирме.
-- Данные автомобиля задавайте параметрами, используйте подзапросы.
declare @model nvarchar(10) = 'Audi', @color nvarchar(10) = N'белый',
@carNum nvarchar(10) = N'CI850O';
declare @year int = 2010, @insurance int = 2000, @payday int = 300;
insert into Cars
   (IdModel, IdColor, CarNumber, [Year], InsurancePay, PayRentalDay)
values 
   ((select Models.Id from Models where Model = @model),
    (select Colors.Id from Colors where Color = @color),
    @carNum, @year, @insurance, @payday);
go


-- 11. Запрос на удаление
-- Удаляет из таблицы ФАКТЫ_ПРОКАТА запись по идентификатору,
-- заданному параметром запроса
declare @identisicator int  = 4
delete from
   Rentals
where
   Rentals.Id = @identisicator;
go


-- 12. Запрос на удаление
-- Удаляет из таблицы ФАКТЫ_ПРОКАТА записи
-- за указанный период для заданного клиента.
delete from
   Rentals 
where
   Rentals.RentalStartDate between '05-01-2021' and '10-01-2021' and Rentals in 
       (select Clients.Surname from  Clients where Clients.Surname = N'Грибова');


-- 13. Запрос на обновление
-- Увеличивает значение в поле Стоимость одного дня проката на
-- заданное количество процентов для автомобилей,
-- изготовленных после заданного года
declare @percent int = 10, @year int = 2020;
update
   Cars
set 
   Cars.PayRentalDay *= (100 + @percent) / 100
where
   Cars.[Year] > @year;
go


-- 14. Запрос на обновление
-- Изменяет данные клиента по его идентификатору на указанные
-- в параметрах запроса значение
update
   Clients
set
   Clients.Surname = N'Иванов',
   Clients.[Name] = N'Иван',
   Clients.Patronymic = N'Иванович'
where
   Clients.Id = 5;





