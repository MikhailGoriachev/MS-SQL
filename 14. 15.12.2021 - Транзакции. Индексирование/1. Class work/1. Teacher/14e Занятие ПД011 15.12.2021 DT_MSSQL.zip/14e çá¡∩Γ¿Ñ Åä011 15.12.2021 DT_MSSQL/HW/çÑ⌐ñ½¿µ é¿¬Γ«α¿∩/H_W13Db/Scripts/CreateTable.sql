﻿-- База данных «Штатное расписание»

-- База данных должна включать как минимум таблицы
-- ПОДРАЗДЕЛЕНИЯ, ШТАТНЫЕ_ЕДИНИЦЫ, РАСПРЕДЕЛЕНИЕ_ШТАТНЫХ_ЕДИНИЦ,
-- содержащие следующую информацию:
-- *Наименование подразделения
-- *Тип подразделения (цех, отдел, бригада и т.д.)
-- *Процент_надбавки_1 (за вредные условия труда, зависит от подразделения,
-- принимает значения от 0 до 100%)
-- *Наименование штатной единицы
-- *Должностной оклад для данной штатной единицы
-- *Процент_надбавки_2 (за ненормированный рабочий день,
-- устанавливается для конкретной штатной единицы от 0 до 100%)
-- *Отпуск (количество дней отпуска в году, устанавливается для конкретной штатной единицы)
-- *Фамилия и инициалы персоны, которой распределена штатная единица конкретного подразделения

-- при повторном запуске скрипта удаляем старые варианты таблиц, не разбирая пустые они или нет
-- таблицы удаляем в порядке, обратном порядку создания
drop table if exists StaffingTable;
drop table if exists AllocationStaffUnits;
drop table if exists StuffUnits;
drop table if exists Subdivisions;
drop table if exists Persons;
drop table if exists TypesSubdivision;
drop table if exists NameStaffUnits;

-- таблица - персоны ФИО
CREATE TABLE [dbo].[Persons]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Surname] NVARCHAR(50) NOT NULL,    -- фамилия 
    [Name] NVARCHAR(40) NOT NULL,       -- имя
    [Patronymic] NVARCHAR(60) NOT NULL  -- отчество
);
go


-- таблица - тип подразделения
CREATE TABLE [dbo].[TypesSubdivision]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [NameSubdivision] NVARCHAR(50) NOT NULL    -- разновидность подразделений 
);
go


-- таблица - название штатной единицы
CREATE TABLE [dbo].[NameStaffUnits]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [NameStaffUnit] NVARCHAR(50) NOT NULL    -- название штатной единицы
);
go


-- таблица - подразделения
CREATE TABLE [dbo].[Subdivisions]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [IdTypeSubdivision] INT NOT NULL,    -- внешний ключ, ссылка на таблицу TypesSubdivision
    [PercentOfPremium1] INT NOT NULL,    -- процент надбавки 1 
    -- проверочное ограничение
    CONSTRAINT [CK_Subdivisions_PercentOfPremium1] CHECK ([PercentOfPremium1] between 0 and 100),
    -- внешние ключи
    CONSTRAINT [FK_Subdivisions_TypesSubdivision] FOREIGN KEY ([IdTypeSubdivision]) REFERENCES [TypesSubdivision]([Id])
);
go


-- таблица - штатные единицы
CREATE TABLE [dbo].[StuffUnits]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [IdTypeSubdivision] INT NOT NULL,    -- внешний ключ, ссылка на таблицу TypesSubdivision
    [IdNameStaffUnit] INT NOT NULL,      -- внешний ключ, ссылка на таблицу NameStaffUnits
    [Salary] INT NOT NULL,               -- должностной оклад для данной штатной единицы
    [PercentOfPremium2] INT NOT NULL,    -- процент надбавки 2
    [Vacation] INT NOT NULL,             -- отпуск(количество дней для каждой штатной единицы)
    [Discharge] NVARCHAR(15) NOT NULL,   -- разряд штатной единицы
    -- проверочное ограничение
    CONSTRAINT [CK_StuffUnits_Salary] CHECK ([Salary] >= 0),
    CONSTRAINT [CK_StuffUnits_PercentOfPremium2] CHECK ([PercentOfPremium2] between 0 and 100),
    CONSTRAINT [CK_StuffUnits_Vacation] CHECK ([Vacation] <= 24),
    -- внешние ключи
    CONSTRAINT [FK_StuffUnits_TypesSubdivision] FOREIGN KEY ([IdTypeSubdivision]) REFERENCES [TypesSubdivision]([Id]),
    CONSTRAINT [FK_StuffUnits_NameStaffUnits] FOREIGN KEY ([IdNameStaffUnit]) REFERENCES [NameStaffUnits]([Id])
);
go


-- таблица - распределение штатных единиц
CREATE TABLE [dbo].[AllocationStaffUnits]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [IdSubdivision] INT NOT NULL,    -- внешний ключ, ссылка на таблицу Subdivisions
    [IdStuffUnit] INT NOT NULL,      -- внешний ключ, ссылка на таблицу StuffUnitns
    [AmountStaffUnit] INT NOT NULL,  -- количество штатных единиц
    -- внешние ключи
    CONSTRAINT [FK_AllocationStaffUnits_Subdivisions] FOREIGN KEY ([IdSubdivision]) REFERENCES [Subdivisions]([Id]),
    CONSTRAINT [FK_AllocationStaffUnits_StuffUnits] FOREIGN KEY ([IdStuffUnit]) REFERENCES [StuffUnits]([Id])
);
go


-- таблица - штатное расписание
CREATE TABLE [dbo].[StaffingTable]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [IdSubdivision] INT NOT NULL,    -- внешний ключ, ссылка на таблицу Subdivisions
    [IdStuffUnit] INT NOT NULL,      -- внешний ключ, ссылка на таблицу StuffUnitns
    [IdPersone] INT NOT NULL,        -- внешний ключ, ссылка на таблицу Persons
    -- внешние ключи
    CONSTRAINT [FK_StaffingTable_Subdivisions] FOREIGN KEY ([IdSubdivision]) REFERENCES [Subdivisions]([Id]),
    CONSTRAINT [FK_StaffingTable_StuffUnits] FOREIGN KEY ([IdStuffUnit]) REFERENCES [StuffUnits]([Id]),
    CONSTRAINT [FK_StaffingTable_Persons] FOREIGN KEY ([IdPersone]) REFERENCES [Persons]([Id])
);
go