﻿--СОЗДАНИЕ ПРОЦЕДУР И ФУНКЦИЙ

--Заработная плата для каждой штатной единицы вычисляется 
--как Оклад *(1+ Процент надбавки за вредные условия труда + 
--Процент надбавки за ненормированный рабочий день).
--С начисленной заработной платы вычитается подоходный налог,
--равный 13 процентам от размера начисления.
--Функция для рассчета з/п без вычета налога
create function GetSalary(@sal int, @perc1 int, @perc2 int)
returns int
as
begin
	return @sal + ((@perc1 + @perc2) * @sal /100)
end
go

--1 Хранимая процедура	
--Выбирает из таблицы ПОДРАЗДЕЛЕНИЯ информацию о подразделениях, 
--имеющих тип «бухгалтерия» или «цех», для которых Процент_надбавки_1 
--больше значения, заданного параметром
create proc ShowUnitsByType
		@perc int
as
begin
	select
		ViewDistribUnits.Тип
		,ViewDistribUnits.Отдел
		,ViewDistribUnits.Процент1
	from ViewDistribUnits
	where ViewDistribUnits.Тип in (N'Цех', N'Бухгалтерия')
			and ViewDistribUnits.Процент1 > @perc
end
go
--2 Хранимая процедура	
--Выбирает из таблицы ШТАТНЫЕ_ЕДИНИЦЫ информацию о штатных единицах 
--с окладом в заданном диапазоне и значением в поле Процент_надбавки_2 
--также равным заданному. Диапазон оклада и процент надбавки задавать параметрами
create proc ShowStaffUnitsBySalary
		@perc int
		,@lo int
		,@hi int
as
begin
	select
		ViewDistribUnits.Должность
		,ViewDistribUnits.Фамилия
		,ViewDistribUnits.Имя
		,ViewDistribUnits.Отчество
		,ViewDistribUnits.[Оклад, р.]
		,ViewDistribUnits.Разряд
		,ViewDistribUnits.Процент2
		,ViewDistribUnits.[Отпуск, д.]
	from ViewDistribUnits
	where ViewDistribUnits.[Зарплата, р.] between @lo and @hi
			and ViewDistribUnits.Процент2 = @perc
end
go
--3 Однотабличная функция	
--Выбирает из таблицы ПОДРАЗДЕЛЕНИЯ информацию о подразделениях, для 
--которых тип подразделения равен заданному параметром или 
--Процент_надбавки_1 равен заданному параметром
create function ShowUnitByTypeOrPercent(@type nvarchar(80), @perc int)
returns table
as
return
(
	select
		ViewDistribUnits.Тип
		,ViewDistribUnits.Отдел
		,ViewDistribUnits.Процент1
	from ViewDistribUnits
	where ViewDistribUnits.Тип = @type
			or ViewDistribUnits.Процент1 = @perc
)
go
	
--4 Хранимая процедура	
--Выбирает из таблицы ШТАТНЫЕ_ЕДИНИЦЫ информацию о штатных единицах 
--с заданным параметром наименованием и заданной параметром величиной оклада
create proc ShowStaffUnitsByPositionNSalary
		@pos nvarchar(80)
		,@sal int
as
begin
	select
		ViewDistribUnits.Должность
		,ViewDistribUnits.Фамилия
		,ViewDistribUnits.Имя
		,ViewDistribUnits.Отчество
		,ViewDistribUnits.[Оклад, р.]
		,ViewDistribUnits.Разряд
		,ViewDistribUnits.Процент2
		,ViewDistribUnits.[Отпуск, д.]
	from ViewDistribUnits
	where ViewDistribUnits.[Зарплата, р.] = @sal
			and ViewDistribUnits.Должность = @pos
end
go
--5 Однотабличная функция	
--Выбирает из таблицы ШТАТНЫЕ_ЕДИНИЦЫ информацию о штатных единицах, 
--имеющих заданное параметром наименование, для которых Процент_надбавки_2 
--имеет значение из некоторого заданного диапазона. Нижняя и верхняя
--границы диапазона также задаются параметрами функции
create function ShowStaffUnitsByPosNPerc(@pos nvarchar(80), @lo int, @hi int)
returns table
as
return
(
	select
		ViewDistribUnits.Должность
		,ViewDistribUnits.Фамилия
		,ViewDistribUnits.Имя
		,ViewDistribUnits.Отчество
		,ViewDistribUnits.[Оклад, р.]
		,ViewDistribUnits.Разряд
		,ViewDistribUnits.Процент2
		,ViewDistribUnits.[Отпуск, д.]
	from ViewDistribUnits
	where ViewDistribUnits.Должность = @pos
			and ViewDistribUnits.Процент2 between @lo and @hi
)
go
--6 Однотабличная функция	
--Вычисляет размер подоходного налога с начисленной заработной платы для
--каждой распределенной штатной единицы в соответствии с таблицей РАСПРЕДЕЛЕНИЕ_ШТАТНЫХ_ЕДИНИЦ. 
--Включает поля Наименование подразделения, Наименование единицы, Оклад,
--Процент_надбавки_1, Процент_надбавки_2, Размер зарплаты, Налог. 
--Сортировка по полю Наименование подразделения
alter function ShowDistribUnitsTax()
returns table
as
return
(
	select top (select COUNT(*) from ViewDistribUnits)
		ViewDistribUnits.Отдел
		,ViewDistribUnits.Фамилия
		,ViewDistribUnits.Имя
		,ViewDistribUnits.Отчество
		,ViewDistribUnits.Процент1
		,ViewDistribUnits.Процент2
		,ViewDistribUnits.[Оклад, р.]
		,dbo.GetSalary(ViewDistribUnits.[Оклад, р.],ViewDistribUnits.Процент1,ViewDistribUnits.Процент2) as Зарплата
		--,0.13 * Зарплата  as Налог
		,0.13 * dbo.GetSalary(ViewDistribUnits.[Оклад, р.],ViewDistribUnits.Процент1,ViewDistribUnits.Процент2) as Налог
	from ViewDistribUnits
	order by ViewDistribUnits.Отдел
	
)
go
--7 Однотабличная функция	
--Выполняет группировку по полю Тип подразделения в таблице ПОДРАЗДЕЛЕНИЯ. 
--Для каждой группы вычисляет среднее значение по полю Процент_надбавки_1
create function ShowAvgPerc1()
returns table
as 
return
(
	select
		ViewDistribUnits.Тип
		,AVG(ViewDistribUnits.Процент1) as [Средний процент]
	from ViewDistribUnits
	group by ViewDistribUnits.Тип
)
go
--8 Однотабличная функция	
--Выполняет группировку по полю Наименование штатной единицы в таблице 
--ШТАТНЫЕ_ЕДИНИЦЫ. Для каждой группы вычисляет минимальное и максимальное 
--значения по полю Отпуск
create function ShowVacation()
returns table
as 
return
(
	select
		ViewDistribUnits.Должность
		,min(ViewDistribUnits.[Отпуск, д.]) as [Минимальный отпуск]
		,min(ViewDistribUnits.[Отпуск, д.]) as [Максимальный отпуск]
	from ViewDistribUnits
	group by ViewDistribUnits.Должность
)
go
--9 Запрос на создание базовой таблицы (просто запрос)	
--Создает таблицу ШТАТНЫЕ_ЕДИНИЦЫ_ИНЖЕНЕР, содержащую информацию о 
--штатных единицах с наименованием «инженер»
--10 Хранимая процедура	
--Создает копию таблицы ПОДРАЗДЕЛЕНИЯ с именем КОПИЯ_ПОДРАЗДЕЛЕНИЯ
--11 Хранимая процедура	
--Удаляет из таблицы КОПИЯ_ПОДРАЗДЕЛЕНИЯ записи, в которых значение в 
--поле Процент_надбавки_1 меньше заданного значения
--12 Хранимая процедура	
--Увеличивает значение в поле Процент_надбавки_1 таблицы КОПИЯ_ПОДРАЗДЕЛЕНИЯ 
--на заданное параметром значение для заданного параметром подразделения
