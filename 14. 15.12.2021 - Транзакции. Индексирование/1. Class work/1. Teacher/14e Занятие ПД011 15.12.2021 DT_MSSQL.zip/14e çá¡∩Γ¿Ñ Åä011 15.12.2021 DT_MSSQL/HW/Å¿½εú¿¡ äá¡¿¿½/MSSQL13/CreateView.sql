﻿drop view if exists ViewDistribUnits
go

--создание представления распределения штатных едениц
create view ViewDistribUnits
as
	select
		UnitTypes.[Type]     as Тип
		,Units.NameUnit		 as Отдел
		,Units.Percent1		 as Процент1
		,Positions.Position	 as Должность
		,Persons.Surname	 as Фамилия
		,Persons.[Name]		 as Имя
		,Persons.Patronymic	 as Отчество
		,StaffUnits.[Rank]	 as Разряд
		,StaffUnits.Salary	 as [Оклад, р.]
		,StaffUnits.Percent2 as Процент2
		,StaffUnits.Vacation as [Отпуск, д.]
	from DistribUnits join (Units join UnitTypes on Units.idType = UnitTypes.Id)
							on DistribUnits.idUnit = Units.Id
					  join (StaffUnits join Positions on StaffUnits.idPosition = Positions.Id
										join Persons on StaffUnits.idPerson = Persons.Id)
							on DistribUnits.idStaffUnit = StaffUnits.Id;
go