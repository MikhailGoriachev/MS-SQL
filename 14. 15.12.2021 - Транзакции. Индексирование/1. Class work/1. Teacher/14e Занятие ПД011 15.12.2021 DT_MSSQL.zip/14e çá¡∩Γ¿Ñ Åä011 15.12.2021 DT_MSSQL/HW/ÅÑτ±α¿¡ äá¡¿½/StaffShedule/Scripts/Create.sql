﻿-- База данных «Штатное расписание»

--Описание предметной области:
--При составлении штатного расписания имеющиеся в организации штатные единицы 
--распределяются по подразделениям. Каждая штатная единица характеризуется 
--названием должности, размером должностного оклада, процентом надбавки за 
--ненормированный рабочий день. Каждое подразделение характеризуется 
--наименованием, типом, процентом надбавки за вредные условия труда.
--Заработная плата для каждой штатной единицы вычисляется как Оклад *(1+ 
--Процент надбавки за вредные условия труда + Процент надбавки за 
--ненормированный рабочий день). С начисленной заработной платы вычитается 
--подоходный налог, равный 13 процентам от размера начисления.

drop table if exists StaffUnits

--Тип подразделения 
create table [dbo].[DivisionTypes] (
   Id int not null Primary key Identity(1,1),  
   DivisionTypeName nvarchar(60) not null,  -- название типа подразделения
);
go

--Тип Штатной единицы 
create table [dbo].[StaffUnitTypes] 
(
      Id int not null Primary key Identity(1,1),
      StaffUnitName nvarchar(60) not null,  -- название штатной единицы
);
go

--Подразделение 
create table [dbo].[Divisions] 
(
   Id int not null Primary key Identity(1,1),
   IdDivisionType int not null, 
   DivisionName nvarchar(60) not null,  -- название подразделения
   SalaryPerk float not null,           -- надбавка за вредные условия труда

   constraint FK_Divions_DivisionTypes foreign key (IdDivisionType) references dbo.DivisionTypes(Id) 
); 
 go

--Распределение штаных единиц 
create table [dbo].[StaffDistribution] 
(
   Id int not null Primary key Identity(1,1),
   IdDivision int not null, 
   IdStaffUnit int not null, 
   NumberOfUnits int not null, 

   constraint FK_StaffDistribution_Divisions foreign key (IdDivision) references dbo.Divisions(Id),
   constraint FK_StaffUnit_StaffUnitTypes foreign key (IdStaffUnit) references dbo.StaffUnits(Id)

);
go 

--Штатные единицы

create table [dbo].[StaffUnits] 
(
     Id int not null Primary key Identity(1,1), 
     IdStaffUnitTypes int not null,
     Salary int not null, 
     Grade nvarchar(20) not null,  -- разряд
     SalaryPerk2 float not null,   -- надбавка за ненормированный рабочий день 
     Leave int not null,           -- количество дней отпуска в году 
);
go 

--Персоны 
create table [dbo].[Persons] 
(
      Id int not null Primary key Identity(1,1), 
      Surname nvarchar(60) not null, 
      [Name] nvarchar(60) not null, 
      Patronymic nvarchar(60) not null, 
);
go

--Штатное расписание 
create table [dbo].[Shedule] 
(
    IdDivision int not null, 
    IdPerson int not null, 
    IdStaffUnits int not null, 

    constraint FK_Shedule_Division foreign key (IdDivision) references dbo.Divisions(Id),
    constraint FK_Shedule_Person foreign key (IdPerson) references dbo.Persons(Id), 
    constraint FK_Shedule_StaffUnits foreign key (IdStaffUnits) references dbo.StaffUnits(Id)
);
 go

