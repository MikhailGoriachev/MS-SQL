﻿/* 
 * База данных «Штатное расписание»
 */

-- создание таблиц базы данных


drop table if exists StaffingTable;
drop table if exists DistributionStaffUnits;
drop table if exists StaffUnits;
drop table if exists Units;
drop table if exists Positions;
drop table if exists TypesOfUnits;   
drop table if exists Persons;  

-- таблица персональных данных
create table dbo.Persons (
	Id          int          not null primary key identity (1, 1),
	Surname     nvarchar(60) not null,    -- Фамилия 
	[Name]      nvarchar(50) not null,    -- Имя 
	Patronymic  nvarchar(60) not null,    -- Отчество 
);
go

-- таблица типов подразделений
create table dbo.TypesOfUnits(
	Id          int          not null primary key identity (1, 1),
	[Type]      nvarchar(30) not null -- тип подразделения
);
go

-- таблица должностей
create table dbo.Positions(
	Id          int          not null primary key identity (1, 1),
	Position    nvarchar(30) not null -- должность
);
go


-- таблица подразделений
create table dbo.Units(
	Id          int           not null primary key identity (1, 1),
	IdType      int           not null, -- внешнией ключ, ссылка на TypesOfUnits, тип подразделения
	Title       nvarchar(120) not null, -- наименование подразделения
	[Percent]   float         not null, -- процент надбавки

	-- внешний ключ
	constraint FK_Units_TypesOfUnits foreign key (IdType) references dbo.TypesOfUnits(Id),
	
	-- процент надбавки принимает значения от 0 до 100%)
	constraint СK_Units_Percent check ([Percent] between 0 and 100)
);
go


-- таблица штатных единиц
create table dbo.StaffUnits(
	Id          int          not null primary key identity (1, 1),
	IdPosition  int          not null, -- внешнией ключ, ссылка на Positions, должность
	Salary      int          not null, -- оклад 
	category    nvarchar(30) not null, -- разряд
	[Percent]   float        not null, -- процент надбавки
	Vacation    int          not null, -- количество дней отпуска в году

	-- внешний ключ
	constraint FK_StaffUnits_Positions foreign key (IdPosition) references dbo.Positions(Id),

	-- ограничения по значением полей/столбцов
	-- процент надбавки принимает значения от 0 до 100%)
	constraint СK_StaffUnits_Percent check ([Percent] between 0 and 100),
	constraint СK_StaffUnits_Vacation check (Vacation > 0)
);
go


-- таблица распределения штатных единиц
create table dbo.DistributionStaffUnits(
	Id          int          not null primary key identity (1, 1),
	IdUnit      int          not null, -- внешнией ключ, ссылка на Units, подразделение
	IdStaffUnit int          not null, -- внешнией ключ, ссылка на StaffUnit, штатная единица
	Amount      int          not null, -- количество

	-- внешние ключи
	constraint FK_DistributionStaffUnits_StaffUnits foreign key (IdStaffUnit) references dbo.StaffUnits(Id),
	constraint FK_DistributionStaffUnits_Units foreign key (IdUnit) references dbo.Units(Id),

	-- ограничения по значением полей/столбцов
	constraint СK_DistributionStaffUnits_Amount check (Amount > 0)
);
go


-- таблица штатного расписания
create table dbo.StaffingTable(
	Id          int          not null primary key identity (1, 1),
	IdUnit      int          not null, -- внешнией ключ, ссылка на Units, подразделение
	IdStaffUnit int          not null, -- внешнией ключ, ссылка на StaffUnit, штатная единица
	IdPerson    int          not null, -- внешнией ключ, ссылка на Persons, персональные данные 

	-- внешние ключи
	constraint FK_StaffingTable_StaffUnits foreign key (IdStaffUnit) references dbo.StaffUnits(Id),
	constraint FK_StaffingTable_Units      foreign key (IdUnit)      references dbo.Units(Id),
	constraint FK_StaffingTable_Persons    foreign key (IdPerson)    references dbo.Persons(Id)
);
go

-- представление подразделений
drop view if exists ViewUnits;
go

create view ViewUnits as
    select distinct
        Units.Title    
		, TypesOfUnits.[Type]
		, Units.[Percent]
		, Units.Id
from
    Units join TypesOfUnits on Units.IdType = TypesOfUnits.Id;
go


-- представление штатных единиц
drop view if exists ViewStaffUnits;
go

create view ViewStaffUnits as
    select distinct
        StaffUnits.category   
		, Positions.Position
		, StaffUnits.Id
		, StaffUnits.[Percent]
		, StaffUnits.Salary
		, StaffUnits.Vacation
from
    StaffUnits join Positions on StaffUnits.IdPosition = Positions.Id;
go


-- представление распределения штатных единиц
drop view if exists ViewDistrStaffUnits;
go

create view ViewDistrStaffUnits as
    select distinct
        DistributionStaffUnits.Amount  
		, ViewStaffUnits.category   
		, ViewStaffUnits.Position
		, ViewStaffUnits.[Percent] as Percent_1
		, ViewStaffUnits.Salary
		, ViewStaffUnits.Vacation
		, ViewUnits.Title          as TitleUnit
		, ViewUnits.[Type]         as UnitType
		, ViewUnits.[Percent]      as Percent_2
from
    DistributionStaffUnits join ViewUnits on DistributionStaffUnits.IdUnit = ViewUnits.Id
                           join ViewStaffUnits on DistributionStaffUnits.IdStaffUnit = ViewStaffUnits.Id;
go


-- представление штатного расписания
drop view if exists ViewStaffingTable;
go

create view ViewStaffingTable as
    select distinct
        Persons.[Name]
		, Persons.Patronymic
		, Persons.Surname
		, ViewStaffUnits.category   
		, ViewStaffUnits.Position
		, ViewStaffUnits.[Percent] as Percent_1
		, ViewStaffUnits.Salary
		, ViewStaffUnits.Vacation
		, ViewUnits.Title          as TitleUnit
		, ViewUnits.[Type]         as UnitType
		, ViewUnits.[Percent]      as Percent_2
from
     StaffingTable join ViewUnits      on StaffingTable.IdUnit = ViewUnits.Id
                   join ViewStaffUnits on StaffingTable.IdStaffUnit = ViewStaffUnits.Id
                   join Persons        on StaffingTable.IdPerson = Persons.Id;
go