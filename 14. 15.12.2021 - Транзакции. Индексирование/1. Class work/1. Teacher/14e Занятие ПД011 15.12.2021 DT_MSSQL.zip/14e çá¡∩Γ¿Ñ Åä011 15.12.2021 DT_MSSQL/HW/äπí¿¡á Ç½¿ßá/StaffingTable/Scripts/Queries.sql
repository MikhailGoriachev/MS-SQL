﻿-- 1. Хранимая процедура	
--    Выбирает из таблицы ПОДРАЗДЕЛЕНИЯ информацию о подразделениях,
--    имеющих тип «отдел» или «цех», для которых Процент_надбавки_1 
--    больше значения, заданного параметром
drop proc if exists ProcQuery01;
go

create proc ProcQuery01
    @percent float
as
begin
    select
        ViewUnits.Id
        , ViewUnits.[Title]
        , ViewUnits.[Type]
        , ViewUnits.[Percent]
    from
        ViewUnits
    where
        [Percent] > @percent
        and ViewUnits.[Type] in (N'отдел', N'цех');
end;
go

-- выполнение
declare @percent float = 4.;
exec dbo.ProcQuery01 @percent;

set @percent = 2.;
exec dbo.ProcQuery01 @percent;

set @percent = 5.;
exec dbo.ProcQuery01 @percent;


-- 2. Хранимая процедура	
--    Выбирает из таблицы ШТАТНЫЕ_ЕДИНИЦЫ информацию о штатных единицах 
--    с окладом в заданном диапазоне и значением в поле Процент_надбавки_2 
--    также равным заданному. Диапазон оклада и процент надбавки задавать параметрами
drop proc if exists ProcQuery02;
go

create proc ProcQuery02
    @percent float,
    @loSalary int,
    @hiSalary int
as
begin
    select
        ViewStaffUnits.Id
        , ViewStaffUnits.Position
        , ViewStaffUnits.category
        , ViewStaffUnits.Salary
        , ViewStaffUnits.[Percent]
        , ViewStaffUnits.Vacation
    from
        ViewStaffUnits
    where
        [Percent] = @percent and Salary between @loSalary and @hiSalary;
end;
go

-- выполнение
declare @percent float = 5., @loSalary int = 10000, @hiSalary int = 25000;
exec dbo.ProcQuery02 @percent, @loSalary, @hiSalary;

set @percent = 4.1; set  @loSalary = 21500; set @hiSalary = 90000;
exec dbo.ProcQuery02 @percent, @loSalary, @hiSalary;

set @percent = 4.6; set  @loSalary = 15000; set @hiSalary = 30000;
exec dbo.ProcQuery02 @percent, @loSalary, @hiSalary;


-- 3. Однотабличная функция
--    Выбирает из таблицы ПОДРАЗДЕЛЕНИЯ информацию о подразделениях,
--    для которых тип подразделения равен заданному параметром или
--    Процент_надбавки_1 равен заданному параметром 
drop function if exists FuncQuery03;
go

create function FuncQuery03(@type nvarchar(30), @percent float) returns table
as
return
    select 
        ViewUnits.Id
        , ViewUnits.Title
        , ViewUnits.[Percent]
        , ViewUnits.[Type]
    from
        ViewUnits
    where
        [Type] = @type or [Percent] = @percent;
go

declare @type nvarchar(30) = N'цех', @percent float = 2.;
select * from dbo.FuncQuery03(@type, @percent);
go

declare @type nvarchar(30) = N'отдел', @percent float = 6.;
select * from dbo.FuncQuery03(@type, @percent);
go

declare @type nvarchar(30) = N'департамент', @percent float = 4.;
select * from dbo.FuncQuery03(@type, @percent);
go


-- 4. Хранимая процедура	
--    Выбирает из таблицы ШТАТНЫЕ_ЕДИНИЦЫ информацию о штатных единицах
--    с заданным параметром наименованием и заданной параметром величиной оклада
drop proc if exists ProcQuery04;
go

create proc ProcQuery04
    @position nvarchar(30),
    @Salary int
as
begin
    select
        ViewStaffUnits.Id
        , ViewStaffUnits.Position
        , ViewStaffUnits.category
        , ViewStaffUnits.Salary
        , ViewStaffUnits.[Percent]
        , ViewStaffUnits.Vacation
    from
        ViewStaffUnits
    where
        Position = @position and Salary = @Salary;
end;
go

-- выполнение
declare @position nvarchar(30) = N'директор', @Salary int = 90000;
exec dbo.ProcQuery04 @position, @Salary;

set @position = N'закройщик'; set  @Salary = 25000;
exec dbo.ProcQuery04 @position, @Salary;

set @position = N'уборщик'; set  @Salary = 15000;
exec dbo.ProcQuery04 @position, @Salary;


-- 5. Однотабличная функция	
--    Выбирает из таблицы ШТАТНЫЕ_ЕДИНИЦЫ информацию о штатных единицах,
--    имеющих заданное параметром наименование, для которых Процент_надбавки_2 
--    имеет значение из некоторого заданного диапазона. 
--    Нижняя и верхняя границы диапазона также задаются параметрами функции
drop function if exists FuncQuery05;
go

create function FuncQuery05(@position nvarchar(30), @loPercent float, @hiPercent float) returns table
as
return
    select
        ViewStaffUnits.Id
        , ViewStaffUnits.Position
        , ViewStaffUnits.category
        , ViewStaffUnits.Salary
        , ViewStaffUnits.[Percent]
        , ViewStaffUnits.Vacation
    from
        ViewStaffUnits
    where
        Position = @position and [Percent] between @loPercent and @hiPercent;
go

declare @position nvarchar(30) = N'технолог', @loPercent float = 2., @hiPercent float = 4.9;
select * from dbo.FuncQuery05(@position, @loPercent, @hiPercent);
go

declare @position nvarchar(30) = N'швея', @loPercent float = 4.2, @hiPercent float = 5;
select * from dbo.FuncQuery05(@position, @loPercent, @hiPercent);
go

declare @position nvarchar(30) = N'медсестра', @loPercent float = 4.8, @hiPercent float = 5;
select * from dbo.FuncQuery05(@position, @loPercent, @hiPercent);
go


-- 6. Однотабличная функция
--    Вычисляет размер подоходного налога с начисленной заработной платы
--    для каждой распределенной штатной единицы в соответствии с таблицей 
--    РАСПРЕДЕЛЕНИЕ_ШТАТНЫХ_ЕДИНИЦ. 
--    Включает поля Наименование подразделения, Наименование единицы, Оклад, 
--    Процент_надбавки_1, Процент_надбавки_2, Размер зарплаты, Налог. 
--    Сортировка по полю Наименование подразделения
drop function if exists FuncQuery06;
go

create function FuncQuery06() returns table
as
return
    select 
        TitleUnit
        , Position
        , Salary
        , Percent_1
        , Percent_2
        -- Заработная плата = Оклад * ( 1+ Процент надбавки за вредные условия труда + Процент надбавки за ненормированный рабочий день). 
        , Salary * (1 + Percent_1/ 100 + Percent_2 / 100) as Wage
        -- подоходный налог = 13 процентам от размера начисления
        , Salary * (1 + Percent_1/ 100 + Percent_2 / 100) * 0.87 as IncomeTax
    from
        ViewDistrStaffUnits;
go

select * from dbo.FuncQuery06();


-- 7. Однотабличная функция	
--    Выполняет группировку по полю Тип подразделения в таблице ПОДРАЗДЕЛЕНИЯ. 
--    Для каждой группы вычисляет среднее значение по полю Процент_надбавки_1
drop function if exists FuncQuery07;
go

create function FuncQuery07() returns table
as
return
    select 
        ViewUnits.[Type]
        , MIN([Percent]) as MinPercent
        , MAX([Percent]) as MaxPercent
        , AVG([Percent]) as AvgPercent
    from
        ViewUnits
    group by
        [Type];
go

select * from dbo.FuncQuery07();

-- 8. Однотабличная функция	
--    Выполняет группировку по полю Наименование штатной единицы в таблице ШТАТНЫЕ_ЕДИНИЦЫ.
--    Для каждой группы вычисляет минимальное и максимальное значения по полю Отпуск
drop function if exists FuncQuery08;
go

create function FuncQuery08() returns table
as
return
    select
        Position
        , MIN(Vacation) as MinVacation
        , MAX(Vacation) as MaxVacation
    from
        ViewStaffUnits
    group by
        Position;
go

select * from dbo.FuncQuery08();


-- 9. Запрос на создание базовой таблицы (просто запрос)	
--    Создает таблицу ШТАТНЫЕ_ЕДИНИЦЫ_ИНЖЕНЕР, содержащую информацию о штатных единицах
--    с наименованием «инженер»
drop table if exists Staff_Units_Engineer;

declare @position nvarchar(30) = N'инженер';
select 
	*
	into Staff_Units_Engineer
from 
	StaffUnits
where 
    IdPosition = (select Id from Positions where Position = @position);
go


-- 10. Хранимая процедура	
--     Создает копию таблицы ПОДРАЗДЕЛЕНИЯ с именем КОПИЯ_ПОДРАЗДЕЛЕНИЯ
drop proc if exists ProcQuery10;
go

create proc ProcQuery10
as
begin
    drop table if exists Copy_Units;
    select 
    	*
    	into Copy_Units
    from 
    	Units;
end;
go

-- выполнение
exec dbo.ProcQuery10;


-- 11. Хранимая процедура	
--     Удаляет из таблицы КОПИЯ_ПОДРАЗДЕЛЕНИЯ записи, в которых значение в 
--     поле Процент_надбавки_1 меньше заданного значения
drop proc if exists ProcQuery11;
go

create proc ProcQuery11
    @percent float
as
begin
    delete from 
        Copy_Units
    where
        Copy_Units.[Percent] < @percent;
end;
go

-- выполнение
declare @percent float = 2.;
exec dbo.ProcQuery11 @percent;

set @percent = 4.;
exec dbo.ProcQuery11 @percent;

set @percent = 5.;
exec dbo.ProcQuery11 @percent;


-- 12. Хранимая процедура	
--     Увеличивает значение в поле Процент_надбавки_1 таблицы КОПИЯ_ПОДРАЗДЕЛЕНИЯ 
--     на заданное параметром значение для заданного параметром подразделения
drop proc if exists ProcQuery12;
go

create proc ProcQuery12
    @title nvarchar(30),
    @percent float
as
begin
    update 
        Copy_Units
    set
        [Percent] += @percent
    from
        Copy_Units
    where
        Copy_Units.Title = @title;
end;
go

-- выполнение
declare @title nvarchar(30) = N'Бухгалтерния', @percent float = 0.1;
exec dbo.ProcQuery12 @title, @percent;

set @title = N'Медпункт'; set  @percent = 0.3;
exec dbo.ProcQuery12 @title, @percent;

set @title = N'Дирекция швейной фабрики'; set  @percent = 0.5;
exec dbo.ProcQuery12 @title, @percent;