﻿drop table if exists dbo.Schedule;
drop table if exists dbo.StaffAllocations;
drop table if exists dbo.Units;
drop table if exists dbo.Divisions;
drop table if exists dbo.DivTypes;
drop table if exists dbo.Positions;
drop table if exists dbo.Persons;

-- таблица личных данных
create table dbo.Persons (
	Id          int          not null primary key identity (1, 1),
	[Name]      nvarchar(60) not null,    -- Имя персоны
	Surname     nvarchar(60) not null,    -- Фамилия персоны
	Patronymic  nvarchar(60) not null,    -- Отчество персоны
);
go

-- названия должностей
create table dbo.Positions(
	Id          int          not null primary key identity (1, 1),
	Position	nvarchar(30) not null
);
go

-- типы подразделений
create table dbo.DivTypes (
	Id          int          not null primary key identity (1, 1),
	Type		nvarchar(60) not null
);
go

-- таблица подразделений
create table dbo.Divisions(
	Id          int          not null primary key identity (1, 1),
	Name		nvarchar(60) not null, -- наименование подразделения
	IdType		int			 not null, -- тип подразделения, внешний ключ к таблице типов подразделений
	SalaryPerks float		 not null  -- Процент_надбавки_1 (за вредные условия труда, зависит от подразделения, принимает значения от 0 до 100%) 

	constraint CK_Divisions_SalaryPerks check (SalaryPerks >= 0 and SalaryPerks <= 100),

	constraint FK_Divisions_DivTypes foreign key (IdType) references dbo.DivTypes(Id)
);
go


-- таблица штатных единиц
create table dbo.Units(
	Id				int				not null primary key identity (1, 1),
	IdType			int				not null,  -- вид должности
	Salary			int				not null,  -- оклад
	[Rank]			nvarchar(20)	not null,  -- разряд
	SalaryPerks		float			not null,  -- Процент_надбавки_2 (за ненормированный рабочий день, устанавливается для конкретной штатной единицы от 0 до 100%) 
	VacationDays	int				not null,  -- количество дней отпуска в году, устанавливается для конкретной штатной единицы

	constraint CK_Units_SalaryPerks check (SalaryPerks >= 0 and SalaryPerks <= 100),
	constraint CK_Units_VacationDays check (VacationDays >= 0),

	constraint FK_Units_Positions foreign key (IdType) references dbo.Positions(Id)
);
go


-- таблица штатных распределений
create table dbo.StaffAllocations(
	Id				int         not null primary key identity (1, 1),
	IdDivision		int			not null,  -- идентификатор отдела, внешний ключ
	IdUnit			int			not null,  -- идентификатор должности, внешний ключ
	IdPerson		int			not null   -- идентификатор персоны, внешний ключ

	constraint FK_Schedule_Divisions foreign key (IdDivision) references dbo.Divisions(Id),
	constraint FK_Schedule_Units foreign key (IdUnit) references dbo.Units(Id),
	constraint FK_Schedule_Persons foreign key (IdPerson) references dbo.Persons(Id)
);
go



-- представление для таблицы штатных распределний
drop view if exists ViewAllocations;
go
create view ViewAllocations as
	select 
		Persons.Surname + N' ' + Substring(Persons.[Name], 1, 1) 
				  + N'.' + Substring(Persons.Patronymic, 1, 1) 
				  + N'.' as Staff  -- Фамилия И.О. персонала
		, Position									-- должность
		, Divisions.Name  as DivisionName           -- наименование подразделения
		, DivTypes.Type as DivisionType				-- тип подразделения
		, Salary									-- оклад
		, Rank										-- ранг
		, Divisions.SalaryPerks as SalaryPerks1		-- надбавка к зарплате 1
		, Units.SalaryPerks as SalaryPerks2			-- надбавка к зарплате 2
		, VacationDays								-- количество дней отпуска
		, Salary * (1 + Divisions.SalaryPerks/100 + Units.SalaryPerks/100) as AccruedWages    -- начислено оплаты
		, Salary * (1 + Divisions.SalaryPerks/100 + Units.SalaryPerks/100) * 0.13 as Tax	  -- подоходный налог

	from StaffAllocations join (Divisions join DivTypes on Divisions.IdType = DivTypes.Id) on IdDivision = Divisions.Id
						  join (Units join Positions on Units.IdType = Positions.Id) on IdUnit = Units.Id
						  join Persons on IdPerson = Persons.Id;
go




