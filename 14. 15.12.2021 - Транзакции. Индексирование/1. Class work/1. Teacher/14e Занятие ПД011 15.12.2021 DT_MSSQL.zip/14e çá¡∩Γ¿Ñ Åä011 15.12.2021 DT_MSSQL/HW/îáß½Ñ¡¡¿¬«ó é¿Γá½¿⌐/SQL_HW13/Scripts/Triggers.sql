﻿drop trigger if exists onUpdateAllocations;
drop trigger if exists onInsertAllocations;
drop trigger if exists onDeleteAllocations;
drop trigger if exists onInsertUnits;
drop trigger if exists onUpdateUnits;
go

-- Создание триггеров для таблиц


--- триггер на изменение записей в таблице StaffAllocations 
create trigger onUpdateAllocations on dbo.StaffAllocations 
    for update 
	as
	begin
	    raiserror('Триггер onUpdateAllocations: В таблице StaffAllocations изменено записей: %d', 0, 1, @@rowcount);
	end;	
go

-- проверка триггера
exec dbo.ProcShowAllocations;
go

update
	StaffAllocations
set 
	IdPerson = 30
where 
	IdPerson = 1
go

exec dbo.ProcShowAllocations;
go

---
--- триггер на добавление записей в таблицу StaffAllocations
---

create trigger onInsertAllocations on dbo.StaffAllocations 
    for insert 
	as
	begin
	    raiserror('Триггер onInsertAllocations: В таблице StaffAllocations добавлено записей: %d', 0, 1, @@rowcount);
	end;	
go

-- проверка триггера
exec dbo.ProcShowAllocations;
go

insert dbo.StaffAllocations
	(IdDivision, IdUnit, IdPerson)
values
	(5,  23,   28),
	(5,  23,   29);
go

exec dbo.ProcShowAllocations;
go


---
--- триггер на удаление записей в таблице StaffAllocations 
---

create trigger onDeleteAllocations on dbo.StaffAllocations 
    for delete 
	as
	begin
	    raiserror('Триггер onDeleteAllocations: В таблице StaffAllocations удалено записей: %d', 0, 1, @@rowcount);
	end;	
go

-- проверка триггера
exec dbo.ProcShowAllocations;
go

delete from StaffAllocations
where Id between 1 and 10;
go

exec dbo.ProcShowAllocations;
go


---
--- триггер на изменение записей в таблице Units
---
drop trigger if exists onUpdateUnits;
go
create trigger onUpdateUnits on dbo.Units
    for update 
	as
	begin
		if (select count(*) from inserted join Positions on IdType = Positions.Id where Position = N'Инженер') > 0 begin
			print N'Запрет на изменение инженера!';
		    rollback tran;
		end else begin
		    raiserror(N'Триггер onUpdateUnits: В таблице Units изменено записей: %d', 0, 1, @counter);
		end;
	
	end;	
go

-- проверка триггера
select 
		Units.Id
		,Position
		, Salary
		, SalaryPerks
		, VacationDays
	from 
		Units join Positions on Units.IdType = Positions.Id;
go

update Units
set SalaryPerks += 10
where IdType = (select Id from Positions where Position = N'Инженер');
go

select 
		Units.Id
		,Position
		, Salary
		, SalaryPerks
		, VacationDays
	from 
		Units join Positions on Units.IdType = Positions.Id;
go


---
--- триггер на добавление записей в таблицу Units
---

create trigger onInsertUnits on dbo.Units
    for insert 
	as
	begin
	    raiserror('Триггер onInsertUnits: В таблице Units добавлено записей: %d', 0, 1, @@rowcount);
	end;	
go

-- проверка триггера
select 
		Units.Id
		,Position
		, Rank
		, Salary
		, SalaryPerks
		, VacationDays
	from 
		Units join Positions on Units.IdType = Positions.Id;
go

insert dbo.Units
	(IdType, Salary, Rank, SalaryPerks, VacationDays)
values
	( 3, 70000, N'Шестой',	10, 25),	
  	( 4, 80000, N'Шестой',	10, 26);	
go

select 
		Units.Id
		,Position
		, Rank
		, Salary
		, SalaryPerks
		, VacationDays
	from 
		Units join Positions on Units.IdType = Positions.Id;
go
